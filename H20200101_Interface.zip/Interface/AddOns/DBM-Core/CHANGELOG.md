# Deadly Boss Mods Core

## [8.2.31](https://github.com/DeadlyBossMods/DeadlyBossMods/tree/8.2.31) (2019-12-19)
[Full Changelog](https://github.com/DeadlyBossMods/DeadlyBossMods/compare/8.2.30...8.2.31)

- Prep tag  
- restore syncing of PVP mod timers  
- Push the updated debug code for count and event sound packs  
- Added additional trash warnings for boss 3 and boss 4 in mechagon dungeon  
- No actual code changes, just added remaining WCL expressions for rest of bosses in Nyalotha for quick fight parsing later on.  
- Quick fix to last  
- Update battleground timer to use faction icon and more accurate timer when available from API  
- Also enable the add switch waring while at it, on mythic.  
- Timer updates from Mythic Skitra testing today.  
- Forgot to register event  
- Updated Ra-den and Xanesh from mythic testing  
- Deleted nameplate interrupt helper from Restless Cabal, Uunat, Xanesh, Ilgynoth, Jaina, and Grong. It has never worked right despite all attempts to diagnose and fix problem. I've decided it's just unfixable so this broken feature will no longer appear in any mods.  
