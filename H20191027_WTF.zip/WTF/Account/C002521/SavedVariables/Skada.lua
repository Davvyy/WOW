
SkadaDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["잘생겨따 - 굴단"] = "Default",
		["무시중한디 - 굴단"] = "Wide",
		["뉘시빨라마 - 굴단"] = "Default",
		["국제금융로 - 굴단"] = "Default",
	},
	["profiles"] = {
		["굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["point"] = "TOPRIGHT",
					["spark"] = false,
				}, -- [1]
			},
		},
		["WARRIOR"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["point"] = "TOPRIGHT",
					["spark"] = false,
				}, -- [1]
			},
		},
		["Default"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 2,
				["적이 받은 치유"] = 1,
				["약화 효과"] = 1,
				["DPS"] = 2,
			},
			["windows"] = {
				{
					["y"] = 6.09520959854126,
					["name"] = "S",
					["point"] = "BOTTOMLEFT",
					["mode"] = "DPS",
					["spark"] = false,
					["barwidth"] = 256.9525146484375,
					["background"] = {
						["strata"] = "LOW",
						["height"] = 266.0478210449219,
						["bordertexture"] = "None",
					},
					["x"] = 455.4290161132813,
				}, -- [1]
			},
			["icon"] = {
				["minimapPos"] = 206.6650563676227,
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
			["reset"] = {
				["leave"] = 2,
				["instance"] = 2,
				["join"] = 2,
			},
		},
		["Wide"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 1,
				["치유"] = 1,
				["DPS"] = 4,
			},
			["windows"] = {
				{
					["y"] = 6.104797840118408,
					["x"] = 458.64990234375,
					["point"] = "BOTTOMLEFT",
					["barwidth"] = 287.238525390625,
					["mode"] = "DPS",
					["background"] = {
						["height"] = 346.28564453125,
					},
				}, -- [1]
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
			["icon"] = {
				["minimapPos"] = 213.6161596799995,
			},
			["report"] = {
				["set"] = "total",
				["chantype"] = "channel",
				["mode"] = "DPS",
				["channel"] = "ok",
			},
		},
		["국제금융로 - 굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["point"] = "TOPRIGHT",
					["spark"] = false,
				}, -- [1]
			},
		},
	},
}
