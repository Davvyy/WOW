
GTFOData = {
	["Active"] = true,
	["TrivialDamagePercent"] = 2,
	["Sounds"] = {
		true, -- [1]
		true, -- [2]
		true, -- [3]
		true, -- [4]
	},
	["TestMode"] = false,
	["DataCode"] = "4",
	["UnmuteMode"] = false,
	["Volume"] = 3,
	["IgnoreOptions"] = {
	},
	["SoundOverrides"] = {
	},
	["SoundChannel"] = "Master",
	["TrivialMode"] = false,
}
