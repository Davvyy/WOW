
MasqueDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["이스레인 - 아즈샤라"] = "Wide",
		["아테리에 - 아즈샤라"] = "Wide",
		["아라스틴 - 아즈샤라"] = "Wide",
		["에레로엘 - 아즈샤라"] = "Wide",
		["잘생겨따 - 굴단"] = "Default",
		["Isolesty - 아즈샤라"] = "Wide",
		["데빌테스트용임 - 아즈샤라"] = "Wide",
		["무시중한디 - 굴단"] = "Wide",
		["레이스가드 - 아즈샤라"] = "Wide",
		["아테르나 - 하이잘"] = "Default",
		["아이루릴 - 아즈샤라"] = "Wide",
		["테스트용임다 - 아즈샤라"] = "Wide",
		["Arastin - 아즈샤라"] = "Wide",
		["시에이레 - 듀로탄"] = "Wide",
		["데빌테스트용 - 아즈샤라"] = "Wide",
		["내꿈은샤먼킹 - 데스윙"] = "Wide",
		["폭까말랑카우 - 아즈샤라"] = "Default",
		["Eldersign - 아즈샤라"] = "Wide",
		["아테르나 - 아즈샤라"] = "Wide",
		["에레로엘 - 데스윙"] = "Wide",
		["이솔레스테 - 아즈샤라"] = "Wide",
		["실베르투스 - 아즈샤라"] = "Wide",
		["아테르나 - 듀로탄"] = "Default",
		["Wraithguard - 아즈샤라"] = "Wide",
		["Vindictus - 아즈샤라"] = "Wide",
		["아테리에 - 데스윙"] = "Wide",
	},
	["profiles"] = {
		["Normal"] = {
			["Groups"] = {
				["Dominos_Bag Bar"] = {
					["Gloss"] = 1,
					["Inherit"] = false,
					["SkinID"] = "Onyx",
				},
				["Dominos_Action Bar"] = {
					["Gloss"] = 1,
					["Inherit"] = false,
					["SkinID"] = "Onyx",
				},
				["Dominos_Pet Bar"] = {
					["Gloss"] = 1,
					["Inherit"] = false,
					["SkinID"] = "Onyx",
				},
				["Dominos"] = {
					["Gloss"] = 1,
					["Inherit"] = false,
					["SkinID"] = "Onyx",
				},
				["Dominos_Class Bar"] = {
					["Gloss"] = 1,
					["Inherit"] = false,
					["SkinID"] = "Onyx",
				},
			},
		},
		["Wide"] = {
			["Groups"] = {
				["Dominos_Action Bar"] = {
					["Inherit"] = false,
					["Gloss"] = 1,
					["SkinID"] = "Onyx",
				},
				["Dominos_Bag Bar"] = {
					["Inherit"] = false,
					["Gloss"] = 1,
					["SkinID"] = "Onyx",
				},
				["Dominos"] = {
					["Inherit"] = false,
					["Gloss"] = 1,
					["SkinID"] = "Onyx",
				},
				["Dominos_Extra Bar"] = {
					["Inherit"] = false,
					["Gloss"] = 1,
					["SkinID"] = "Onyx",
				},
				["Dominos_Class Bar"] = {
					["Inherit"] = false,
					["Gloss"] = 1,
					["SkinID"] = "Onyx",
				},
				["Dominos_Pet Bar"] = {
					["Inherit"] = false,
					["Gloss"] = 1,
					["SkinID"] = "Onyx",
				},
			},
		},
		["Default"] = {
		},
	},
}
