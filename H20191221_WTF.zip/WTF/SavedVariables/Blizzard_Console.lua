
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Level: 12d 14h 43m 55s", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"Time set to 12/6/2019 (Fri) 5:37", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"Total: 37d 1h 11m 46s", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Level: 26d 20h 8m 6s", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [107]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [108]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Time set to 12/7/2019 (Sat) 20:48", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Total: 37d 1h 13m 30s", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Level: 26d 20h 9m 50s", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Weather changed to 2, intensity 0.124130\n", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Weather changed to 2, intensity 0.124130\n", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"Time set to 12/7/2019 (Sat) 21:10", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"Total: 29d 22h 29m 5s", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Level: 4d 20h 19m 46s", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Weather changed to 2, intensity 0.115449\n", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Weather changed to 2, intensity 0.115449\n", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Weather changed to 3, intensity 0.361736\n", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Weather changed to 2, intensity 0.115449\n", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Weather changed to 3, intensity 0.361736\n", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Weather changed to 2, intensity 0.115449\n", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Completed challenge mode mapID 1754, level 11, time 2509378", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Time set to 12/7/2019 (Sat) 22:20", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Total: 37d 1h 35m 4s", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Level: 26d 20h 31m 24s", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Completed challenge mode mapID 1594, level 13, time 2113364", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [332]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [333]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"Time set to 12/9/2019 (Mon) 21:33", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"Total: 18d 18h 39m 14s", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"Level: 12d 14h 45m 7s", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"Time set to 12/9/2019 (Mon) 21:38", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Total: 37d 3h 5m 23s", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Level: 26d 22h 1m 43s", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"Time set to 12/9/2019 (Mon) 21:39", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Total: 29d 23h 38m 46s", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Level: 4d 21h 29m 27s", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"Time set to 12/9/2019 (Mon) 21:41", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Total: 18d 18h 43m 49s", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Level: 12d 14h 49m 42s", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"Weather changed to 2, intensity 0.161923\n", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [455]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [456]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [457]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [458]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [459]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [460]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [463]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [464]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"Completed challenge mode mapID 1594, level 13, time 2351324", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [558]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [559]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"Time set to 12/13/2019 (Fri) 4:55", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"Total: 29d 23h 40m 26s", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Level: 4d 21h 31m 7s", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Time set to 12/13/2019 (Fri) 4:57", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Total: 18d 19h 56m 17s", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Level: 12d 16h 2m 10s", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Time set to 12/13/2019 (Fri) 5:00", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Total: 37d 3h 6m 51s", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Level: 26d 22h 3m 11s", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Time set to 12/13/2019 (Fri) 5:00", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Total: 18d 19h 59m 17s", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Level: 12d 16h 5m 10s", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"Time set to 12/13/2019 (Fri) 5:02", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"Total: 29d 23h 42m 17s", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"Level: 4d 21h 32m 58s", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Time set to 12/13/2019 (Fri) 5:03", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"Total: 37d 3h 7m 19s", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Level: 26d 22h 3m 39s", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"5\"", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [807]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [808]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Time set to 12/21/2019 (Sat) 1:29", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Total: 37d 6h 52m 43s", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Level: 27d 1h 49m 3s", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Weather changed to 2, intensity 0.116611\n", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Weather changed to 2, intensity 0.116611\n", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Time set to 12/21/2019 (Sat) 1:34", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Total: 30d 0h 46m 40s", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Level: 4d 22h 37m 21s", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Weather changed to 2, intensity 0.116611\n", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Weather changed to 2, intensity 0.116611\n", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Weather changed to 2, intensity 0.116611\n", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"Weather changed to 3, intensity 0.376166\n", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"Weather changed to 3, intensity 0.376166\n", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"Weather changed to 3, intensity 0.376166\n", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"Weather changed to 3, intensity 0.376166\n", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"Weather changed to 3, intensity 0.376166\n", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"Weather changed to 3, intensity 0.376166\n", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Weather changed to 3, intensity 0.376166\n", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"5\"", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [973]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [974]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Time set to 12/21/2019 (Sat) 1:57", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Total: 18d 22h 50m 27s", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Level: 12d 18h 56m 20s", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 300.0002136230469,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
