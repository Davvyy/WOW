
ElvCharacterDB = {
	["ChatEditHistory"] = {
	},
	["ChatHistoryLog"] = {
		{
			"\"Lord of The Clan\" 길드에서 |cffffff00|Hachievement:5362:0000000000000000:1:6:7:19:4294967295:4294967295:4294967295:4294967295|h[누구나 휘장 하나쯤은 있잖아요]|h|r 업적을 이루었습니다!", -- [1]
			"Lord of The Clan", -- [2]
			"", -- [3]
			"", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			125, -- [11]
			false, -- [12]
			0, -- [13]
			false, -- [14]
			false, -- [15]
			false, -- [16]
			false, -- [17]
			[52] = "Lord of The Clan",
			[51] = 1559916402,
			[50] = "CHAT_MSG_GUILD_ACHIEVEMENT",
		}, -- [1]
	},
}
