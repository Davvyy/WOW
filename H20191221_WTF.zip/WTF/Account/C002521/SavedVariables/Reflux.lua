
RefluxDB = {
	["emulated"] = {
	},
	["activeProfile"] = "Wide",
	["addons"] = {
	},
	["ignored"] = {
	},
	["profiles"] = {
	},
}
