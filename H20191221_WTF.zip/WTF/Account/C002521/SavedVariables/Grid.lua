
GridDB = {
	["namespaces"] = {
		["GridStatusStagger"] = {
		},
		["GridFrame"] = {
			["profiles"] = {
				["Default"] = {
					["fontSize"] = 10,
					["cornerSize"] = 9,
					["rightClickMenu"] = true,
					["enableText2"] = true,
					["font"] = "기본 글꼴",
					["healingBar_useStatusColor"] = true,
					["orientation"] = "HORIZONTAL",
					["statusmap"] = {
						["corner2"] = {
							["dispel_magic"] = false,
							["dispel_poison"] = false,
							["dispel_disease"] = false,
							["buff_PowerWord:Shield"] = true,
							["dispel_curse"] = false,
						},
						["text2"] = {
							["buff_Atonement"] = false,
							["buff_LifeCocoon"] = false,
							["buff_고통억제"] = true,
						},
						["text"] = {
							["alert_offline"] = false,
							["unit_healthDeficit"] = false,
							["alert_heals"] = false,
						},
						["border"] = {
							["dispel_magic"] = true,
							["mouseover"] = true,
							["dispel_curse"] = true,
							["dispel_poison"] = true,
							["dispel_disease"] = true,
							["alert_lowHealth"] = false,
							["alert_aggro"] = false,
						},
						["corner4"] = {
							["leader"] = false,
							["master_looter"] = false,
							["raid_icon"] = true,
							["assistant"] = false,
						},
						["healingBar"] = {
							["alert_absorbs"] = false,
						},
						["corner1"] = {
							["buff_Atonement"] = true,
							["buff_Renew"] = true,
							["alert_aggro"] = false,
						},
						["frameAlpha"] = {
							["mouseover"] = true,
						},
						["icon"] = {
							["raid_icon"] = false,
						},
					},
					["frameWidth"] = 68,
					["invertBarColor"] = true,
				},
			},
		},
		["GridStatusVehicle"] = {
		},
		["LibDualSpec-1.0"] = {
		},
		["GridStatusAuras"] = {
			["profiles"] = {
				["Default"] = {
					["buff_Atonement"] = {
						["icon"] = "INTERFACE\\ICONS\\ability_priest_atonement",
					},
					["buff_LifeCocoon"] = {
						["text"] = "고치",
						["color"] = {
							["b"] = 1,
							["g"] = 1,
							["r"] = 0.988235294117647,
						},
					},
					["buff_고통억제"] = {
						["icon"] = "Interface\\Icons\\Spell_Holy_PainSupression",
						["text"] = "고억",
						["desc"] = "강화 효과: 고통 억제",
						["buff"] = "고통 억제",
						["color"] = {
							["r"] = 0.968627450980392,
							["g"] = 1,
							["b"] = 0.984313725490196,
						},
					},
					["buff_PowerWord:Shield"] = {
						["icon"] = "Interface\\Icons\\Spell_Holy_PowerWordShield",
					},
				},
			},
		},
		["GridStatusAbsorbs"] = {
		},
		["GridStatusTarget"] = {
		},
		["GridStatusMouseover"] = {
		},
		["GridRoster"] = {
		},
		["GridStatusRole"] = {
		},
		["GridLayout"] = {
			["profiles"] = {
				["Default"] = {
					["anchorRel"] = "TOPLEFT",
					["layouts"] = {
						["raid"] = "ByGroup",
					},
					["borderSize"] = 1,
					["PosX"] = 1047,
					["PosY"] = -457,
					["layout"] = "ByGroup",
					["lock"] = true,
					["borderInset"] = 1,
					["showOffline"] = true,
					["backgroundTexture"] = "None",
					["clickThrough"] = false,
					["borderTexture"] = "None",
				},
			},
		},
		["GridStatusResurrect"] = {
		},
		["GridStatusRange"] = {
		},
		["GridStatusVoiceComm"] = {
		},
		["GridLayoutManager"] = {
		},
		["GridStatusAggro"] = {
		},
		["GridStatusHeals"] = {
			["profiles"] = {
				["Default"] = {
					["alert_heals"] = {
						["minimumValue"] = 0.05,
					},
				},
			},
		},
		["GridStatusReadyCheck"] = {
		},
		["GridStatus"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["PALADIN"] = {
							["r"] = 0.96,
							["g"] = 0.55,
							["b"] = 0.73,
						},
						["MAGE"] = {
							["r"] = 0.25,
							["g"] = 0.78,
							["b"] = 0.92,
						},
						["DRUID"] = {
							["r"] = 1,
							["g"] = 0.49,
							["b"] = 0.04,
						},
						["MONK"] = {
							["r"] = 0,
							["g"] = 1,
							["b"] = 0.59,
						},
						["DEATHKNIGHT"] = {
							["r"] = 0.77,
							["g"] = 0.12,
							["b"] = 0.23,
						},
						["SHAMAN"] = {
							["r"] = 0,
							["g"] = 0.44,
							["b"] = 0.87,
						},
						["HUNTER"] = {
							["r"] = 0.67,
							["g"] = 0.83,
							["b"] = 0.45,
						},
						["PRIEST"] = {
							["r"] = 1,
							["g"] = 1,
							["b"] = 1,
						},
						["WARLOCK"] = {
							["r"] = 0.53,
							["g"] = 0.53,
							["b"] = 0.93,
						},
						["DEMONHUNTER"] = {
							["r"] = 0.64,
							["g"] = 0.19,
							["b"] = 0.79,
						},
						["WARRIOR"] = {
							["r"] = 0.78,
							["g"] = 0.61,
							["b"] = 0.43,
						},
						["ROGUE"] = {
							["r"] = 1,
							["g"] = 0.96,
							["b"] = 0.41,
						},
					},
				},
			},
		},
		["GridStatusGroup"] = {
		},
		["GridStatusHealth"] = {
			["profiles"] = {
				["Default"] = {
					["alert_offline"] = {
						["color"] = {
							["a"] = 1,
							["r"] = 0.356862745098039,
							["b"] = 0.356862745098039,
							["g"] = 0.356862745098039,
						},
					},
				},
			},
		},
		["GridStatusRaidIcon"] = {
		},
		["GridStatusName"] = {
		},
		["GridStatusMana"] = {
		},
	},
	["profileKeys"] = {
		["아라스틴 - 아즈샤라"] = "Default",
		["Arastin - 아즈샤라"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["minimap"] = {
				["hide"] = true,
			},
		},
	},
}
