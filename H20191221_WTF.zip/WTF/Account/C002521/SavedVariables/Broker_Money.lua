
Broker_MoneyDB = {
	["realm"] = {
		["굴단"] = {
			["Horde"] = {
			},
			["Alliance"] = {
				["무시중한디"] = 245365016,
			},
		},
	},
}
