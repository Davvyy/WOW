
MasterPlanAG = {
	["굴단"] = {
		["무시중한디"] = {
			["class"] = "DEMONHUNTER",
			["faction"] = "Alliance",
		},
		["잘생겨따"] = {
			["faction"] = "Alliance",
			["class"] = "SHAMAN",
		},
	},
}
