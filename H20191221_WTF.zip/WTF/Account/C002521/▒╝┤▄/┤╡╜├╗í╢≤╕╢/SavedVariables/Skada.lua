
SkadaPerCharDB = {
	["sets"] = {
	},
	["total"] = {
		["healingabsorbed"] = 0,
		["alertDamage"] = 0,
		["ccbreaks"] = 0,
		["overhealing"] = 0,
		["interrupts"] = 0,
		["ffdamagedone"] = 0,
		["auras"] = {
		},
		["damage"] = 0,
		["players"] = {
		},
		["deaths"] = 0,
		["damagetaken"] = 0,
		["shielding"] = 0,
		["mobtaken"] = 0,
		["healing"] = 0,
		["dispells"] = 0,
		["mobs"] = {
		},
		["power"] = {
		},
		["starttime"] = 1575899559,
		["name"] = "전체",
		["alertCount"] = 0,
		["time"] = 0,
		["mobhdone"] = 0,
		["last_action"] = 1575899559,
		["mobdone"] = 0,
	},
}
