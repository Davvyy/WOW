
InvenRaidFrames3CharDB = {
	["clickCasting"] = {
		{
		}, -- [1]
		{
		}, -- [2]
		{
		}, -- [3]
		{
		}, -- [4]
	},
	["classBuff2"] = {
		[21562] = 1,
	},
	["class"] = "PRIEST",
	["spellTimer"] = {
		{
			["name"] = "소생",
			["scale"] = 1,
			["pos"] = "BOTTOMLEFT",
			["display"] = 1,
			["use"] = 1,
		}, -- [1]
		{
			["name"] = "회복의 기원",
			["scale"] = 1,
			["pos"] = "BOTTOM",
			["display"] = 1,
			["use"] = 1,
		}, -- [2]
		{
			["name"] = "의지의 명료함",
			["scale"] = 1,
			["pos"] = "BOTTOMRIGHT",
			["display"] = 1,
			["use"] = 4,
		}, -- [3]
		{
			["name"] = "신의 권능: 보호막",
			["scale"] = 1,
			["pos"] = "BOTTOM",
			["display"] = 1,
			["use"] = 3,
		}, -- [4]
		{
			["name"] = "의지의 명료함",
			["scale"] = 1,
			["pos"] = "BOTTOMLEFT",
			["display"] = 1,
			["use"] = 1,
		}, -- [5]
		{
			["name"] = "속죄",
			["scale"] = 1,
			["pos"] = "BOTTOMLEFT",
			["display"] = 1,
			["use"] = 1,
		}, -- [6]
		{
			["display"] = 1,
			["pos"] = "TOP",
			["scale"] = 1,
			["use"] = 0,
		}, -- [7]
		{
			["display"] = 1,
			["pos"] = "TOPRIGHT",
			["scale"] = 1,
			["use"] = 0,
		}, -- [8]
	},
}
