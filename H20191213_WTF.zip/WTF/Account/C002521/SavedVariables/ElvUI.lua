
ElvDB = {
	["gold"] = {
		["렉사르"] = {
			["쌩뚱마삼"] = 9280735,
			["쌩뚱마꾼"] = 1123,
			["오지져스"] = 3323,
			["쌩뚱마적"] = 563,
			["닌자창고"] = 65181,
			["쌩뚱마장"] = 15998,
			["아놀드클래식"] = 0,
			["쌩뚱마죠"] = 71493,
			["쌩뚱악사"] = 0,
			["오우지져스"] = 692,
		},
		["굴단"] = {
			["Udiess"] = 6497538,
			["공허엘프닷"] = 81650,
			["Odfefe"] = 5916180,
			["뉘시빨라마"] = 2355653357,
			["무시중한디"] = 1491918901,
			["국제금융로"] = 231935488,
			["완소야드"] = 12786440,
		},
		["아즈샤라"] = {
			["받아줘요악사"] = 3567073,
			["악사다구"] = 31190489,
			["아호와의증인"] = 4510,
		},
	},
	["profileKeys"] = {
		["쌩뚱마삼 - 렉사르"] = "쌩뚱마삼 - 렉사르",
		["쌩뚱악사 - 렉사르"] = "ldw",
		["쌩뚱마꾼 - 렉사르"] = "쌩뚱마꾼 - 렉사르",
		["쌩뚱마죠 - 렉사르"] = "쌩뚱마죠 - 렉사르",
		["오지져스 - 렉사르"] = "오지져스 - 렉사르",
		["뉘시빨라마 - 굴단"] = "2dw",
		["아놀드클래식 - 렉사르"] = "아놀드클래식 - 렉사르",
		["닌자창고 - 렉사르"] = "닌자창고 - 렉사르",
		["Udiess - 굴단"] = "Udiess - 굴단",
		["오우지져스 - 렉사르"] = "오우지져스 - 렉사르",
		["악사다구 - 아즈샤라"] = "ldw",
		["국제금융로 - 굴단"] = "2dw",
		["Odfefe - 굴단"] = "Odfefe - 굴단",
		["쌩뚱마장 - 렉사르"] = "쌩뚱마장 - 렉사르",
		["쌩뚱마적 - 렉사르"] = "쌩뚱마적 - 렉사르",
		["받아줘요악사 - 아즈샤라"] = "ldw",
		["완소야드 - 굴단"] = "Skullflower",
		["아호와의증인 - 아즈샤라"] = "ldw",
		["무시중한디 - 굴단"] = "2dw",
		["공허엘프닷 - 굴단"] = "공허엘프닷 - 굴단",
	},
	["SLE_DB_Ver"] = "3.59",
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["class"] = {
		["렉사르"] = {
			["쌩뚱마삼"] = "PRIEST",
			["쌩뚱마꾼"] = "HUNTER",
			["오지져스"] = "DRUID",
			["쌩뚱마적"] = "ROGUE",
			["닌자창고"] = "MAGE",
			["쌩뚱마장"] = "WARLOCK",
			["아놀드클래식"] = "SHAMAN",
			["쌩뚱마죠"] = "WARRIOR",
			["쌩뚱악사"] = "DEMONHUNTER",
			["오우지져스"] = "WARRIOR",
		},
		["굴단"] = {
			["국제금융로"] = "WARRIOR",
			["뉘시빨라마"] = "SHAMAN",
			["무시중한디"] = "DEMONHUNTER",
			["공허엘프닷"] = "MONK",
			["완소야드"] = "DRUID",
		},
		["아즈샤라"] = {
			["받아줘요악사"] = "DEMONHUNTER",
			["악사다구"] = "DEMONHUNTER",
			["아호와의증인"] = "MONK",
		},
	},
	["global"] = {
		["nameplate"] = {
			["filters"] = {
				["ElvUI_Explosives"] = {
				},
				["Explosives"] = {
				},
				["ElvUI_Boss"] = {
				},
				["ElvUI_NonTarget"] = {
				},
				["ElvUI_Target"] = {
				},
				["Boss"] = {
				},
			},
		},
		["general"] = {
			["AceGUI"] = {
				["top"] = 908.57,
				["height"] = 600,
				["left"] = 810.48,
				["width"] = 800,
			},
			["commandBarSetting"] = "DISABLED",
			["smallerWorldMapScale"] = 0.8,
			["UIScale"] = 0.7,
		},
		["uiScale"] = "0.64",
		["aprilFoolsSLE"] = true,
		["unitframe"] = {
			["ChannelTicks"] = {
				[47540] = 3,
			},
		},
	},
	["profiles"] = {
		["쌩뚱마삼 - 렉사르"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0.99,
					["g"] = 0.99,
					["b"] = 0.99,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,305",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "TOP,ElvUIParent,TOP,300,-508",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,256",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,434",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,270",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-598,20",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["v11NamePlateReset"] = true,
			["hideTutorial"] = true,
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["timeStampFormat"] = "%H:%M",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeight"] = 500,
				["emotionIcons"] = false,
				["tabFont"] = "기본 글꼴",
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
					},
				},
				["fontOutline"] = "OUTLINE",
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["width"] = 100,
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["enable"] = true,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["height"] = 16,
						["width"] = 120,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["width"] = 100,
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
						["width"] = 180,
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["power"] = {
							["text_format"] = "",
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["xOffset"] = 0,
							["damager"] = false,
							["enable"] = true,
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 20,
							["enable"] = false,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 16,
							["sizeOverride"] = 0,
							["numrows"] = 3,
							["attachTo"] = "BUFFS",
							["yOffset"] = -1,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["detachedWidth"] = 92,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["pvpIcon"] = {
							["enable"] = true,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["width"] = 200,
						["stagger"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["powerPrediction"] = true,
							["xOffset"] = 0,
							["text_format"] = "[power:current]",
							["strataAndLevel"] = {
								["frameLevel"] = 2,
								["useCustomStrata"] = true,
							},
							["height"] = 15,
							["druidMana"] = false,
							["detachFromFrame"] = true,
							["detachedWidth"] = 92,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "FRAME",
							["numrows"] = 3,
							["yOffset"] = -1,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["position"] = "TOPLEFT",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["width"] = 50,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["verticalSpacing"] = 1,
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["barPet"] = {
					["backdrop"] = false,
					["backdropSpacing"] = 0,
					["style"] = "darkenInactive",
					["buttonspacing"] = 1,
					["showGrid"] = true,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
					["point"] = "BOTTOMLEFT",
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["backdropSpacing"] = 0,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdrop"] = false,
					["buttonsize"] = 30,
				},
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["fontSize"] = 13,
				["smallTextFontSize"] = 13,
			},
			["bags"] = {
				["countFontSize"] = 13,
				["itemLevelFont"] = "기본 글꼴",
				["split"] = {
					["bagSpacing"] = 0,
				},
				["bagSize"] = 28,
				["itemLevelFontSize"] = 13,
				["alignToChat"] = false,
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["clearSearchOnClose"] = true,
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagWidth"] = 400,
				["countFont"] = "기본 글꼴",
				["vendorGrays"] = {
					["enable"] = true,
				},
				["bagBar"] = {
					["enable"] = false,
				},
			},
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["enable"] = true,
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
		},
		["쌩뚱악사 - 렉사르"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["height"] = 32,
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0.639214277267456,
					["g"] = 0.188234880566597,
					["b"] = 0.788233578205109,
				},
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,305",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "TOP,ElvUIParent,TOP,300,-508",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,256",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,270",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-598,20",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,434",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["bags"] = {
				["countFontSize"] = 13,
				["itemLevelFont"] = "기본 글꼴",
				["split"] = {
					["bagSpacing"] = 0,
				},
				["bagSize"] = 28,
				["itemLevelFontSize"] = 13,
				["alignToChat"] = false,
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagWidth"] = 400,
				["countFont"] = "기본 글꼴",
				["bagBar"] = {
					["enable"] = false,
				},
				["clearSearchOnClose"] = true,
			},
			["hideTutorial"] = true,
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "기본 글꼴",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["keywords"] = "%MYNAME%, ElvUI",
				["timeStampFormat"] = "%H:%M",
				["emotionIcons"] = false,
				["panelHeight"] = 500,
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["classResources"] = {
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
					},
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "OUTLINE",
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 100,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
					},
					["focustarget"] = {
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 180,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["threatStyle"] = "NONE",
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 16,
							["sizeOverride"] = 0,
							["numrows"] = 3,
							["attachTo"] = "BUFFS",
							["yOffset"] = -1,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 92,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["height"] = 15,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["pvpIcon"] = {
							["enable"] = true,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["width"] = 200,
						["stagger"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["power"] = {
							["detachFromFrame"] = true,
							["powerPrediction"] = true,
							["xOffset"] = 0,
							["text_format"] = "[power:current]",
							["strataAndLevel"] = {
								["frameLevel"] = 2,
								["useCustomStrata"] = true,
							},
							["detachedWidth"] = 92,
							["druidMana"] = false,
							["attachTextTo"] = "Power",
							["height"] = 15,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "FRAME",
							["numrows"] = 3,
							["yOffset"] = -1,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["enable"] = true,
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["enable"] = false,
							["yOffset"] = 20,
							["xOffset"] = 30,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["damager"] = false,
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
						["width"] = 50,
						["height"] = 25,
						["verticalSpacing"] = 1,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["barPet"] = {
					["style"] = "darkenInactive",
					["backdropSpacing"] = 0,
					["point"] = "BOTTOMLEFT",
					["showGrid"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
					["backdrop"] = false,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["showGrid"] = true,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonsize"] = 30,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["tooltip"] = {
				["fontSize"] = 13,
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["itemCount"] = "NONE",
				["smallTextFontSize"] = 13,
			},
			["v11NamePlateReset"] = true,
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["enable"] = true,
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
		},
		["쌩뚱마꾼 - 렉사르"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["height"] = 32,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0.7764688730239868,
					["g"] = 0.6078417897224426,
					["b"] = 0.427450031042099,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,305",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "TOP,ElvUIParent,TOP,300,-508",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,256",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,270",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-598,20",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,434",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["bags"] = {
				["countFontSize"] = 13,
				["itemLevelFont"] = "기본 글꼴",
				["split"] = {
					["bagSpacing"] = 0,
				},
				["bagSize"] = 28,
				["itemLevelFontSize"] = 13,
				["alignToChat"] = false,
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagWidth"] = 400,
				["countFont"] = "기본 글꼴",
				["clearSearchOnClose"] = true,
				["bagBar"] = {
					["enable"] = false,
				},
			},
			["hideTutorial"] = true,
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["timeStampFormat"] = "%H:%M",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeight"] = 500,
				["emotionIcons"] = false,
				["tabFont"] = "기본 글꼴",
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
					},
				},
				["fontOutline"] = "OUTLINE",
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["width"] = 100,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["insideInfoPanel"] = false,
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["focustarget"] = {
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["enable"] = true,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
						["width"] = 180,
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["power"] = {
							["text_format"] = "",
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 16,
							["sizeOverride"] = 0,
							["numrows"] = 3,
							["attachTo"] = "BUFFS",
							["yOffset"] = -1,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["detachedWidth"] = 92,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["pvpIcon"] = {
							["enable"] = true,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["width"] = 200,
						["stagger"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["powerPrediction"] = true,
							["xOffset"] = 0,
							["text_format"] = "[power:current]",
							["strataAndLevel"] = {
								["frameLevel"] = 2,
								["useCustomStrata"] = true,
							},
							["height"] = 15,
							["druidMana"] = false,
							["detachFromFrame"] = true,
							["detachedWidth"] = 92,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "FRAME",
							["numrows"] = 3,
							["yOffset"] = -1,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["xOffset"] = 0,
							["damager"] = false,
							["enable"] = true,
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 20,
							["enable"] = false,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["position"] = "TOPLEFT",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["width"] = 50,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["verticalSpacing"] = 1,
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["barPet"] = {
					["backdrop"] = false,
					["backdropSpacing"] = 0,
					["style"] = "darkenInactive",
					["buttonspacing"] = 1,
					["showGrid"] = true,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
					["point"] = "BOTTOMLEFT",
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["backdrop"] = false,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
					["backdropSpacing"] = 0,
				},
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["fontSize"] = 13,
				["smallTextFontSize"] = 13,
			},
			["v11NamePlateReset"] = true,
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["enable"] = true,
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
		},
		["오우지져스 - 렉사르"] = {
			["currentTutorial"] = 1,
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["쌩뚱마죠 - 렉사르"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
						["enable"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,359",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,760,500",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,311",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,434",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,325",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-598,20",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "기본 글꼴",
				["vendorGrays"] = {
					["enable"] = true,
				},
				["clearSearchOnClose"] = true,
				["countFont"] = "기본 글꼴",
				["bankSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bagBar"] = {
					["enable"] = false,
				},
				["itemLevelFontSize"] = 13,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagWidth"] = 400,
				["bagSize"] = 28,
				["alignToChat"] = false,
				["countFontSize"] = 13,
			},
			["hideTutorial"] = true,
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["timeStampFormat"] = "%H:%M",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["panelColor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["panelHeight"] = 500,
				["tabFont"] = "기본 글꼴",
				["emotionIcons"] = false,
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["b"] = 0.631372549019608,
							["g"] = 0.450980392156863,
							["r"] = 0.309803921568627,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["ENERGY"] = {
							["b"] = 0.349019607843137,
							["g"] = 0.631372549019608,
							["r"] = 0.650980392156863,
						},
						["FOCUS"] = {
							["b"] = 0.270588235294118,
							["g"] = 0.431372549019608,
							["r"] = 0.709803921568628,
						},
						["RAGE"] = {
							["b"] = 0.250980392156863,
							["g"] = 0.250980392156863,
							["r"] = 0.780392156862745,
						},
					},
					["castColor"] = {
						["b"] = 0.8,
						["g"] = 0.8,
						["r"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["b"] = 0.850980392156863,
						["g"] = 0.792156862745098,
						["r"] = 0.764705882352941,
					},
					["health"] = {
						["b"] = 0.403921568627451,
						["g"] = 1,
						["r"] = 0.419607843137255,
					},
					["reaction"] = {
						["BAD"] = {
							["b"] = 0.195555555555556,
							["g"] = 0.137777777777778,
							["r"] = 1,
						},
						["NEUTRAL"] = {
							["b"] = 0.368627450980392,
							["g"] = 0.976470588235294,
							["r"] = 1,
						},
						["GOOD"] = {
							["b"] = 0.403921568627451,
							["g"] = 1,
							["r"] = 0.419607843137255,
						},
					},
					["health_backdrop"] = {
						["b"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["r"] = 0.0705882352941177,
					},
					["castNoInterrupt"] = {
						["b"] = 0.195555555555556,
						["g"] = 0.137777777777778,
						["r"] = 1,
					},
					["disconnected"] = {
						["b"] = 0.850980392156863,
						["g"] = 0.792156862745098,
						["r"] = 0.764705882352941,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [1]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [2]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [3]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [4]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [5]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [6]
						},
						["bgColor"] = {
							["b"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["r"] = 0.0705882352941177,
						},
					},
				},
				["fontOutline"] = "OUTLINE",
				["smartRaidFilter"] = false,
				["font"] = "기본 글꼴",
				["smoothbars"] = true,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 22,
							["xOffset"] = 1,
							["sizeOverride"] = 35,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["fontSize"] = 22,
							["xOffset"] = -3,
							["enable"] = false,
							["sizeOverride"] = 35,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:percent]",
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["perrow"] = 1,
							["yOffset"] = -20,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["verticalSpacing"] = 1,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["width"] = 50,
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["damager"] = false,
						},
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["height"] = 16,
						["enable"] = true,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 120,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 100,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["perrow"] = 1,
							["attachTo"] = "Frame",
							["yOffset"] = -20,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["size"] = 20,
							["enable"] = false,
							["yOffset"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["yOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["detachedWidth"] = 220,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["text_format"] = "[health:percent]",
							["yOffset"] = -22,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["fontSize"] = 16,
							["enable"] = false,
							["xOffset"] = -1,
							["sizeOverride"] = 46,
							["attachTo"] = "Frame",
							["yOffset"] = -8,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 200,
							["height"] = 15,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["pvpIcon"] = {
							["enable"] = true,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["stagger"] = {
							["enable"] = false,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["text_format"] = "[health:current]",
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
						},
						["power"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["text_format"] = "[power:current]",
							["xOffset"] = 0,
							["attachTextTo"] = "Power",
							["druidMana"] = false,
							["detachedWidth"] = 92,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["castbar"] = {
							["spark"] = false,
							["latency"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["perrow"] = 1,
							["yOffset"] = -20,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["size"] = 20,
							["yOffset"] = 10,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["yOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["xOffset"] = 0,
							["yOffset"] = 0,
							["enable"] = true,
							["damager"] = false,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 180,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:current] | [health:percent]",
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["width"] = 100,
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 260,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["power"] = {
							["enable"] = false,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["showGrid"] = true,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
				},
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonsize"] = 17,
					["style"] = "darkenInactive",
					["showGrid"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 5,
					["backdrop"] = false,
					["backdropSpacing"] = 0,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["backdropSpacing"] = 0,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdrop"] = false,
					["buttonsize"] = 30,
				},
			},
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["size"] = 150,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["yOffset"] = 0,
							["hide"] = false,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["yOffset"] = 4,
							["xOffset"] = 4,
							["position"] = "BOTTOMLEFT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["locationFontSize"] = 14,
				},
				["valuecolor"] = {
					["b"] = 0.43,
					["g"] = 0.61,
					["r"] = 0.78,
				},
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["backdropcolor"] = {
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["objectiveFrameHeight"] = 500,
				["fontSize"] = 15,
			},
			["v11NamePlateReset"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["smallTextFontSize"] = 13,
				["fontSize"] = 13,
				["spellID"] = false,
			},
		},
		["오지져스 - 렉사르"] = {
			["currentTutorial"] = 1,
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["2dw"] = {
			["databars"] = {
				["artifact"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["height"] = 20,
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 220,
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["honor"] = {
					["textFormat"] = "PERCENT",
					["height"] = 32,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["textSize"] = 12,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["textSize"] = 12,
					["height"] = 32,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["spacing"] = 3,
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0.639214277267456,
					["g"] = 0.188234880566597,
					["b"] = 0.7882335782051086,
				},
				["threat"] = {
					["enable"] = false,
				},
				["font"] = "기본 글꼴",
				["fontSize"] = 15,
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFont"] = "기본 글꼴",
					["locationFontSize"] = 14,
					["icons"] = {
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["classHall"] = {
							["position"] = "BOTTOMRIGHT",
							["scale"] = 0.6,
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["bottomPanel"] = false,
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["talkingHeadFrameScale"] = 0.75,
				["numberPrefixStyle"] = "KOREAN",
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
			},
			["bags"] = {
				["itemLevelFont"] = "기본 글꼴",
				["bagSize"] = 28,
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["bankSize"] = 28,
				["itemLevelFontOutline"] = "OUTLINE",
				["countFontSize"] = 13,
				["split"] = {
					["bagSpacing"] = 0,
				},
				["itemLevelFontSize"] = 13,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["alignToChat"] = false,
				["bagWidth"] = 400,
				["countFont"] = "기본 글꼴",
				["clearSearchOnClose"] = true,
				["countFontOutline"] = "OUTLINE",
				["bagBar"] = {
					["enable"] = false,
				},
				["bankWidth"] = 400,
			},
			["hideTutorial"] = true,
			["chat"] = {
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "기본 글꼴",
				["lfgIcons"] = false,
				["fontOutline"] = "OUTLINE",
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
				["fontSize"] = 13,
				["emotionIcons"] = false,
				["tabFontSize"] = 15,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelColorConverted"] = true,
				["timeStampFormat"] = "%H:%M",
				["panelHeight"] = 500,
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
			},
			["gridsize"] = 128,
			["benikuiDatabars"] = {
				["artifact"] = {
					["notifiers"] = {
					},
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,256",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-284,184",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,456,62",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["ElvUF_TargetCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,435",
				["tokenHolderMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-370",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
				["ElvUF_PlayerCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,760,435",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["LocationMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,149,506",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ClassBarMover"] = "TOP,ElvUIParent,TOP,300,-508",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,435",
				["BuiDashboardMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-258",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AzeriteBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-456,23",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,435",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,435",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,305",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,270",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-345,184",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,284,193",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvNP_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,378",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,345,193",
				["TooltipMover"] = "BOTTOM,ElvUIParent,BOTTOM,316,4",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
			},
			["tooltip"] = {
				["fontSize"] = 13,
				["headerFontSize"] = 13,
				["fontOutline"] = "OUTLINE",
				["healthBar"] = {
					["font"] = "기본 글꼴",
					["height"] = 0,
					["text"] = false,
					["fontSIze"] = 11,
				},
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["spellID"] = false,
				["itemCount"] = "NONE",
				["smallTextFontSize"] = 13,
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["fontSize"] = 11,
				["smoothbars"] = true,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 100,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["height"] = 35,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
					},
					["focustarget"] = {
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 120,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["height"] = 16,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
					},
					["pet"] = {
						["buffIndicator"] = {
							["enable"] = false,
						},
						["insideInfoPanel"] = false,
						["threatStyle"] = "NONE",
						["power"] = {
							["enable"] = false,
						},
						["width"] = 100,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["castbar"] = {
							["icon"] = false,
							["spark"] = false,
							["iconAttached"] = false,
							["width"] = 100,
							["height"] = 15,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["sizeOverride"] = 19,
							["yOffset"] = -11,
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
						},
						["spacing"] = 20,
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 180,
						["name"] = {
							["position"] = "LEFT",
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
						},
						["castbar"] = {
							["format"] = "",
							["icon"] = false,
							["spark"] = false,
							["width"] = 180,
							["height"] = 10,
						},
						["height"] = 30,
						["buffs"] = {
							["sizeOverride"] = 19,
							["yOffset"] = 10,
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
							["xOffset"] = -4,
							["text_format"] = "[health:current] | [health:percent]",
						},
					},
					["target"] = {
						["debuffs"] = {
							["fontSize"] = 11,
							["enable"] = false,
							["yOffset"] = 31,
							["anchorPoint"] = "TOPLEFT",
							["attachTo"] = "FRAME",
							["sizeOverride"] = 26,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["name"] = {
							["position"] = "LEFT",
							["text_format"] = "",
						},
						["aurabar"] = {
							["height"] = 18,
							["yOffset"] = 2,
							["attachTo"] = "FRAME",
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["format"] = "Remaining",
							["icon"] = false,
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["size"] = 14,
								["enable"] = true,
								["xOffset"] = 4,
								["text_format"] = "[name:long]",
								["yOffset"] = 4,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["size"] = 32,
								["enable"] = true,
								["xOffset"] = -6,
								["text_format"] = "[health:current]",
								["yOffset"] = 5,
							},
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["power"] = {
							["text_format"] = "[health:percent]",
							["yOffset"] = -22,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["detachedWidth"] = 220,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["height"] = 60,
						["buffs"] = {
							["fontSize"] = 11,
							["yOffset"] = -1,
							["anchorPoint"] = "BOTTOMLEFT",
							["attachTo"] = "POWER",
							["sizeOverride"] = 26,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["sizeOverride"] = 35,
							["yOffset"] = 0,
							["anchorPoint"] = "RIGHT",
							["numrows"] = 1,
							["fontSize"] = 22,
							["xOffset"] = 1,
						},
						["spacing"] = 20,
						["name"] = {
							["position"] = "LEFT",
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
						},
						["castbar"] = {
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
							["height"] = 10,
						},
						["width"] = 175,
						["health"] = {
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
							["xOffset"] = -4,
							["text_format"] = "[health:percent]",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["yOffset"] = 0,
							["fontSize"] = 22,
							["xOffset"] = -3,
						},
					},
					["raid40"] = {
						["debuffs"] = {
							["sizeOverride"] = 20,
							["enable"] = true,
							["yOffset"] = -20,
							["anchorPoint"] = "TOPRIGHT",
							["onlyDispellable"] = true,
							["perrow"] = 1,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["horizontalSpacing"] = 1,
						["rdebuffs"] = {
							["xOffset"] = 30,
							["yOffset"] = 10,
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["size"] = 20,
						},
						["width"] = 50,
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["roleIcon"] = {
							["enable"] = true,
							["yOffset"] = 0,
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["damager"] = false,
							["xOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["castbar"] = {
							["format"] = "Remaining",
							["icon"] = false,
							["spark"] = false,
							["width"] = 120,
							["height"] = 15,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["debuffs"] = {
							["sizeOverride"] = 20,
							["enable"] = true,
							["yOffset"] = -20,
							["anchorPoint"] = "TOPRIGHT",
							["onlyDispellable"] = true,
							["perrow"] = 1,
							["attachTo"] = "Frame",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["horizontalSpacing"] = 1,
						["rdebuffs"] = {
							["enable"] = false,
							["yOffset"] = 20,
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["size"] = 20,
						},
						["power"] = {
							["enable"] = false,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["roleIcon"] = {
							["yOffset"] = 0,
							["attachTo"] = "Frame",
							["damager"] = false,
							["xOffset"] = 0,
						},
					},
					["player"] = {
						["debuffs"] = {
							["fontSize"] = 16,
							["yOffset"] = -1,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 3,
							["attachTo"] = "BUFFS",
							["sizeOverride"] = 0,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["pvpIcon"] = {
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["detachedWidth"] = 92,
							["height"] = 15,
						},
						["aurabar"] = {
							["height"] = 18,
							["yOffset"] = 2,
							["attachTo"] = "FRAME",
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["format"] = "Remaining",
							["icon"] = false,
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["latency"] = false,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["xOffset"] = 0,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["enable"] = false,
								["size"] = 11,
							},
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["power"] = {
							["detachFromFrame"] = true,
							["text_format"] = "[power:current]",
							["powerPrediction"] = true,
							["druidMana"] = false,
							["attachTextTo"] = "Power",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
								["frameLevel"] = 2,
							},
							["detachedWidth"] = 92,
							["xOffset"] = 0,
							["height"] = 15,
						},
						["name"] = {
							["position"] = "LEFT",
							["text_format"] = "[name:long]",
						},
						["stagger"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["buffs"] = {
							["yOffset"] = -1,
							["anchorPoint"] = "BOTTOMLEFT",
							["numrows"] = 3,
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
							["text_format"] = "[health:current]",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["party"] = {
						["debuffs"] = {
							["sizeOverride"] = 20,
							["yOffset"] = -20,
							["anchorPoint"] = "TOPRIGHT",
							["onlyDispellable"] = true,
							["perrow"] = 1,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["horizontalSpacing"] = 1,
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["damager"] = false,
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["width"] = 50,
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["xOffset"] = 0,
							["text_format"] = "",
						},
						["buffs"] = {
							["sizeOverride"] = 20,
							["xOffset"] = -47,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
					},
				},
				["font"] = "기본 글꼴",
				["colors"] = {
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["b"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["r"] = 0.0705882352941177,
						},
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["colorhealthbyvalue"] = false,
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "OUTLINE",
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["panelTransparency"] = true,
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["LeftChatDataPanel"] = {
						["right"] = "Talent/Loot Specialization",
						["left"] = "Time",
					},
					["BottomMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
				},
				["fontOutline"] = "OUTLINE",
				["font"] = "기본 글꼴",
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["buttons"] = 12,
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["fontOutline"] = "OUTLINE",
				["font"] = "기본 글꼴",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
					["style"] = "darkenInactive",
					["showGrid"] = true,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
				},
				["bar6"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 3,
					["buttonsize"] = 30,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar2"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 3,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["buttons"] = 12,
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
					["showGrid"] = true,
				},
				["bar4"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
					["point"] = "TOPLEFT",
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
				},
			},
			["benikuiSkins"] = {
				["addonSkins"] = {
					["immersion"] = false,
				},
			},
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["Armory"] = {
					["Character"] = {
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Artifact"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["bags"] = {
					["artifactPower"] = {
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
						["enable"] = true,
					},
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["maxWraps"] = 2,
					["durationFontSize"] = 13,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["fontOutline"] = "OUTLINE",
				["font"] = "기본 글꼴",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["maxWraps"] = 2,
					["durationFontSize"] = 13,
					["countFontSize"] = 13,
					["size"] = 34,
				},
			},
		},
		["p20190930"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["size"] = 150,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["locationFontSize"] = 14,
				},
				["valuecolor"] = {
					["r"] = 0,
					["g"] = 0.4392147064208984,
					["b"] = 0.8666647672653198,
				},
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["fontSize"] = 15,
			},
			["bags"] = {
				["countFontSize"] = 13,
				["itemLevelFont"] = "기본 글꼴",
				["split"] = {
					["bagSpacing"] = 0,
				},
				["bagSize"] = 28,
				["itemLevelFontSize"] = 13,
				["alignToChat"] = false,
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagBar"] = {
					["enable"] = false,
				},
				["clearSearchOnClose"] = true,
				["countFont"] = "기본 글꼴",
				["bagWidth"] = 400,
			},
			["hideTutorial"] = true,
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["timeStampFormat"] = "%H:%M",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeight"] = 500,
				["tabFont"] = "기본 글꼴",
				["emotionIcons"] = false,
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
			["gridsize"] = 128,
			["benikuiDatabars"] = {
				["artifact"] = {
					["notifiers"] = {
					},
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,256",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-284,184",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,456,62",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["tokenHolderMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-370",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,305",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["LocationMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,149,506",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ClassBarMover"] = "TOP,ElvUIParent,TOP,300,-508",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,435",
				["BuiDashboardMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-258",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,435",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,435",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-345,184",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,284,193",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["AzeriteBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-456,23",
				["ElvNP_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,378",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,345,193",
				["TooltipMover"] = "BOTTOM,ElvUIParent,BOTTOM,316,4",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,270",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["fontSize"] = 13,
				["smallTextFontSize"] = 13,
			},
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
					},
				},
				["fontOutline"] = "OUTLINE",
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["power"] = {
							["enable"] = false,
						},
						["width"] = 100,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["insideInfoPanel"] = false,
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["enable"] = true,
						["height"] = 16,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 120,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 100,
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
						["width"] = 180,
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:current] | [health:percent]",
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["power"] = {
							["text_format"] = "",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["detachedWidth"] = 220,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["text_format"] = "[health:percent]",
							["yOffset"] = -22,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:percent]",
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["perrow"] = 1,
							["yOffset"] = -20,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["size"] = 20,
							["yOffset"] = 10,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["xOffset"] = 0,
							["damager"] = false,
							["enable"] = true,
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["yOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["height"] = 30,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["perrow"] = 1,
							["attachTo"] = "Frame",
							["yOffset"] = -20,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["size"] = 20,
							["enable"] = false,
							["yOffset"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["yOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 16,
							["sizeOverride"] = 0,
							["attachTo"] = "BUFFS",
							["numrows"] = 3,
							["yOffset"] = -1,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["detachedWidth"] = 92,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["latency"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["pvpIcon"] = {
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["powerPrediction"] = true,
							["xOffset"] = 0,
							["text_format"] = "[power:current]",
							["strataAndLevel"] = {
								["frameLevel"] = 2,
								["useCustomStrata"] = true,
							},
							["height"] = 15,
							["detachedWidth"] = 92,
							["detachFromFrame"] = true,
							["druidMana"] = false,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["stagger"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "FRAME",
							["numrows"] = 3,
							["yOffset"] = -1,
						},
						["health"] = {
							["text_format"] = "[health:current]",
							["frequentUpdates"] = true,
							["position"] = "RIGHT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["perrow"] = 1,
							["yOffset"] = -20,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["width"] = 50,
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["damager"] = false,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["showGrid"] = true,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
				},
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonsize"] = 17,
					["style"] = "darkenInactive",
					["showGrid"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 5,
					["backdrop"] = false,
					["backdropSpacing"] = 0,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["backdrop"] = false,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
					["backdropSpacing"] = 0,
				},
			},
			["benikuiSkins"] = {
				["addonSkins"] = {
					["immersion"] = false,
				},
			},
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["fonts"] = {
							["font"] = "Expressway",
						},
						["enable"] = true,
						["short"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["spacing"] = 3,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["iconperrow"] = 6,
					},
				},
				["Armory"] = {
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
					["Character"] = {
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
			["v11NamePlateReset"] = true,
		},
		["무시중한디 - 굴단"] = {
			["databars"] = {
				["artifact"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 395,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 13,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "GUILD",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "Expressway",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["yOffset"] = 4,
							["xOffset"] = 4,
							["position"] = "BOTTOMLEFT",
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 11,
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["objectiveFrameHeight"] = 500,
				["numberPrefixStyle"] = "KOREAN",
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0.639214277267456,
					["g"] = 0.188234880566597,
					["b"] = 0.7882335782051086,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,295",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,-240,236",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,905",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-30",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,311",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,184",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,280,200",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,342",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,910",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-340,-285",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,34",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,1",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-248,1",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,247,1",
				["ArtifactBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-81,-280",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,959,140",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,263",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-29,168",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,263",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,200",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,660",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-148",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-30",
			},
			["v11NamePlateReset"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "Expressway",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 11,
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["smallTextFontSize"] = 11,
				["visibility"] = {
					["combat"] = true,
				},
				["spellID"] = false,
			},
			["chat"] = {
				["panelWidth"] = 400,
				["tabFontOutline"] = "OUTLINE",
				["emotionIcons"] = false,
				["tabFont"] = "Expressway",
				["panelColor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["font"] = "Expressway",
				["lfgIcons"] = false,
				["panelHeightRight"] = 175,
				["panelColorConverted"] = true,
				["timeStampFormat"] = "%H:%M",
				["panelHeight"] = 175,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelBackdrop"] = "HIDEBOTH",
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 11,
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.64,
						["g"] = 0.19,
						["b"] = 0.79,
					},
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
					},
				},
				["smartRaidFilter"] = false,
				["smoothbars"] = true,
				["statusbar"] = "Skullflower",
				["font"] = "Expressway",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "",
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 100,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "",
						},
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 225,
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 40,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 225,
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 28,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["detachFromFrame"] = true,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["height"] = 15,
							["detachedWidth"] = 220,
							["text_format"] = "",
							["yOffset"] = -22,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["enable"] = true,
								["xOffset"] = 4,
								["text_format"] = "",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["enable"] = true,
								["xOffset"] = -6,
								["text_format"] = "",
								["size"] = 32,
							},
						},
						["width"] = 220,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["yOffset"] = 1,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 220,
						},
						["aurabar"] = {
							["enable"] = false,
							["attachTo"] = "FRAME",
							["height"] = 18,
						},
					},
					["party"] = {
						["roleIcon"] = {
							["xOffset"] = 2,
							["damager"] = false,
							["position"] = "LEFT",
						},
						["debuffs"] = {
							["anchorPoint"] = "BOTTOM",
							["sizeOverride"] = 30,
							["onlyDispellable"] = true,
							["enable"] = false,
							["yOffset"] = -1,
							["numrows"] = 3,
							["perrow"] = 1,
						},
						["power"] = {
							["height"] = 5,
						},
						["growthDirection"] = "DOWN_RIGHT",
						["name"] = {
							["xOffset"] = 205,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["width"] = 200,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:deficit]",
							["position"] = "CENTER",
						},
						["verticalSpacing"] = 1,
					},
					["raid40"] = {
						["horizontalSpacing"] = 0,
						["growthDirection"] = "DOWN_RIGHT",
						["width"] = 170,
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "[health:deficit]",
							["yOffset"] = 0,
						},
						["height"] = 15,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["groupsPerRowCol"] = 8,
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 0,
						["debuffs"] = {
							["anchorPoint"] = "CENTER",
							["sizeOverride"] = 18,
							["onlyDispellable"] = true,
							["enable"] = true,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
							["fontOutline"] = "OUTLINE",
							["size"] = 20,
						},
						["numGroups"] = 6,
						["growthDirection"] = "DOWN_RIGHT",
						["groupsPerRowCol"] = 6,
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "LEFT",
							["xOffset"] = 2,
							["damager"] = false,
							["yOffset"] = 0,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "[health:deficit]",
							["yOffset"] = 0,
						},
						["height"] = 20,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["width"] = 170,
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 22,
							["xOffset"] = 1,
							["sizeOverride"] = 35,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["enable"] = false,
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["fontSize"] = 22,
							["xOffset"] = -3,
							["enable"] = false,
							["sizeOverride"] = 35,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
					},
					["player"] = {
						["RestIcon"] = {
							["enable"] = false,
						},
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["fontSize"] = 16,
							["enable"] = false,
							["xOffset"] = -1,
							["attachTo"] = "Frame",
							["sizeOverride"] = 46,
							["yOffset"] = -8,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["width"] = 220,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["customTexts"] = {
							["HealthText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 5,
								["enable"] = true,
								["xOffset"] = 6,
								["text_format"] = "",
								["size"] = 32,
							},
						},
						["aurabar"] = {
							["enable"] = false,
							["attachTo"] = "FRAME",
							["height"] = 18,
						},
						["width"] = 220,
						["stagger"] = {
							["enable"] = false,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["detachedWidth"] = 220,
							["detachFromFrame"] = true,
							["text_format"] = "",
							["xOffset"] = 0,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "CENTER",
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["detachedWidth"] = 220,
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["minimapBottom"] = true,
				["panelTransparency"] = true,
				["panels"] = {
					["LeftMiniPanel"] = "",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["BottomMiniPanel"] = "Time (SFUI)",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["leftChatPanel"] = false,
				["rightChatPanel"] = false,
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 12,
					["backdropSpacing"] = 0,
				},
				["bar6"] = {
					["buttonspacing"] = 1,
					["enabled"] = true,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["enabled"] = true,
				},
				["bar1"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
				},
				["bar5"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
				},
				["hotkeytext"] = false,
				["font"] = "Expressway",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["backdrop"] = false,
					["style"] = "darkenInactive",
					["mouseover"] = true,
					["showGrid"] = true,
					["buttonsPerRow"] = 10,
					["buttonsize"] = 17,
					["backdropSpacing"] = 0,
				},
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 12,
				["stanceBar"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["mouseover"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["layoutSet"] = "dpsMelee",
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 12,
					["durationFontSize"] = 12,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["font"] = "Expressway",
				["buffs"] = {
					["countFontSize"] = 12,
					["durationFontSize"] = 12,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["wrapAfter"] = 10,
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "Expressway",
				["countFontSize"] = 12,
				["clearSearchOnClose"] = true,
				["countFont"] = "Expressway",
				["bagSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bagWidth"] = 400,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["itemLevelFontSize"] = 12,
				["bagBar"] = {
					["enable"] = false,
				},
				["alignToChat"] = false,
				["vendorGrays"] = {
					["enable"] = true,
				},
			},
			["lowresolutionset"] = true,
		},
		["뉘시빨라마 - 굴단"] = {
			["databars"] = {
				["artifact"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 13,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "GUILD",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "Expressway",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 11,
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["objectiveFrameHeight"] = 500,
				["numberPrefixStyle"] = "KOREAN",
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0,
					["g"] = 0.44,
					["b"] = 0.87,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,295",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,-240,236",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,905",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,342",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-30",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-30",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-148",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,311",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,660",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,184",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,200",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,280,200",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,910",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,263",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,1",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,34",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-248,1",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,247,1",
				["ArtifactBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-81,-280",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,959,140",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-340,-285",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-29,168",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,67",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "Expressway",
				["countFontSize"] = 12,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFont"] = "Expressway",
				["bagSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bagWidth"] = 400,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["itemLevelFontSize"] = 12,
				["bagBar"] = {
					["enable"] = false,
				},
				["alignToChat"] = false,
				["clearSearchOnClose"] = true,
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "Expressway",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 11,
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["visibility"] = {
					["combat"] = true,
				},
				["smallTextFontSize"] = 11,
			},
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 12,
					["durationFontSize"] = 12,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["font"] = "Expressway",
				["buffs"] = {
					["countFontSize"] = 12,
					["durationFontSize"] = 12,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["wrapAfter"] = 10,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["smartRaidFilter"] = false,
				["fontSize"] = 11,
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.64,
						["g"] = 0.19,
						["b"] = 0.79,
					},
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
					},
				},
				["fontOutline"] = "OUTLINE",
				["smoothbars"] = true,
				["font"] = "Expressway",
				["statusbar"] = "Skullflower",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["power"] = {
							["enable"] = false,
						},
						["width"] = 100,
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "",
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["insideInfoPanel"] = false,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "",
						},
						["enable"] = true,
						["height"] = 16,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 120,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "",
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 100,
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
							["sizeOverride"] = 19,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 225,
						},
						["width"] = 225,
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 40,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
							["sizeOverride"] = 19,
							["yOffset"] = 10,
						},
						["power"] = {
							["text_format"] = "",
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["party"] = {
						["roleIcon"] = {
							["xOffset"] = 2,
							["damager"] = false,
							["position"] = "LEFT",
						},
						["debuffs"] = {
							["anchorPoint"] = "BOTTOM",
							["sizeOverride"] = 30,
							["onlyDispellable"] = true,
							["enable"] = false,
							["yOffset"] = -1,
							["numrows"] = 3,
							["perrow"] = 1,
						},
						["power"] = {
							["height"] = 5,
						},
						["growthDirection"] = "DOWN_RIGHT",
						["name"] = {
							["xOffset"] = 205,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["width"] = 200,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:deficit]",
							["position"] = "CENTER",
						},
						["verticalSpacing"] = 1,
					},
					["raid40"] = {
						["horizontalSpacing"] = 0,
						["growthDirection"] = "DOWN_RIGHT",
						["groupsPerRowCol"] = 8,
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "[health:deficit]",
							["yOffset"] = 0,
						},
						["height"] = 15,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["width"] = 170,
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["name"] = {
							["text_format"] = "",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["sizeOverride"] = 26,
							["fontSize"] = 11,
							["attachTo"] = "FRAME",
							["yOffset"] = 28,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 220,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["size"] = 14,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "",
								["yOffset"] = 4,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["size"] = 32,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "",
								["yOffset"] = 5,
							},
						},
						["width"] = 220,
						["power"] = {
							["detachFromFrame"] = true,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["height"] = 15,
							["detachedWidth"] = 220,
							["text_format"] = "",
							["yOffset"] = -22,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["sizeOverride"] = 26,
							["fontSize"] = 11,
							["yOffset"] = 1,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["aurabar"] = {
							["enable"] = false,
							["attachTo"] = "FRAME",
							["height"] = 18,
						},
					},
					["raid"] = {
						["horizontalSpacing"] = 0,
						["debuffs"] = {
							["anchorPoint"] = "CENTER",
							["sizeOverride"] = 18,
							["onlyDispellable"] = true,
							["enable"] = true,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
							["fontOutline"] = "OUTLINE",
							["size"] = 20,
						},
						["numGroups"] = 6,
						["growthDirection"] = "DOWN_RIGHT",
						["groupsPerRowCol"] = 6,
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "LEFT",
							["xOffset"] = 2,
							["yOffset"] = 0,
							["damager"] = false,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "[health:deficit]",
							["yOffset"] = 0,
						},
						["height"] = 20,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["width"] = 170,
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["enable"] = false,
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
					["player"] = {
						["RestIcon"] = {
							["enable"] = false,
						},
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["sizeOverride"] = 46,
							["enable"] = false,
							["xOffset"] = -1,
							["attachTo"] = "Frame",
							["fontSize"] = 16,
							["yOffset"] = -8,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["width"] = 220,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["customTexts"] = {
							["HealthText"] = {
								["justifyH"] = "Left",
								["size"] = 32,
								["xOffset"] = 6,
								["enable"] = true,
								["text_format"] = "",
								["yOffset"] = 5,
							},
						},
						["aurabar"] = {
							["enable"] = false,
							["attachTo"] = "FRAME",
							["height"] = 18,
						},
						["width"] = 220,
						["stagger"] = {
							["enable"] = false,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 220,
							["height"] = 15,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["power"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 220,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["height"] = 15,
							["attachTextTo"] = "Power",
							["text_format"] = "",
							["xOffset"] = 0,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "CENTER",
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["minimapBottom"] = true,
				["panelTransparency"] = true,
				["panels"] = {
					["LeftMiniPanel"] = "",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["BottomMiniPanel"] = "Time (SFUI)",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["leftChatPanel"] = false,
				["rightChatPanel"] = false,
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 12,
					["backdropSpacing"] = 0,
				},
				["bar6"] = {
					["buttonspacing"] = 1,
					["enabled"] = true,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["enabled"] = true,
				},
				["bar1"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
				},
				["bar5"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
				},
				["hotkeytext"] = false,
				["font"] = "Expressway",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["style"] = "darkenInactive",
					["backdrop"] = false,
					["showGrid"] = true,
					["buttonsPerRow"] = 10,
					["buttonsize"] = 17,
					["backdropSpacing"] = 0,
				},
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 12,
				["stanceBar"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["mouseover"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["layoutSet"] = "dpsMelee",
			["v11NamePlateReset"] = true,
			["chat"] = {
				["panelWidth"] = 400,
				["tabFontOutline"] = "OUTLINE",
				["emotionIcons"] = false,
				["tabFont"] = "Expressway",
				["keywords"] = "%MYNAME%, ElvUI",
				["font"] = "Expressway",
				["lfgIcons"] = false,
				["panelHeightRight"] = 175,
				["panelColorConverted"] = true,
				["panelHeight"] = 175,
				["fontOutline"] = "OUTLINE",
				["timeStampFormat"] = "%H:%M",
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["panelBackdrop"] = "HIDEBOTH",
			},
			["lowresolutionset"] = true,
		},
		["DEMONHUNTER"] = {
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,967",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
			},
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["v11NamePlateReset"] = true,
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["아놀드클래식 - 렉사르"] = {
			["currentTutorial"] = 1,
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Default"] = {
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["닌자창고 - 렉사르"] = {
			["currentTutorial"] = 1,
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["ldw"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 395,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["height"] = 32,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 3,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "GUILD",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "Expressway",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 11,
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0,
					["g"] = 0.44,
					["b"] = 0.87,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,295",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,263",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,905",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-30",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,311",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,200",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,184",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,280,200",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,342",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,910",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,67",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,263",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,34",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-340,-285",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-248,1",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-81,-280",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,959,140",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,247,1",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,1",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-29,168",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,-240,236",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,660",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-148",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-30",
			},
			["v11NamePlateReset"] = true,
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "Expressway",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 11,
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["visibility"] = {
					["combat"] = true,
				},
				["smallTextFontSize"] = 11,
			},
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 12,
					["maxWraps"] = 2,
					["countFontSize"] = 12,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["font"] = "Expressway",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 12,
					["maxWraps"] = 2,
					["countFontSize"] = 12,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["wrapAfter"] = 10,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 11,
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.64,
						["g"] = 0.19,
						["b"] = 0.79,
					},
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["b"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["r"] = 0.0705882352941177,
						},
					},
				},
				["smartRaidFilter"] = false,
				["font"] = "Expressway",
				["statusbar"] = "Skullflower",
				["smoothbars"] = true,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "",
						},
						["width"] = 100,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["healPrediction"] = {
							["enable"] = false,
						},
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["name"] = {
							["text_format"] = "",
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["enable"] = true,
						["name"] = {
							["text_format"] = "",
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 225,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 40,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 225,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["sizeOverride"] = 26,
							["fontSize"] = 11,
							["attachTo"] = "FRAME",
							["yOffset"] = 28,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 220,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["enable"] = true,
								["xOffset"] = 4,
								["text_format"] = "",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["enable"] = true,
								["xOffset"] = -6,
								["text_format"] = "",
								["size"] = 32,
							},
						},
						["healPrediction"] = {
							["enable"] = false,
						},
						["width"] = 220,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["yOffset"] = 1,
						},
						["power"] = {
							["detachFromFrame"] = true,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["height"] = 15,
							["detachedWidth"] = 220,
							["text_format"] = "",
							["yOffset"] = -22,
						},
						["aurabar"] = {
							["enable"] = false,
							["attachTo"] = "FRAME",
							["height"] = 18,
						},
					},
					["player"] = {
						["RestIcon"] = {
							["enable"] = false,
						},
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["sizeOverride"] = 46,
							["xOffset"] = -1,
							["enable"] = false,
							["attachTo"] = "Frame",
							["fontSize"] = 16,
							["yOffset"] = -8,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["width"] = 220,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["customTexts"] = {
							["HealthText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 5,
								["enable"] = true,
								["xOffset"] = 6,
								["text_format"] = "",
								["size"] = 32,
							},
						},
						["aurabar"] = {
							["enable"] = false,
							["attachTo"] = "FRAME",
							["height"] = 18,
						},
						["width"] = 220,
						["stagger"] = {
							["enable"] = false,
						},
						["CombatIcon"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["power"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["detachedWidth"] = 220,
							["attachTextTo"] = "Power",
							["text_format"] = "",
							["xOffset"] = 0,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "CENTER",
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 220,
							["height"] = 15,
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 0,
						["growthDirection"] = "DOWN_RIGHT",
						["width"] = 170,
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "[health:deficit]",
							["yOffset"] = 0,
						},
						["height"] = 15,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["groupsPerRowCol"] = 8,
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 0,
						["debuffs"] = {
							["anchorPoint"] = "CENTER",
							["sizeOverride"] = 18,
							["onlyDispellable"] = true,
							["enable"] = true,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
							["fontOutline"] = "OUTLINE",
							["size"] = 20,
						},
						["numGroups"] = 6,
						["growthDirection"] = "DOWN_RIGHT",
						["groupsPerRowCol"] = 6,
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "LEFT",
							["xOffset"] = 2,
							["yOffset"] = 0,
							["damager"] = false,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "[health:deficit]",
							["yOffset"] = 0,
						},
						["height"] = 20,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["width"] = 170,
					},
					["party"] = {
						["roleIcon"] = {
							["xOffset"] = 2,
							["damager"] = false,
							["position"] = "LEFT",
						},
						["debuffs"] = {
							["anchorPoint"] = "BOTTOM",
							["sizeOverride"] = 30,
							["onlyDispellable"] = true,
							["enable"] = false,
							["yOffset"] = -1,
							["numrows"] = 3,
							["perrow"] = 1,
						},
						["power"] = {
							["height"] = 5,
						},
						["growthDirection"] = "DOWN_RIGHT",
						["name"] = {
							["xOffset"] = 205,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["width"] = 200,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:deficit]",
							["position"] = "CENTER",
						},
						["verticalSpacing"] = 1,
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["enable"] = false,
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["minimapBottom"] = true,
				["panelTransparency"] = true,
				["panels"] = {
					["LeftMiniPanel"] = "",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["BottomMiniPanel"] = "Time (SFUI)",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["leftChatPanel"] = false,
				["rightChatPanel"] = false,
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 12,
					["backdropSpacing"] = 0,
				},
				["bar6"] = {
					["buttonspacing"] = 1,
					["enabled"] = true,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["enabled"] = true,
				},
				["bar1"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
				},
				["bar5"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
				},
				["hotkeytext"] = false,
				["font"] = "Expressway",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["style"] = "darkenInactive",
					["backdrop"] = false,
					["showGrid"] = true,
					["buttonsPerRow"] = 10,
					["buttonsize"] = 17,
					["backdropSpacing"] = 0,
				},
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 12,
				["stanceBar"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["mouseover"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["layoutSet"] = "dpsMelee",
			["chat"] = {
				["panelWidth"] = 400,
				["tabFontOutline"] = "OUTLINE",
				["emotionIcons"] = false,
				["tabFont"] = "Expressway",
				["panelColor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["font"] = "Expressway",
				["lfgIcons"] = false,
				["panelHeightRight"] = 175,
				["panelColorConverted"] = true,
				["timeStampFormat"] = "%H:%M",
				["panelHeight"] = 175,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelBackdrop"] = "HIDEBOTH",
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "Expressway",
				["countFontSize"] = 12,
				["clearSearchOnClose"] = true,
				["countFont"] = "Expressway",
				["bagSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bagWidth"] = 400,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["itemLevelFontSize"] = 12,
				["bagBar"] = {
					["enable"] = false,
				},
				["alignToChat"] = false,
				["vendorGrays"] = {
					["enable"] = true,
				},
			},
			["lowresolutionset"] = true,
		},
		["완소야드 - 굴단"] = {
			["databars"] = {
				["artifact"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 395,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["height"] = 32,
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["font"] = "Expressway",
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["height"] = 32,
					["mouseover"] = true,
					["width"] = 395,
				},
			},
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["fontSize"] = 11,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["vendorGrays"] = true,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "GUILD",
				["minimap"] = {
					["size"] = 150,
					["locationFont"] = "Expressway",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["yOffset"] = 0,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["yOffset"] = 4,
							["xOffset"] = 4,
							["position"] = "BOTTOMLEFT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["locationFontSize"] = 14,
				},
				["valuecolor"] = {
					["r"] = 1,
					["g"] = 0.49,
					["b"] = 0.04,
				},
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["objectiveFrameHeight"] = 500,
				["talkingHeadFrameScale"] = 0.75,
				["interruptAnnounce"] = "SAY",
				["threat"] = {
					["enable"] = false,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,295",
				["PetAB"] = "BOTTOM,ElvUIParent,BOTTOM,-240,236",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,905",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-30",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,0,140",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,311",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,660",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,184",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,30",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,281",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,30,910",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,280,200",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,34",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,0,1",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-248,1",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,247,1",
				["ArtifactBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,100",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-280,200",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-81,-280",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,959,140",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-340,-285",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-29,168",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-460,342",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,220,281",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,30",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-184,-148",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-30",
			},
			["bags"] = {
				["countFontSize"] = 12,
				["moneyCoins"] = false,
				["itemLevelFont"] = "Expressway",
				["clearSearchOnClose"] = true,
				["countFont"] = "Expressway",
				["bankSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bagSize"] = 28,
				["bankWidth"] = 400,
				["itemLevelFontSize"] = 12,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagBar"] = {
					["enable"] = false,
				},
				["junkIcon"] = true,
				["alignToChat"] = false,
				["bagWidth"] = 400,
			},
			["chat"] = {
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "Expressway",
				["keywords"] = "%MYNAME%, ElvUI",
				["panelBackdrop"] = "HIDEBOTH",
				["lfgIcons"] = false,
				["panelHeightRight"] = 175,
				["font"] = "Expressway",
				["panelHeight"] = 175,
				["fontOutline"] = "OUTLINE",
				["timeStampFormat"] = "%H:%M",
				["panelWidthRight"] = 400,
				["emotionIcons"] = false,
				["panelWidth"] = 400,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["classResources"] = {
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
					},
				},
				["smartRaidFilter"] = false,
				["font"] = "Expressway",
				["smoothbars"] = true,
				["statusbar"] = "Skullflower",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["party"] = {
						["roleIcon"] = {
							["xOffset"] = 2,
							["damager"] = false,
							["position"] = "LEFT",
						},
						["debuffs"] = {
							["numrows"] = 3,
							["sizeOverride"] = 30,
							["onlyDispellable"] = true,
							["enable"] = false,
							["perrow"] = 1,
							["anchorPoint"] = "BOTTOM",
							["yOffset"] = -1,
						},
						["power"] = {
							["height"] = 5,
						},
						["growthDirection"] = "DOWN_RIGHT",
						["name"] = {
							["xOffset"] = 205,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["xOffset"] = 0,
							["text_format"] = "[health:deficit]",
							["position"] = "CENTER",
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 20,
							["xOffset"] = -47,
							["perrow"] = 2,
						},
						["width"] = 200,
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "",
						},
						["enable"] = true,
						["rangeCheck"] = false,
						["height"] = 16,
						["width"] = 120,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["rangeCheck"] = false,
						["healPrediction"] = false,
						["width"] = 100,
						["name"] = {
							["text_format"] = "",
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["insideInfoPanel"] = false,
					},
					["player"] = {
						["restIcon"] = false,
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["fontSize"] = 16,
							["enable"] = false,
							["xOffset"] = -1,
							["attachTo"] = "Frame",
							["sizeOverride"] = 46,
							["yOffset"] = -8,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["latency"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 220,
						},
						["customTexts"] = {
							["HealthText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 5,
								["enable"] = true,
								["xOffset"] = 6,
								["text_format"] = "",
								["size"] = 32,
							},
						},
						["pvp"] = {
							["text_format"] = "",
						},
						["width"] = 220,
						["stagger"] = {
							["enable"] = false,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["detachedWidth"] = 220,
						},
						["health"] = {
							["text_format"] = "",
						},
						["power"] = {
							["attachTextTo"] = "Power",
							["detachFromFrame"] = true,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["detachedWidth"] = 220,
							["height"] = 15,
							["text_format"] = "",
							["xOffset"] = 0,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "CENTER",
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["combatIcon"] = false,
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
							["attachTo"] = "FRAME",
						},
					},
					["raid"] = {
						["horizontalSpacing"] = 0,
						["debuffs"] = {
							["attachTo"] = "Frame",
							["sizeOverride"] = 18,
							["onlyDispellable"] = true,
							["enable"] = true,
							["anchorPoint"] = "CENTER",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
							["size"] = 20,
							["fontOutline"] = "OUTLINE",
						},
						["numGroups"] = 6,
						["growthDirection"] = "DOWN_RIGHT",
						["groupsPerRowCol"] = 6,
						["width"] = 170,
						["health"] = {
							["attachTextTo"] = "Frame",
							["yOffset"] = 0,
							["text_format"] = "[health:deficit]",
							["position"] = "CENTER",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["height"] = 20,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "LEFT",
							["xOffset"] = 2,
							["damager"] = false,
							["yOffset"] = 0,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["numrows"] = 1,
							["fontSize"] = 22,
							["xOffset"] = 1,
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["enable"] = false,
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["fontSize"] = 22,
							["xOffset"] = -3,
							["enable"] = false,
							["sizeOverride"] = 35,
							["yOffset"] = 0,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 0,
						["growthDirection"] = "DOWN_RIGHT",
						["width"] = 170,
						["health"] = {
							["attachTextTo"] = "Frame",
							["yOffset"] = 0,
							["text_format"] = "[health:deficit]",
							["position"] = "CENTER",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 175,
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["height"] = 15,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["groupsPerRowCol"] = 8,
					},
					["focus"] = {
						["name"] = {
							["text_format"] = "",
						},
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["rangeCheck"] = false,
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["height"] = 30,
						["width"] = 120,
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["attachTo"] = "FRAME",
							["sizeOverride"] = 26,
							["yOffset"] = 28,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 220,
						},
						["rangeCheck"] = false,
						["healPrediction"] = false,
						["width"] = 220,
						["power"] = {
							["detachFromFrame"] = true,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["height"] = 15,
							["detachedWidth"] = 220,
							["text_format"] = "",
							["yOffset"] = -22,
						},
						["health"] = {
							["text_format"] = "",
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["yOffset"] = 1,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["enable"] = true,
								["xOffset"] = 4,
								["text_format"] = "",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["enable"] = true,
								["xOffset"] = -6,
								["text_format"] = "",
								["size"] = 32,
							},
						},
						["aurabar"] = {
							["enable"] = false,
							["height"] = 18,
							["attachTo"] = "FRAME",
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 225,
						},
						["width"] = 225,
						["health"] = {
							["xOffset"] = -4,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 40,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["power"] = {
							["text_format"] = "",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "",
						},
						["power"] = {
							["enable"] = false,
						},
						["rangeCheck"] = false,
						["height"] = 35,
						["width"] = 100,
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["minimapBottom"] = true,
				["panelTransparency"] = true,
				["panels"] = {
					["LeftMiniPanel"] = "",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["BottomMiniPanel"] = "Time (SFUI)",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["leftChatPanel"] = false,
				["battleground"] = false,
				["rightChatPanel"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 12,
					["backdropSpacing"] = 0,
				},
				["fontSize"] = 12,
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["enabled"] = true,
				},
				["bar1"] = {
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
				},
				["bar5"] = {
					["enabled"] = false,
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
				},
				["bar6"] = {
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["enabled"] = true,
				},
				["font"] = "Expressway",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["backdrop"] = false,
					["style"] = "darkenInactive",
					["mouseover"] = true,
					["showGrid"] = true,
					["buttonsPerRow"] = 10,
					["backdropSpacing"] = 0,
					["buttonsize"] = 17,
				},
				["fontOutline"] = "OUTLINE",
				["hotkeytext"] = false,
				["stanceBar"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["enabled"] = false,
					["point"] = "BOTTOMLEFT",
					["mouseover"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["nameplates"] = {
				["fontSize"] = 12,
				["durationFont"] = "Expressway",
				["units"] = {
					["ENEMY_NPC"] = {
						["debuffs"] = {
							["baseHeight"] = 30,
						},
						["healthbar"] = {
							["height"] = 14,
							["text"] = {
								["enable"] = true,
								["format"] = "CURRENT_PERCENT",
							},
							["width"] = 175,
						},
						["buffs"] = {
							["baseHeight"] = 30,
						},
					},
					["FRIENDLY_NPC"] = {
						["debuffs"] = {
							["baseHeight"] = 30,
						},
						["healthbar"] = {
							["height"] = 14,
							["text"] = {
								["enable"] = true,
								["format"] = "CURRENT_PERCENT",
							},
							["width"] = 175,
						},
						["buffs"] = {
							["baseHeight"] = 30,
						},
					},
					["PLAYER"] = {
						["debuffs"] = {
							["baseHeight"] = 30,
						},
						["healthbar"] = {
							["height"] = 14,
							["text"] = {
								["enable"] = true,
								["format"] = "CURRENT_PERCENT",
							},
							["width"] = 175,
						},
						["buffs"] = {
							["baseHeight"] = 30,
						},
					},
					["ENEMY_PLAYER"] = {
						["debuffs"] = {
							["baseHeight"] = 30,
						},
						["healthbar"] = {
							["height"] = 14,
							["text"] = {
								["enable"] = true,
								["format"] = "CURRENT_PERCENT",
							},
							["width"] = 174,
						},
						["buffs"] = {
							["baseHeight"] = 30,
						},
					},
					["HEALER"] = {
						["debuffs"] = {
							["baseHeight"] = 30,
						},
						["healthbar"] = {
							["height"] = 14,
							["text"] = {
								["enable"] = true,
								["format"] = "CURRENT_PERCENT",
							},
							["width"] = 175,
						},
						["buffs"] = {
							["baseHeight"] = 30,
						},
					},
					["FRIENDLY_PLAYER"] = {
						["debuffs"] = {
							["baseHeight"] = 30,
						},
						["healthbar"] = {
							["height"] = 14,
							["text"] = {
								["enable"] = true,
								["format"] = "CURRENT_PERCENT",
							},
							["width"] = 175,
						},
						["buffs"] = {
							["baseHeight"] = 30,
						},
					},
				},
				["statusbar"] = "Skullflower",
				["nonTargetTransparency"] = 0.65,
				["stackFont"] = "Expressway",
				["font"] = "Expressway",
				["healthFont"] = "Expressway",
				["classbar"] = {
					["enable"] = false,
				},
				["healthFontSize"] = 12,
			},
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["maxWraps"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["fontSize"] = 12,
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["maxWraps"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "Expressway",
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "Expressway",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 11,
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["fontOutline"] = "OUTLINE",
				["smallTextFontSize"] = 11,
				["visibility"] = {
					["combat"] = true,
				},
				["spellID"] = false,
			},
		},
		["Udiess - 굴단"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["height"] = 32,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
						["enable"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,359",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-176,-576",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-176,-576",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,435",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,5,668",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,499",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,311",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,335,434",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,189,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-189,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,325",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-503,280",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,188,557",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,378",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "기본 글꼴",
				["countFontSize"] = 13,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFont"] = "기본 글꼴",
				["bagSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bagWidth"] = 400,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["itemLevelFontSize"] = 13,
				["bagBar"] = {
					["enable"] = false,
				},
				["alignToChat"] = false,
				["clearSearchOnClose"] = true,
			},
			["hideTutorial"] = true,
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["b"] = 0.631372549019608,
							["g"] = 0.450980392156863,
							["r"] = 0.309803921568627,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["ENERGY"] = {
							["b"] = 0.349019607843137,
							["g"] = 0.631372549019608,
							["r"] = 0.650980392156863,
						},
						["FOCUS"] = {
							["b"] = 0.270588235294118,
							["g"] = 0.431372549019608,
							["r"] = 0.709803921568628,
						},
						["RAGE"] = {
							["b"] = 0.250980392156863,
							["g"] = 0.250980392156863,
							["r"] = 0.780392156862745,
						},
					},
					["castColor"] = {
						["b"] = 0.8,
						["g"] = 0.8,
						["r"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["b"] = 0.850980392156863,
						["g"] = 0.792156862745098,
						["r"] = 0.764705882352941,
					},
					["health"] = {
						["b"] = 0.403921568627451,
						["g"] = 1,
						["r"] = 0.419607843137255,
					},
					["reaction"] = {
						["BAD"] = {
							["b"] = 0.195555555555556,
							["g"] = 0.137777777777778,
							["r"] = 1,
						},
						["NEUTRAL"] = {
							["b"] = 0.368627450980392,
							["g"] = 0.976470588235294,
							["r"] = 1,
						},
						["GOOD"] = {
							["b"] = 0.403921568627451,
							["g"] = 1,
							["r"] = 0.419607843137255,
						},
					},
					["disconnected"] = {
						["b"] = 0.850980392156863,
						["g"] = 0.792156862745098,
						["r"] = 0.764705882352941,
					},
					["castNoInterrupt"] = {
						["b"] = 0.195555555555556,
						["g"] = 0.137777777777778,
						["r"] = 1,
					},
					["health_backdrop"] = {
						["b"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["r"] = 0.0705882352941177,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [1]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [2]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [3]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [4]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [5]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [6]
						},
						["bgColor"] = {
							["b"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["r"] = 0.0705882352941177,
						},
					},
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "OUTLINE",
				["font"] = "기본 글꼴",
				["smoothbars"] = true,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["insideInfoPanel"] = false,
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["enable"] = true,
						["height"] = 16,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 120,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["enable"] = false,
							["yOffset"] = 20,
							["xOffset"] = 30,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["position"] = "TOPLEFT",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["width"] = 50,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["verticalSpacing"] = 1,
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["enable"] = true,
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["sizeOverride"] = 26,
							["enable"] = false,
							["fontSize"] = 11,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["sizeOverride"] = 26,
							["fontSize"] = 11,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["threatStyle"] = "NONE",
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
							["sizeOverride"] = 19,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
						["width"] = 180,
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
							["sizeOverride"] = 19,
							["yOffset"] = 10,
						},
						["power"] = {
							["text_format"] = "",
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["sizeOverride"] = 46,
							["xOffset"] = -1,
							["enable"] = false,
							["attachTo"] = "Frame",
							["fontSize"] = 16,
							["yOffset"] = -8,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["detachedWidth"] = 200,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["detachedWidth"] = 92,
							["attachTextTo"] = "Power",
							["text_format"] = "[power:current]",
							["xOffset"] = 0,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["pvpIcon"] = {
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["stagger"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 100,
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["style"] = "darkenInactive",
					["backdrop"] = false,
					["showGrid"] = true,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
					["backdropSpacing"] = 0,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonsize"] = 30,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["smallTextFontSize"] = 13,
				["fontSize"] = 13,
				["spellID"] = false,
			},
			["v11NamePlateReset"] = true,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["yOffset"] = 0,
							["hide"] = false,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["yOffset"] = 4,
							["xOffset"] = 4,
							["position"] = "BOTTOMLEFT",
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["b"] = 0.92,
					["g"] = 0.78,
					["r"] = 0.25,
				},
			},
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "기본 글꼴",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["panelColor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["panelHeight"] = 500,
				["emotionIcons"] = false,
				["timeStampFormat"] = "%H:%M",
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
		},
		["Skullflower"] = {
			["databars"] = {
				["artifact"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["height"] = 20,
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 1,
					["g"] = 0.49,
					["b"] = 0.04,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,359",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-176,-576",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-176,-576",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,435",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,5,668",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,499",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,311",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,335,434",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,189,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-189,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,325",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-503,280",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,188,557",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,378",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["v11NamePlateReset"] = true,
			["hideTutorial"] = true,
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["countFontSize"] = 13,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["horizontalSpacing"] = 2,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
					},
				},
				["fontOutline"] = "OUTLINE",
				["smartRaidFilter"] = false,
				["font"] = "기본 글꼴",
				["smoothbars"] = true,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 100,
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["width"] = 100,
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
							["sizeOverride"] = 19,
							["yOffset"] = -11,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 180,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 11,
							["xOffset"] = 1,
							["sizeOverride"] = 19,
							["yOffset"] = 10,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["sizeOverride"] = 46,
							["enable"] = false,
							["xOffset"] = -1,
							["attachTo"] = "Frame",
							["fontSize"] = 16,
							["yOffset"] = -8,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["detachedWidth"] = 200,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["pvpIcon"] = {
							["enable"] = true,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["power"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["detachedWidth"] = 92,
							["attachTextTo"] = "Power",
							["text_format"] = "[power:current]",
							["xOffset"] = 0,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["stagger"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["xOffset"] = 0,
							["damager"] = false,
							["enable"] = true,
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["sizeOverride"] = 26,
							["enable"] = false,
							["fontSize"] = 11,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["sizeOverride"] = 26,
							["fontSize"] = 11,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 20,
							["enable"] = false,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["position"] = "TOPLEFT",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["width"] = 50,
						["height"] = 25,
						["verticalSpacing"] = 1,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["backdrop"] = false,
					["style"] = "darkenInactive",
					["mouseover"] = true,
					["showGrid"] = true,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
					["backdropSpacing"] = 0,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonsize"] = 30,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["tooltip"] = {
				["fontSize"] = 13,
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["itemCount"] = "NONE",
				["smallTextFontSize"] = 13,
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "기본 글꼴",
				["countFontSize"] = 13,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFont"] = "기본 글꼴",
				["bagSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bagWidth"] = 400,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["itemLevelFontSize"] = 13,
				["bagBar"] = {
					["enable"] = false,
				},
				["alignToChat"] = false,
				["clearSearchOnClose"] = true,
			},
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["enable"] = true,
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["timeStampFormat"] = "%H:%M",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeight"] = 500,
				["emotionIcons"] = false,
				["tabFont"] = "기본 글꼴",
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
		},
		["악사다구 - 아즈샤라"] = {
			["currentTutorial"] = 1,
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["국제금융로 - 굴단"] = {
			["currentTutorial"] = 2,
			["general"] = {
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.80000001192093,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["a"] = 1,
					["r"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["bordercolor"] = {
					["r"] = 0.30588235294118,
					["g"] = 0.30588235294118,
					["b"] = 0.30588235294118,
				},
				["fontSize"] = 11,
				["reputation"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["height"] = 16,
					["width"] = 200,
				},
			},
			["movers"] = {
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,133",
				["ElvUF_RaidMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,51,120",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,50",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,250,-50",
				["BossButton"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-117,-298",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,249,-216",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,827",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-52",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,51,-87",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,143",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,392,1073",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,50",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvAB_4"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-394",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-186",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,305,50",
				["ReputationBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-228",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-50",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,140",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-122,-393",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,232",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,1150",
				["PetAB"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-428",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,184,773",
				["ElvAB_6"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-488,330",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,995",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,140",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,463,50",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,200",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-50",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,-305,50",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,51,937",
			},
			["v11NamePlateReset"] = true,
			["hideTutorial"] = true,
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 11,
					["durationFontSize"] = 11,
				},
				["font"] = "Expressway",
				["buffs"] = {
					["countFontSize"] = 11,
					["maxWraps"] = 2,
					["durationFontSize"] = 11,
				},
			},
			["unitframe"] = {
				["fontSize"] = 9,
				["fontOutline"] = "THICKOUTLINE",
				["font"] = "Expressway",
				["statusbar"] = "ElvUI Blank",
				["smoothbars"] = true,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["enable"] = true,
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["width"] = 122,
						},
						["height"] = 50,
						["portrait"] = {
							["camDistanceScale"] = 2,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 122,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 50,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "TOP",
							["yOffset"] = -2,
						},
						["width"] = 122,
					},
					["arena"] = {
						["spacing"] = 26,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["castbar"] = {
							["width"] = 246,
						},
					},
					["target"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["frequentUpdates"] = true,
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["castbar"] = {
							["iconAttached"] = false,
							["iconSize"] = 54,
						},
						["height"] = 80,
						["buffs"] = {
							["perrow"] = 7,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["smartAuraPosition"] = "DEBUFFS_ON_BUFFS",
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["raid40"] = {
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
					},
					["focus"] = {
						["infoPanel"] = {
							["enable"] = true,
							["height"] = 17,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
						},
						["castbar"] = {
							["iconSize"] = 26,
							["width"] = 122,
						},
						["height"] = 56,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["frequentUpdates"] = true,
							["text_format"] = "[healthcolor][health:current]",
						},
						["threatStyle"] = "NONE",
						["width"] = 189,
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["roleIcon"] = {
							["position"] = "RIGHT",
						},
						["debuffs"] = {
							["enable"] = true,
							["sizeOverride"] = 27,
							["perrow"] = 4,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
						},
						["growthDirection"] = "UP_RIGHT",
						["name"] = {
							["position"] = "LEFT",
						},
						["width"] = 140,
						["height"] = 28,
						["health"] = {
							["yOffset"] = -6,
						},
						["visibility"] = "[nogroup] hide;show",
						["groupsPerRowCol"] = 5,
					},
					["player"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["castbar"] = {
							["iconSize"] = 54,
							["height"] = 35,
							["iconAttached"] = false,
							["width"] = 478,
						},
						["height"] = 80,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["frequentUpdates"] = true,
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["classbar"] = {
							["height"] = 15,
							["autoHide"] = true,
						},
						["fader"] = {
							["enable"] = true,
							["minAlpha"] = 0,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 3,
						["debuffs"] = {
							["anchorPoint"] = "BOTTOM",
							["numrows"] = 4,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["enable"] = false,
						["healPrediction"] = {
							["enable"] = true,
						},
						["growthDirection"] = "RIGHT_DOWN",
						["infoPanel"] = {
							["enable"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name:short]",
							["position"] = "LEFT",
						},
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
						["height"] = 59,
						["verticalSpacing"] = 0,
						["width"] = 110,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["orientation"] = "VERTICAL",
							["text_format"] = "[healthcolor][health:current]",
							["position"] = "RIGHT",
						},
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["fontSize"] = 11,
				["font"] = "Expressway",
				["goldFormat"] = "SHORT",
				["panelTransparency"] = true,
				["leftChatPanel"] = false,
				["panels"] = {
					["LeftMiniPanel"] = "",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["rightChatPanel"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["bar6"] = {
					["buttonsize"] = 38,
				},
				["bar2"] = {
					["enabled"] = true,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar1"] = {
					["heightMult"] = 2,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar5"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["globalFadeAlpha"] = 0.87,
				["stanceBar"] = {
					["inheritGlobalFade"] = true,
				},
				["fontSize"] = 9,
				["bar4"] = {
					["enabled"] = false,
					["backdrop"] = false,
					["buttonsize"] = 38,
				},
			},
			["layoutSet"] = "dpsMelee",
			["tooltip"] = {
				["textFontSize"] = 11,
				["fontSize"] = 11,
				["healthBar"] = {
					["font"] = "Expressway",
				},
				["headerFontSize"] = 11,
				["font"] = "Expressway",
				["smallTextFontSize"] = 11,
			},
			["bags"] = {
				["countFontSize"] = 9,
				["itemLevelFontSize"] = 9,
			},
			["chat"] = {
				["chatHistory"] = false,
				["fontSize"] = 11,
				["tabFont"] = "Expressway",
				["panelColor"] = {
					["a"] = 0.80000001192093,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["tabFontSize"] = 11,
				["fadeUndockedTabs"] = false,
				["font"] = "Expressway",
				["fadeTabsNoBackdrop"] = false,
				["panelColorConverted"] = true,
				["editBoxPosition"] = "ABOVE_CHAT",
				["panelBackdrop"] = "HIDEBOTH",
			},
		},
		["Odfefe - 굴단"] = {
			["databars"] = {
				["artifact"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["textSize"] = 12,
					["fontOutline"] = "OUTLINE",
					["height"] = 20,
					["font"] = "Expressway",
					["mouseover"] = true,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
						["enable"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,359",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-176,-576",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-176,-576",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,435",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,5,668",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,188,557",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,499",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,311",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,335,434",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,189,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-189,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,325",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-503,280",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,378",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["v11NamePlateReset"] = true,
			["hideTutorial"] = true,
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["b"] = 0.631372549019608,
							["g"] = 0.450980392156863,
							["r"] = 0.309803921568627,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["ENERGY"] = {
							["b"] = 0.349019607843137,
							["g"] = 0.631372549019608,
							["r"] = 0.650980392156863,
						},
						["FOCUS"] = {
							["b"] = 0.270588235294118,
							["g"] = 0.431372549019608,
							["r"] = 0.709803921568628,
						},
						["RAGE"] = {
							["b"] = 0.250980392156863,
							["g"] = 0.250980392156863,
							["r"] = 0.780392156862745,
						},
					},
					["castColor"] = {
						["b"] = 0.8,
						["g"] = 0.8,
						["r"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["b"] = 0.850980392156863,
						["g"] = 0.792156862745098,
						["r"] = 0.764705882352941,
					},
					["health"] = {
						["b"] = 0.403921568627451,
						["g"] = 1,
						["r"] = 0.419607843137255,
					},
					["reaction"] = {
						["BAD"] = {
							["b"] = 0.195555555555556,
							["g"] = 0.137777777777778,
							["r"] = 1,
						},
						["NEUTRAL"] = {
							["b"] = 0.368627450980392,
							["g"] = 0.976470588235294,
							["r"] = 1,
						},
						["GOOD"] = {
							["b"] = 0.403921568627451,
							["g"] = 1,
							["r"] = 0.419607843137255,
						},
					},
					["disconnected"] = {
						["b"] = 0.850980392156863,
						["g"] = 0.792156862745098,
						["r"] = 0.764705882352941,
					},
					["castNoInterrupt"] = {
						["b"] = 0.195555555555556,
						["g"] = 0.137777777777778,
						["r"] = 1,
					},
					["health_backdrop"] = {
						["b"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["r"] = 0.0705882352941177,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [1]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [2]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [3]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [4]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [5]
							{
								["b"] = 0.588235294117647,
								["g"] = 1,
								["r"] = 0,
							}, -- [6]
						},
						["bgColor"] = {
							["b"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["r"] = 0.0705882352941177,
						},
					},
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "OUTLINE",
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["width"] = 100,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["insideInfoPanel"] = false,
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["power"] = {
							["enable"] = false,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["position"] = "TOPLEFT",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
						["width"] = 50,
						["height"] = 25,
						["verticalSpacing"] = 1,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 16,
						["width"] = 120,
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 100,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["enable"] = false,
							["yOffset"] = 20,
							["xOffset"] = 30,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["fontSize"] = 16,
							["enable"] = false,
							["xOffset"] = -1,
							["attachTo"] = "Frame",
							["sizeOverride"] = 46,
							["yOffset"] = -8,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["height"] = 15,
							["detachedWidth"] = 200,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["attachTextTo"] = "Power",
							["xOffset"] = 0,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["detachedWidth"] = 92,
							["detachFromFrame"] = true,
							["text_format"] = "[power:current]",
							["height"] = 15,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["pvpIcon"] = {
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["stagger"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["enable"] = true,
							["damager"] = false,
							["xOffset"] = 0,
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
						["width"] = 180,
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["power"] = {
							["text_format"] = "",
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 22,
							["xOffset"] = 1,
							["sizeOverride"] = 35,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["fontSize"] = 22,
							["xOffset"] = -3,
							["enable"] = false,
							["sizeOverride"] = 35,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["font"] = "기본 글꼴",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["style"] = "darkenInactive",
					["backdrop"] = false,
					["showGrid"] = true,
					["buttonsPerRow"] = 5,
					["backdropSpacing"] = 0,
					["buttonsize"] = 17,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["backdrop"] = false,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
					["backdropSpacing"] = 0,
				},
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["smallTextFontSize"] = 13,
				["fontSize"] = 13,
				["spellID"] = false,
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "기본 글꼴",
				["countFontSize"] = 13,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFont"] = "기본 글꼴",
				["bagBar"] = {
					["enable"] = false,
				},
				["countFontOutline"] = "OUTLINE",
				["bagSize"] = 28,
				["bagWidth"] = 400,
				["itemLevelFontSize"] = 13,
				["itemLevelFontOutline"] = "OUTLINE",
				["bankWidth"] = 400,
				["bankSize"] = 28,
				["alignToChat"] = false,
				["clearSearchOnClose"] = true,
			},
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["yOffset"] = 0,
							["hide"] = false,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["yOffset"] = 4,
							["xOffset"] = 4,
							["position"] = "BOTTOMLEFT",
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["b"] = 0.92,
					["g"] = 0.78,
					["r"] = 0.25,
				},
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
			},
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "기본 글꼴",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["b"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["r"] = 0.0705882352941177,
				},
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeight"] = 500,
				["emotionIcons"] = false,
				["timeStampFormat"] = "%H:%M",
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
		},
		["받아줘요악사 - 아즈샤라"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["height"] = 32,
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["enable"] = true,
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,305",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "TOP,ElvUIParent,TOP,300,-508",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,256",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,434",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,574,270",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-598,20",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["v11NamePlateReset"] = true,
			["hideTutorial"] = true,
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["classResources"] = {
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
					},
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "OUTLINE",
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 100,
					},
					["focustarget"] = {
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 180,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["threatStyle"] = "NONE",
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["damager"] = false,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["width"] = 50,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["verticalSpacing"] = 1,
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["enable"] = true,
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["enable"] = false,
							["yOffset"] = 20,
							["xOffset"] = 30,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 16,
							["sizeOverride"] = 0,
							["numrows"] = 3,
							["attachTo"] = "BUFFS",
							["yOffset"] = -1,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 92,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["height"] = 15,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["pvpIcon"] = {
							["enable"] = true,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["width"] = 200,
						["stagger"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["detachFromFrame"] = true,
							["powerPrediction"] = true,
							["xOffset"] = 0,
							["text_format"] = "[power:current]",
							["strataAndLevel"] = {
								["frameLevel"] = 2,
								["useCustomStrata"] = true,
							},
							["detachedWidth"] = 92,
							["druidMana"] = false,
							["attachTextTo"] = "Power",
							["height"] = 15,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "FRAME",
							["numrows"] = 3,
							["yOffset"] = -1,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["backdropSpacing"] = 0,
					["style"] = "darkenInactive",
					["showGrid"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 5,
					["backdrop"] = false,
					["buttonsize"] = 17,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["showGrid"] = true,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["backdrop"] = false,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
					["backdropSpacing"] = 0,
				},
			},
			["tooltip"] = {
				["fontSize"] = 13,
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["itemCount"] = "NONE",
				["smallTextFontSize"] = 13,
			},
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0.639214277267456,
					["g"] = 0.188234880566597,
					["b"] = 0.788233578205109,
				},
			},
			["bags"] = {
				["countFontSize"] = 13,
				["itemLevelFont"] = "기본 글꼴",
				["split"] = {
					["bagSpacing"] = 0,
				},
				["bagSize"] = 28,
				["itemLevelFontSize"] = 13,
				["alignToChat"] = false,
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagWidth"] = 400,
				["countFont"] = "기본 글꼴",
				["bagBar"] = {
					["enable"] = false,
				},
				["clearSearchOnClose"] = true,
			},
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "기본 글꼴",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["keywords"] = "%MYNAME%, ElvUI",
				["timeStampFormat"] = "%H:%M",
				["emotionIcons"] = false,
				["panelHeight"] = 500,
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
		},
		["쌩뚱마적 - 렉사르"] = {
			["currentTutorial"] = 1,
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["쌩뚱마장 - 렉사르"] = {
			["currentTutorial"] = 1,
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Minimalistic"] = {
			["currentTutorial"] = 2,
			["general"] = {
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.80000001192093,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["valuecolor"] = {
					["a"] = 1,
					["b"] = 1,
					["g"] = 1,
					["r"] = 1,
				},
				["bordercolor"] = {
					["b"] = 0.30588235294118,
					["g"] = 0.30588235294118,
					["r"] = 0.30588235294118,
				},
				["fontSize"] = 11,
				["reputation"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["height"] = 16,
					["width"] = 200,
				},
			},
			["movers"] = {
				["PetAB"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-428",
				["ElvUF_RaidMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,51,120",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,50",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,250,-50",
				["BossButton"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-117,-298",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,249,-216",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,827",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-52",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,51,-87",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,143",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,392,1073",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,50",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvAB_4"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-394",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-186",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,305,50",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,-305,50",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,51,937",
				["ReputationBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-228",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-122,-393",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,232",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,1150",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,133",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvAB_6"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-488,330",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,995",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,463,50",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,200",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,140",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,184,773",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-50",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,140",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-50",
			},
			["bags"] = {
				["countFontSize"] = 9,
				["itemLevelFontSize"] = 9,
			},
			["hideTutorial"] = true,
			["chat"] = {
				["chatHistory"] = false,
				["fontSize"] = 11,
				["tabFont"] = "Expressway",
				["panelColor"] = {
					["a"] = 0.80000001192093,
					["b"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["r"] = 0.058823529411765,
				},
				["tabFontSize"] = 11,
				["fadeUndockedTabs"] = false,
				["font"] = "Expressway",
				["fadeTabsNoBackdrop"] = false,
				["panelColorConverted"] = true,
				["editBoxPosition"] = "ABOVE_CHAT",
				["panelBackdrop"] = "HIDEBOTH",
			},
			["unitframe"] = {
				["fontSize"] = 9,
				["fontOutline"] = "THICKOUTLINE",
				["font"] = "Expressway",
				["smoothbars"] = true,
				["statusbar"] = "ElvUI Blank",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "TOP",
							["yOffset"] = -2,
						},
						["height"] = 50,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 122,
					},
					["player"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["castbar"] = {
							["iconSize"] = 54,
							["height"] = 35,
							["iconAttached"] = false,
							["width"] = 478,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["frequentUpdates"] = true,
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["height"] = 80,
						["fader"] = {
							["enable"] = true,
							["minAlpha"] = 0,
						},
						["classbar"] = {
							["height"] = 15,
							["autoHide"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["infoPanel"] = {
							["height"] = 14,
							["enable"] = true,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["portrait"] = {
							["camDistanceScale"] = 2,
						},
						["castbar"] = {
							["width"] = 122,
						},
						["height"] = 50,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["threatStyle"] = "NONE",
						["width"] = 122,
					},
					["raid"] = {
						["roleIcon"] = {
							["position"] = "RIGHT",
						},
						["debuffs"] = {
							["enable"] = true,
							["sizeOverride"] = 27,
							["perrow"] = 4,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
						},
						["growthDirection"] = "UP_RIGHT",
						["name"] = {
							["position"] = "LEFT",
						},
						["groupsPerRowCol"] = 5,
						["height"] = 28,
						["health"] = {
							["yOffset"] = -6,
						},
						["visibility"] = "[nogroup] hide;show",
						["width"] = 140,
					},
					["target"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["castbar"] = {
							["iconAttached"] = false,
							["iconSize"] = 54,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["frequentUpdates"] = true,
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["power"] = {
							["height"] = 15,
							["text_format"] = "[powercolor][power:current-max]",
							["attachTextTo"] = "InfoPanel",
						},
						["height"] = 80,
						["buffs"] = {
							["perrow"] = 7,
						},
						["smartAuraPosition"] = "DEBUFFS_ON_BUFFS",
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
					},
					["party"] = {
						["horizontalSpacing"] = 3,
						["debuffs"] = {
							["anchorPoint"] = "BOTTOM",
							["numrows"] = 4,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["enable"] = false,
						["healPrediction"] = {
							["enable"] = true,
						},
						["growthDirection"] = "RIGHT_DOWN",
						["infoPanel"] = {
							["enable"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name:short]",
							["position"] = "LEFT",
						},
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
						["height"] = 59,
						["verticalSpacing"] = 0,
						["width"] = 110,
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["orientation"] = "VERTICAL",
							["text_format"] = "[healthcolor][health:current]",
							["position"] = "RIGHT",
						},
					},
					["raid40"] = {
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
					},
					["focus"] = {
						["infoPanel"] = {
							["enable"] = true,
							["height"] = 17,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["frequentUpdates"] = true,
							["text_format"] = "[healthcolor][health:current]",
						},
						["castbar"] = {
							["iconSize"] = 26,
							["width"] = 122,
						},
						["height"] = 56,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
						},
						["threatStyle"] = "NONE",
						["width"] = 189,
					},
					["assist"] = {
						["enable"] = false,
					},
					["arena"] = {
						["spacing"] = 26,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["castbar"] = {
							["width"] = 246,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["fontSize"] = 11,
				["font"] = "Expressway",
				["goldFormat"] = "SHORT",
				["panelTransparency"] = true,
				["leftChatPanel"] = false,
				["panels"] = {
					["LeftMiniPanel"] = "",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["rightChatPanel"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["fontSize"] = 9,
				["bar2"] = {
					["enabled"] = true,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar1"] = {
					["heightMult"] = 2,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar5"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["globalFadeAlpha"] = 0.87,
				["stanceBar"] = {
					["inheritGlobalFade"] = true,
				},
				["bar6"] = {
					["buttonsize"] = 38,
				},
				["bar4"] = {
					["enabled"] = false,
					["backdrop"] = false,
					["buttonsize"] = 38,
				},
			},
			["layoutSet"] = "dpsMelee",
			["tooltip"] = {
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["healthBar"] = {
					["font"] = "Expressway",
				},
				["headerFontSize"] = 11,
				["fontSize"] = 11,
				["smallTextFontSize"] = 11,
			},
			["v11NamePlateReset"] = true,
			["auras"] = {
				["debuffs"] = {
					["countFontSize"] = 11,
					["durationFontSize"] = 11,
				},
				["font"] = "Expressway",
				["buffs"] = {
					["countFontSize"] = 11,
					["maxWraps"] = 2,
					["durationFontSize"] = 11,
				},
			},
		},
		["아호와의증인 - 아즈샤라"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["height"] = 32,
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0,
					["g"] = 0.999997794628143,
					["b"] = 0.588234007358551,
				},
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,359",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-297,-476",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-297,-476",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-450,435",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,6,668",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,760,500",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,311",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,300,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-300,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,325",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-598,20",
				["ElvUF_TargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-760,434",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["PlayerPowerBarMover"] = "TOP,ElvUIParent,TOP,300,-525",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,1183,379",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["bags"] = {
				["countFontSize"] = 13,
				["itemLevelFont"] = "기본 글꼴",
				["split"] = {
					["bagSpacing"] = 0,
				},
				["bagSize"] = 28,
				["itemLevelFontSize"] = 13,
				["alignToChat"] = false,
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["bagWidth"] = 400,
				["countFont"] = "기본 글꼴",
				["bagBar"] = {
					["enable"] = false,
				},
				["clearSearchOnClose"] = true,
			},
			["hideTutorial"] = true,
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "기본 글꼴",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["keywords"] = "%MYNAME%, ElvUI",
				["timeStampFormat"] = "%H:%M",
				["emotionIcons"] = false,
				["panelHeight"] = 500,
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["classResources"] = {
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
					},
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "OUTLINE",
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["width"] = 100,
					},
					["focustarget"] = {
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["insideInfoPanel"] = false,
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 260,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["power"] = {
							["text_format"] = "",
						},
						["width"] = 180,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["threatStyle"] = "NONE",
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["damager"] = false,
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
						["width"] = 50,
						["height"] = 25,
						["verticalSpacing"] = 1,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["enable"] = true,
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["enable"] = false,
							["yOffset"] = 20,
							["xOffset"] = 30,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 35,
							["xOffset"] = 1,
							["fontSize"] = 22,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["sizeOverride"] = 35,
							["enable"] = false,
							["xOffset"] = -3,
							["fontSize"] = 22,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["fontSize"] = 16,
							["xOffset"] = -1,
							["enable"] = false,
							["attachTo"] = "Frame",
							["sizeOverride"] = 46,
							["yOffset"] = -8,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 200,
							["height"] = 15,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["pvpIcon"] = {
							["enable"] = true,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["width"] = 200,
						["stagger"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["power"] = {
							["detachFromFrame"] = true,
							["xOffset"] = 0,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["height"] = 15,
							["attachTextTo"] = "Power",
							["text_format"] = "[power:current]",
							["detachedWidth"] = 92,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["font"] = "기본 글꼴",
				["barPet"] = {
					["style"] = "darkenInactive",
					["backdropSpacing"] = 0,
					["point"] = "BOTTOMLEFT",
					["showGrid"] = true,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
					["backdrop"] = false,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["showGrid"] = true,
					["backdropSpacing"] = 0,
					["mouseover"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["backdrop"] = false,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["buttonsize"] = 30,
					["backdropSpacing"] = 0,
				},
			},
			["tooltip"] = {
				["fontSize"] = 13,
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["itemCount"] = "NONE",
				["smallTextFontSize"] = 13,
			},
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["enable"] = true,
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["v11NamePlateReset"] = true,
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
		},
		["굴단"] = {
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1093",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,350",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,402",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focustarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pet"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["boss"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["focus"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["target"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["player"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
				},
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["공허엘프닷 - 굴단"] = {
			["databars"] = {
				["artifact"] = {
					["height"] = 20,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 220,
				},
				["reputation"] = {
					["textFormat"] = "PERCENT",
					["enable"] = true,
					["mouseover"] = true,
					["width"] = 395,
					["font"] = "Expressway",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["textSize"] = 12,
					["orientation"] = "HORIZONTAL",
				},
				["experience"] = {
					["textFormat"] = "PERCENT",
					["orientation"] = "HORIZONTAL",
					["fontOutline"] = "OUTLINE",
					["height"] = 32,
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
				["honor"] = {
					["height"] = 32,
					["textFormat"] = "PERCENT",
					["mouseover"] = true,
					["fontOutline"] = "OUTLINE",
					["orientation"] = "HORIZONTAL",
					["font"] = "Expressway",
					["textSize"] = 12,
					["width"] = 395,
				},
			},
			["currentTutorial"] = 9,
			["general"] = {
				["totems"] = {
					["enable"] = false,
					["spacing"] = 3,
				},
				["threat"] = {
					["enable"] = false,
				},
				["interruptAnnounce"] = "SAY",
				["talkingHeadFrameScale"] = 0.75,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["autoRepair"] = "PLAYER",
				["minimap"] = {
					["locationFontSize"] = 14,
					["locationFont"] = "기본 글꼴",
					["icons"] = {
						["mail"] = {
							["xOffset"] = -2,
							["hide"] = false,
							["yOffset"] = 0,
						},
						["lfgEye"] = {
							["scale"] = 0.75,
							["position"] = "BOTTOMLEFT",
							["xOffset"] = 4,
							["yOffset"] = 4,
						},
						["classHall"] = {
							["scale"] = 0.6,
							["position"] = "BOTTOMRIGHT",
						},
						["vehicleLeave"] = {
							["size"] = 40,
						},
					},
					["size"] = 150,
				},
				["fontSize"] = 15,
				["font"] = "기본 글꼴",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["numberPrefixStyle"] = "KOREAN",
				["objectiveFrameHeight"] = 500,
				["backdropcolor"] = {
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["valuecolor"] = {
					["r"] = 0.639214277267456,
					["g"] = 0.188234880566597,
					["b"] = 0.7882335782051086,
				},
			},
			["movers"] = {
				["ElvUF_FocusCastbarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,320",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,207",
				["PetAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,359",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-82",
				["BuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-32",
				["TargetPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,250,301",
				["MinimapMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,-1",
				["BossButton"] = "TOP,ElvUIParent,TOP,-176,-576",
				["LootFrameMover"] = "TOP,ElvUIParent,TOP,0,-275",
				["ZoneAbility"] = "TOP,ElvUIParent,TOP,-176,-576",
				["DebuffsMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-264,-134",
				["PlayerPowerBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,188,557",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,5,668",
				["ElvUIBagMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-6,34",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,432,30",
				["ElvUF_FocusMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-568,334",
				["ElvUF_FocusTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-569,363",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-107",
				["ClassBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,499",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-30",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,311",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-183",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,335,434",
				["ExperienceBarMover"] = "TOP,ElvUIParent,TOP,0,-1",
				["ArenaHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-385,-285",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-570,386",
				["RaidUtility_Mover"] = "BOTTOM,ElvUIParent,BOTTOM,-59,155",
				["LossControlMover"] = "TOP,ElvUIParent,TOP,0,-490",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,379",
				["CM_MOVER"] = "BOTTOM,ElvUIParent,BOTTOM,0,150",
				["VOICECHAT"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-61",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,189,434",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,-189,434",
				["ElvUF_TargetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,240,263",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-155",
				["ElvAB_4"] = "BOTTOM,ElvUIParent,BOTTOM,-170,193",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,170,193",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-100",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,-230,193",
				["ReputationBarMover"] = "TOP,ElvUIParent,TOP,0,-34",
				["ArtifactBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,503",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,571,325",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-240,263",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-52,-32",
				["BNETMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-30,206",
				["ShiftAB"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,509,31",
				["SquareMinimapButtonBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-204",
				["HonorBarMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvAB_6"] = "BOTTOM,ElvUIParent,BOTTOM,230,193",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-598,20",
				["ElvUIBankMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,6,31",
				["BossHeaderMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-390,-285",
				["WatchFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-30,-300",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-335,435",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,940,378",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-250",
				["ComboBarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-220,342",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,30,-340",
			},
			["v11NamePlateReset"] = true,
			["hideTutorial"] = true,
			["auras"] = {
				["debuffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["fontOutline"] = "OUTLINE",
				["buffs"] = {
					["horizontalSpacing"] = 2,
					["durationFontSize"] = 13,
					["maxWraps"] = 2,
					["countFontSize"] = 13,
					["size"] = 34,
				},
				["timeYOffset"] = -1,
				["font"] = "기본 글꼴",
			},
			["gridsize"] = 128,
			["unitframe"] = {
				["fontSize"] = 11,
				["colors"] = {
					["power"] = {
						["MANA"] = {
							["r"] = 0.309803921568627,
							["g"] = 0.450980392156863,
							["b"] = 0.631372549019608,
						},
						["RUNIC_POWER"] = {
							["g"] = 0.819607843137255,
						},
						["RAGE"] = {
							["r"] = 0.780392156862745,
							["g"] = 0.250980392156863,
							["b"] = 0.250980392156863,
						},
						["FOCUS"] = {
							["r"] = 0.709803921568628,
							["g"] = 0.431372549019608,
							["b"] = 0.270588235294118,
						},
						["ENERGY"] = {
							["r"] = 0.650980392156863,
							["g"] = 0.631372549019608,
							["b"] = 0.349019607843137,
						},
					},
					["castColor"] = {
						["r"] = 0.8,
						["g"] = 0.8,
						["b"] = 0.8,
					},
					["colorhealthbyvalue"] = false,
					["healthclass"] = true,
					["customhealthbackdrop"] = true,
					["tapped"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["health"] = {
						["r"] = 0.419607843137255,
						["g"] = 1,
						["b"] = 0.403921568627451,
					},
					["reaction"] = {
						["BAD"] = {
							["r"] = 1,
							["g"] = 0.137777777777778,
							["b"] = 0.195555555555556,
						},
						["NEUTRAL"] = {
							["r"] = 1,
							["g"] = 0.976470588235294,
							["b"] = 0.368627450980392,
						},
						["GOOD"] = {
							["r"] = 0.419607843137255,
							["g"] = 1,
							["b"] = 0.403921568627451,
						},
					},
					["disconnected"] = {
						["r"] = 0.764705882352941,
						["g"] = 0.792156862745098,
						["b"] = 0.850980392156863,
					},
					["castNoInterrupt"] = {
						["r"] = 1,
						["g"] = 0.137777777777778,
						["b"] = 0.195555555555556,
					},
					["health_backdrop"] = {
						["r"] = 0.0705882352941177,
						["g"] = 0.0705882352941177,
						["b"] = 0.0705882352941177,
					},
					["classResources"] = {
						["MONK"] = {
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [1]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [2]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [3]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [4]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [5]
							{
								["r"] = 0,
								["g"] = 1,
								["b"] = 0.588235294117647,
							}, -- [6]
						},
						["bgColor"] = {
							["r"] = 0.0705882352941177,
							["g"] = 0.0705882352941177,
							["b"] = 0.0705882352941177,
						},
					},
				},
				["smartRaidFilter"] = false,
				["fontOutline"] = "OUTLINE",
				["smoothbars"] = true,
				["font"] = "기본 글꼴",
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettargettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["targettarget"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["power"] = {
							["enable"] = false,
						},
						["height"] = 35,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["width"] = 100,
					},
					["pet"] = {
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["iconAttached"] = false,
							["height"] = 15,
							["icon"] = false,
							["width"] = 100,
						},
						["width"] = 100,
						["power"] = {
							["enable"] = false,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["insideInfoPanel"] = false,
						["height"] = 35,
						["buffIndicator"] = {
							["enable"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
					},
					["focustarget"] = {
						["name"] = {
							["text_format"] = "[name:medium]",
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["enable"] = true,
						["health"] = {
							["frequentUpdates"] = true,
						},
						["height"] = 16,
						["width"] = 120,
					},
					["pettarget"] = {
						["health"] = {
							["frequentUpdates"] = true,
						},
					},
					["arena"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = -11,
						},
						["castbar"] = {
							["spark"] = false,
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 180,
						},
						["width"] = 180,
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:current] | [health:percent]",
							["position"] = "RIGHT",
						},
						["spacing"] = 20,
						["height"] = 30,
						["buffs"] = {
							["anchorPoint"] = "RIGHT",
							["sizeOverride"] = 19,
							["xOffset"] = 1,
							["fontSize"] = 11,
							["yOffset"] = 10,
						},
						["power"] = {
							["text_format"] = "",
						},
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
					},
					["assist"] = {
						["enable"] = false,
					},
					["player"] = {
						["debuffs"] = {
							["anchorPoint"] = "LEFT",
							["fontSize"] = 16,
							["xOffset"] = -1,
							["enable"] = false,
							["attachTo"] = "Frame",
							["sizeOverride"] = 46,
							["yOffset"] = -8,
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["classbar"] = {
							["detachFromFrame"] = true,
							["detachedWidth"] = 200,
							["height"] = 15,
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
						["threatStyle"] = "NONE",
						["power"] = {
							["attachTextTo"] = "Power",
							["detachedWidth"] = 92,
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["druidMana"] = false,
							["height"] = 15,
							["detachFromFrame"] = true,
							["text_format"] = "[power:current]",
							["xOffset"] = 0,
						},
						["customTexts"] = {
							[""] = {
								["attachTextTo"] = "Health",
								["enable"] = false,
								["text_format"] = "[health:current]",
								["yOffset"] = 0,
								["font"] = "기본 글꼴",
								["justifyH"] = "CENTER",
								["fontOutline"] = "OUTLINE",
								["xOffset"] = 0,
								["size"] = 11,
							},
						},
						["pvpIcon"] = {
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["castbar"] = {
							["spark"] = false,
							["width"] = 200,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["latency"] = false,
						},
						["name"] = {
							["text_format"] = "[name:long]",
							["position"] = "LEFT",
						},
						["stagger"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["enable"] = true,
							["attachTo"] = "Frame",
							["yOffset"] = 4,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "[health:current]",
							["position"] = "RIGHT",
						},
						["pvp"] = {
							["text_format"] = "",
						},
					},
					["raid40"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["xOffset"] = 30,
							["yOffset"] = 10,
							["size"] = 20,
						},
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid31,noexists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["position"] = "TOPLEFT",
							["enable"] = true,
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
					},
					["focus"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 15,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 120,
						},
						["width"] = 120,
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["height"] = 30,
						["power"] = {
							["enable"] = false,
							["height"] = 3,
						},
						["health"] = {
							["frequentUpdates"] = true,
						},
						["name"] = {
							["text_format"] = "[name:medium]",
						},
					},
					["target"] = {
						["debuffs"] = {
							["anchorPoint"] = "TOPLEFT",
							["fontSize"] = 11,
							["enable"] = false,
							["sizeOverride"] = 26,
							["attachTo"] = "FRAME",
							["yOffset"] = 31,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["spark"] = false,
							["height"] = 17,
							["format"] = "Remaining",
							["icon"] = false,
							["width"] = 200,
						},
						["customTexts"] = {
							["NameText"] = {
								["justifyH"] = "Left",
								["yOffset"] = 4,
								["xOffset"] = 4,
								["enable"] = true,
								["text_format"] = "[name:long]",
								["size"] = 14,
							},
							["HealthText"] = {
								["justifyH"] = "Right",
								["yOffset"] = 5,
								["xOffset"] = -6,
								["enable"] = true,
								["text_format"] = "[health:current]",
								["size"] = 32,
							},
						},
						["portrait"] = {
							["overlay"] = true,
							["enable"] = true,
						},
						["width"] = 200,
						["infoPanel"] = {
							["enable"] = true,
							["transparent"] = true,
						},
						["fader"] = {
							["enable"] = false,
							["range"] = false,
						},
						["health"] = {
							["frequentUpdates"] = true,
							["text_format"] = "",
						},
						["power"] = {
							["detachedWidth"] = 220,
							["text_format"] = "[health:percent]",
							["strataAndLevel"] = {
								["useCustomStrata"] = true,
							},
							["yOffset"] = -22,
						},
						["height"] = 60,
						["buffs"] = {
							["anchorPoint"] = "BOTTOMLEFT",
							["fontSize"] = 11,
							["sizeOverride"] = 26,
							["attachTo"] = "POWER",
							["yOffset"] = -1,
						},
						["name"] = {
							["text_format"] = "",
							["position"] = "LEFT",
						},
						["aurabar"] = {
							["attachTo"] = "FRAME",
							["height"] = 18,
							["yOffset"] = 2,
						},
					},
					["raid"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["enable"] = true,
							["yOffset"] = -20,
							["attachTo"] = "Frame",
							["perrow"] = 1,
						},
						["power"] = {
							["enable"] = false,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
							["fontOutline"] = "OUTLINE",
							["enable"] = false,
							["yOffset"] = 20,
							["xOffset"] = 30,
							["size"] = 20,
						},
						["numGroups"] = 6,
						["width"] = 50,
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["health"] = {
							["attachTextTo"] = "Frame",
							["position"] = "CENTER",
							["text_format"] = "",
							["yOffset"] = 0,
						},
						["height"] = 25,
						["verticalSpacing"] = 1,
						["visibility"] = "[@raid6,noexists][@raid31,exists] hide;show",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["yOffset"] = 0,
							["xOffset"] = 0,
							["damager"] = false,
						},
					},
					["party"] = {
						["horizontalSpacing"] = 1,
						["debuffs"] = {
							["anchorPoint"] = "TOPRIGHT",
							["sizeOverride"] = 20,
							["onlyDispellable"] = true,
							["yOffset"] = -20,
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["rdebuffs"] = {
							["font"] = "기본 글꼴",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["roleIcon"] = {
							["attachTo"] = "Frame",
							["damager"] = false,
							["position"] = "TOPLEFT",
						},
						["name"] = {
							["attachTextTo"] = "Frame",
							["text_format"] = "[name:medium]",
						},
						["width"] = 50,
						["height"] = 25,
						["buffs"] = {
							["xOffset"] = -47,
							["sizeOverride"] = 20,
							["anchorPoint"] = "RIGHT",
							["perrow"] = 2,
						},
						["verticalSpacing"] = 1,
						["health"] = {
							["attachTextTo"] = "Frame",
							["xOffset"] = 0,
							["text_format"] = "",
							["position"] = "CENTER",
						},
					},
					["boss"] = {
						["debuffs"] = {
							["anchorPoint"] = "RIGHT",
							["fontSize"] = 22,
							["xOffset"] = 1,
							["sizeOverride"] = 35,
							["numrows"] = 1,
							["yOffset"] = 0,
						},
						["castbar"] = {
							["height"] = 10,
							["format"] = "",
							["icon"] = false,
							["width"] = 175,
						},
						["width"] = 175,
						["name"] = {
							["xOffset"] = 4,
							["text_format"] = "[name:medium]",
							["position"] = "LEFT",
						},
						["spacing"] = 20,
						["height"] = 35,
						["buffs"] = {
							["fontSize"] = 22,
							["xOffset"] = -3,
							["enable"] = false,
							["sizeOverride"] = 35,
							["yOffset"] = 0,
						},
						["health"] = {
							["xOffset"] = -4,
							["frequentUpdates"] = true,
							["text_format"] = "[health:percent]",
							["position"] = "RIGHT",
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
					},
				},
			},
			["datatexts"] = {
				["fontSize"] = 15,
				["fontOutline"] = "OUTLINE",
				["panelTransparency"] = true,
				["font"] = "기본 글꼴",
				["panels"] = {
					["LeftMiniPanel"] = "Time",
					["RightMiniPanel"] = "BfA Missions",
					["RightChatDataPanel"] = {
						["middle"] = "Bags",
					},
					["BottomMiniPanel"] = "Time",
					["LeftChatDataPanel"] = {
						["left"] = "Time",
						["right"] = "Talent/Loot Specialization",
					},
				},
				["battleground"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["fontSize"] = 12,
				["extraActionButton"] = {
					["scale"] = 0.75,
				},
				["bar2"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar1"] = {
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 3,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar5"] = {
					["point"] = "TOPLEFT",
					["buttons"] = 12,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["bar6"] = {
					["enabled"] = true,
					["point"] = "TOPLEFT",
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["buttonsize"] = 30,
				},
				["font"] = "기본 글꼴",
				["barPet"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["style"] = "darkenInactive",
					["backdrop"] = false,
					["showGrid"] = true,
					["buttonsPerRow"] = 5,
					["buttonsize"] = 17,
					["backdropSpacing"] = 0,
				},
				["fontOutline"] = "OUTLINE",
				["macrotext"] = true,
				["stanceBar"] = {
					["point"] = "BOTTOMLEFT",
					["buttonspacing"] = 1,
					["mouseover"] = true,
					["backdropSpacing"] = 0,
					["showGrid"] = true,
				},
				["microbar"] = {
					["enabled"] = true,
					["buttonsPerRow"] = 12,
					["mouseover"] = true,
				},
				["bar4"] = {
					["point"] = "TOPLEFT",
					["buttonsize"] = 30,
					["buttonspacing"] = 1,
					["buttonsPerRow"] = 2,
					["backdropSpacing"] = 0,
					["backdrop"] = false,
				},
			},
			["tooltip"] = {
				["itemCount"] = "NONE",
				["healthBar"] = {
					["height"] = 0,
					["font"] = "기본 글꼴",
					["fontSIze"] = 11,
					["text"] = false,
				},
				["headerFontSize"] = 13,
				["textFontSize"] = 13,
				["font"] = "기본 글꼴",
				["fontOutline"] = "OUTLINE",
				["spellID"] = false,
				["fontSize"] = 13,
				["smallTextFontSize"] = 13,
			},
			["bags"] = {
				["junkIcon"] = true,
				["moneyCoins"] = false,
				["itemLevelFont"] = "기본 글꼴",
				["countFontSize"] = 13,
				["vendorGrays"] = {
					["enable"] = true,
				},
				["countFont"] = "기본 글꼴",
				["bagSize"] = 28,
				["countFontOutline"] = "OUTLINE",
				["bankSize"] = 28,
				["bagWidth"] = 400,
				["bankWidth"] = 400,
				["itemLevelFontOutline"] = "OUTLINE",
				["itemLevelFontSize"] = 13,
				["bagBar"] = {
					["enable"] = false,
				},
				["alignToChat"] = false,
				["clearSearchOnClose"] = true,
			},
			["sle"] = {
				["raidmarkers"] = {
					["enable"] = false,
					["backdrop"] = true,
				},
				["media"] = {
					["fonts"] = {
						["gossip"] = {
							["font"] = "Expressway",
						},
						["zone"] = {
							["font"] = "Expressway",
						},
						["subzone"] = {
							["font"] = "Expressway",
						},
						["pvp"] = {
							["font"] = "Expressway",
						},
						["objectiveHeader"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
							["size"] = 16,
						},
						["mail"] = {
							["font"] = "Expressway",
						},
						["editbox"] = {
							["font"] = "Expressway",
						},
						["objective"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
						["questFontSuperHuge"] = {
							["outline"] = "OUTLINE",
							["font"] = "Expressway",
						},
					},
				},
				["blizzard"] = {
					["rumouseover"] = true,
				},
				["bags"] = {
					["artifactPower"] = {
						["enable"] = true,
						["short"] = true,
						["fonts"] = {
							["font"] = "Expressway",
						},
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconsize"] = 22,
						["iconmouseover"] = true,
						["spacing"] = 3,
					},
				},
				["datatexts"] = {
					["chathandle"] = false,
				},
				["unitframes"] = {
					["roleicons"] = "MiirGui",
				},
				["tooltip"] = {
					["RaidProg"] = {
						["enable"] = true,
					},
				},
				["Armory"] = {
					["Character"] = {
						["Artifact"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
						["Durability"] = {
							["Font"] = "Expressway",
						},
						["Enchant"] = {
							["Font"] = "Expressway",
						},
					},
					["Inspect"] = {
						["Enchant"] = {
							["Font"] = "Expressway",
						},
						["Level"] = {
							["Font"] = "Expressway",
						},
					},
				},
				["pvp"] = {
					["autorelease"] = true,
				},
			},
			["chat"] = {
				["fontSize"] = 13,
				["tabFontOutline"] = "OUTLINE",
				["tabFont"] = "기본 글꼴",
				["tabFontSize"] = 15,
				["lfgIcons"] = false,
				["panelColorConverted"] = true,
				["fontOutline"] = "OUTLINE",
				["panelWidthRight"] = 400,
				["panelColor"] = {
					["a"] = 0.85,
					["r"] = 0.0705882352941177,
					["g"] = 0.0705882352941177,
					["b"] = 0.0705882352941177,
				},
				["panelHeightRight"] = 175,
				["font"] = "기본 글꼴",
				["keywords"] = "%MYNAME%, ElvUI",
				["panelHeight"] = 500,
				["emotionIcons"] = false,
				["timeStampFormat"] = "%H:%M",
				["tapFontSize"] = 13,
				["panelWidth"] = 450,
			},
		},
	},
}
ElvPrivateDB = {
	["profileKeys"] = {
		["쌩뚱마삼 - 렉사르"] = "쌩뚱마삼 - 렉사르",
		["쌩뚱악사 - 렉사르"] = "쌩뚱악사 - 렉사르",
		["쌩뚱마꾼 - 렉사르"] = "쌩뚱마꾼 - 렉사르",
		["쌩뚱마죠 - 렉사르"] = "쌩뚱마죠 - 렉사르",
		["오지져스 - 렉사르"] = "오지져스 - 렉사르",
		["뉘시빨라마 - 굴단"] = "뉘시빨라마 - 굴단",
		["아놀드클래식 - 렉사르"] = "아놀드클래식 - 렉사르",
		["닌자창고 - 렉사르"] = "닌자창고 - 렉사르",
		["Udiess - 굴단"] = "Udiess - 굴단",
		["오우지져스 - 렉사르"] = "오우지져스 - 렉사르",
		["악사다구 - 아즈샤라"] = "악사다구 - 아즈샤라",
		["국제금융로 - 굴단"] = "국제금융로 - 굴단",
		["Odfefe - 굴단"] = "Odfefe - 굴단",
		["쌩뚱마장 - 렉사르"] = "쌩뚱마장 - 렉사르",
		["쌩뚱마적 - 렉사르"] = "쌩뚱마적 - 렉사르",
		["받아줘요악사 - 아즈샤라"] = "받아줘요악사 - 아즈샤라",
		["완소야드 - 굴단"] = "Skullflower",
		["아호와의증인 - 아즈샤라"] = "아호와의증인 - 아즈샤라",
		["무시중한디 - 굴단"] = "Skullflower",
		["공허엘프닷 - 굴단"] = "공허엘프닷 - 굴단",
	},
	["profiles"] = {
		["쌩뚱마삼 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["쌩뚱악사 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["쌩뚱마꾼 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["쌩뚱마죠 - 렉사르"] = {
			["sle"] = {
				["characterGoldsSorting"] = {
					["렉사르"] = {
					},
				},
				["pvpreadydialogreset"] = true,
			},
			["install_complete"] = "10.92",
		},
		["오지져스 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["무시중한디 - 굴단"] = {
			["sle"] = {
				["characterGoldsSorting"] = {
					["굴단"] = {
					},
				},
				["install_complete"] = "3.35",
			},
			["general"] = {
				["chatBubbleFontSize"] = 12,
				["normTex"] = "Skullflower",
				["dmgfont"] = "Expressway",
				["chatBubbleFontOutline"] = "OUTLINE",
				["chatBubbleFont"] = "Expressway",
				["namefont"] = "Expressway",
				["glossTex"] = "Skullflower",
			},
			["theme"] = "SkullflowerUI",
			["install_complete"] = "10.73",
		},
		["아놀드클래식 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["닌자창고 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["오우지져스 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["Udiess - 굴단"] = {
			["install_complete"] = "10.82",
		},
		["Skullflower"] = {
			["install_complete"] = "11.23",
		},
		["악사다구 - 아즈샤라"] = {
			["install_complete"] = "11.12",
		},
		["국제금융로 - 굴단"] = {
			["benikui"] = {
				["session"] = {
					["day"] = 6,
				},
			},
			["install_complete"] = "10.75",
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["characterGoldsSorting"] = {
					["굴단"] = {
					},
				},
				["install_complete"] = "BETA",
			},
			["dashboards"] = {
				["tokens"] = {
					["chooseTokens"] = {
						[416] = false,
						[828] = false,
						[515] = false,
						[1534] = false,
						[361] = false,
						[1101] = false,
						[1357] = false,
						[1172] = false,
						[789] = false,
						[980] = false,
						[1129] = false,
						[1275] = false,
						[738] = false,
						[1149] = false,
						[994] = false,
						[1535] = false,
						[614] = false,
						[1416] = false,
						[944] = false,
						[1173] = false,
						[754] = false,
						[752] = false,
						[821] = false,
						[823] = false,
						[1508] = false,
						[697] = false,
						[829] = false,
						[1268] = false,
						[1587] = false,
						[1342] = false,
						[391] = false,
						[776] = false,
						[393] = false,
						[1355] = false,
						[384] = false,
						[1174] = false,
						[397] = false,
						[398] = false,
						[399] = false,
						[400] = false,
						[401] = false,
						[394] = false,
						[385] = false,
						[1273] = false,
						[676] = false,
						[615] = false,
						[1155] = false,
						[1154] = false,
						[1226] = false,
						[1356] = false,
						[1299] = false,
						[677] = false,
						[61] = false,
						[1716] = false,
						[1191] = false,
						[1314] = false,
					},
				},
			},
		},
		["Odfefe - 굴단"] = {
			["install_complete"] = "10.82",
		},
		["쌩뚱마장 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["쌩뚱마적 - 렉사르"] = {
			["install_complete"] = "11.12",
		},
		["받아줘요악사 - 아즈샤라"] = {
			["install_complete"] = "11.12",
		},
		["완소야드 - 굴단"] = {
			["general"] = {
				["chatBubbleFontSize"] = 12,
				["normTex"] = "Skullflower",
				["dmgfont"] = "Expressway",
				["chatBubbleFontOutline"] = "OUTLINE",
				["chatBubbleFont"] = "Expressway",
				["namefont"] = "Expressway",
				["glossTex"] = "Skullflower",
			},
			["sle"] = {
				["characterGoldsSorting"] = {
					["굴단"] = {
					},
				},
				["pvpreadydialogreset"] = true,
			},
			["theme"] = "SkullflowerUI",
		},
		["아호와의증인 - 아즈샤라"] = {
			["install_complete"] = "11.12",
		},
		["뉘시빨라마 - 굴단"] = {
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["bags"] = {
					["transparentSlots"] = true,
				},
				["characterGoldsSorting"] = {
					["굴단"] = {
					},
				},
				["actionbars"] = {
					["transparentBackdrop"] = true,
					["transparentButtons"] = true,
				},
			},
			["install_complete"] = "11.02",
		},
		["공허엘프닷 - 굴단"] = {
			["install_complete"] = "10.82",
		},
	},
}
