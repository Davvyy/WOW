
ShinyBuffsDB = {
	["whoCast"] = true,
	["sbar"] = "Solid",
	["fstyle"] = "Outline",
	["allWhiteText"] = true,
	["border"] = "Devil2",
	["bprow"] = 14,
	["bgColor"] = {
		["b"] = 0.32,
		["g"] = 0.32,
		["r"] = 0.32,
	},
	["posX"] = -20,
	["bg"] = "Solid",
	["posY"] = -30,
	["borColor"] = {
		["b"] = 1,
		["g"] = 1,
		["r"] = 1,
	},
	["debuffs"] = {
		["size"] = 40,
		["cfsize"] = 14,
		["dfsize"] = 12,
	},
	["font"] = "기본 글꼴",
	["borAlpha"] = 0.4,
	["classbg"] = false,
	["sbarColor"] = {
		["b"] = 0,
		["g"] = 1,
		["r"] = 0,
	},
	["buffs"] = {
		["size"] = 36,
		["cfsize"] = 14,
		["dfsize"] = 12,
	},
	["classbor"] = false,
	["classbar"] = false,
}
