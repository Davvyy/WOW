
CastbarsDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
			["char"] = {
				["아라스틴 - 아즈샤라"] = {
					"Wide", -- [1]
					"Wide", -- [2]
					"Wide", -- [3]
					["enabled"] = true,
				},
			},
		},
	},
	["profileKeys"] = {
		["아테리에 - 아즈샤라"] = "Wide",
		["아라스틴 - 아즈샤라"] = "Wide",
		["Eldersign - 아즈샤라"] = "Wide",
		["내꿈은샤먼킹 - 데스윙"] = "Wide",
		["레이스가드 - 아즈샤라"] = "Wide",
		["실베르투스 - 아즈샤라"] = "Wide",
		["Vindictus - 아즈샤라"] = "Wide",
		["이솔레스테 - 아즈샤라"] = "Wide",
		["아이루릴 - 아즈샤라"] = "Wide",
		["시에이레 - 듀로탄"] = "Wide",
		["Isolesty - 아즈샤라"] = "Wide",
	},
	["profiles"] = {
		["Normal"] = {
			["FocusCastingBarFrame"] = {
				["FontSize"] = 12,
				["BorderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.659999996423721, -- [4]
				},
				["BarColor"] = {
					1, -- [1]
					0.670588235294118, -- [2]
					0.254901960784314, -- [3]
				},
				["Position"] = {
					["y"] = 500,
					["x"] = 320,
				},
				["Border"] = "Devil",
				["Width"] = 150,
				["Show"] = true,
				["Font"] = "기본 글꼴",
				["Height"] = 16,
				["BorderWidthAdjustment"] = -3,
				["ShowShield"] = true,
				["BorderOffsetAdjustment"] = 3,
				["FontOutline"] = false,
				["Texture"] = "Glamour7",
			},
			["MirrorTimer"] = {
				["FontSize"] = 12,
				["Font"] = "기본 글꼴",
				["BorderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.659999996423721, -- [4]
				},
				["BorderWidthAdjustment"] = -2,
				["Height"] = 20,
				["BorderOffsetAdjustment"] = 1,
				["Border"] = "Devil",
				["Texture"] = "Glamour7",
			},
			["CastingBarFrame"] = {
				["FontSize"] = 14,
				["FontOutline"] = false,
				["BarColor"] = {
					1, -- [1]
					0.670588235294118, -- [2]
					0.254901960784314, -- [3]
				},
				["Position"] = {
					["y"] = 275,
				},
				["Border"] = "Devil",
				["Width"] = 260,
				["Height"] = 20,
				["Font"] = "기본 글꼴",
				["ShowCooldownSpark"] = false,
				["BorderWidthAdjustment"] = -5,
				["ShowSwingTimer"] = false,
				["BorderOffsetAdjustment"] = 3,
				["BorderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.659999996423721, -- [4]
				},
				["Texture"] = "Glamour7",
			},
			["PetCastingBarFrame"] = {
				["Show"] = false,
			},
			["TargetCastingBarFrame"] = {
				["FontSize"] = 12,
				["BarColor"] = {
					1, -- [1]
					0.670588235294118, -- [2]
					0.254901960784314, -- [3]
				},
				["FontOutline"] = false,
				["Border"] = "Devil",
				["Width"] = 200,
				["BorderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.659999996423721, -- [4]
				},
				["Font"] = "기본 글꼴",
				["ShowShield"] = true,
				["BorderWidthAdjustment"] = -4,
				["Height"] = 18,
				["BorderOffsetAdjustment"] = 3,
				["Position"] = {
					["y"] = 382,
					["x"] = 300,
				},
				["Texture"] = "Glamour7",
			},
		},
		["내꿈은샤먼킹 - 데스윙"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["레이스가드 - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["아테리에 - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["아라스틴 - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["Eldersign - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["Vindictus - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["실베르투스 - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["Isolesty - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["이솔레스테 - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["Default"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["Wide"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["시에이레 - 듀로탄"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
		["아이루릴 - 아즈샤라"] = {
			["MirrorTimer"] = {
			},
			["FocusCastingBarFrame"] = {
			},
		},
	},
}
