
TomTomDB = {
	["profileKeys"] = {
		["뉘시빨라마 - 굴단"] = "Default",
		["무시중한디 - 굴단"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["arrow"] = {
				["position"] = {
					"CENTER", -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					0, -- [4]
					0, -- [5]
				},
			},
			["block"] = {
				["position"] = {
					"BOTTOM", -- [1]
					nil, -- [2]
					"BOTTOM", -- [3]
					134.6665802001953, -- [4]
					3.809475898742676, -- [5]
				},
			},
		},
	},
}
TomTomWaypoints = nil
TomTomWaypointsM = {
	["profileKeys"] = {
		["뉘시빨라마 - 굴단"] = "뉘시빨라마 - 굴단",
		["무시중한디 - 굴단"] = "무시중한디 - 굴단",
	},
	["profiles"] = {
		["뉘시빨라마 - 굴단"] = {
		},
		["무시중한디 - 굴단"] = {
		},
	},
}
