
SkadaDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["잘생겨따 - 굴단"] = "Default",
		["무시중한디 - 굴단"] = "Wide",
	},
	["profiles"] = {
		["Default"] = {
			["windows"] = {
				{
					["y"] = -46.4000244140625,
					["x"] = 128.799697875977,
					["point"] = "LEFT",
				}, -- [1]
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
		},
		["Wide"] = {
			["windows"] = {
				{
					["y"] = 98.2952041625977,
					["point"] = "BOTTOMLEFT",
					["mode"] = "GTFO 경고",
					["x"] = 3.79259181022644,
				}, -- [1]
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
			["modeclicks"] = {
				["GTFO 경고"] = 1,
			},
		},
	},
}
