
RareScannerDB = {
	["char"] = {
		["무시중한디 - 굴단"] = {
			["events_completed"] = {
			},
			["quests_completed"] = {
				[49162] = true,
				[49290] = true,
				[49418] = true,
				[50058] = true,
				[38413] = true,
				[42892] = true,
				[55561] = true,
				[39437] = true,
				[47755] = true,
				[47883] = true,
				[52234] = true,
				[40077] = true,
				[52490] = true,
				[48523] = true,
				[52874] = true,
				[57097] = true,
				[44940] = true,
				[57353] = true,
				[49419] = true,
				[41485] = true,
				[49803] = true,
				[50059] = true,
				[38286] = true,
				[50699] = true,
				[46732] = true,
				[50955] = true,
				[51083] = true,
				[51211] = true,
				[51339] = true,
				[51723] = true,
				[51851] = true,
				[47884] = true,
				[56330] = true,
				[52491] = true,
				[48524] = true,
				[53131] = true,
				[57354] = true,
				[49292] = true,
				[53771] = true,
				[49804] = true,
				[54283] = true,
				[50700] = true,
				[46733] = true,
				[38671] = true,
				[55179] = true,
				[39439] = true,
				[51852] = true,
				[52492] = true,
				[48525] = true,
				[52876] = true,
				[48909] = true,
				[49805] = true,
				[50061] = true,
				[54284] = true,
				[54412] = true,
				[50445] = true,
				[50573] = true,
				[46734] = true,
				[38672] = true,
				[51085] = true,
				[51341] = true,
				[39440] = true,
				[55948] = true,
				[48014] = true,
				[40080] = true,
				[52493] = true,
				[48654] = true,
				[49806] = true,
				[50446] = true,
				[51214] = true,
				[51470] = true,
				[51726] = true,
				[51982] = true,
				[48015] = true,
				[40081] = true,
				[48399] = true,
				[52750] = true,
				[53006] = true,
				[49039] = true,
				[49295] = true,
				[49807] = true,
				[50063] = true,
				[50447] = true,
				[55182] = true,
				[51215] = true,
				[51343] = true,
				[51471] = true,
				[55694] = true,
				[55950] = true,
				[47888] = true,
				[56334] = true,
				[48272] = true,
				[48400] = true,
				[53007] = true,
				[45329] = true,
				[49936] = true,
				[50064] = true,
				[38035] = true,
				[50448] = true,
				[50576] = true,
				[50704] = true,
				[38675] = true,
				[51088] = true,
				[51472] = true,
				[55695] = true,
				[51728] = true,
				[55951] = true,
				[43794] = true,
				[56207] = true,
				[52240] = true,
				[48273] = true,
				[52496] = true,
				[40339] = true,
				[45330] = true,
				[50065] = true,
				[54288] = true,
				[38036] = true,
				[50449] = true,
				[38420] = true,
				[55056] = true,
				[51217] = true,
				[39316] = true,
				[55824] = true,
				[39572] = true,
				[47890] = true,
				[56208] = true,
				[52241] = true,
				[53265] = true,
				[37653] = true,
				[37909] = true,
				[42132] = true,
				[50450] = true,
				[50706] = true,
				[54929] = true,
				[55057] = true,
				[55185] = true,
				[51218] = true,
				[55569] = true,
				[43412] = true,
				[55825] = true,
				[47891] = true,
				[52242] = true,
				[40085] = true,
				[56593] = true,
				[56721] = true,
				[49299] = true,
				[49427] = true,
				[37526] = true,
				[49939] = true,
				[45972] = true,
				[31308] = true,
				[50451] = true,
				[55058] = true,
				[51091] = true,
				[47252] = true,
				[55570] = true,
				[39318] = true,
				[47892] = true,
				[56594] = true,
				[56722] = true,
				[44821] = true,
				[53267] = true,
				[49428] = true,
				[41494] = true,
				[54035] = true,
				[54163] = true,
				[50452] = true,
				[51220] = true,
				[55571] = true,
				[39575] = true,
				[52116] = true,
				[48277] = true,
				[56595] = true,
				[44694] = true,
				[53268] = true,
				[53652] = true,
				[37528] = true,
				[37656] = true,
				[50069] = true,
				[54292] = true,
				[31309] = true,
				[50453] = true,
				[38424] = true,
				[50965] = true,
				[38808] = true,
				[51221] = true,
				[51349] = true,
				[55828] = true,
				[55956] = true,
				[56212] = true,
				[52245] = true,
				[48406] = true,
				[56724] = true,
				[45079] = true,
				[49302] = true,
				[53909] = true,
				[49942] = true,
				[50070] = true,
				[54293] = true,
				[54421] = true,
				[50454] = true,
				[42776] = true,
				[51222] = true,
				[51350] = true,
				[55573] = true,
				[39321] = true,
				[39577] = true,
				[52118] = true,
				[52246] = true,
				[44184] = true,
				[40217] = true,
				[40345] = true,
				[52886] = true,
				[49431] = true,
				[53910] = true,
				[37658] = true,
				[50071] = true,
				[50327] = true,
				[50455] = true,
				[50583] = true,
				[46744] = true,
				[42777] = true,
				[47000] = true,
				[51351] = true,
				[55574] = true,
				[39322] = true,
				[39578] = true,
				[56086] = true,
				[52247] = true,
				[48280] = true,
				[56598] = true,
				[48792] = true,
				[37659] = true,
				[50456] = true,
				[50584] = true,
				[42522] = true,
				[55063] = true,
				[51352] = true,
				[55575] = true,
				[39323] = true,
				[47641] = true,
				[39579] = true,
				[56087] = true,
				[48025] = true,
				[48281] = true,
				[40219] = true,
				[40347] = true,
				[40475] = true,
				[48793] = true,
				[49305] = true,
				[49433] = true,
				[53784] = true,
				[37660] = true,
				[50329] = true,
				[50457] = true,
				[50585] = true,
				[38684] = true,
				[51225] = true,
				[51353] = true,
				[39580] = true,
				[52121] = true,
				[48538] = true,
				[40476] = true,
				[49178] = true,
				[45339] = true,
				[49818] = true,
				[54041] = true,
				[54169] = true,
				[42268] = true,
				[50586] = true,
				[55065] = true,
				[38813] = true,
				[51226] = true,
				[51354] = true,
				[55833] = true,
				[47771] = true,
				[51994] = true,
				[48283] = true,
				[48539] = true,
				[52762] = true,
				[44700] = true,
				[49435] = true,
				[50075] = true,
				[54298] = true,
				[50331] = true,
				[38558] = true,
				[55066] = true,
				[51611] = true,
				[52123] = true,
				[40222] = true,
				[48540] = true,
				[48668] = true,
				[44701] = true,
				[53275] = true,
				[45853] = true,
				[54171] = true,
				[54299] = true,
				[50332] = true,
				[50460] = true,
				[50588] = true,
				[38431] = true,
				[54939] = true,
				[50972] = true,
				[39071] = true,
				[55707] = true,
				[39455] = true,
				[52252] = true,
				[56603] = true,
				[40479] = true,
				[49181] = true,
				[41119] = true,
				[37536] = true,
				[54172] = true,
				[50333] = true,
				[42271] = true,
				[54940] = true,
				[50973] = true,
				[51229] = true,
				[55708] = true,
				[39456] = true,
				[52125] = true,
				[52253] = true,
				[56604] = true,
				[48542] = true,
				[48670] = true,
				[57244] = true,
				[41120] = true,
				[45727] = true,
				[45855] = true,
				[50334] = true,
				[38305] = true,
				[38433] = true,
				[50974] = true,
				[51358] = true,
				[55837] = true,
				[51870] = true,
				[56221] = true,
				[56605] = true,
				[44448] = true,
				[48671] = true,
				[49311] = true,
				[49439] = true,
				[37538] = true,
				[49951] = true,
				[54174] = true,
				[54302] = true,
				[38690] = true,
				[51359] = true,
				[51487] = true,
				[56350] = true,
				[56606] = true,
				[48544] = true,
				[48672] = true,
				[48928] = true,
				[8237] = true,
				[53919] = true,
				[41762] = true,
				[41890] = true,
				[54303] = true,
				[54559] = true,
				[38435] = true,
				[50976] = true,
				[38819] = true,
				[47137] = true,
				[51488] = true,
				[51872] = true,
				[52000] = true,
				[52128] = true,
				[52256] = true,
				[56479] = true,
				[56607] = true,
				[48673] = true,
				[48929] = true,
				[41763] = true,
				[41891] = true,
				[54304] = true,
				[42147] = true,
				[50593] = true,
				[38436] = true,
				[31571] = true,
				[42787] = true,
				[55200] = true,
				[51489] = true,
				[51617] = true,
				[51873] = true,
				[52001] = true,
				[52257] = true,
				[56608] = true,
				[48674] = true,
				[40612] = true,
				[57248] = true,
				[49698] = true,
				[54305] = true,
				[38053] = true,
				[50594] = true,
				[54945] = true,
				[50978] = true,
				[51490] = true,
				[52130] = true,
				[52258] = true,
				[48419] = true,
				[56737] = true,
				[48675] = true,
				[49443] = true,
				[45476] = true,
				[37542] = true,
				[41893] = true,
				[54306] = true,
				[50339] = true,
				[50595] = true,
				[31572] = true,
				[51363] = true,
				[47652] = true,
				[39590] = true,
				[52003] = true,
				[52259] = true,
				[44325] = true,
				[48676] = true,
				[48804] = true,
				[49060] = true,
				[45477] = true,
				[54307] = true,
				[50340] = true,
				[54947] = true,
				[51492] = true,
				[51748] = true,
				[51876] = true,
				[52132] = true,
				[48165] = true,
				[48421] = true,
				[56739] = true,
				[48677] = true,
				[48805] = true,
				[53028] = true,
				[49317] = true,
				[49445] = true,
				[54436] = true,
				[38312] = true,
				[50725] = true,
				[31573] = true,
				[39080] = true,
				[47526] = true,
				[51749] = true,
				[51877] = true,
				[56100] = true,
				[52261] = true,
				[56612] = true,
				[44455] = true,
				[48678] = true,
				[48806] = true,
				[45863] = true,
				[38057] = true,
				[42664] = true,
				[55077] = true,
				[42920] = true,
				[43176] = true,
				[39593] = true,
				[44072] = true,
				[40233] = true,
				[56741] = true,
				[48679] = true,
				[40617] = true,
				[53030] = true,
				[41129] = true,
				[49703] = true,
				[49831] = true,
				[54182] = true,
				[54310] = true,
				[50343] = true,
				[50599] = true,
				[38442] = true,
				[42665] = true,
				[42921] = true,
				[51367] = true,
				[43305] = true,
				[43433] = true,
				[51879] = true,
				[56358] = true,
				[44457] = true,
				[48680] = true,
				[56998] = true,
				[49704] = true,
				[45865] = true,
				[50088] = true,
				[38059] = true,
				[50600] = true,
				[38443] = true,
				[50856] = true,
				[55079] = true,
				[55207] = true,
				[51240] = true,
				[51368] = true,
				[55719] = true,
				[51752] = true,
				[51880] = true,
				[52008] = true,
				[56615] = true,
				[53160] = true,
				[53672] = true,
				[49705] = true,
				[50089] = true,
				[54312] = true,
				[38060] = true,
				[50601] = true,
				[38444] = true,
				[51369] = true,
				[55720] = true,
				[51881] = true,
				[48170] = true,
				[56744] = true,
				[48682] = true,
				[53161] = true,
				[49450] = true,
				[53673] = true,
				[49706] = true,
				[50090] = true,
				[46251] = true,
				[42284] = true,
				[38445] = true,
				[51242] = true,
				[55465] = true,
				[55593] = true,
				[39597] = true,
				[48171] = true,
				[48683] = true,
				[48939] = true,
				[57385] = true,
				[49451] = true,
				[53674] = true,
				[37678] = true,
				[50091] = true,
				[37934] = true,
				[38318] = true,
				[50731] = true,
				[31576] = true,
				[55082] = true,
				[55210] = true,
				[51371] = true,
				[47532] = true,
				[56106] = true,
				[56234] = true,
				[40238] = true,
				[53163] = true,
				[49452] = true,
				[53675] = true,
				[50092] = true,
				[37935] = true,
				[46253] = true,
				[42286] = true,
				[29401] = true,
				[46765] = true,
				[50988] = true,
				[55211] = true,
				[39087] = true,
				[55595] = true,
				[47533] = true,
				[55851] = true,
				[39983] = true,
				[48557] = true,
				[48941] = true,
				[49069] = true,
				[57387] = true,
				[49453] = true,
				[50349] = true,
				[50605] = true,
				[50733] = true,
				[42671] = true,
				[47022] = true,
				[51757] = true,
				[52013] = true,
				[39856] = true,
				[40112] = true,
				[56620] = true,
				[48558] = true,
				[57004] = true,
				[48942] = true,
				[57260] = true,
				[57388] = true,
				[49454] = true,
				[53677] = true,
				[49710] = true,
				[50094] = true,
				[54317] = true,
				[50734] = true,
				[47023] = true,
				[43184] = true,
				[55597] = true,
				[47663] = true,
				[47919] = true,
				[39985] = true,
				[56493] = true,
				[56621] = true,
				[48559] = true,
				[44720] = true,
				[48943] = true,
				[57389] = true,
				[53678] = true,
				[50095] = true,
				[54318] = true,
				[50351] = true,
				[42673] = true,
				[42801] = true,
				[47024] = true,
				[43185] = true,
				[55598] = true,
				[55726] = true,
				[55854] = true,
				[47792] = true,
				[39858] = true,
				[39986] = true,
				[44337] = true,
				[48560] = true,
				[44721] = true,
				[48944] = true,
				[49072] = true,
				[53295] = true,
				[53551] = true,
				[41778] = true,
				[50096] = true,
				[50352] = true,
				[50608] = true,
				[42802] = true,
				[47025] = true,
				[43186] = true,
				[51504] = true,
				[51632] = true,
				[55855] = true,
				[51888] = true,
				[43954] = true,
				[39987] = true,
				[44338] = true,
				[44466] = true,
				[48945] = true,
				[53168] = true,
				[45490] = true,
				[53936] = true,
				[49969] = true,
				[54192] = true,
				[50225] = true,
				[50353] = true,
				[50481] = true,
				[50609] = true,
				[31579] = true,
				[55088] = true,
				[55600] = true,
				[55856] = true,
				[39860] = true,
				[48178] = true,
				[56624] = true,
				[53041] = true,
				[53169] = true,
				[54193] = true,
				[50226] = true,
				[50354] = true,
				[42292] = true,
				[50610] = true,
				[55089] = true,
				[55601] = true,
				[55729] = true,
				[51762] = true,
				[39733] = true,
				[52146] = true,
				[48179] = true,
				[40373] = true,
				[56881] = true,
				[57009] = true,
				[49075] = true,
				[45492] = true,
				[49715] = true,
				[54194] = true,
				[50227] = true,
				[50355] = true,
				[42293] = true,
				[50611] = true,
				[42677] = true,
				[55090] = true,
				[51251] = true,
				[55602] = true,
				[55730] = true,
				[55986] = true,
				[47924] = true,
				[48052] = true,
				[39990] = true,
				[48308] = true,
				[56626] = true,
				[40374] = true,
				[44597] = true,
				[57010] = true,
				[53043] = true,
				[53171] = true,
				[45365] = true,
				[45493] = true,
				[49716] = true,
				[49972] = true,
				[54195] = true,
				[50228] = true,
				[50356] = true,
				[50612] = true,
				[38455] = true,
				[46773] = true,
				[47541] = true,
				[55859] = true,
				[43702] = true,
				[47925] = true,
				[52148] = true,
				[48181] = true,
				[48309] = true,
				[40247] = true,
				[44598] = true,
				[53044] = true,
				[49077] = true,
				[36920] = true,
				[54196] = true,
				[50229] = true,
				[50741] = true,
				[46774] = true,
				[43191] = true,
				[43447] = true,
				[55860] = true,
				[39864] = true,
				[44087] = true,
				[48310] = true,
				[56628] = true,
				[44471] = true,
				[44599] = true,
				[53045] = true,
				[49718] = true,
				[54197] = true,
				[54325] = true,
				[50614] = true,
				[50742] = true,
				[54965] = true,
				[42808] = true,
				[51126] = true,
				[47287] = true,
				[43576] = true,
				[56117] = true,
				[52150] = true,
				[48183] = true,
				[48311] = true,
				[40249] = true,
				[44600] = true,
				[40761] = true,
				[53174] = true,
				[49719] = true,
				[37690] = true,
				[54198] = true,
				[50359] = true,
				[42681] = true,
				[38714] = true,
				[51383] = true,
				[47416] = true,
				[43449] = true,
				[56118] = true,
				[56246] = true,
				[52279] = true,
				[40122] = true,
				[48440] = true,
				[44473] = true,
				[44601] = true,
				[57142] = true,
				[40890] = true,
				[45497] = true,
				[49720] = true,
				[49976] = true,
				[54199] = true,
				[38331] = true,
				[42682] = true,
				[42810] = true,
				[47289] = true,
				[43834] = true,
				[48057] = true,
				[40123] = true,
				[48441] = true,
				[40379] = true,
				[44602] = true,
				[53176] = true,
				[49465] = true,
				[53816] = true,
				[54200] = true,
				[46266] = true,
				[38460] = true,
				[42683] = true,
				[51001] = true,
				[51129] = true,
				[55480] = true,
				[55608] = true,
				[55736] = true,
				[56248] = true,
				[52281] = true,
				[48442] = true,
				[48570] = true,
				[52793] = true,
				[48954] = true,
				[53177] = true,
				[37565] = true,
				[37821] = true,
				[50362] = true,
				[38333] = true,
				[54969] = true,
				[38717] = true,
				[51386] = true,
				[43580] = true,
				[52026] = true,
				[52154] = true,
				[52282] = true,
				[48443] = true,
				[44604] = true,
				[53178] = true,
				[53306] = true,
				[53434] = true,
				[49467] = true,
				[53818] = true,
				[37566] = true,
				[54202] = true,
				[50363] = true,
				[38206] = true,
				[46780] = true,
				[38718] = true,
				[55610] = true,
				[39614] = true,
				[52027] = true,
				[52283] = true,
				[40126] = true,
				[40254] = true,
				[44605] = true,
				[53307] = true,
				[53435] = true,
				[49468] = true,
				[53819] = true,
				[37823] = true,
				[54459] = true,
				[38719] = true,
				[38847] = true,
				[39487] = true,
				[55995] = true,
				[52028] = true,
				[52156] = true,
				[52284] = true,
				[48317] = true,
				[48445] = true,
				[52796] = true,
				[53052] = true,
				[49341] = true,
				[45502] = true,
				[49725] = true,
				[49981] = true,
				[54204] = true,
				[50365] = true,
				[50493] = true,
				[50621] = true,
				[31585] = true,
				[51389] = true,
				[39488] = true,
				[52029] = true,
				[52285] = true,
				[44223] = true,
				[48446] = true,
				[44479] = true,
				[44607] = true,
				[53181] = true,
				[53309] = true,
				[45503] = true,
				[50110] = true,
				[50238] = true,
				[50366] = true,
				[38337] = true,
				[38721] = true,
				[51134] = true,
				[51390] = true,
				[51646] = true,
				[39489] = true,
				[55997] = true,
				[52030] = true,
				[48063] = true,
				[52286] = true,
				[48447] = true,
				[48575] = true,
				[56893] = true,
				[53182] = true,
				[53310] = true,
				[45504] = true,
				[50111] = true,
				[50239] = true,
				[50367] = true,
				[38210] = true,
				[38466] = true,
				[31586] = true,
				[51135] = true,
				[51391] = true,
				[39490] = true,
				[51903] = true,
				[52031] = true,
				[48064] = true,
				[52287] = true,
				[48448] = true,
				[40386] = true,
				[53183] = true,
				[49216] = true,
				[53439] = true,
				[49984] = true,
				[50368] = true,
				[38595] = true,
				[38723] = true,
				[51136] = true,
				[39235] = true,
				[55743] = true,
				[39491] = true,
				[51904] = true,
				[52032] = true,
				[52288] = true,
				[44226] = true,
				[52544] = true,
				[40515] = true,
				[53184] = true,
				[49601] = true,
				[38212] = true,
				[50753] = true,
				[38596] = true,
				[38724] = true,
				[47554] = true,
				[56000] = true,
				[52033] = true,
				[52289] = true,
				[56640] = true,
				[44483] = true,
				[52801] = true,
				[48962] = true,
				[53185] = true,
				[49218] = true,
				[53441] = true,
				[49602] = true,
				[49730] = true,
				[37957] = true,
				[50370] = true,
				[29412] = true,
				[50754] = true,
				[38725] = true,
				[47043] = true,
				[55361] = true,
				[51394] = true,
				[55617] = true,
				[52034] = true,
				[48195] = true,
				[56641] = true,
				[44484] = true,
				[52802] = true,
				[48963] = true,
				[53186] = true,
				[53442] = true,
				[45764] = true,
				[54082] = true,
				[50371] = true,
				[38342] = true,
				[31588] = true,
				[51139] = true,
				[55362] = true,
				[51395] = true,
				[47428] = true,
				[52035] = true,
				[48196] = true,
				[56642] = true,
				[53187] = true,
				[53443] = true,
				[53571] = true,
				[37447] = true,
				[54083] = true,
				[37831] = true,
				[37959] = true,
				[50372] = true,
				[38727] = true,
				[51140] = true,
				[55363] = true,
				[51396] = true,
				[55619] = true,
				[47685] = true,
				[51908] = true,
				[52036] = true,
				[48453] = true,
				[44486] = true,
				[56899] = true,
				[48965] = true,
				[53444] = true,
				[53572] = true,
				[49733] = true,
				[53956] = true,
				[37960] = true,
				[50373] = true,
				[42567] = true,
				[42695] = true,
				[38728] = true,
				[47046] = true,
				[43207] = true,
				[47686] = true,
				[56004] = true,
				[48070] = true,
				[48198] = true,
				[56644] = true,
				[40520] = true,
				[53445] = true,
				[53573] = true,
				[45511] = true,
				[37449] = true,
				[53957] = true,
				[50374] = true,
				[38217] = true,
				[50758] = true,
				[38729] = true,
				[47047] = true,
				[47431] = true,
				[47687] = true,
				[52038] = true,
				[56261] = true,
				[48199] = true,
				[48455] = true,
				[40905] = true,
				[49223] = true,
				[53446] = true,
				[53574] = true,
				[37450] = true,
				[54086] = true,
				[50759] = true,
				[42697] = true,
				[47048] = true,
				[55622] = true,
				[47688] = true,
				[52039] = true,
				[48200] = true,
				[52807] = true,
				[49224] = true,
				[53575] = true,
				[49736] = true,
				[53959] = true,
				[54087] = true,
				[37963] = true,
				[50376] = true,
				[50504] = true,
				[50760] = true,
				[51144] = true,
				[55623] = true,
				[47689] = true,
				[56007] = true,
				[47945] = true,
				[48201] = true,
				[49225] = true,
				[53704] = true,
				[49737] = true,
				[53960] = true,
				[41803] = true,
				[50249] = true,
				[50761] = true,
				[46794] = true,
				[42827] = true,
				[51145] = true,
				[51401] = true,
				[47562] = true,
				[47690] = true,
				[47946] = true,
				[40012] = true,
				[56520] = true,
				[48842] = true,
				[49226] = true,
				[49738] = true,
				[53961] = true,
				[41804] = true,
				[50762] = true,
				[51018] = true,
				[39117] = true,
				[39373] = true,
				[47691] = true,
				[56009] = true,
				[47947] = true,
				[52170] = true,
				[48203] = true,
				[56777] = true,
				[53194] = true,
				[41037] = true,
				[53450] = true,
				[49739] = true,
				[49867] = true,
				[49995] = true,
				[50251] = true,
				[50635] = true,
				[50763] = true,
				[46796] = true,
				[51019] = true,
				[38862] = true,
				[47180] = true,
				[51403] = true,
				[43341] = true,
				[39374] = true,
				[43597] = true,
				[56010] = true,
				[47948] = true,
				[52171] = true,
				[48460] = true,
				[56778] = true,
				[48972] = true,
				[49740] = true,
				[41806] = true,
				[50508] = true,
				[46797] = true,
				[51020] = true,
				[47181] = true,
				[39247] = true,
				[51660] = true,
				[51916] = true,
				[47949] = true,
				[52172] = true,
				[52428] = true,
				[48461] = true,
				[56779] = true,
				[48973] = true,
				[49229] = true,
				[53452] = true,
				[49741] = true,
				[49869] = true,
				[41807] = true,
				[50253] = true,
				[46286] = true,
				[38352] = true,
				[46798] = true,
				[42831] = true,
				[51149] = true,
				[47182] = true,
				[39120] = true,
				[55884] = true,
				[47950] = true,
				[52173] = true,
				[48462] = true,
				[56780] = true,
				[57036] = true,
				[53069] = true,
				[53197] = true,
				[49230] = true,
				[53453] = true,
				[45391] = true,
				[49998] = true,
				[46159] = true,
				[38225] = true,
				[46799] = true,
				[55117] = true,
				[51150] = true,
				[47183] = true,
				[51534] = true,
				[47567] = true,
				[55885] = true,
				[51918] = true,
				[56141] = true,
				[44496] = true,
				[53070] = true,
				[53198] = true,
				[49231] = true,
				[49999] = true,
				[50639] = true,
				[54862] = true,
				[46800] = true,
				[55118] = true,
				[51151] = true,
				[47184] = true,
				[51407] = true,
				[47952] = true,
				[48080] = true,
				[52431] = true,
				[52559] = true,
				[44497] = true,
				[53071] = true,
				[49232] = true,
				[45393] = true,
				[53711] = true,
				[49744] = true,
				[50640] = true,
				[38483] = true,
				[38611] = true,
				[55119] = true,
				[29675] = true,
				[51280] = true,
				[39123] = true,
				[55887] = true,
				[56143] = true,
				[48081] = true,
				[52560] = true,
				[57167] = true,
				[49233] = true,
				[45394] = true,
				[53712] = true,
				[49745] = true,
				[50001] = true,
				[38612] = true,
				[47186] = true,
				[39124] = true,
				[55888] = true,
				[56016] = true,
				[52433] = true,
				[57040] = true,
				[48978] = true,
				[49234] = true,
				[45395] = true,
				[49746] = true,
				[50002] = true,
				[50386] = true,
				[38613] = true,
				[55121] = true,
				[34774] = true,
				[51282] = true,
				[43348] = true,
				[39381] = true,
				[51922] = true,
				[39765] = true,
				[56529] = true,
				[40405] = true,
				[52946] = true,
				[53074] = true,
				[53202] = true,
				[41045] = true,
				[45396] = true,
				[49619] = true,
				[50003] = true,
				[50259] = true,
				[50387] = true,
				[54610] = true,
				[38486] = true,
				[38614] = true,
				[51283] = true,
				[51795] = true,
				[51923] = true,
				[56530] = true,
				[57170] = true,
				[49620] = true,
				[50260] = true,
				[54611] = true,
				[50644] = true,
				[46805] = true,
				[38743] = true,
				[47189] = true,
				[51540] = true,
				[39383] = true,
				[51796] = true,
				[56019] = true,
				[52308] = true,
				[48597] = true,
				[48853] = true,
				[48981] = true,
				[53332] = true,
				[49621] = true,
				[50133] = true,
				[38232] = true,
				[50645] = true,
				[50773] = true,
				[38616] = true,
				[51029] = true,
				[55380] = true,
				[43351] = true,
				[39384] = true,
				[55892] = true,
				[39768] = true,
				[56276] = true,
				[56532] = true,
				[56660] = true,
				[56788] = true,
				[57044] = true,
				[53461] = true,
				[53717] = true,
				[50134] = true,
				[54485] = true,
				[50774] = true,
				[38617] = true,
				[46935] = true,
				[43480] = true,
				[39769] = true,
				[48087] = true,
				[44120] = true,
				[56533] = true,
				[56789] = true,
				[44760] = true,
				[53206] = true,
				[49239] = true,
				[49367] = true,
				[53974] = true,
				[50135] = true,
				[50263] = true,
				[50391] = true,
				[54870] = true,
				[50903] = true,
				[51159] = true,
				[51543] = true,
				[55894] = true,
				[56022] = true,
				[47960] = true,
				[48088] = true,
				[52311] = true,
				[52439] = true,
				[56662] = true,
				[48600] = true,
				[40794] = true,
				[49368] = true,
				[37467] = true,
				[53975] = true,
				[50136] = true,
				[50264] = true,
				[46297] = true,
				[38235] = true,
				[38363] = true,
				[54871] = true,
				[51544] = true,
				[39387] = true,
				[39515] = true,
				[56023] = true,
				[47961] = true,
				[48089] = true,
				[48345] = true,
				[48601] = true,
				[40923] = true,
				[53336] = true,
				[53464] = true,
				[37468] = true,
				[37596] = true,
				[50137] = true,
				[50265] = true,
				[50649] = true,
				[50777] = true,
				[46938] = true,
				[47066] = true,
				[55512] = true,
				[51545] = true,
				[43483] = true,
				[39516] = true,
				[56024] = true,
				[47962] = true,
				[56280] = true,
				[52441] = true,
				[44379] = true,
				[48602] = true,
				[48986] = true,
				[40924] = true,
				[49242] = true,
				[53465] = true,
				[37469] = true,
				[53977] = true,
				[37853] = true,
				[50266] = true,
				[38237] = true,
				[38365] = true,
				[50778] = true,
				[51034] = true,
				[51418] = true,
				[39261] = true,
				[39517] = true,
				[47835] = true,
				[52058] = true,
				[48347] = true,
				[48475] = true,
				[40413] = true,
				[49755] = true,
				[53978] = true,
				[37726] = true,
				[50139] = true,
				[38238] = true,
				[51035] = true,
				[51163] = true,
				[47196] = true,
				[39134] = true,
				[51547] = true,
				[55898] = true,
				[39646] = true,
				[56410] = true,
				[52443] = true,
				[48476] = true,
				[40414] = true,
				[41054] = true,
				[53723] = true,
				[41694] = true,
				[37727] = true,
				[37855] = true,
				[54363] = true,
				[50780] = true,
				[50908] = true,
				[46941] = true,
				[29681] = true,
				[43358] = true,
				[39391] = true,
				[55899] = true,
				[52060] = true,
				[48477] = true,
				[48605] = true,
				[44638] = true,
				[49373] = true,
				[49757] = true,
				[37728] = true,
				[37856] = true,
				[50269] = true,
				[50525] = true,
				[50653] = true,
				[50781] = true,
				[50909] = true,
				[51165] = true,
				[39392] = true,
				[39776] = true,
				[56284] = true,
				[44383] = true,
				[48606] = true,
				[44639] = true,
				[41056] = true,
				[49886] = true,
				[37729] = true,
				[37857] = true,
				[46815] = true,
				[38753] = true,
				[55261] = true,
				[55517] = true,
				[55645] = true,
				[47583] = true,
				[55901] = true,
				[39777] = true,
				[52318] = true,
				[53470] = true,
				[53726] = true,
				[49887] = true,
				[37730] = true,
				[46176] = true,
				[50783] = true,
				[50911] = true,
				[51167] = true,
				[55390] = true,
				[47584] = true,
				[51807] = true,
				[47968] = true,
				[56286] = true,
				[48352] = true,
				[52575] = true,
				[44641] = true,
				[48864] = true,
				[37859] = true,
				[46177] = true,
				[54495] = true,
				[50528] = true,
				[50784] = true,
				[50912] = true,
				[51168] = true,
				[47329] = true,
				[51552] = true,
				[47585] = true,
				[55903] = true,
				[56031] = true,
				[47969] = true,
				[48353] = true,
				[37860] = true,
				[54183] = true,
				[53814] = true,
				[54187] = true,
				[56840] = true,
				[46818] = true,
				[53334] = true,
				[51169] = true,
				[55392] = true,
				[47330] = true,
				[55891] = true,
				[47586] = true,
				[51809] = true,
				[39652] = true,
				[52065] = true,
				[55776] = true,
				[57166] = true,
				[48354] = true,
				[56032] = true,
				[39692] = true,
				[50910] = true,
				[44771] = true,
				[31580] = true,
				[55765] = true,
				[41060] = true,
				[51465] = true,
				[55264] = true,
				[54458] = true,
				[53857] = true,
				[49890] = true,
				[37733] = true,
				[37861] = true,
				[51637] = true,
				[56729] = true,
				[50530] = true,
				[50658] = true,
				[42596] = true,
				[50914] = true,
				[46730] = true,
				[51170] = true,
				[51298] = true,
				[51426] = true,
				[51554] = true,
				[47587] = true,
				[55905] = true,
				[50697] = true,
				[56760] = true,
				[52194] = true,
				[53037] = true,
				[48355] = true,
				[48483] = true,
				[55895] = true,
				[52834] = true,
				[52962] = true,
				[55853] = true,
				[54555] = true,
				[43837] = true,
				[56629] = true,
				[45412] = true,
				[50960] = true,
				[39089] = true,
				[53986] = true,
				[54114] = true,
				[37862] = true,
				[39495] = true,
				[42213] = true,
				[50531] = true,
				[38374] = true,
				[50787] = true,
				[50915] = true,
				[49289] = true,
				[38886] = true,
				[55394] = true,
				[51427] = true,
				[56142] = true,
				[55852] = true,
				[56121] = true,
				[54618] = true,
				[52067] = true,
				[56290] = true,
				[51662] = true,
				[52451] = true,
				[56370] = true,
				[40422] = true,
				[55820] = true,
				[52963] = true,
				[55823] = true,
				[56756] = true,
				[41062] = true,
				[55068] = true,
				[45413] = true,
				[55060] = true,
				[56136] = true,
				[41702] = true,
				[39435] = true,
				[50148] = true,
				[37991] = true,
				[54498] = true,
				[54627] = true,
				[55513] = true,
				[50788] = true,
				[55880] = true,
				[38759] = true,
				[56355] = true,
				[55395] = true,
				[56011] = true,
				[37657] = true,
				[47589] = true,
				[55907] = true,
				[46729] = true,
				[55463] = true,
				[55831] = true,
				[56501] = true,
				[40167] = true,
				[50312] = true,
				[56891] = true,
				[56025] = true,
				[51722] = true,
				[43446] = true,
				[52296] = true,
				[55775] = true,
				[53476] = true,
				[41319] = true,
				[45798] = true,
				[52450] = true,
				[53988] = true,
				[37736] = true,
				[50149] = true,
				[55982] = true,
				[53436] = true,
				[50533] = true,
				[54946] = true,
				[50789] = true,
				[48776] = true,
				[46802] = true,
				[57135] = true,
				[55396] = true,
				[51808] = true,
				[39272] = true,
				[43495] = true,
				[51813] = true,
				[52062] = true,
				[38994] = true,
				[52197] = true,
				[48230] = true,
				[56278] = true,
				[55857] = true,
				[56471] = true,
				[52837] = true,
				[57060] = true,
				[44106] = true,
				[53221] = true,
				[41064] = true,
				[48202] = true,
				[45415] = true,
				[39178] = true,
				[39050] = true,
				[41704] = true,
				[54117] = true,
				[38922] = true,
				[37518] = true,
				[52639] = true,
				[50534] = true,
				[50662] = true,
				[50790] = true,
				[55973] = true,
				[42505] = true,
				[55701] = true,
				[55397] = true,
				[51430] = true,
				[44879] = true,
				[43496] = true,
				[38058] = true,
				[56037] = true,
				[52070] = true,
				[39498] = true,
				[52326] = true,
				[43857] = true,
				[55103] = true,
				[53414] = true,
				[55777] = true,
				[57061] = true,
				[54315] = true,
				[53222] = true,
				[43467] = true,
				[49383] = true,
				[40921] = true,
				[55945] = true,
				[53715] = true,
				[53990] = true,
				[54118] = true,
				[50151] = true,
				[56643] = true,
				[42510] = true,
				[54630] = true,
				[56613] = true,
				[39718] = true,
				[39694] = true,
				[42857] = true,
				[56528] = true,
				[55398] = true,
				[56149] = true,
				[56844] = true,
				[45117] = true,
				[55910] = true,
				[56038] = true,
				[51846] = true,
				[44009] = true,
				[44137] = true,
				[40170] = true,
				[56633] = true,
				[48616] = true,
				[45843] = true,
				[47508] = true,
				[49735] = true,
				[56139] = true,
				[41066] = true,
				[49384] = true,
				[55393] = true,
				[56586] = true,
				[57006] = true,
				[49896] = true,
				[41834] = true,
				[50152] = true,
				[50280] = true,
				[56791] = true,
				[54631] = true,
				[48449] = true,
				[46247] = true,
				[56611] = true,
				[38624] = true,
				[56422] = true,
				[55399] = true,
				[56167] = true,
				[56585] = true,
				[55783] = true,
				[55911] = true,
				[56039] = true,
				[52072] = true,
				[46244] = true,
				[49734] = true,
				[45385] = true,
				[41096] = true,
				[56247] = true,
				[38473] = true,
				[57063] = true,
				[56609] = true,
				[44679] = true,
				[41067] = true,
				[39873] = true,
				[31592] = true,
				[56244] = true,
				[49769] = true,
				[49897] = true,
				[46314] = true,
				[45856] = true,
				[50281] = true,
				[54504] = true,
				[54632] = true,
				[31589] = true,
				[50793] = true,
				[42731] = true,
				[44606] = true,
				[51177] = true,
				[55400] = true,
				[55528] = true,
				[47978] = true,
				[55784] = true,
				[55912] = true,
				[42181] = true,
				[56168] = true,
				[56119] = true,
				[52329] = true,
				[56156] = true,
				[56239] = true,
				[56808] = true,
				[50616] = true,
				[52969] = true,
				[53097] = true,
				[41033] = true,
				[43855] = true,
				[56095] = true,
				[56131] = true,
				[41452] = true,
				[51613] = true,
				[49898] = true,
				[50026] = true,
				[37869] = true,
				[55497] = true,
				[42220] = true,
				[55618] = true,
				[38381] = true,
				[41707] = true,
				[38637] = true,
				[42860] = true,
				[39277] = true,
				[48107] = true,
				[39149] = true,
				[55657] = true,
				[40008] = true,
				[55913] = true,
				[39661] = true,
				[47979] = true,
				[56297] = true,
				[44140] = true,
				[56242] = true,
				[40301] = true,
				[56809] = true,
				[56243] = true,
				[56245] = true,
				[53098] = true,
				[44480] = true,
				[49259] = true,
				[41197] = true,
				[38810] = true,
				[41453] = true,
				[37486] = true,
				[56215] = true,
				[48184] = true,
				[50155] = true,
				[48773] = true,
				[42221] = true,
				[44463] = true,
				[38382] = true,
				[50795] = true,
				[42733] = true,
				[38766] = true,
				[38894] = true,
				[43501] = true,
				[55565] = true,
				[55658] = true,
				[55786] = true,
				[55914] = true,
				[56042] = true,
				[47980] = true,
				[48108] = true,
				[56426] = true,
				[56241] = true,
				[40302] = true,
				[56810] = true,
				[55734] = true,
				[54972] = true,
				[49004] = true,
				[55999] = true,
				[49260] = true,
				[49388] = true,
				[41149] = true,
				[39992] = true,
				[39741] = true,
				[54705] = true,
				[55908] = true,
				[50156] = true,
				[42701] = true,
				[46268] = true,
				[55957] = true,
				[42630] = true,
				[38407] = true,
				[55521] = true,
				[38767] = true,
				[56240] = true,
				[51308] = true,
				[55531] = true,
				[55659] = true,
				[46213] = true,
				[31582] = true,
				[56043] = true,
				[47981] = true,
				[48109] = true,
				[56162] = true,
				[48365] = true,
				[47853] = true,
				[56811] = true,
				[55861] = true,
				[44782] = true,
				[40815] = true,
				[49133] = true,
				[53356] = true,
				[39867] = true,
				[44214] = true,
				[55960] = true,
				[55072] = true,
				[54508] = true,
				[51402] = true,
				[50157] = true,
				[54380] = true,
				[42223] = true,
				[40378] = true,
				[38384] = true,
				[55696] = true,
				[42735] = true,
				[44213] = true,
				[40326] = true,
				[55404] = true,
				[55520] = true,
				[55213] = true,
				[43503] = true,
				[55916] = true,
				[47854] = true,
				[47982] = true,
				[48110] = true,
				[56812] = true,
				[48366] = true,
				[39862] = true,
				[48622] = true,
				[50637] = true,
				[52973] = true,
				[40816] = true,
				[49134] = true,
				[55095] = true,
				[55061] = true,
				[55753] = true,
				[55069] = true,
				[51331] = true,
				[54922] = true,
				[42809] = true,
				[50158] = true,
				[40253] = true,
				[50819] = true,
				[50542] = true,
				[38641] = true,
				[55096] = true,
				[42736] = true,
				[51310] = true,
				[50307] = true,
				[55405] = true,
				[55533] = true,
				[48946] = true,
				[54201] = true,
				[55917] = true,
				[47855] = true,
				[48623] = true,
				[48111] = true,
				[52974] = true,
				[48367] = true,
				[44400] = true,
				[56813] = true,
				[56301] = true,
				[48879] = true,
				[40817] = true,
				[49997] = true,
				[55087] = true,
				[54206] = true,
				[50898] = true,
				[55070] = true,
				[48899] = true,
				[54703] = true,
				[51278] = true,
				[50159] = true,
				[54088] = true,
				[54510] = true,
				[38615] = true,
				[31583] = true,
				[54324] = true,
				[46832] = true,
				[42865] = true,
				[56220] = true,
				[39026] = true,
				[50824] = true,
				[51842] = true,
				[55790] = true,
				[55918] = true,
				[47856] = true,
				[51714] = true,
				[48368] = true,
				[39991] = true,
				[56558] = true,
				[47235] = true,
				[56814] = true,
				[42118] = true,
				[48880] = true,
				[51074] = true,
				[44785] = true,
				[53602] = true,
				[54992] = true,
				[54626] = true,
				[54433] = true,
				[42116] = true,
				[45908] = true,
				[53849] = true,
				[50160] = true,
				[54113] = true,
				[46321] = true,
				[50544] = true,
				[50672] = true,
				[54895] = true,
				[38643] = true,
				[47217] = true,
				[42738] = true,
				[55407] = true,
				[50698] = true,
				[47473] = true,
				[55791] = true,
				[55919] = true,
				[50692] = true,
				[56175] = true,
				[48113] = true,
				[40051] = true,
				[48369] = true,
				[41092] = true,
				[56815] = true,
				[56943] = true,
				[48881] = true,
				[44914] = true,
				[49137] = true,
				[41749] = true,
				[49393] = true,
				[53616] = true,
				[29674] = true,
				[37492] = true,
				[37654] = true,
				[53815] = true,
				[50161] = true,
				[38644] = true,
				[50417] = true,
				[39859] = true,
				[50929] = true,
				[40796] = true,
				[42739] = true,
				[38772] = true,
				[53462] = true,
				[47218] = true,
				[39796] = true,
				[51569] = true,
				[39684] = true,
				[55920] = true,
				[56048] = true,
				[47986] = true,
				[56304] = true,
				[56816] = true,
				[48370] = true,
				[45171] = true,
				[48626] = true,
				[49522] = true,
				[48882] = true,
				[44915] = true,
				[53976] = true,
				[49266] = true,
				[49394] = true,
				[53617] = true,
				[51142] = true,
				[47106] = true,
				[51073] = true,
				[54129] = true,
				[50162] = true,
				[51826] = true,
				[50418] = true,
				[50546] = true,
				[50674] = true,
				[50802] = true,
				[38645] = true,
				[55153] = true,
				[54203] = true,
				[47219] = true,
				[55537] = true,
				[51570] = true,
				[51698] = true,
				[55921] = true,
				[51058] = true,
				[47987] = true,
				[40087] = true,
				[55793] = true,
				[56561] = true,
				[42115] = true,
				[39262] = true,
				[50049] = true,
				[48883] = true,
				[56790] = true,
				[49793] = true,
				[49267] = true,
				[49395] = true,
				[49523] = true,
				[53746] = true,
				[45570] = true,
				[31591] = true,
				[53583] = true,
				[50163] = true,
				[31568] = true,
				[42229] = true,
				[39607] = true,
				[50675] = true,
				[31548] = true,
				[38646] = true,
				[42869] = true,
				[53989] = true,
				[47220] = true,
				[55538] = true,
				[51571] = true,
				[42732] = true,
				[55922] = true,
				[13807] = true,
				[47988] = true,
				[56306] = true,
				[56434] = true,
				[48372] = true,
				[48500] = true,
				[52977] = true,
				[52851] = true,
				[41069] = true,
				[41462] = true,
				[57330] = true,
				[49268] = true,
				[45301] = true,
				[53619] = true,
				[53747] = true,
				[37495] = true,
				[49908] = true,
				[50036] = true,
				[50164] = true,
				[51538] = true,
				[42775] = true,
				[38687] = true,
				[39683] = true,
				[53406] = true,
				[38647] = true,
				[43993] = true,
				[47889] = true,
				[47221] = true,
				[55539] = true,
				[51572] = true,
				[51700] = true,
				[42741] = true,
				[51956] = true,
				[47989] = true,
				[52212] = true,
				[48344] = true,
				[44278] = true,
				[51200] = true,
				[56947] = true,
				[52852] = true,
				[52980] = true,
				[52975] = true,
				[31577] = true,
				[49269] = true,
				[51281] = true,
				[41463] = true,
				[53748] = true,
				[37496] = true,
				[50432] = true,
				[50037] = true,
				[50165] = true,
				[39663] = true,
				[41121] = true,
				[44382] = true,
				[50677] = true,
				[31549] = true,
				[54401] = true,
				[37507] = true,
				[49480] = true,
				[47222] = true,
				[48474] = true,
				[42670] = true,
				[43511] = true,
				[55924] = true,
				[41070] = true,
				[39800] = true,
				[37470] = true,
				[52853] = true,
				[52469] = true,
				[48026] = true,
				[37497] = true,
				[40568] = true,
				[44545] = true,
				[49014] = true,
				[56218] = true,
				[45175] = true,
				[49398] = true,
				[53621] = true,
				[53749] = true,
				[53877] = true,
				[52976] = true,
				[39595] = true,
				[54261] = true,
				[42104] = true,
				[38715] = true,
				[39588] = true,
				[51967] = true,
				[52494] = true,
				[46839] = true,
				[42872] = true,
				[51190] = true,
				[47223] = true,
				[51711] = true,
				[41475] = true,
				[38689] = true,
				[39775] = true,
				[51958] = true,
				[56181] = true,
				[56309] = true,
				[51199] = true,
				[56053] = true,
				[47134] = true,
				[47706] = true,
				[52854] = true,
				[38765] = true,
				[49015] = true,
				[49143] = true,
				[42786] = true,
				[49399] = true,
				[53622] = true,
				[53750] = true,
				[44464] = true,
				[44920] = true,
				[37890] = true,
				[54262] = true,
				[53110] = true,
				[54518] = true,
				[55030] = true,
				[50679] = true,
				[47224] = true,
				[46840] = true,
				[51063] = true,
				[51191] = true,
				[51319] = true,
				[39972] = true,
				[39133] = true,
				[52795] = true,
				[55926] = true,
				[11970] = true,
				[47992] = true,
				[55414] = true,
				[44153] = true,
				[52654] = true,
				[48504] = true,
				[52788] = true,
				[41760] = true,
				[52461] = true,
				[53623] = true,
				[57334] = true,
				[42079] = true,
				[49400] = true,
				[49528] = true,
				[53751] = true,
				[52290] = true,
				[53155] = true,
				[50040] = true,
				[54263] = true,
				[52041] = true,
				[54519] = true,
				[40229] = true,
				[38907] = true,
				[47743] = true,
				[46841] = true,
				[38834] = true,
				[51192] = true,
				[51320] = true,
				[47487] = true,
				[55671] = true,
				[39419] = true,
				[55799] = true,
				[56055] = true,
				[47993] = true,
				[56311] = true,
				[52460] = true,
				[52472] = true,
				[48505] = true,
				[49066] = true,
				[53887] = true,
				[47967] = true,
				[44922] = true,
				[57335] = true,
				[50814] = true,
				[49401] = true,
				[47654] = true,
				[41467] = true,
				[52158] = true,
				[51309] = true,
				[50041] = true,
				[42747] = true,
				[37889] = true,
				[50046] = true,
				[50553] = true,
				[47098] = true,
				[51959] = true,
				[50937] = true,
				[38780] = true,
				[51193] = true,
				[55928] = true,
				[55544] = true,
				[56184] = true,
				[47994] = true,
				[51833] = true,
				[51961] = true,
				[39804] = true,
				[52075] = true,
				[42721] = true,
				[52473] = true,
				[48506] = true,
				[46816] = true,
				[52205] = true,
				[53369] = true,
				[52462] = true,
				[57336] = true,
				[49274] = true,
				[41212] = true,
				[49530] = true,
				[53753] = true,
				[33071] = true,
				[41724] = true,
				[50170] = true,
				[54265] = true,
				[38691] = true,
				[55033] = true,
				[50554] = true,
				[50938] = true,
				[50810] = true,
				[46843] = true,
				[56057] = true,
				[38909] = true,
				[41099] = true,
				[55545] = true,
				[49975] = true,
				[55801] = true,
				[55929] = true,
				[47867] = true,
				[47995] = true,
				[56313] = true,
				[51581] = true,
				[52149] = true,
				[48507] = true,
				[38014] = true,
				[40573] = true,
				[57081] = true,
				[44924] = true,
				[47102] = true,
				[53370] = true,
				[49403] = true,
				[49531] = true,
				[41469] = true,
				[49787] = true,
				[50299] = true,
				[50043] = true,
				[54266] = true,
				[54394] = true,
				[38142] = true,
				[42749] = true,
				[38910] = true,
				[31552] = true,
				[50939] = true,
				[38782] = true,
				[47100] = true,
				[47228] = true,
				[55546] = true,
				[38778] = true,
				[42594] = true,
				[51835] = true,
				[56058] = true,
				[43901] = true,
				[52219] = true,
				[39592] = true,
				[52475] = true,
				[48508] = true,
				[50301] = true,
				[52859] = true,
				[31574] = true,
				[44925] = true,
				[57338] = true,
				[49276] = true,
				[49404] = true,
				[38052] = true,
				[38246] = true,
				[52208] = true,
				[42622] = true,
				[50044] = true,
				[50172] = true,
				[38015] = true,
				[38143] = true,
				[38911] = true,
				[49405] = true,
				[46717] = true,
				[46845] = true,
				[38655] = true,
				[47101] = true,
				[52040] = true,
				[55547] = true,
				[47485] = true,
				[45174] = true,
				[55931] = true,
				[47869] = true,
				[45414] = true,
				[56315] = true,
				[48774] = true,
				[56571] = true,
				[48874] = true,
				[46245] = true,
				[56165] = true,
				[49312] = true,
				[43942] = true,
				[47203] = true,
				[53372] = true,
				[41215] = true,
				[47653] = true,
				[52042] = true,
				[38377] = true,
				[48356] = true,
				[55260] = true,
				[50173] = true,
				[46206] = true,
				[38144] = true,
				[42367] = true,
				[44071] = true,
				[31553] = true,
				[38656] = true,
				[51069] = true,
				[38912] = true,
				[52789] = true,
				[55548] = true,
				[47486] = true,
				[43900] = true,
				[55932] = true,
				[47099] = true,
				[47998] = true,
				[52203] = true,
				[51949] = true,
				[56572] = true,
				[39594] = true,
				[49402] = true,
				[44070] = true,
				[57084] = true,
				[49960] = true,
				[57340] = true,
				[53373] = true,
				[56056] = true,
				[44004] = true,
				[52074] = true,
				[46842] = true,
				[55032] = true,
				[54141] = true,
				[50174] = true,
				[39591] = true,
				[38145] = true,
				[42368] = true,
				[51384] = true,
				[38529] = true,
				[42752] = true,
				[42666] = true,
				[38913] = true,
				[39803] = true,
				[55549] = true,
				[51582] = true,
				[39425] = true,
				[55933] = true,
				[42593] = true,
				[51366] = true,
				[52800] = true,
				[50168] = true,
				[56573] = true,
				[39596] = true,
				[39789] = true,
				[44672] = true,
				[53276] = true,
				[52327] = true,
				[39788] = true,
				[52204] = true,
				[49407] = true,
				[47991] = true,
				[41473] = true,
				[49791] = true,
				[52495] = true,
				[50047] = true,
				[50175] = true,
				[53916] = true,
				[38146] = true,
				[42369] = true,
				[40256] = true,
				[38916] = true,
				[42753] = true,
				[44663] = true,
				[47104] = true,
				[41708] = true,
				[55550] = true,
				[47488] = true,
				[39426] = true,
				[55934] = true,
				[39682] = true,
				[47627] = true,
				[39988] = true,
				[44161] = true,
				[38618] = true,
				[41464] = true,
				[56830] = true,
				[53109] = true,
				[57086] = true,
				[52790] = true,
				[40175] = true,
				[47990] = true,
				[49996] = true,
				[53631] = true,
				[41474] = true,
				[49792] = true,
				[51314] = true,
				[39027] = true,
				[48348] = true,
				[52291] = true,
				[38147] = true,
				[42370] = true,
				[50688] = true,
				[51356] = true,
				[42754] = true,
				[40567] = true,
				[38915] = true,
				[39043] = true,
				[56307] = true,
				[47489] = true,
				[51712] = true,
				[55935] = true,
				[51968] = true,
				[51279] = true,
				[56319] = true,
				[44381] = true,
				[52480] = true,
				[48513] = true,
				[50705] = true,
				[40819] = true,
				[52992] = true,
				[53820] = true,
				[53073] = true,
				[50803] = true,
				[49409] = true,
				[39772] = true,
				[53760] = true,
				[53888] = true,
				[49921] = true,
				[54144] = true,
				[50177] = true,
				[54400] = true,
				[46772] = true,
				[42371] = true,
				[42669] = true,
				[47827] = true,
				[55040] = true,
				[42883] = true,
				[51201] = true,
				[40814] = true,
				[55552] = true,
				[38488] = true,
				[50325] = true,
				[55936] = true,
				[51969] = true,
				[51825] = true,
				[56320] = true,
				[31015] = true,
				[46834] = true,
				[48180] = true,
				[53847] = true,
				[54628] = true,
				[48898] = true,
				[54058] = true,
				[52147] = true,
				[49282] = true,
				[41220] = true,
				[54417] = true,
				[53761] = true,
				[49794] = true,
				[54878] = true,
				[53405] = true,
				[37530] = true,
				[50306] = true,
				[42244] = true,
				[50562] = true,
				[38405] = true,
				[54205] = true,
				[42756] = true,
				[42884] = true,
				[47107] = true,
				[55425] = true,
				[55553] = true,
				[51586] = true,
				[39429] = true,
				[55937] = true,
				[39685] = true,
				[48003] = true,
				[56321] = true,
				[42737] = true,
				[48182] = true,
				[54441] = true,
				[56506] = true,
				[52866] = true,
				[52994] = true,
				[54418] = true,
				[54938] = true,
				[55373] = true,
				[41221] = true,
				[55101] = true,
				[53762] = true,
				[37510] = true,
				[49923] = true,
				[53167] = true,
				[41989] = true,
				[42117] = true,
				[39025] = true,
				[55116] = true,
				[50691] = true,
				[31556] = true,
				[38662] = true,
				[51075] = true,
				[51203] = true,
				[55426] = true,
				[55554] = true,
				[39438] = true,
				[51715] = true,
				[54964] = true,
				[39686] = true,
				[48004] = true,
				[52787] = true,
				[38414] = true,
				[50622] = true,
				[48516] = true,
				[50669] = true,
				[44677] = true,
				[40584] = true,
				[49028] = true,
				[50348] = true,
				[49284] = true,
				[49412] = true,
				[53635] = true,
				[41478] = true,
				[50897] = true,
				[42131] = true,
				[54975] = true,
				[54629] = true,
				[50308] = true,
				[55947] = true,
				[55519] = true,
				[54787] = true,
				[46725] = true,
				[38663] = true,
				[55171] = true,
				[51204] = true,
				[39047] = true,
				[55555] = true,
				[55955] = true,
				[56356] = true,
				[51844] = true,
				[56089] = true,
				[48005] = true,
				[50361] = true,
				[55374] = true,
				[55697] = true,
				[48517] = true,
				[55731] = true,
				[44678] = true,
				[56211] = true,
				[53124] = true,
				[42590] = true,
				[49285] = true,
				[39742] = true,
				[37256] = true,
				[41479] = true,
				[55183] = true,
				[56041] = true,
				[41863] = true,
				[55529] = true,
				[54404] = true,
				[55451] = true,
				[42375] = true,
				[50693] = true,
				[38857] = true,
				[55044] = true,
				[44481] = true,
				[51205] = true,
				[47238] = true,
				[55556] = true,
				[55599] = true,
				[55983] = true,
				[51845] = true,
				[39688] = true,
				[40255] = true,
				[40388] = true,
				[45507] = true,
				[39496] = true,
				[48518] = true,
				[56627] = true,
				[52869] = true,
				[48902] = true,
				[55902] = true,
				[48873] = true,
				[49286] = true,
				[56610] = true,
				[37257] = true,
				[41480] = true,
				[56787] = true,
				[49926] = true,
				[56632] = true,
				[56635] = true,
				[56378] = true,
				[50438] = true,
				[42376] = true,
				[50694] = true,
				[46727] = true,
				[55045] = true,
				[57134] = true,
				[38472] = true,
				[39049] = true,
				[56740] = true,
				[55890] = true,
				[55813] = true,
				[55941] = true,
				[39689] = true,
				[31752] = true,
				[56325] = true,
				[56587] = true,
				[44296] = true,
				[48519] = true,
				[39372] = true,
				[52870] = true,
				[48903] = true,
				[57133] = true,
				[54879] = true,
				[49287] = true,
				[48077] = true,
				[56597] = true,
				[56994] = true,
				[40009] = true,
				[55836] = true,
				[40401] = true,
				[53164] = true,
				[50311] = true,
				[55064] = true,
				[50567] = true,
				[38410] = true,
				[46728] = true,
				[39735] = true,
				[37969] = true,
				[51207] = true,
				[51335] = true,
				[55558] = true,
				[48974] = true,
				[55814] = true,
				[55942] = true,
				[39690] = true,
				[48008] = true,
				[56326] = true,
				[56996] = true,
				[56582] = true,
				[48520] = true,
				[56892] = true,
				[52871] = true,
				[48904] = true,
				[49032] = true,
				[54090] = true,
				[49288] = true,
				[41226] = true,
				[56652] = true,
				[40753] = true,
				[56534] = true,
				[55994] = true,
				[50056] = true,
				[56082] = true,
				[54407] = true,
				[42679] = true,
				[56599] = true,
				[50696] = true,
				[42634] = true,
				[56523] = true,
				[55175] = true,
				[51208] = true,
				[39051] = true,
				[56751] = true,
				[56380] = true,
				[51720] = true,
				[55943] = true,
				[39691] = true,
				[48009] = true,
				[56327] = true,
				[57169] = true,
				[57165] = true,
				[48521] = true,
				[56238] = true,
				[52260] = true,
				[53337] = true,
				[56079] = true,
				[49161] = true,
				[53384] = true,
				[49417] = true,
				[56277] = true,
				[53768] = true,
				[53896] = true,
				[49929] = true,
				[50057] = true,
				[56361] = true,
				[50604] = true,
				[38582] = true,
				[55073] = true,
				[38412] = true,
				[50825] = true,
				[50953] = true,
				[54876] = true,
				[51209] = true,
				[55896] = true,
				[55560] = true,
				[55688] = true,
				[55816] = true,
				[47754] = true,
				[47882] = true,
				[56508] = true,
				[56328] = true,
				[40076] = true,
				[52489] = true,
				[48522] = true,
				[44555] = true,
				[48778] = true,
				[56335] = true,
				[54454] = true,
			},
			["containers_opened"] = {
				[326407] = -1,
				[291263] = -1,
				[326415] = -1,
				[326409] = -1,
			},
			["rares_killed"] = {
				[50734] = -1,
				[152298] = -1,
				[152426] = -1,
				[152554] = -1,
				[129601] = -1,
				[133373] = -1,
				[153194] = -1,
				[50159] = -1,
				[127939] = -1,
				[151660] = -1,
				[139385] = -1,
				[152812] = -1,
				[138618] = -1,
				[131585] = -1,
				[134782] = -1,
				[154347] = -1,
				[131009] = -1,
				[151534] = -1,
				[152685] = -1,
				[152813] = -1,
				[131586] = -1,
				[145013] = -1,
				[134144] = -1,
				[151663] = -1,
				[131587] = -1,
				[155628] = -1,
				[152687] = -1,
				[123146] = -1,
				[147061] = -1,
				[153327] = -1,
				[129476] = -1,
				[155629] = -1,
				[152816] = -1,
				[147062] = -1,
				[132868] = -1,
				[128965] = -1,
				[134147] = -1,
				[154863] = -1,
				[138623] = -1,
				[145017] = -1,
				[130436] = -1,
				[139135] = -1,
				[151667] = -1,
				[131847] = -1,
				[141182] = -1,
				[127048] = -1,
				[150773] = -1,
				[151157] = -1,
				[130437] = -1,
				[147321] = -1,
				[134150] = -1,
				[153843] = -1,
				[138626] = -1,
				[145020] = -1,
				[131849] = -1,
				[152565] = -1,
				[138499] = -1,
				[138627] = -1,
				[132745] = -1,
				[131850] = -1,
				[134024] = -1,
				[139395] = -1,
				[128648] = -1,
				[150393] = -1,
				[139396] = -1,
				[138501] = -1,
				[153335] = -1,
				[135049] = -1,
				[139269] = -1,
				[147965] = -1,
				[137096] = -1,
				[151674] = -1,
				[138887] = -1,
				[140038] = -1,
				[125453] = -1,
				[136330] = -1,
				[147839] = -1,
				[144898] = -1,
				[145026] = -1,
				[152315] = -1,
				[135052] = -1,
				[155768] = -1,
				[152827] = -1,
				[140679] = -1,
				[147968] = -1,
				[129802] = -1,
				[127820] = -1,
				[147202] = -1,
				[152445] = -1,
				[146819] = -1,
				[145029] = -1,
				[131858] = -1,
				[129547] = -1,
				[151679] = -1,
				[129803] = -1,
				[153470] = -1,
				[144647] = -1,
				[131476] = -1,
				[132755] = -1,
				[130443] = -1,
				[129548] = -1,
				[130635] = -1,
				[134418] = -1,
				[152960] = -1,
				[128973] = -1,
				[139278] = -1,
				[122963] = -1,
				[122004] = -1,
				[153984] = -1,
				[154240] = -1,
				[145161] = -1,
				[153473] = -1,
				[151683] = -1,
				[152962] = -1,
				[153218] = -1,
				[131863] = -1,
				[128974] = -1,
				[139280] = -1,
				[139536] = -1,
				[153091] = -1,
				[153219] = -1,
				[151301] = -1,
				[136340] = -1,
				[139537] = -1,
				[139665] = -1,
				[152069] = -1,
				[146059] = -1,
				[146187] = -1,
				[145292] = -1,
				[152709] = -1,
				[140561] = -1,
				[129231] = -1,
				[152070] = -1,
				[136214] = -1,
				[152710] = -1,
				[140562] = -1,
				[148874] = -1,
				[152071] = -1,
				[146061] = -1,
				[134041] = -1,
				[152711] = -1,
				[140563] = -1,
				[136599] = -1,
				[144911] = -1,
				[153479] = -1,
				[139285] = -1,
				[130639] = -1,
				[141587] = -1,
				[153991] = -1,
				[149004] = -1,
				[153224] = -1,
				[153352] = -1,
				[138135] = -1,
				[150667] = -1,
				[151946] = -1,
				[155271] = -1,
				[135962] = -1,
				[139287] = -1,
				[153737] = -1,
				[146832] = -1,
				[139799] = -1,
				[155272] = -1,
				[135963] = -1,
				[148367] = -1,
				[132127] = -1,
				[153738] = -1,
				[127124] = -1,
				[146833] = -1,
				[144915] = -1,
				[121242] = -1,
				[152460] = -1,
				[139289] = -1,
				[153739] = -1,
				[127636] = -1,
				[130897] = -1,
				[152461] = -1,
				[139290] = -1,
				[153740] = -1,
				[147730] = -1,
				[146835] = -1,
				[123289] = -1,
				[134048] = -1,
				[153741] = -1,
				[155276] = -1,
				[155404] = -1,
				[122970] = -1,
				[153998] = -1,
				[139804] = -1,
				[123290] = -1,
				[140188] = -1,
				[133155] = -1,
				[140444] = -1,
				[155917] = -1,
				[146838] = -1,
				[139805] = -1,
				[144409] = -1,
				[136353] = -1,
				[155918] = -1,
				[146072] = -1,
				[123291] = -1,
				[126424] = -1,
				[155791] = -1,
				[155919] = -1,
				[146840] = -1,
				[139807] = -1,
				[132007] = -1,
				[133158] = -1,
				[154769] = -1,
				[155920] = -1,
				[139808] = -1,
				[123292] = -1,
				[145307] = -1,
				[139297] = -1,
				[152724] = -1,
				[130638] = -1,
				[125828] = -1,
				[153192] = -1,
				[135048] = -1,
				[141088] = -1,
				[145308] = -1,
				[139298] = -1,
				[154771] = -1,
				[127129] = -1,
				[140430] = -1,
				[142454] = -1,
				[129232] = -1,
				[145181] = -1,
				[134056] = -1,
				[129559] = -1,
				[154772] = -1,
				[129995] = -1,
				[141980] = -1,
				[140690] = -1,
				[132778] = -1,
				[135975] = -1,
				[145035] = -1,
				[138497] = -1,
				[152969] = -1,
				[153069] = -1,
				[139684] = -1,
				[127757] = -1,
				[127315] = -1,
				[146826] = -1,
				[151676] = -1,
				[137255] = -1,
				[139429] = -1,
				[140432] = -1,
				[132126] = -1,
				[155512] = -1,
				[122972] = -1,
				[122965] = -1,
				[130435] = -1,
				[129471] = -1,
				[154775] = -1,
				[136470] = -1,
				[134571] = -1,
				[154491] = -1,
				[122969] = -1,
				[127879] = -1,
				[134060] = -1,
				[122968] = -1,
				[154776] = -1,
				[122967] = -1,
				[154482] = -1,
				[131631] = -1,
				[145058] = -1,
				[142587] = -1,
				[153332] = -1,
				[145180] = -1,
				[145415] = -1,
				[131376] = -1,
				[144803] = -1,
				[125214] = -1,
				[135852] = -1,
				[132911] = -1,
				[140200] = -1,
				[145443] = -1,
				[139152] = -1,
				[131377] = -1,
				[126983] = -1,
				[147561] = -1,
				[145060] = -1,
				[151326] = -1,
				[134417] = -1,
				[149536] = -1,
				[130138] = -1,
				[140585] = -1,
				[139690] = -1,
				[153504] = -1,
				[145061] = -1,
				[151327] = -1,
				[130522] = -1,
				[155361] = -1,
				[154780] = -1,
				[135796] = -1,
				[130778] = -1,
				[140334] = -1,
				[130012] = -1,
				[138498] = -1,
				[141226] = -1,
				[152675] = -1,
				[131252] = -1,
				[129180] = -1,
				[152547] = -1,
				[134005] = -1,
				[130077] = -1,
				[155421] = -1,
				[154786] = -1,
				[137713] = -1,
				[140792] = -1,
				[131381] = -1,
				[152992] = -1,
				[134706] = -1,
				[132919] = -1,
				[140077] = -1,
				[140205] = -1,
				[74834] = -1,
				[145513] = -1,
				[135474] = -1,
				[132086] = -1,
				[132922] = -1,
				[145065] = -1,
				[140078] = -1,
				[140206] = -1,
				[138288] = -1,
				[155807] = -1,
				[155935] = -1,
				[152994] = -1,
				[145129] = -1,
				[138863] = -1,
				[155424] = -1,
				[148391] = -1,
				[140335] = -1,
				[154785] = -1,
				[130143] = -1,
				[138500] = -1,
				[136186] = -1,
				[145195] = -1,
				[152356] = -1,
				[140208] = -1,
				[126497] = -1,
				[132280] = -1,
				[134828] = -1,
				[131513] = -1,
				[154378] = -1,
				[136944] = -1,
				[152357] = -1,
				[145324] = -1,
				[140337] = -1,
				[154787] = -1,
				[150541] = -1,
				[138675] = -1,
				[130334] = -1,
				[146186] = -1,
				[152358] = -1,
				[153895] = -1,
				[150568] = -1,
				[150696] = -1,
				[153893] = -1,
				[141585] = -1,
				[136100] = -1,
				[139955] = -1,
				[128928] = -1,
				[145326] = -1,
				[130079] = -1,
				[151720] = -1,
				[145328] = -1,
				[155813] = -1,
				[130335] = -1,
				[134897] = -1,
				[152362] = -1,
				[145327] = -1,
				[135939] = -1,
				[152744] = -1,
				[124581] = -1,
				[146862] = -1,
				[145967] = -1,
				[130011] = -1,
				[148231] = -1,
				[137144] = -1,
				[4075] = -1,
				[131262] = -1,
				[153896] = -1,
				[132211] = -1,
				[154152] = -1,
				[130400] = -1,
				[139063] = -1,
				[152543] = -1,
				[139319] = -1,
				[138938] = -1,
				[127651] = -1,
				[129602] = -1,
				[155228] = -1,
				[122264] = -1,
				[152363] = -1,
				[137146] = -1,
				[122266] = -1,
				[151775] = -1,
				[134139] = -1,
				[131520] = -1,
				[145059] = -1,
				[140983] = -1,
				[152364] = -1,
				[137147] = -1,
				[139321] = -1,
				[141239] = -1,
				[136338] = -1,
				[134173] = -1,
				[129826] = -1,
				[140984] = -1,
				[119724] = -1,
				[138171] = -1,
				[130298] = -1,
				[153948] = -1,
				[141959] = -1,
				[126621] = -1,
				[144949] = -1,
				[127333] = -1,
				[138495] = -1,
				[145333] = -1,
				[150389] = -1,
				[138428] = -1,
				[129699] = -1,
				[131825] = -1,
				[129827] = -1,
				[154285] = -1,
				[152367] = -1,
				[130653] = -1,
				[129786] = -1,
				[138429] = -1,
				[128699] = -1,
				[144823] = -1,
				[134270] = -1,
				[151985] = -1,
				[135964] = -1,
				[152412] = -1,
				[152624] = -1,
				[134338] = -1,
				[155612] = -1,
				[137663] = -1,
				[152492] = -1,
				[131568] = -1,
				[139693] = -1,
				[137152] = -1,
				[135234] = -1,
				[126056] = -1,
				[152881] = -1,
				[139710] = -1,
				[145976] = -1,
				[130404] = -1,
				[151604] = -1,
				[145337] = -1,
				[154713] = -1,
				[134213] = -1,
				[152882] = -1,
				[131527] = -1,
				[145977] = -1,
				[154799] = -1,
				[131823] = -1,
				[145338] = -1,
				[133190] = -1,
				[137155] = -1,
				[152883] = -1,
				[151988] = -1,
				[138434] = -1,
				[139968] = -1,
				[138820] = -1,
				[153523] = -1,
				[151605] = -1,
				[135365] = -1,
				[152884] = -1,
				[151989] = -1,
				[130680] = -1,
				[154717] = -1,
				[126460] = -1,
				[137156] = -1,
				[155698] = -1,
				[130488] = -1,
				[138983] = -1,
				[151990] = -1,
				[124185] = -1,
				[153269] = -1,
				[137029] = -1,
				[154548] = -1,
				[140354] = -1,
				[139459] = -1,
				[132887] = -1,
				[153217] = -1,
				[140866] = -1,
				[148155] = -1,
				[152793] = -1,
				[154711] = -1,
				[140355] = -1,
				[139460] = -1,
				[131404] = -1,
				[138693] = -1,
				[138821] = -1,
				[130508] = -1,
				[140356] = -1,
				[139205] = -1,
				[155701] = -1,
				[139461] = -1,
				[145339] = -1,
				[136139] = -1,
				[138822] = -1,
				[139328] = -1,
				[144944] = -1,
				[130024] = -1,
				[130679] = -1,
				[139462] = -1,
				[145008] = -1,
				[140260] = -1,
				[138823] = -1,
				[140997] = -1,
				[136189] = -1,
				[149437] = -1,
				[154936] = -1,
				[139463] = -1,
				[131407] = -1,
				[138696] = -1,
				[131663] = -1,
				[137830] = -1,
				[129961] = -1,
				[145346] = -1,
				[154681] = -1,
				[151740] = -1,
				[144707] = -1,
				[139720] = -1,
				[154092] = -1,
				[149850] = -1,
				[152380] = -1,
				[155860] = -1,
				[151640] = -1,
				[145603] = -1,
				[139400] = -1,
				[144836] = -1,
				[131389] = -1,
				[135329] = -1,
				[152381] = -1,
				[126190] = -1,
				[134738] = -1,
				[151742] = -1,
				[152893] = -1,
				[151998] = -1,
				[131666] = -1,
				[152918] = -1,
				[148290] = -1,
				[130678] = -1,
				[152638] = -1,
				[133842] = -1,
				[151871] = -1,
				[129527] = -1,
				[129835] = -1,
				[148163] = -1,
				[152383] = -1,
				[138189] = -1,
				[132179] = -1,
				[152641] = -1,
				[137956] = -1,
				[148164] = -1,
				[138469] = -1,
				[139980] = -1,
				[152384] = -1,
				[148392] = -1,
				[153812] = -1,
				[151745] = -1,
				[154707] = -1,
				[158395] = -1,
				[154175] = -1,
				[146119] = -1,
				[152092] = -1,
				[129005] = -1,
				[154687] = -1,
				[154815] = -1,
				[140076] = -1,
				[148292] = -1,
				[131670] = -1,
				[158396] = -1,
				[155585] = -1,
				[129517] = -1,
				[132182] = -1,
				[152916] = -1,
				[128686] = -1,
				[134612] = -1,
				[135240] = -1,
				[136914] = -1,
				[145028] = -1,
				[146607] = -1,
				[152560] = -1,
				[144810] = -1,
				[150156] = -1,
				[153027] = -1,
				[155201] = -1,
				[132904] = -1,
				[152635] = -1,
				[132056] = -1,
				[155814] = -1,
				[155403] = -1,
				[152135] = -1,
				[144844] = -1,
				[138837] = -1,
				[153963] = -1,
				[127799] = -1,
				[145356] = -1,
				[144975] = -1,
				[151750] = -1,
				[126187] = -1,
				[144845] = -1,
				[145340] = -1,
				[138963] = -1,
				[144976] = -1,
				[131667] = -1,
				[134232] = -1,
				[144846] = -1,
				[144974] = -1,
				[133593] = -1,
				[155204] = -1,
				[140107] = -1,
				[139988] = -1,
				[129719] = -1,
				[138470] = -1,
				[139476] = -1,
				[144719] = -1,
				[153814] = -1,
				[154182] = -1,
				[154310] = -1,
				[148300] = -1,
				[134106] = -1,
				[136280] = -1,
				[149707] = -1,
				[151881] = -1,
				[137946] = -1,
				[131677] = -1,
				[154311] = -1,
				[155465] = -1,
				[150475] = -1,
				[152273] = -1,
				[131685] = -1,
				[136807] = -1,
				[146895] = -1,
				[138839] = -1,
				[154312] = -1,
				[128434] = -1,
				[153935] = -1,
				[152906] = -1,
				[139617] = -1,
				[144722] = -1,
				[126455] = -1,
				[138840] = -1,
				[137945] = -1,
				[155859] = -1,
				[154569] = -1,
				[154697] = -1,
				[132319] = -1,
				[137950] = -1,
				[152790] = -1,
				[157383] = -1,
				[138969] = -1,
				[128435] = -1,
				[144727] = -1,
				[154698] = -1,
				[126205] = -1,
				[149839] = -1,
				[135903] = -1,
				[131864] = -1,
				[137947] = -1,
				[131812] = -1,
				[145110] = -1,
				[152653] = -1,
				[153804] = -1,
				[136541] = -1,
				[144725] = -1,
				[136797] = -1,
				[153293] = -1,
				[130550] = -1,
				[147411] = -1,
				[138332] = -1,
				[153888] = -1,
				[153933] = -1,
				[154700] = -1,
				[158397] = -1,
				[148179] = -1,
				[155468] = -1,
				[133482] = -1,
				[144977] = -1,
				[144724] = -1,
				[146773] = -1,
				[134625] = -1,
				[141059] = -1,
				[132835] = -1,
				[149331] = -1,
				[132068] = -1,
				[138471] = -1,
				[126583] = -1,
				[149843] = -1,
				[154768] = -1,
				[134754] = -1,
				[137951] = -1,
				[153694] = -1,
				[138838] = -1,
				[144720] = -1,
				[152392] = -1,
				[131545] = -1,
				[153699] = -1,
				[137824] = -1,
				[152274] = -1,
				[154448] = -1,
				[153462] = -1,
				[146892] = -1,
				[126832] = -1,
				[131431] = -1,
				[131311] = -1,
				[137825] = -1,
				[134884] = -1,
				[131408] = -1,
				[146890] = -1,
				[154705] = -1,
				[128551] = -1,
				[152915] = -1,
				[150997] = -1,
				[144987] = -1,
				[130421] = -1,
				[136551] = -1,
				[139233] = -1,
				[154706] = -1,
				[138466] = -1,
				[151893] = -1,
				[131669] = -1,
				[144966] = -1,
				[148185] = -1,
				[128951] = -1,
				[126969] = -1,
				[139362] = -1,
				[138467] = -1,
				[152917] = -1,
				[140108] = -1,
				[132713] = -1,
				[131818] = -1,
				[139398] = -1,
				[139235] = -1,
				[136393] = -1,
				[138468] = -1,
				[136550] = -1,
				[155195] = -1,
				[134760] = -1,
				[131819] = -1,
				[128707] = -1,
				[146859] = -1,
				[136295] = -1,
				[149722] = -1,
				[152919] = -1,
				[147932] = -1,
				[127290] = -1,
				[137958] = -1,
				[145323] = -1,
				[132076] = -1,
				[154710] = -1,
				[152792] = -1,
				[136552] = -1,
				[147933] = -1,
				[145343] = -1,
				[130661] = -1,
				[126907] = -1,
				[139457] = -1,
				[136297] = -1,
				[133356] = -1,
				[152921] = -1,
				[144958] = -1,
				[144993] = -1,
				[141029] = -1,
				[156502] = -1,
				[129529] = -1,
				[140353] = -1,
				[138472] = -1,
				[132807] = -1,
				[147935] = -1,
				[136810] = -1,
				[152283] = -1,
				[152411] = -1,
				[141286] = -1,
				[152667] = -1,
				[153818] = -1,
				[151900] = -1,
				[147936] = -1,
				[136811] = -1,
				[131824] = -1,
				[155481] = -1,
				[140264] = -1,
				[148513] = -1,
				[136428] = -1,
				[153947] = -1,
				[134638] = -1,
				[136812] = -1,
				[126845] = -1,
				[152413] = -1,
				[152541] = -1,
				[155900] = -1,
				[127119] = -1,
				[139626] = -1,
				[147938] = -1,
				[144997] = -1,
				[50355] = -1,
				[134271] = -1,
				[130779] = -1,
				[122971] = -1,
				[133361] = -1,
				[152236] = -1,
				[131571] = -1,
				[152159] = -1,
				[152287] = -1,
				[152822] = -1,
				[148451] = -1,
				[145510] = -1,
				[137529] = -1,
				[140458] = -1,
				[153055] = -1,
				[129340] = -1,
				[152288] = -1,
				[136249] = -1,
				[126463] = -1,
				[136304] = -1,
				[155869] = -1,
				[134514] = -1,
				[150698] = -1,
				[123352] = -1,
				[126847] = -1,
				[150371] = -1,
				[132918] = -1,
				[152673] = -1,
				[136341] = -1,
				[139399] = -1,
				[154530] = -1,
				[152162] = -1,
				[148198] = -1,
				[135961] = -1,
				[148454] = -1,
				[154720] = -1,
				[155871] = -1,
				[127111] = -1,
				[152035] = -1,
				[134069] = -1,
				[138992] = -1,
				[150373] = -1,
				[155616] = -1,
				[154721] = -1,
				[126919] = -1,
				[129214] = -1,
				[134269] = -1,
				[125250] = -1,
				[141039] = -1,
				[145444] = -1,
				[138226] = -1,
				[152676] = -1,
				[136598] = -1,
				[139800] = -1,
				[130521] = -1,
				[136347] = -1,
				[145132] = -1,
				[139691] = -1,
				[155618] = -1,
				[147562] = -1,
				[140457] = -1,
				[134423] = -1,
				[156130] = -1,
				[126429] = -1,
				[151581] = -1,
				[150376] = -1,
				[155619] = -1,
				[129599] = -1,
				[124548] = -1,
				[153957] = -1,
				[153333] = -1,
				[154213] = -1,
				[140434] = -1,
				[145163] = -1,
				[134137] = -1,
				[154725] = -1,
				[127106] = -1,
				[145153] = -1,
				[147948] = -1,
				[136083] = -1,
				[140678] = -1,
				[140691] = -1,
				[130325] = -1,
				[129600] = -1,
				[152683] = -1,
				[153959] = -1,
				[156133] = -1,
				[143985] = -1,
				[152297] = -1,
				[49999] = -1,
			},
		},
		["뉘시빨라마 - 굴단"] = {
			["scannerXPos"] = 1610.431518554688,
			["containers_opened"] = {
				[293962] = -1,
				[293964] = -1,
				[275076] = -1,
			},
			["scannerYPos"] = 629.3333129882813,
			["quests_completed"] = {
				[55117] = true,
				[47057] = true,
				[51215] = true,
				[49232] = true,
				[51343] = true,
				[51407] = true,
				[45394] = true,
				[49744] = true,
				[47889] = true,
				[50064] = true,
				[48081] = true,
				[42068] = true,
				[31309] = true,
				[52495] = true,
				[40341] = true,
				[40405] = true,
				[50704] = true,
				[38486] = true,
				[46802] = true,
				[55118] = true,
				[51088] = true,
				[47058] = true,
				[51280] = true,
				[45395] = true,
				[53711] = true,
				[51728] = true,
				[49745] = true,
				[47890] = true,
				[50001] = true,
				[50065] = true,
				[52240] = true,
				[42197] = true,
				[50449] = true,
				[50705] = true,
				[50897] = true,
				[55119] = true,
				[55183] = true,
				[47059] = true,
				[51217] = true,
				[51281] = true,
				[45396] = true,
				[53712] = true,
				[49746] = true,
				[47891] = true,
				[50002] = true,
				[45972] = true,
				[52241] = true,
				[42198] = true,
				[50450] = true,
				[50706] = true,
				[50898] = true,
				[44821] = true,
				[53073] = true,
				[51218] = true,
				[51282] = true,
				[47252] = true,
				[49427] = true,
				[51538] = true,
				[47508] = true,
				[49619] = true,
				[49939] = true,
				[50003] = true,
				[52242] = true,
				[54417] = true,
				[56528] = true,
				[50451] = true,
				[46805] = true,
				[53074] = true,
				[55185] = true,
				[53202] = true,
				[51283] = true,
				[49300] = true,
				[49428] = true,
				[49620] = true,
				[51795] = true,
				[50260] = true,
				[48277] = true,
				[42200] = true,
				[50452] = true,
				[54610] = true,
				[48597] = true,
				[48853] = true,
				[57169] = true,
				[51220] = true,
				[51540] = true,
				[49621] = true,
				[51796] = true,
				[54035] = true,
				[50069] = true,
				[50133] = true,
				[44120] = true,
				[50325] = true,
				[56530] = true,
				[50453] = true,
				[54611] = true,
				[50645] = true,
				[50773] = true,
				[44760] = true,
				[50965] = true,
				[51029] = true,
				[51221] = true,
				[53332] = true,
				[49302] = true,
				[41306] = true,
				[53652] = true,
				[39771] = true,
				[50070] = true,
				[50134] = true,
				[52245] = true,
				[50454] = true,
				[56787] = true,
				[50774] = true,
				[31568] = true,
				[47000] = true,
				[51222] = true,
				[49239] = true,
				[51350] = true,
				[49367] = true,
				[49431] = true,
				[43418] = true,
				[53717] = true,
				[53909] = true,
				[47960] = true,
				[52118] = true,
				[50135] = true,
				[50263] = true,
				[50327] = true,
				[48344] = true,
				[56596] = true,
				[50583] = true,
				[48600] = true,
				[48792] = true,
				[50903] = true,
				[51159] = true,
				[53334] = true,
				[51351] = true,
				[49368] = true,
				[47641] = true,
				[43675] = true,
				[53974] = true,
				[47961] = true,
				[48025] = true,
				[50136] = true,
				[46106] = true,
				[50264] = true,
				[48281] = true,
				[48345] = true,
				[50584] = true,
				[48601] = true,
				[54870] = true,
				[48793] = true,
				[46938] = true,
				[47066] = true,
				[47194] = true,
				[49305] = true,
				[49369] = true,
				[49433] = true,
				[51544] = true,
				[53847] = true,
				[45723] = true,
				[53975] = true,
				[50009] = true,
				[48026] = true,
				[50137] = true,
				[46107] = true,
				[50265] = true,
				[50329] = true,
				[56534] = true,
				[50457] = true,
				[48474] = true,
				[48538] = true,
				[50649] = true,
				[50777] = true,
				[52888] = true,
				[48986] = true,
				[47003] = true,
				[49178] = true,
				[49242] = true,
				[51353] = true,
				[53464] = true,
				[51545] = true,
				[55895] = true,
				[47771] = true,
				[47835] = true,
				[45852] = true,
				[45916] = true,
				[52121] = true,
				[50266] = true,
				[48283] = true,
				[44253] = true,
				[48475] = true,
				[50586] = true,
				[50778] = true,
				[42782] = true,
				[51034] = true,
				[47004] = true,
				[47196] = true,
				[51354] = true,
				[51418] = true,
				[49435] = true,
				[49755] = true,
				[45725] = true,
				[53977] = true,
				[43806] = true,
				[52058] = true,
				[50075] = true,
				[50139] = true,
				[50331] = true,
				[48348] = true,
				[40224] = true,
				[48476] = true,
				[48540] = true,
				[48668] = true,
				[50779] = true,
				[46941] = true,
				[47005] = true,
				[51163] = true,
				[51547] = true,
				[43423] = true,
				[53978] = true,
				[56089] = true,
				[41888] = true,
				[42208] = true,
				[40225] = true,
				[48477] = true,
				[50588] = true,
				[48605] = true,
				[50780] = true,
				[31571] = true,
				[50908] = true,
				[55066] = true,
				[47006] = true,
				[49181] = true,
				[51356] = true,
				[53723] = true,
				[55898] = true,
				[45727] = true,
				[52060] = true,
				[54171] = true,
				[54299] = true,
				[50269] = true,
				[50525] = true,
				[48542] = true,
				[50653] = true,
				[48670] = true,
				[50781] = true,
				[54939] = true,
				[46815] = true,
				[50973] = true,
				[42977] = true,
				[51229] = true,
				[55707] = true,
				[53916] = true,
				[49886] = true,
				[45856] = true,
				[47967] = true,
				[52125] = true,
				[48671] = true,
				[54876] = true,
				[31572] = true,
				[46816] = true,
				[13807] = true,
				[51358] = true,
				[49439] = true,
				[55708] = true,
				[55836] = true,
				[49887] = true,
				[49951] = true,
				[47968] = true,
				[56220] = true,
				[37989] = true,
				[48352] = true,
				[56604] = true,
				[48544] = true,
				[48672] = true,
				[50783] = true,
				[57244] = true,
				[51167] = true,
				[47137] = true,
				[51359] = true,
				[47329] = true,
				[51487] = true,
				[55645] = true,
				[51807] = true,
				[47969] = true,
				[56221] = true,
				[56285] = true,
				[54302] = true,
				[48353] = true,
				[50528] = true,
				[50784] = true,
				[31573] = true,
				[46818] = true,
				[48929] = true,
				[51168] = true,
				[47202] = true,
				[51424] = true,
				[51488] = true,
				[51872] = true,
				[52128] = true,
				[52256] = true,
				[48354] = true,
				[54559] = true,
				[46499] = true,
				[48674] = true,
				[51169] = true,
				[47203] = true,
				[55519] = true,
				[51489] = true,
				[45476] = true,
				[41510] = true,
				[51809] = true,
				[51873] = true,
				[49890] = true,
				[56095] = true,
				[52065] = true,
				[56287] = true,
				[52257] = true,
				[46244] = true,
				[48355] = true,
				[48419] = true,
				[50530] = true,
				[50594] = true,
				[48675] = true,
				[31574] = true,
				[51170] = true,
				[51298] = true,
				[55520] = true,
				[49443] = true,
				[51554] = true,
				[45477] = true,
				[47652] = true,
				[53857] = true,
				[52002] = true,
				[44006] = true,
				[44070] = true,
				[46245] = true,
				[48356] = true,
				[50467] = true,
				[50531] = true,
				[50595] = true,
				[48676] = true,
				[52834] = true,
				[48804] = true,
				[49060] = true,
				[42983] = true,
				[49252] = true,
				[51363] = true,
				[51427] = true,
				[53602] = true,
				[55713] = true,
				[47589] = true,
				[47653] = true,
				[53986] = true,
				[52003] = true,
				[52067] = true,
				[50148] = true,
				[48165] = true,
				[46182] = true,
				[50340] = true,
				[52451] = true,
				[48421] = true,
				[54626] = true,
				[48677] = true,
				[48805] = true,
				[53155] = true,
				[42984] = true,
				[51492] = true,
				[47526] = true,
				[47654] = true,
				[51876] = true,
				[56162] = true,
				[41897] = true,
				[50149] = true,
				[52260] = true,
				[46247] = true,
				[56610] = true,
				[50533] = true,
				[48678] = true,
				[48806] = true,
				[53028] = true,
				[42857] = true,
				[53476] = true,
				[43433] = true,
				[51749] = true,
				[51813] = true,
				[39595] = true,
				[53988] = true,
				[41770] = true,
				[43945] = true,
				[44009] = true,
				[52261] = true,
				[54436] = true,
				[56611] = true,
				[50534] = true,
				[50662] = true,
				[48679] = true,
				[52837] = true,
				[31576] = true,
				[42986] = true,
				[51366] = true,
				[49383] = true,
				[33071] = true,
				[49703] = true,
				[49831] = true,
				[53989] = true,
				[41771] = true,
				[52070] = true,
				[43946] = true,
				[46057] = true,
				[50343] = true,
				[54629] = true,
				[56740] = true,
				[48616] = true,
				[48680] = true,
				[57060] = true,
				[53222] = true,
				[51367] = true,
				[51431] = true,
				[51623] = true,
				[49704] = true,
				[51879] = true,
				[49896] = true,
				[41772] = true,
				[43947] = true,
				[50152] = true,
				[54310] = true,
				[50280] = true,
				[54630] = true,
				[50600] = true,
				[31577] = true,
				[57061] = true,
				[42988] = true,
				[51368] = true,
				[49385] = true,
				[49705] = true,
				[49769] = true,
				[51880] = true,
				[56038] = true,
				[41773] = true,
				[47978] = true,
				[43948] = true,
				[48170] = true,
				[50281] = true,
				[46251] = true,
				[40238] = true,
				[44396] = true,
				[50601] = true,
				[48682] = true,
				[50793] = true,
				[56998] = true,
				[53160] = true,
				[42989] = true,
				[52874] = true,
				[55399] = true,
				[51369] = true,
				[38355] = true,
				[56023] = true,
				[51541] = true,
				[53672] = true,
				[55783] = true,
				[39471] = true,
				[49299] = true,
				[51881] = true,
				[49898] = true,
				[55887] = true,
				[47979] = true,
				[50090] = true,
				[48107] = true,
				[48171] = true,
				[52329] = true,
				[44205] = true,
				[40175] = true,
				[42286] = true,
				[44397] = true,
				[51611] = true,
				[38384] = true,
				[48683] = true,
				[44653] = true,
				[52969] = true,
				[57063] = true,
				[48939] = true,
				[55712] = true,
				[56652] = true,
				[42990] = true,
				[51242] = true,
				[49259] = true,
				[52494] = true,
				[50599] = true,
				[49451] = true,
				[38037] = true,
				[53673] = true,
				[55784] = true,
				[47892] = true,
				[51035] = true,
				[46033] = true,
				[53715] = true,
				[41775] = true,
				[47980] = true,
				[49999] = true,
				[48108] = true,
				[47888] = true,
				[56724] = true,
				[46253] = true,
				[49807] = true,
				[56143] = true,
				[44398] = true,
				[52778] = true,
				[56808] = true,
				[50731] = true,
				[44654] = true,
				[46765] = true,
				[44782] = true,
				[53206] = true,
				[53098] = true,
				[53414] = true,
				[51534] = true,
				[56149] = true,
				[49260] = true,
				[51371] = true,
				[49388] = true,
				[49452] = true,
				[40084] = true,
				[53674] = true,
				[56277] = true,
				[51278] = true,
				[56422] = true,
				[34774] = true,
				[47853] = true,
				[41776] = true,
				[47981] = true,
				[50092] = true,
				[48109] = true,
				[39985] = true,
				[56276] = true,
				[55116] = true,
				[48365] = true,
				[56024] = true,
				[44399] = true,
				[44463] = true,
				[48621] = true,
				[51150] = true,
				[48941] = true,
				[31579] = true,
				[38642] = true,
				[40753] = true,
				[57167] = true,
				[55210] = true,
				[49133] = true,
				[48273] = true,
				[51308] = true,
				[55720] = true,
				[56593] = true,
				[49453] = true,
				[41901] = true,
				[53675] = true,
				[52493] = true,
				[56606] = true,
				[54412] = true,
				[47854] = true,
				[56042] = true,
				[41777] = true,
				[47982] = true,
				[54618] = true,
				[48110] = true,
				[39986] = true,
				[56039] = true,
				[50349] = true,
				[48366] = true,
				[40242] = true,
				[48558] = true,
				[50605] = true,
				[50669] = true,
				[50733] = true,
				[50797] = true,
				[44720] = true,
				[41899] = true,
				[48942] = true,
				[55374] = true,
				[53164] = true,
				[49134] = true,
				[41330] = true,
				[51309] = true,
				[39596] = true,
				[55531] = true,
				[55595] = true,
				[55659] = true,
				[50593] = true,
				[49710] = true,
				[47663] = true,
				[56212] = true,
				[54992] = true,
				[47855] = true,
				[52013] = true,
				[54315] = true,
				[54871] = true,
				[50158] = true,
				[39987] = true,
				[54380] = true,
				[44465] = true,
				[48367] = true,
				[31580] = true,
				[49230] = true,
				[48559] = true,
				[56043] = true,
				[51149] = true,
				[31548] = true,
				[44721] = true,
				[44785] = true,
				[48943] = true,
				[55179] = true,
				[48974] = true,
				[51310] = true,
				[57034] = true,
				[55404] = true,
				[41694] = true,
				[48539] = true,
				[33079] = true,
				[56156] = true,
				[53677] = true,
				[54946] = true,
				[48483] = true,
				[52492] = true,
				[47792] = true,
				[47856] = true,
				[56037] = true,
				[55529] = true,
				[50095] = true,
				[50253] = true,
				[54317] = true,
				[47843] = true,
				[50351] = true,
				[48368] = true,
				[45864] = true,
				[53221] = true,
				[48560] = true,
				[47950] = true,
				[49706] = true,
				[54628] = true,
				[57004] = true,
				[52974] = true,
				[48944] = true,
				[46961] = true,
				[42931] = true,
				[42995] = true,
				[51852] = true,
				[47217] = true,
				[51311] = true,
				[55533] = true,
				[55597] = true,
				[47473] = true,
				[53678] = true,
				[54495] = true,
				[55593] = true,
				[54485] = true,
				[48606] = true,
				[50352] = true,
				[48369] = true,
				[55182] = true,
				[50096] = true,
				[48113] = true,
				[54318] = true,
				[45915] = true,
				[46258] = true,
				[54510] = true,
				[55851] = true,
				[50544] = true,
				[50608] = true,
				[50672] = true,
				[44659] = true,
				[31549] = true,
				[54421] = true,
				[42740] = true,
				[48945] = true,
				[38774] = true,
				[42932] = true,
				[42996] = true,
				[50644] = true,
				[45171] = true,
				[55598] = true,
				[49393] = true,
				[51504] = true,
				[54418] = true,
				[51632] = true,
				[46734] = true,
				[50446] = true,
				[54312] = true,
				[55982] = true,
				[54938] = true,
				[49969] = true,
				[47986] = true,
				[50161] = true,
				[52208] = true,
				[48178] = true,
				[50481] = true,
				[50353] = true,
				[42229] = true,
				[42293] = true,
				[54945] = true,
				[50609] = true,
				[56814] = true,
				[54627] = true,
				[50151] = true,
				[57006] = true,
				[42741] = true,
				[48946] = true,
				[39607] = true,
				[42933] = true,
				[42997] = true,
				[54878] = true,
				[47219] = true,
				[52171] = true,
				[49394] = true,
				[55599] = true,
				[49522] = true,
				[53583] = true,
				[47949] = true,
				[42640] = true,
				[53936] = true,
				[55983] = true,
				[55945] = true,
				[48111] = true,
				[47987] = true,
				[56239] = true,
				[50162] = true,
				[50226] = true,
				[54703] = true,
				[50354] = true,
				[53976] = true,
				[48947] = true,
				[53551] = true,
				[50610] = true,
				[50674] = true,
				[51339] = true,
				[50802] = true,
				[31582] = true,
				[55497] = true,
				[55088] = true,
				[8237] = true,
				[49075] = true,
				[42998] = true,
				[55600] = true,
				[47220] = true,
				[41335] = true,
				[49395] = true,
				[45365] = true,
				[49523] = true,
				[51994] = true,
				[49715] = true,
				[51762] = true,
				[52146] = true,
				[54129] = true,
				[54193] = true,
				[56304] = true,
				[47988] = true,
				[56240] = true,
				[50163] = true,
				[50227] = true,
				[52074] = true,
				[55089] = true,
				[48372] = true,
				[56624] = true,
				[48500] = true,
				[50611] = true,
				[50675] = true,
				[47541] = true,
				[50803] = true,
				[46773] = true,
				[48524] = true,
				[48948] = true,
				[55153] = true,
				[42935] = true,
				[42999] = true,
				[51251] = true,
				[49268] = true,
				[39097] = true,
				[53746] = true,
				[55601] = true,
				[51571] = true,
				[55729] = true,
				[55793] = true,
				[49818] = true,
				[53470] = true,
				[51891] = true,
				[49908] = true,
				[50585] = true,
				[47989] = true,
				[52147] = true,
				[51403] = true,
				[50228] = true,
				[56328] = true,
				[50356] = true,
				[56561] = true,
				[47962] = true,
				[31583] = true,
				[50612] = true,
				[56136] = true,
				[56881] = true,
				[44663] = true,
				[57009] = true,
				[47884] = true,
				[40761] = true,
				[55090] = true,
				[42936] = true,
				[43000] = true,
				[53276] = true,
				[47222] = true,
				[51490] = true,
				[51572] = true,
				[55602] = true,
				[53619] = true,
				[55730] = true,
				[51700] = true,
				[50910] = true,
				[56242] = true,
				[55986] = true,
				[50165] = true,
				[47990] = true,
				[50037] = true,
				[54195] = true,
				[52212] = true,
				[56370] = true,
				[48310] = true,
				[54451] = true,
				[46327] = true,
				[56626] = true,
				[38305] = true,
				[51151] = true,
				[51177] = true,
				[50741] = true,
				[53167] = true,
				[57010] = true,
				[46839] = true,
				[50909] = true,
				[49014] = true,
				[42937] = true,
				[43001] = true,
				[55731] = true,
				[47223] = true,
				[47287] = true,
				[49398] = true,
				[51637] = true,
				[52008] = true,
				[43449] = true,
				[53748] = true,
				[49718] = true,
				[52318] = true,
				[56243] = true,
				[52654] = true,
				[41786] = true,
				[47991] = true,
				[54196] = true,
				[44771] = true,
				[54324] = true,
				[46200] = true,
				[48311] = true,
				[52469] = true,
				[56627] = true,
				[52789] = true,
				[50614] = true,
				[57139] = true,
				[50742] = true,
				[31552] = true,
				[54964] = true,
				[46840] = true,
				[53045] = true,
				[49015] = true,
				[56244] = true,
				[49143] = true,
				[49719] = true,
				[47224] = true,
				[43003] = true,
				[49399] = true,
				[47416] = true,
				[53621] = true,
				[45497] = true,
				[53749] = true,
				[55860] = true,
				[53877] = true,
				[54325] = true,
				[56628] = true,
				[49975] = true,
				[47992] = true,
				[52150] = true,
				[53174] = true,
				[48184] = true,
				[51191] = true,
				[50359] = true,
				[54088] = true,
				[48440] = true,
				[48504] = true,
				[41742] = true,
				[50679] = true,
				[52790] = true,
				[53960] = true,
				[53896] = true,
				[46841] = true,
				[57140] = true,
				[53622] = true,
				[47033] = true,
				[47097] = true,
				[47627] = true,
				[51319] = true,
				[47289] = true,
				[49400] = true,
				[55861] = true,
				[49528] = true,
				[56309] = true,
				[53750] = true,
				[53814] = true,
				[53465] = true,
				[51465] = true,
				[51959] = true,
				[49976] = true,
				[47993] = true,
				[54198] = true,
				[50168] = true,
				[52279] = true,
				[56629] = true,
				[53384] = true,
				[54518] = true,
				[48441] = true,
				[48505] = true,
				[50616] = true,
				[46842] = true,
				[47098] = true,
				[31553] = true,
				[31585] = true,
				[55030] = true,
				[57141] = true,
				[38782] = true,
				[52327] = true,
				[51192] = true,
				[56118] = true,
				[51320] = true,
				[51384] = true,
				[49401] = true,
				[49465] = true,
				[53623] = true,
				[55734] = true,
				[53751] = true,
				[53815] = true,
				[43644] = true,
				[50041] = true,
				[52472] = true,
				[45883] = true,
				[47994] = true,
				[56246] = true,
				[50553] = true,
				[50233] = true,
				[50825] = true,
				[40126] = true,
				[54519] = true,
				[48442] = true,
				[48506] = true,
				[48570] = true,
				[52462] = true,
				[39806] = true,
				[38367] = true,
				[51129] = true,
				[46843] = true,
				[48954] = true,
				[51321] = true,
				[47035] = true,
				[47099] = true,
				[52448] = true,
				[49274] = true,
				[48557] = true,
				[49402] = true,
				[47867] = true,
				[49530] = true,
				[48202] = true,
				[43837] = true,
				[53816] = true,
				[43645] = true,
				[43901] = true,
				[56055] = true,
				[56119] = true,
				[47995] = true,
				[54200] = true,
				[56311] = true,
				[52281] = true,
				[53169] = true,
				[46268] = true,
				[52473] = true,
				[48443] = true,
				[48507] = true,
				[54087] = true,
				[47882] = true,
				[52793] = true,
				[50810] = true,
				[31586] = true,
				[48280] = true,
				[55096] = true,
				[55942] = true,
				[8860] = true,
				[47100] = true,
				[51386] = true,
				[47228] = true,
				[55480] = true,
				[49403] = true,
				[55608] = true,
				[53405] = true,
				[55736] = true,
				[53753] = true,
				[53172] = true,
				[49787] = true,
				[54201] = true,
				[56056] = true,
				[52026] = true,
				[50043] = true,
				[52154] = true,
				[56248] = true,
				[52282] = true,
				[50939] = true,
				[50363] = true,
				[50417] = true,
				[56632] = true,
				[48508] = true,
				[55033] = true,
				[49161] = true,
				[51144] = true,
				[47101] = true,
				[54969] = true,
				[46845] = true,
				[56313] = true,
				[56057] = true,
				[53178] = true,
				[57336] = true,
				[53306] = true,
				[49276] = true,
				[53434] = true,
				[51279] = true,
				[52871] = true,
				[47485] = true,
				[45502] = true,
				[54458] = true,
				[53818] = true,
				[51835] = true,
				[44555] = true,
				[47869] = true,
				[52027] = true,
				[50044] = true,
				[54202] = true,
				[54266] = true,
				[52283] = true,
				[54394] = true,
				[48317] = true,
				[52475] = true,
				[48445] = true,
				[52308] = true,
				[53176] = true,
				[56633] = true,
				[52795] = true,
				[52859] = true,
				[50026] = true,
				[46282] = true,
				[48622] = true,
				[43002] = true,
				[50725] = true,
				[53747] = true,
				[53307] = true,
				[50056] = true,
				[53435] = true,
				[52039] = true,
				[55610] = true,
				[47486] = true,
				[45503] = true,
				[52296] = true,
				[53819] = true,
				[54203] = true,
				[56378] = true,
				[56058] = true,
				[39746] = true,
				[54459] = true,
				[52156] = true,
				[50173] = true,
				[52284] = true,
				[50301] = true,
				[50365] = true,
				[46079] = true,
				[48446] = true,
				[38275] = true,
				[50621] = true,
				[44544] = true,
				[52796] = true,
				[52439] = true,
				[52788] = true,
				[44800] = true,
				[53171] = true,
				[45079] = true,
				[51352] = true,
				[51335] = true,
				[52041] = true,
				[53372] = true,
				[53436] = true,
				[40317] = true,
				[41741] = true,
				[47487] = true,
				[45504] = true,
				[56635] = true,
				[53820] = true,
				[47743] = true,
				[55995] = true,
				[56315] = true,
				[52029] = true,
				[48447] = true,
				[54204] = true,
				[46080] = true,
				[50238] = true,
				[42114] = true,
				[46272] = true,
				[56571] = true,
				[38212] = true,
				[42142] = true,
				[48575] = true,
				[46729] = true,
				[54972] = true,
				[50814] = true,
				[31588] = true,
				[52072] = true,
				[49960] = true,
				[46781] = true,
				[53181] = true,
				[52450] = true,
				[47189] = true,
				[52457] = true,
				[51390] = true,
				[49407] = true,
				[43993] = true,
				[47488] = true,
				[51582] = true,
				[52946] = true,
				[54205] = true,
				[55932] = true,
				[48064] = true,
				[50111] = true,
				[52030] = true,
				[50047] = true,
				[52158] = true,
				[52286] = true,
				[50239] = true,
				[42115] = true,
				[50367] = true,
				[56004] = true,
				[48448] = true,
				[51949] = true,
				[47688] = true,
				[52205] = true,
				[49234] = true,
				[52197] = true,
				[53573] = true,
				[48370] = true,
				[55101] = true,
				[53118] = true,
				[53182] = true,
				[51199] = true,
				[49216] = true,
				[50640] = true,
				[51391] = true,
				[50088] = true,
				[57340] = true,
				[47489] = true,
				[31752] = true,
				[51711] = true,
				[51383] = true,
				[49792] = true,
				[52116] = true,
				[51967] = true,
				[52031] = true,
				[46274] = true,
				[54206] = true,
				[46082] = true,
				[52287] = true,
				[42116] = true,
				[50368] = true,
				[50432] = true,
				[48449] = true,
				[48513] = true,
				[44483] = true,
				[50688] = true,
				[40517] = true,
				[52997] = true,
				[31589] = true,
				[45652] = true,
				[52869] = true,
				[49984] = true,
				[53183] = true,
				[51200] = true,
				[45123] = true,
				[52123] = true,
				[53439] = true,
				[49409] = true,
				[52028] = true,
				[53631] = true,
				[49601] = true,
				[51712] = true,
				[55934] = true,
				[49793] = true,
				[45763] = true,
				[51968] = true,
				[52032] = true,
				[50049] = true,
				[56643] = true,
				[50177] = true,
				[52288] = true,
				[42117] = true,
				[46275] = true,
				[52480] = true,
				[52544] = true,
				[47221] = true,
				[44484] = true,
				[52062] = true,
				[50753] = true,
				[48898] = true,
				[54975] = true,
				[57086] = true,
				[48962] = true,
				[49282] = true,
				[53184] = true,
				[51201] = true,
				[49218] = true,
				[47235] = true,
				[47106] = true,
				[51752] = true,
				[48347] = true,
				[49794] = true,
				[49602] = true,
				[39691] = true,
				[49730] = true,
				[53888] = true,
				[42118] = true,
				[51969] = true,
				[52033] = true,
				[48003] = true,
				[48195] = true,
				[54400] = true,
				[52289] = true,
				[50306] = true,
				[50370] = true,
				[40122] = true,
				[51961] = true,
				[50562] = true,
				[45769] = true,
				[47431] = true,
				[40519] = true,
				[52040] = true,
				[46772] = true,
				[55040] = true,
				[48963] = true,
				[49233] = true,
				[53185] = true,
				[48899] = true,
				[46297] = true,
				[43495] = true,
				[53441] = true,
				[53124] = true,
				[47428] = true,
				[51586] = true,
				[50447] = true,
				[51714] = true,
				[43334] = true,
				[51842] = true,
				[45765] = true,
				[49923] = true,
				[52034] = true,
				[48004] = true,
				[48196] = true,
				[56320] = true,
				[52290] = true,
				[46213] = true,
				[50371] = true,
				[46727] = true,
				[56640] = true,
				[48516] = true,
				[44486] = true,
				[50691] = true,
				[47218] = true,
				[52866] = true,
				[45971] = true,
				[50819] = true,
				[49284] = true,
				[55425] = true,
				[53186] = true,
				[51203] = true,
				[55361] = true,
				[51331] = true,
				[53442] = true,
				[49412] = true,
				[55617] = true,
				[51757] = true,
				[45510] = true,
				[51715] = true,
				[47685] = true,
				[55937] = true,
				[50493] = true,
				[46774] = true,
				[52035] = true,
				[48005] = true,
				[52163] = true,
				[56321] = true,
				[52291] = true,
				[50372] = true,
				[42184] = true,
				[56641] = true,
				[48453] = true,
				[48517] = true,
				[51139] = true,
				[51569] = true,
				[48773] = true,
				[52867] = true,
				[31591] = true,
				[47238] = true,
				[48965] = true,
				[53443] = true,
				[53187] = true,
				[51204] = true,
				[55362] = true,
				[55426] = true,
				[51396] = true,
				[51395] = true,
				[55618] = true,
				[53635] = true,
				[45511] = true,
				[53571] = true,
				[47686] = true,
				[52285] = true,
				[45767] = true,
				[49285] = true,
				[52036] = true,
				[48087] = true,
				[48070] = true,
				[51851] = true,
				[48198] = true,
				[40009] = true,
				[50373] = true,
				[44296] = true,
				[56642] = true,
				[48518] = true,
				[51314] = true,
				[54787] = true,
				[40008] = true,
				[48774] = true,
				[54401] = true,
				[48902] = true,
				[47186] = true,
				[55171] = true,
				[51394] = true,
				[51205] = true,
				[55363] = true,
				[49286] = true,
				[53444] = true,
				[51833] = true,
				[53572] = true,
				[54947] = true,
				[55044] = true,
				[39435] = true,
				[47687] = true,
				[51845] = true,
				[53956] = true,
				[49926] = true,
				[56131] = true,
				[51570] = true,
				[53887] = true,
				[50386] = true,
				[48199] = true,
				[54404] = true,
				[50374] = true,
				[37830] = true,
				[48455] = true,
				[48519] = true,
				[44406] = true,
				[50694] = true,
				[56899] = true,
				[46728] = true,
				[31592] = true,
				[48903] = true,
				[52203] = true,
				[52042] = true,
				[51142] = true,
				[47112] = true,
				[49223] = true,
				[49287] = true,
				[53445] = true,
				[51349] = true,
				[43338] = true,
				[54183] = true,
				[40123] = true,
				[52259] = true,
				[49735] = true,
				[51846] = true,
				[53957] = true,
				[39692] = true,
				[52038] = true,
				[48008] = true,
				[49791] = true,
				[44471] = true,
				[48200] = true,
				[55087] = true,
				[52247] = true,
				[53617] = true,
				[56644] = true,
				[48520] = true,
				[52204] = true,
				[37726] = true,
				[31556] = true,
				[48776] = true,
				[50622] = true,
				[55045] = true,
				[44473] = true,
				[52443] = true,
				[51581] = true,
				[51207] = true,
				[51389] = true,
				[49288] = true,
				[53446] = true,
				[49981] = true,
				[49480] = true,
				[52461] = true,
				[50824] = true,
				[56506] = true,
				[47689] = true,
				[45706] = true,
				[49725] = true,
				[41740] = true,
				[47945] = true,
				[48009] = true,
				[56261] = true,
				[53369] = true,
				[52132] = true,
				[50312] = true,
				[42188] = true,
				[52975] = true,
				[50504] = true,
				[48521] = true,
				[52219] = true,
				[50696] = true,
				[46078] = true,
				[46730] = true,
				[46794] = true,
				[50172] = true,
				[53370] = true,
				[42892] = true,
				[38862] = true,
				[51208] = true,
				[49225] = true,
				[49289] = true,
				[56241] = true,
				[49417] = true,
				[49481] = true,
				[55686] = true,
				[52973] = true,
				[51720] = true,
				[47690] = true,
				[47754] = true,
				[53959] = true,
				[49929] = true,
				[47946] = true,
				[50057] = true,
				[50170] = true,
				[56247] = true,
				[44108] = true,
				[54407] = true,
				[52496] = true,
				[53268] = true,
				[51193] = true,
				[48522] = true,
				[55095] = true,
				[50697] = true,
				[48088] = true,
				[48778] = true,
				[48842] = true,
				[54199] = true,
				[43900] = true,
				[55175] = true,
				[51145] = true,
				[51209] = true,
				[49226] = true,
				[49290] = true,
				[51401] = true,
				[49418] = true,
				[43341] = true,
				[56245] = true,
				[53704] = true,
				[53768] = true,
				[47691] = true,
				[47755] = true,
				[56007] = true,
				[47883] = true,
				[47947] = true,
				[50058] = true,
				[41934] = true,
				[51190] = true,
				[48203] = true,
				[40079] = true,
				[54197] = true,
				[52489] = true,
				[53275] = true,
				[48523] = true,
				[53461] = true,
				[50698] = true,
				[44184] = true,
				[46732] = true,
				[46796] = true,
				[45724] = true,
				[46834] = true,
				[57330] = true,
				[54041] = true,
				[53406] = true,
				[47180] = true,
				[53616] = true,
				[51402] = true,
				[49419] = true,
				[49995] = true,
				[48089] = true,
				[53267] = true,
				[51722] = true,
				[54194] = true,
				[49803] = true,
				[53961] = true,
				[41743] = true,
				[47948] = true,
				[50059] = true,
				[52170] = true,
				[52234] = true,
				[50251] = true,
				[50036] = true,
				[56520] = true,
				[52490] = true,
				[48460] = true,
				[42383] = true,
				[50635] = true,
				[50699] = true,
				[53910] = true,
				[46733] = true,
				[46797] = true,
				[50955] = true,
				[42831] = true,
				[51083] = true,
				[53919] = true,
				[51211] = true,
				[47181] = true,
				[49292] = true,
				[53450] = true,
				[49267] = true,
				[53041] = true,
				[53990] = true,
				[40593] = true,
				[51723] = true,
				[54192] = true,
				[49804] = true,
				[54163] = true,
				[41744] = true,
				[49996] = true,
				[54303] = true,
				[48077] = true,
				[55407] = true,
				[53168] = true,
				[40081] = true,
				[46286] = true,
				[52491] = true,
				[48461] = true,
				[38894] = true,
				[56777] = true,
				[50700] = true,
				[54940] = true,
				[56969] = true,
				[46798] = true,
				[57097] = true,
				[48973] = true,
				[53131] = true,
				[54632] = true,
				[56813] = true,
				[49229] = true,
				[56211] = true,
				[53849] = true,
				[54169] = true,
				[54631] = true,
				[55400] = true,
				[51660] = true,
				[53771] = true,
				[8861] = true,
				[49805] = true,
				[51916] = true,
				[41745] = true,
				[49997] = true,
				[48014] = true,
				[52172] = true,
				[56031] = true,
				[42065] = true,
				[50157] = true,
				[52428] = true,
				[50445] = true,
				[55521] = true,
				[50573] = true,
				[56778] = true,
				[48654] = true,
				[51877] = true,
				[52876] = true,
				[46799] = true,
				[53037] = true,
				[44880] = true,
				[51085] = true,
				[47055] = true,
				[46832] = true,
				[47183] = true,
				[51341] = true,
				[53452] = true,
				[41900] = true,
				[56533] = true,
				[56607] = true,
				[56350] = true,
				[41898] = true,
				[42141] = true,
				[49806] = true,
				[40302] = true,
				[41746] = true,
				[49998] = true,
				[48015] = true,
				[52173] = true,
				[51613] = true,
				[56529] = true,
				[31308] = true,
				[56598] = true,
				[48399] = true,
				[54441] = true,
				[49445] = true,
				[42450] = true,
				[57040] = true,
				[55890] = true,
				[39087] = true,
				[46800] = true,
				[50604] = true,
				[53069] = true,
				[41747] = true,
				[47056] = true,
				[51214] = true,
				[47184] = true,
				[49295] = true,
				[53453] = true,
				[51470] = true,
				[45393] = true,
				[56087] = true,
				[51662] = true,
				[51726] = true,
				[55884] = true,
				[55948] = true,
				[51918] = true,
				[51982] = true,
				[47952] = true,
				[50063] = true,
				[48080] = true,
				[37909] = true,
				[51617] = true,
				[48272] = true,
				[51032] = true,
				[48400] = true,
				[40276] = true,
				[56729] = true,
				[56994] = true,
				[55777] = true,
				[55910] = true,
				[55264] = true,
				[57036] = true,
				[53265] = true,
			},
			["events_completed"] = {
			},
			["rares_killed"] = {
				[134012] = -1,
				[49999] = -1,
				[153066] = -1,
				[151660] = -1,
				[153067] = -1,
				[134270] = -1,
				[140792] = -1,
				[136828] = -1,
				[151534] = -1,
				[152685] = -1,
				[154092] = -1,
				[145013] = -1,
				[151663] = -1,
				[131587] = -1,
				[126918] = -1,
				[123146] = -1,
				[136831] = -1,
				[153327] = -1,
				[145399] = -1,
				[132740] = -1,
				[132868] = -1,
				[126919] = -1,
				[134147] = -1,
				[138495] = -1,
				[126216] = -1,
				[132741] = -1,
				[130436] = -1,
				[151667] = -1,
				[132742] = -1,
				[131847] = -1,
				[141182] = -1,
				[145402] = -1,
				[139392] = -1,
				[138497] = -1,
				[134789] = -1,
				[130437] = -1,
				[139393] = -1,
				[138498] = -1,
				[145020] = -1,
				[153332] = -1,
				[128967] = -1,
				[139394] = -1,
				[153333] = -1,
				[134024] = -1,
				[127497] = -1,
				[139395] = -1,
				[128648] = -1,
				[135048] = -1,
				[129032] = -1,
				[139396] = -1,
				[138501] = -1,
				[140292] = -1,
				[139397] = -1,
				[127626] = -1,
				[147965] = -1,
				[129928] = -1,
				[133004] = -1,
				[140293] = -1,
				[151674] = -1,
				[144897] = -1,
				[145153] = -1,
				[139399] = -1,
				[128650] = -1,
				[138888] = -1,
				[152315] = -1,
				[135052] = -1,
				[140295] = -1,
				[151676] = -1,
				[147968] = -1,
				[128651] = -1,
				[129802] = -1,
				[145028] = -1,
				[147202] = -1,
				[152445] = -1,
				[146819] = -1,
				[131858] = -1,
				[129547] = -1,
				[151679] = -1,
				[152319] = -1,
				[145286] = -1,
				[137614] = -1,
				[132755] = -1,
				[145287] = -1,
				[145415] = -1,
				[130635] = -1,
				[129996] = -1,
				[138255] = -1,
				[127119] = -1,
				[127503] = -1,
				[140430] = -1,
				[135699] = -1,
				[146185] = -1,
				[139152] = -1,
				[139280] = -1,
				[140431] = -1,
				[139536] = -1,
				[146186] = -1,
				[129550] = -1,
				[140432] = -1,
				[139537] = -1,
				[139665] = -1,
				[146059] = -1,
				[146187] = -1,
				[152709] = -1,
				[146827] = -1,
				[139283] = -1,
				[152710] = -1,
				[136470] = -1,
				[148874] = -1,
				[134041] = -1,
				[152711] = -1,
				[153862] = -1,
				[140691] = -1,
				[144911] = -1,
				[123286] = -1,
				[130639] = -1,
				[126100] = -1,
				[135706] = -1,
				[123287] = -1,
				[139287] = -1,
				[146832] = -1,
				[130896] = -1,
				[145298] = -1,
				[132127] = -1,
				[127124] = -1,
				[146833] = -1,
				[144915] = -1,
				[123288] = -1,
				[152460] = -1,
				[146834] = -1,
				[152461] = -1,
				[153740] = -1,
				[146835] = -1,
				[122266] = -1,
				[126422] = -1,
				[153741] = -1,
				[140059] = -1,
				[140443] = -1,
				[126295] = -1,
				[123290] = -1,
				[140188] = -1,
				[135329] = -1,
				[146838] = -1,
				[145304] = -1,
				[144409] = -1,
				[146072] = -1,
				[126424] = -1,
				[144410] = -1,
				[146840] = -1,
				[139807] = -1,
				[141981] = -1,
				[131112] = -1,
				[140447] = -1,
				[136483] = -1,
				[139808] = -1,
				[129366] = -1,
				[145307] = -1,
				[139297] = -1,
				[152724] = -1,
				[145308] = -1,
				[146843] = -1,
				[136869] = -1,
				[145181] = -1,
				[129559] = -1,
				[136870] = -1,
				[140067] = -1,
				[145310] = -1,
				[139684] = -1,
				[140068] = -1,
				[139429] = -1,
				[137511] = -1,
				[140069] = -1,
				[129369] = -1,
				[145058] = -1,
				[144803] = -1,
				[129370] = -1,
				[132911] = -1,
				[130521] = -1,
				[139433] = -1,
				[145060] = -1,
				[140201] = -1,
				[149536] = -1,
				[140457] = -1,
				[140585] = -1,
				[129371] = -1,
				[130522] = -1,
				[140458] = -1,
				[137517] = -1,
				[130011] = -1,
				[129372] = -1,
				[140076] = -1,
				[139693] = -1,
				[153504] = -1,
				[135474] = -1,
				[129373] = -1,
				[132917] = -1,
				[140206] = -1,
				[138288] = -1,
				[137521] = -1,
				[144810] = -1,
				[140207] = -1,
				[140335] = -1,
				[133430] = -1,
				[130333] = -1,
				[123236] = -1,
				[132919] = -1,
				[148392] = -1,
				[126497] = -1,
				[130653] = -1,
				[140976] = -1,
				[132920] = -1,
				[145324] = -1,
				[140337] = -1,
				[133432] = -1,
				[130334] = -1,
				[142000] = -1,
				[150696] = -1,
				[132922] = -1,
				[145326] = -1,
				[130335] = -1,
				[124581] = -1,
				[145967] = -1,
				[140980] = -1,
				[137144] = -1,
				[4075] = -1,
				[146607] = -1,
				[153896] = -1,
				[130400] = -1,
				[139063] = -1,
				[137146] = -1,
				[131520] = -1,
				[137147] = -1,
				[144948] = -1,
				[119724] = -1,
				[138171] = -1,
				[138427] = -1,
				[140985] = -1,
				[137405] = -1,
				[129699] = -1,
				[140986] = -1,
				[138429] = -1,
				[138557] = -1,
				[153263] = -1,
				[138558] = -1,
				[137152] = -1,
				[135234] = -1,
				[152881] = -1,
				[139710] = -1,
				[130404] = -1,
				[140094] = -1,
				[141629] = -1,
				[137665] = -1,
				[145977] = -1,
				[140095] = -1,
				[138561] = -1,
				[126185] = -1,
				[132807] = -1,
				[137155] = -1,
				[128551] = -1,
				[130661] = -1,
				[138562] = -1,
				[151989] = -1,
				[131785] = -1,
				[136005] = -1,
				[137156] = -1,
				[140353] = -1,
				[135366] = -1,
				[153269] = -1,
				[136006] = -1,
				[137157] = -1,
				[140354] = -1,
				[141633] = -1,
				[144958] = -1,
				[148155] = -1,
				[129000] = -1,
				[140355] = -1,
				[139460] = -1,
				[132683] = -1,
				[145343] = -1,
				[140356] = -1,
				[139461] = -1,
				[138822] = -1,
				[133963] = -1,
				[130024] = -1,
				[138823] = -1,
				[149437] = -1,
				[139463] = -1,
				[131407] = -1,
				[138696] = -1,
				[137162] = -1,
				[154681] = -1,
				[144707] = -1,
				[139720] = -1,
				[135245] = -1,
				[145603] = -1,
				[130026] = -1,
				[155834] = -1,
				[144837] = -1,
				[131666] = -1,
				[148290] = -1,
				[131411] = -1,
				[131667] = -1,
				[144071] = -1,
				[140107] = -1,
				[130027] = -1,
				[144839] = -1,
				[148164] = -1,
				[140108] = -1,
				[151745] = -1,
				[132692] = -1,
				[146119] = -1,
				[130028] = -1,
				[131670] = -1,
				[130668] = -1,
				[153026] = -1,
				[138960] = -1,
				[132056] = -1,
				[127600] = -1,
				[133463] = -1,
				[131545] = -1,
				[138962] = -1,
				[134998] = -1,
				[145356] = -1,
				[144845] = -1,
				[135894] = -1,
				[134232] = -1,
				[138332] = -1,
				[126642] = -1,
				[133593] = -1,
				[138836] = -1,
				[135895] = -1,
				[883] = -1,
				[145358] = -1,
				[2442] = -1,
				[139476] = -1,
				[140205] = -1,
				[127048] = -1,
				[144975] = -1,
				[139988] = -1,
				[148300] = -1,
				[131864] = -1,
				[132820] = -1,
				[149707] = -1,
				[145008] = -1,
				[131677] = -1,
				[144976] = -1,
				[154311] = -1,
				[126832] = -1,
				[130012] = -1,
				[135258] = -1,
				[145067] = -1,
				[146826] = -1,
				[138711] = -1,
				[138839] = -1,
				[154312] = -1,
				[136330] = -1,
				[131669] = -1,
				[138837] = -1,
				[139269] = -1,
				[144722] = -1,
				[136665] = -1,
				[138840] = -1,
				[137945] = -1,
				[126429] = -1,
				[141631] = -1,
				[135240] = -1,
				[137626] = -1,
				[137625] = -1,
				[137516] = -1,
				[138841] = -1,
				[138969] = -1,
				[141625] = -1,
				[141627] = -1,
				[131585] = -1,
				[135241] = -1,
				[154285] = -1,
				[129471] = -1,
				[128928] = -1,
				[138970] = -1,
				[140456] = -1,
				[152462] = -1,
				[134787] = -1,
				[153804] = -1,
				[136541] = -1,
				[136598] = -1,
				[136797] = -1,
				[153293] = -1,
				[129548] = -1,
				[137181] = -1,
				[135263] = -1,
				[133345] = -1,
				[153933] = -1,
				[138972] = -1,
				[136798] = -1,
				[145110] = -1,
				[129879] = -1,
				[137182] = -1,
				[132819] = -1,
				[146773] = -1,
				[144727] = -1,
				[144974] = -1,
				[137950] = -1,
				[132835] = -1,
				[149331] = -1,
				[137183] = -1,
				[145026] = -1,
				[138002] = -1,
				[149843] = -1,
				[152273] = -1,
				[131685] = -1,
				[137951] = -1,
				[129640] = -1,
				[145346] = -1,
				[140381] = -1,
				[129231] = -1,
				[139400] = -1,
				[123352] = -1,
				[137824] = -1,
				[152274] = -1,
				[153068] = -1,
				[127479] = -1,
				[140382] = -1,
				[138464] = -1,
				[145163] = -1,
				[138254] = -1,
				[126983] = -1,
				[136139] = -1,
				[153618] = -1,
				[129602] = -1,
				[154705] = -1,
				[138465] = -1,
				[127111] = -1,
				[131262] = -1,
				[144987] = -1,
				[130421] = -1,
				[130485] = -1,
				[129526] = -1,
				[123289] = -1,
				[138466] = -1,
				[127478] = -1,
				[140866] = -1,
				[137955] = -1,
				[148185] = -1,
				[126969] = -1,
				[129015] = -1,
				[139362] = -1,
				[144733] = -1,
				[136549] = -1,
				[134788] = -1,
				[132713] = -1,
				[131818] = -1,
				[140334] = -1,
				[129527] = -1,
				[137029] = -1,
				[152790] = -1,
				[136550] = -1,
				[131819] = -1,
				[140259] = -1,
				[136934] = -1,
				[126928] = -1,
				[129016] = -1,
				[136807] = -1,
				[138469] = -1,
				[133482] = -1,
				[139748] = -1,
				[137830] = -1,
				[137958] = -1,
				[140260] = -1,
				[132076] = -1,
				[129374] = -1,
				[138470] = -1,
				[136552] = -1,
				[147933] = -1,
				[135365] = -1,
				[130435] = -1,
				[127486] = -1,
				[132299] = -1,
				[137947] = -1,
				[140690] = -1,
				[151898] = -1,
				[139750] = -1,
				[144993] = -1,
				[139111] = -1,
				[130488] = -1,
				[129529] = -1,
				[127480] = -1,
				[131311] = -1,
				[140208] = -1,
				[147935] = -1,
				[129989] = -1,
				[152686] = -1,
				[130582] = -1,
				[156502] = -1,
				[129227] = -1,
				[153818] = -1,
				[136555] = -1,
				[147936] = -1,
				[136811] = -1,
				[131824] = -1,
				[122263] = -1,
				[140264] = -1,
				[126190] = -1,
				[153567] = -1,
				[130087] = -1,
				[130025] = -1,
				[136812] = -1,
				[131825] = -1,
				[140977] = -1,
				[153561] = -1,
				[128969] = -1,
				[147938] = -1,
				[148391] = -1,
				[130298] = -1,
				[127482] = -1,
				[132849] = -1,
				[97754] = -1,
				[127485] = -1,
				[126526] = -1,
				[133361] = -1,
				[127484] = -1,
				[153563] = -1,
				[137954] = -1,
				[152287] = -1,
				[136832] = -1,
				[140336] = -1,
				[153694] = -1,
				[147932] = -1,
				[122264] = -1,
				[130299] = -1,
				[129340] = -1,
				[152288] = -1,
				[129601] = -1,
				[126463] = -1,
				[135893] = -1,
				[130683] = -1,
				[131445] = -1,
				[129788] = -1,
				[129208] = -1,
				[126847] = -1,
				[150371] = -1,
				[153568] = -1,
				[144944] = -1,
				[137956] = -1,
				[154276] = -1,
				[145372] = -1,
				[138820] = -1,
				[134899] = -1,
				[154310] = -1,
				[148454] = -1,
				[133990] = -1,
				[131221] = -1,
				[140383] = -1,
				[126215] = -1,
				[139398] = -1,
				[126848] = -1,
				[134005] = -1,
				[141980] = -1,
				[152675] = -1,
				[129232] = -1,
				[129214] = -1,
				[139465] = -1,
				[138247] = -1,
				[126423] = -1,
				[138958] = -1,
				[127488] = -1,
				[133848] = -1,
				[130685] = -1,
				[131812] = -1,
				[144977] = -1,
				[152883] = -1,
				[152884] = -1,
				[129367] = -1,
				[136181] = -1,
				[147562] = -1,
				[144725] = -1,
				[140200] = -1,
				[136599] = -1,
				[135642] = -1,
				[153655] = -1,
				[150376] = -1,
				[146118] = -1,
				[129599] = -1,
				[148513] = -1,
				[127381] = -1,
				[137946] = -1,
				[140058] = -1,
				[138838] = -1,
				[142587] = -1,
				[131586] = -1,
				[131863] = -1,
				[127106] = -1,
				[140444] = -1,
				[147948] = -1,
				[146828] = -1,
				[131850] = -1,
				[131849] = -1,
				[127490] = -1,
				[129600] = -1,
				[133436] = -1,
				[153959] = -1,
				[140441] = -1,
				[153192] = -1,
				[152297] = -1,
				[151988] = -1,
			},
		},
	},
	["profileKeys"] = {
		["무시중한디 - 굴단"] = "무시중한디 - 굴단",
		["뉘시빨라마 - 굴단"] = "뉘시빨라마 - 굴단",
	},
	["global"] = {
		["object_names"] = {
			["koKR"] = {
				[273955] = "작은 보물 상자",
				[291264] = "작은 보물 상자",
				[291201] = "작은 보물 상자",
				[275074] = "작은 보물 상자",
				[273956] = "작은 보물 상자",
				[279042] = "밀수업자의 보관함",
				[325665] = "기계 상자",
				[325664] = "기계 상자",
				[291267] = "작은 보물 상자",
				[293881] = "묻힌 보물 상자",
				[325661] = "기계 상자",
				[291204] = "작은 보물 상자",
				[280619] = "오래된 철제 궤짝",
				[302954] = "잊혀진 보물 상자",
				[325663] = "기계 상자",
				[325666] = "기계 상자",
				[293964] = "잊혀진 보물 상자",
				[275071] = "작은 보물 상자",
				[293962] = "위태로운 보물 상자",
				[325667] = "기계 상자",
				[281646] = "꿀곰",
				[291225] = "작은 보물 상자",
				[273905] = "작은 보물 상자",
				[325668] = "기계 상자",
				[284469] = "작은 보물 상자",
				[325659] = "기계 상자",
				[291255] = "작은 보물 상자",
				[293350] = "조각한 나무 궤짝",
				[291224] = "작은 보물 상자",
				[273902] = "작은 보물 상자",
				[293965] = "뼈새김 보관함",
				[280751] = "작은 보물 상자",
				[281397] = "바다가름 보물 상자",
				[273903] = "작은 보물 상자",
				[291257] = "작은 보물 상자",
				[297825] = "그물투성이 상자",
				[273901] = "작은 보물 상자",
				[273917] = "작은 보물 상자",
				[291258] = "작은 보물 상자",
				[291211] = "작은 보물 상자",
				[281903] = "보물 상자",
				[273918] = "작은 보물 상자",
				[291259] = "작은 보물 상자",
				[297828] = "상인의 상자",
				[281904] = "보물 상자",
				[291244] = "작은 보물 상자",
				[281494] = "서리 보물 상자",
				[291213] = "작은 보물 상자",
				[291227] = "작은 보물 상자",
				[291226] = "작은 보물 상자",
				[275070] = "작은 보물 상자",
				[297892] = "룬결속 상자",
				[291230] = "작은 보물 상자",
				[291246] = "작은 보물 상자",
				[325660] = "기계 상자",
				[293349] = "버려진 도시락",
				[273900] = "작은 보물 상자",
				[275076] = "작은 보물 상자",
				[291263] = "작은 보물 상자",
				[273910] = "작은 보물 상자",
				[291266] = "작은 보물 상자",
				[287531] = "작은 보물 상자",
				[325662] = "기계 상자",
				[291265] = "작은 보물 상자",
			},
		},
		["addonVersion"] = 600,
		["event_names"] = {
			["koKR"] = {
				[137180] = "위험에 처한 상인",
				[277329] = "고대 석관",
			},
		},
		["quest_ids"] = {
			[153310] = {
				57170, -- [1]
			},
			[152697] = {
				56058, -- [1]
			},
			[155840] = {
				56893, -- [1]
			},
			[153314] = {
				57166, -- [1]
			},
			[152671] = {
				56055, -- [1]
			},
			[137665] = {
				52002, -- [1]
			},
		},
		["lootdbversion"] = 16,
		["rares_found"] = {
			[139814] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1565917193,
				["coordX"] = 0.573119580745697,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6057994365692139,
			},
			[129343] = {
				["mapID"] = 862,
				["coordY"] = 0.5742475986480713,
				["foundTime"] = 1566650740,
				["coordX"] = 0.4983270168304443,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[140453] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4579221606254578,
				["coordX"] = 0.3808060884475708,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924653,
			},
			[138473] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920410,
				["coordX"] = 0.5748206377029419,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4265384078025818,
			},
			[277329] = {
				["mapID"] = 896,
				["coordY"] = 0.3648057878017426,
				["foundTime"] = 1567000182,
				["coordX"] = 0.4195208847522736,
				["artID"] = 921,
				["atlasName"] = "VignetteEvent",
			},
			[291255] = {
				["mapID"] = 942,
				["coordY"] = 0.3205832540988922,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7414048910140991,
				["artID"] = 967,
				["foundTime"] = 1566133907,
			},
			[151569] = {
				["mapID"] = 1462,
				["coordY"] = 0.4291911423206329,
				["foundTime"] = 1564324200,
				["coordX"] = 0.3528560996055603,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[133812] = {
				["mapID"] = 863,
				["coordY"] = 0.7140004634857178,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.387877345085144,
				["artID"] = 888,
				["foundTime"] = 1564240413,
			},
			[291257] = {
				["mapID"] = 942,
				["coordY"] = 0.7021880745887756,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6431940793991089,
				["artID"] = 967,
				["foundTime"] = 1566648811,
			},
			[127939] = {
				["mapID"] = 862,
				["coordY"] = 0.6524829268455505,
				["foundTime"] = 1564235468,
				["coordX"] = 0.467953622341156,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[138667] = {
				["mapID"] = 896,
				["coordY"] = 0.1110316142439842,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3600378632545471,
				["artID"] = 921,
				["foundTime"] = 1567000339,
			},
			[291258] = {
				["mapID"] = 942,
				["coordY"] = 0.6198052763938904,
				["foundTime"] = 1566583483,
				["coordX"] = 0.4577608108520508,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[291259] = {
				["mapID"] = 942,
				["coordY"] = 0.5546790957450867,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4784861207008362,
				["artID"] = 967,
				["foundTime"] = 1566320776,
			},
			[152465] = {
				["mapID"] = 1355,
				["coordY"] = 0.2814700603485107,
				["foundTime"] = 1563552991,
				["coordX"] = 0.3961526155471802,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[139818] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1565917193,
				["coordX"] = 0.5703206062316895,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6048926711082458,
			},
			[151124] = {
				["mapID"] = 1462,
				["coordY"] = 0.5210065245628357,
				["foundTime"] = 1566742522,
				["coordX"] = 0.5691445469856262,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[153296] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.414139449596405,
				["coordX"] = 0.336714506149292,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564912563,
			},
			[149847] = {
				["mapID"] = 1462,
				["coordY"] = 0.2093054950237274,
				["foundTime"] = 1565917597,
				["coordX"] = 0.8245287537574768,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[140777] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.7295215129852295,
				["coordX"] = 0.5951787233352661,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925637,
			},
			[291263] = {
				["mapID"] = 942,
				["coordY"] = 0.6994284987449646,
				["foundTime"] = 1566321359,
				["coordX"] = 0.4288050532341003,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[291264] = {
				["mapID"] = 942,
				["coordY"] = 0.6955002546310425,
				["foundTime"] = 1566649973,
				["coordX"] = 0.2978658080101013,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[291265] = {
				["mapID"] = 942,
				["coordY"] = 0.6137629151344299,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.2821501195430756,
				["artID"] = 967,
				["foundTime"] = 1564583731,
			},
			[291266] = {
				["mapID"] = 942,
				["coordY"] = 0.2635148167610169,
				["foundTime"] = 1563552357,
				["coordX"] = 0.4059697091579437,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[154640] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.554,
				["coordX"] = 0.38,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563462987,
			},
			[151702] = {
				["mapID"] = 1462,
				["coordY"] = 0.6817215085029602,
				["foundTime"] = 1565919199,
				["coordX"] = 0.2311172634363174,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[153299] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563553857,
				["coordX"] = 0.638,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.57,
			},
			[149339] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565919954,
				["coordX"] = 0.3940021395683289,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6101217865943909,
			},
			[135926] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1564922849,
				["coordX"] = 0.5907793641090393,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6947014331817627,
			},
			[139695] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.6207869052886963,
				["coordX"] = 0.6392873525619507,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564241713,
			},
			[144997] = {
				["mapID"] = 942,
				["coordY"] = 0.4603925347328186,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4691177308559418,
				["artID"] = 967,
				["foundTime"] = 1566321758,
			},
			[153301] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.39200002,
				["coordX"] = 0.33200002,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564587669,
			},
			[149341] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.5522624254226685,
				["coordX"] = 0.6175167560577393,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924198,
			},
			[142251] = {
				["mapID"] = 943,
				["artID"] = 968,
				["coordY"] = 0.282260119915009,
				["coordX"] = 0.442937970161438,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563547968,
			},
			[140271] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920127,
				["coordX"] = 0.2991082668304443,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4942335486412048,
			},
			[130338] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3703657388687134,
				["coordX"] = 0.4418883919715881,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567004360,
			},
			[153302] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563720157,
				["coordX"] = 0.42,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.676,
			},
			[273900] = {
				["mapID"] = 895,
				["coordY"] = 0.7398664355278015,
				["foundTime"] = 1566735355,
				["coordX"] = 0.8386907577514648,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[153303] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.4,
				["coordX"] = 0.33,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564321850,
			},
			[326407] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.4977533221244812,
				["coordX"] = 0.5283011198043823,
				["atlasName"] = "VignetteLoot",
				["foundTime"] = 1564913248,
			},
			[273902] = {
				["mapID"] = 895,
				["coordY"] = 0.809145987033844,
				["foundTime"] = 1565927737,
				["coordX"] = 0.7636740803718567,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[152729] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3394231796264648,
				["coordX"] = 0.8385803699493408,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567008984,
			},
			[273903] = {
				["mapID"] = 895,
				["coordY"] = 0.8277919888496399,
				["foundTime"] = 1565927749,
				["coordX"] = 0.7575080394744873,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[326409] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.49193,
				["coordX"] = 0.39713,
				["atlasName"] = "VignetteLoot",
				["foundTime"] = 1564908037,
			},
			[139763] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565797940,
				["coordX"] = 0.5410265922546387,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.1556164622306824,
			},
			[139444] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565799005,
				["coordX"] = 0.4481260776519775,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6019729375839233,
			},
			[273905] = {
				["mapID"] = 895,
				["coordY"] = 0.3310234248638153,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3844930827617645,
				["artID"] = 920,
				["foundTime"] = 1563977662,
			},
			[293962] = {
				["mapID"] = 895,
				["coordY"] = 0.331906259059906,
				["foundTime"] = 1564914429,
				["coordX"] = 0.5602756142616272,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[148451] = {
				["mapID"] = 864,
				["coordY"] = 0.3844084441661835,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3631913661956787,
				["artID"] = 889,
				["foundTime"] = 1565964803,
			},
			[140978] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4599134922027588,
				["coordX"] = 0.3717272877693176,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565926377,
			},
			[152795] = {
				["mapID"] = 1355,
				["coordY"] = 0.4054084420204163,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8552875518798828,
				["artID"] = 1186,
				["foundTime"] = 1567009028,
			},
			[293964] = {
				["mapID"] = 895,
				["coordY"] = 0.6274539828300476,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6177815198898315,
				["artID"] = 920,
				["foundTime"] = 1563551207,
			},
			[293965] = {
				["mapID"] = 895,
				["coordY"] = 0.2133042067289352,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7265006899833679,
				["artID"] = 920,
				["foundTime"] = 1567072492,
			},
			[153307] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.406,
				["coordX"] = 0.48599997,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563807754,
			},
			[154968] = {
				["mapID"] = 1462,
				["coordY"] = 0.4979767501354218,
				["foundTime"] = 1566742034,
				["coordX"] = 0.5333603620529175,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[326415] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.7441,
				["coordX"] = 0.3871,
				["atlasName"] = "VignetteLoot",
				["foundTime"] = 1564908523,
			},
			[273910] = {
				["mapID"] = 895,
				["coordY"] = 0.2495183795690537,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3896916210651398,
				["artID"] = 920,
				["foundTime"] = 1566649920,
			},
			[140341] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564581312,
				["coordX"] = 0.6349585056304932,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.576948881149292,
			},
			[148198] = {
				["mapID"] = 862,
				["coordY"] = 0.4185632467269898,
				["foundTime"] = 1565296442,
				["coordX"] = 0.7727118134498596,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[152414] = {
				["mapID"] = 1355,
				["coordY"] = 0.3471251130104065,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6429882645606995,
				["artID"] = 1186,
				["foundTime"] = 1565921469,
			},
			[152542] = {
				["mapID"] = 1355,
				["coordY"] = 0.4661996364593506,
				["foundTime"] = 1563719920,
				["coordX"] = 0.2861908674240112,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[143025] = {
				["mapID"] = 1044,
				["coordY"] = 0.5765138864517212,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5217545032501221,
				["artID"] = 968,
				["foundTime"] = 1567173974,
			},
			[153309] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563892599,
				["coordX"] = 0.41599998,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.246,
			},
			[126637] = {
				["mapID"] = 862,
				["coordY"] = 0.4876110553741455,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6865893006324768,
				["artID"] = 887,
				["foundTime"] = 1564240228,
			},
			[138618] = {
				["mapID"] = 896,
				["coordY"] = 0.3052253723144531,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2355144917964935,
				["artID"] = 921,
				["foundTime"] = 1566649835,
			},
			[134147] = {
				["mapID"] = 942,
				["coordY"] = 0.7461163401603699,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6607165336608887,
				["artID"] = 967,
				["foundTime"] = 1563978822,
			},
			[138299] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.33,
				["coordX"] = 0.588,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564914424,
			},
			[152671] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1565879920,
				["coordX"] = 0.4299968481063843,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7550837397575378,
			},
			[151202] = {
				["mapID"] = 1462,
				["coordY"] = 0.5161255598068237,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6563528180122375,
				["artID"] = 1276,
				["foundTime"] = 1566575025,
			},
			[153310] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.122,
				["coordX"] = 0.618,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564237790,
			},
			[152416] = {
				["mapID"] = 1355,
				["coordY"] = 0.3670188188552856,
				["foundTime"] = 1565921519,
				["coordX"] = 0.6540259122848511,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[139769] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565799092,
				["coordX"] = 0.466456413269043,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4459150433540344,
			},
			[139322] = {
				["mapID"] = 896,
				["coordY"] = 0.6410086154937744,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2950240671634674,
				["artID"] = 921,
				["foundTime"] = 1566649642,
			},
			[147562] = {
				["mapID"] = 942,
				["coordY"] = 0.4652308225631714,
				["foundTime"] = 1565915311,
				["coordX"] = 0.4303671419620514,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[152736] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3539354205131531,
				["coordX"] = 0.837614893913269,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567008987,
			},
			[273917] = {
				["mapID"] = 895,
				["coordY"] = 0.4825604856014252,
				["foundTime"] = 1567171400,
				["coordX"] = 0.796704113483429,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[149351] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.543757438659668,
				["coordX"] = 0.6155840158462524,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924221,
			},
			[273918] = {
				["mapID"] = 895,
				["coordY"] = 0.59695965051651,
				["foundTime"] = 1566735331,
				["coordX"] = 0.7766144871711731,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[134213] = {
				["mapID"] = 896,
				["coordY"] = 0.1906081140041351,
				["foundTime"] = 1567000207,
				["coordX"] = 0.3187871873378754,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[127820] = {
				["mapID"] = 863,
				["coordY"] = 0.3878504037857056,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5913995504379272,
				["artID"] = 888,
				["foundTime"] = 1563551612,
			},
			[136385] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.2379547357559204,
				["coordX"] = 0.6236034035682678,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1566485806,
			},
			[153312] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1564431117,
				["coordX"] = 0.414,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.24,
			},
			[325659] = {
				["mapID"] = 1462,
				["coordY"] = 0.4188947379589081,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5324981212615967,
				["artID"] = 1276,
				["foundTime"] = 1566743075,
			},
			[152291] = {
				["mapID"] = 1355,
				["coordY"] = 0.4948077201843262,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5673771500587463,
				["artID"] = 1186,
				["foundTime"] = 1563975893,
			},
			[325660] = {
				["mapID"] = 1462,
				["coordY"] = 0.7142783999443054,
				["foundTime"] = 1566573557,
				["coordX"] = 0.2059285789728165,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[325661] = {
				["mapID"] = 1462,
				["coordY"] = 0.5626015663146973,
				["foundTime"] = 1566742462,
				["coordX"] = 0.6723509430885315,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[146607] = {
				["mapID"] = 896,
				["coordY"] = 0.3305632770061493,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3180270195007324,
				["artID"] = 921,
				["foundTime"] = 1563979098,
			},
			[153314] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1566932365,
				["coordX"] = 0.5235252380371094,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.255308985710144,
			},
			[325662] = {
				["mapID"] = 1462,
				["coordY"] = 0.4733925759792328,
				["foundTime"] = 1566743159,
				["coordX"] = 0.7258507609367371,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[137665] = {
				["mapID"] = 896,
				["coordY"] = 0.5488458871841431,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.271853893995285,
				["artID"] = 921,
				["foundTime"] = 1566649545,
			},
			[325663] = {
				["mapID"] = 1462,
				["coordY"] = 0.5738828778266907,
				["foundTime"] = 1566741949,
				["coordX"] = 0.5665207505226135,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[140987] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.5550318956375122,
				["coordX"] = 0.4504950046539307,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925477,
			},
			[153315] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.251192569732666,
				["coordX"] = 0.5194318294525146,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563463098,
			},
			[325664] = {
				["mapID"] = 1462,
				["coordY"] = 0.2916927635669708,
				["foundTime"] = 1566743000,
				["coordX"] = 0.5676262974739075,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[325665] = {
				["mapID"] = 1462,
				["coordY"] = 0.2287934273481369,
				["foundTime"] = 1566742262,
				["coordX"] = 0.6732412576675415,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[325666] = {
				["mapID"] = 1462,
				["coordY"] = 0.7759378552436829,
				["foundTime"] = 1566390761,
				["coordX"] = 0.6675953269004822,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[126449] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1564922147,
				["coordX"] = 0.580394446849823,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.822287917137146,
			},
			[325667] = {
				["mapID"] = 1462,
				["coordY"] = 0.6597946286201477,
				["foundTime"] = 1566574886,
				["coordX"] = 0.7648739814758301,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[325668] = {
				["mapID"] = 1462,
				["coordY"] = 0.8304821252822876,
				["foundTime"] = 1566573394,
				["coordX"] = 0.2178962975740433,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[154148] = {
				["mapID"] = 1355,
				["coordY"] = 0.2231147885322571,
				["foundTime"] = 1566319037,
				["coordX"] = 0.6592226028442383,
				["artID"] = 1186,
				["atlasName"] = "VignetteEvent",
			},
			[134794] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.419087827205658,
				["coordX"] = 0.5781365036964417,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925180,
			},
			[148144] = {
				["mapID"] = 1203,
				["coordY"] = 0.509800374507904,
				["foundTime"] = 1563628106,
				["coordX"] = 0.588461697101593,
				["artID"] = 1165,
				["atlasName"] = "VignetteKill",
			},
			[293349] = {
				["mapID"] = 942,
				["coordY"] = 0.6368243098258972,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5820598006248474,
				["artID"] = 967,
				["foundTime"] = 1566322058,
			},
			[152360] = {
				["mapID"] = 1355,
				["coordY"] = 0.5054889917373657,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6553360223770142,
				["artID"] = 1186,
				["foundTime"] = 1566654147,
			},
			[128973] = {
				["mapID"] = 896,
				["coordY"] = 0.2143227607011795,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6496957540512085,
				["artID"] = 921,
				["foundTime"] = 1567000144,
			},
			[132048] = {
				["mapID"] = 1044,
				["coordY"] = 0.3144999146461487,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4613356590270996,
				["artID"] = 968,
				["foundTime"] = 1563549046,
			},
			[293350] = {
				["mapID"] = 942,
				["coordY"] = 0.735307514667511,
				["foundTime"] = 1563536678,
				["coordX"] = 0.4443886578083038,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[132879] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.535889744758606,
				["coordX"] = 0.4237756729125977,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567006346,
			},
			[145271] = {
				["mapID"] = 1203,
				["artID"] = 1165,
				["foundTime"] = 1563445651,
				["coordX"] = 0.58707594871521,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5088509321212769,
			},
			[152553] = {
				["mapID"] = 1355,
				["coordY"] = 0.4198992252349854,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3938496708869934,
				["artID"] = 1186,
				["foundTime"] = 1564908065,
			},
			[152681] = {
				["mapID"] = 1355,
				["coordY"] = 0.8794395923614502,
				["foundTime"] = 1563888971,
				["coordX"] = 0.4304642081260681,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[155811] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563890493,
				["coordX"] = 0.3344057202339172,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3012655973434448,
			},
			[147188] = {
				["mapID"] = 1032,
				["coordY"] = 0.6496200561523438,
				["atlasName"] = "VignetteKillElite",
				["coordX"] = 0.4709588289260864,
				["artID"] = 1013,
				["foundTime"] = 1567007766,
			},
			[149360] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.4328230023384094,
				["coordX"] = 0.5749641060829163,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565919878,
			},
			[297825] = {
				["mapID"] = 896,
				["coordY"] = 0.3007924258708954,
				["foundTime"] = 1567000203,
				["coordX"] = 0.3371013402938843,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[152682] = {
				["mapID"] = 1355,
				["coordY"] = 0.7552899718284607,
				["foundTime"] = 1565879935,
				["coordX"] = 0.4299296736717224,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[150191] = {
				["mapID"] = 1355,
				["coordY"] = 0.112368106842041,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.3690873980522156,
				["artID"] = 1186,
				["foundTime"] = 1564320474,
			},
			[138502] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.8132179379463196,
				["coordX"] = 0.668412446975708,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924096,
			},
			[152555] = {
				["mapID"] = 1355,
				["coordY"] = 0.7544835209846497,
				["foundTime"] = 1564802876,
				["coordX"] = 0.5207043886184692,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[297828] = {
				["mapID"] = 896,
				["coordY"] = 0.199462041258812,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.2574792802333832,
				["artID"] = 921,
				["foundTime"] = 1566649860,
			},
			[154153] = {
				["mapID"] = 1462,
				["coordY"] = 0.5517680644989014,
				["foundTime"] = 1566742568,
				["coordX"] = 0.553820788860321,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[132244] = {
				["mapID"] = 862,
				["coordY"] = 0.3590457141399384,
				["foundTime"] = 1564235760,
				["coordX"] = 0.7562843561172485,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[138504] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.5475974082946777,
				["coordX"] = 0.7199010848999023,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924043,
			},
			[140357] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.4217172861099243,
				["coordX"] = 0.4637579917907715,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564925045,
			},
			[145020] = {
				["mapID"] = 942,
				["coordY"] = 0.4621987044811249,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4690589606761932,
				["artID"] = 967,
				["foundTime"] = 1566321785,
			},
			[138441] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4388901591300964,
				["coordX"] = 0.5867986679077148,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567008085,
			},
			[138825] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1564922197,
				["coordX"] = 0.5807844400405884,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8363896012306213,
			},
			[138442] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1567008057,
				["coordX"] = 0.7151713371276855,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7212041616439819,
			},
			[139145] = {
				["mapID"] = 895,
				["coordY"] = 0.7343687415122986,
				["foundTime"] = 1566735355,
				["coordX"] = 0.8525850772857666,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[139529] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582646,
				["coordX"] = 0.4560043215751648,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7053842544555664,
			},
			[140168] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.6579194664955139,
				["coordX"] = 0.5303711891174316,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564241646,
			},
			[152113] = {
				["mapID"] = 1462,
				["coordY"] = 0.4827,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6839,
				["artID"] = 1276,
				["foundTime"] = 1564585571,
			},
			[138508] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564581966,
				["coordX"] = 0.5956070423126221,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4537070393562317,
			},
			[138636] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.3367382884025574,
				["coordX"] = 0.583147406578064,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564242114,
			},
			[140361] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1567006244,
				["coordX"] = 0.5562286376953125,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7488114833831787,
			},
			[134804] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1565919653,
				["coordX"] = 0.7010776400566101,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7466039657592773,
			},
			[138445] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1565916928,
				["coordX"] = 0.4776913523674011,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5790448188781738,
			},
			[293881] = {
				["mapID"] = 895,
				["coordY"] = 0.7550604343414307,
				["foundTime"] = 1566736914,
				["coordX"] = 0.9049660563468933,
				["artID"] = 920,
				["atlasName"] = "VignetteLootElite",
			},
			[148155] = {
				["mapID"] = 896,
				["coordY"] = 0.3705662488937378,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3367797434329987,
				["artID"] = 921,
				["foundTime"] = 1563979062,
			},
			[138510] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3227379322052002,
				["coordX"] = 0.6731036901473999,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007544,
			},
			[138830] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.4734777212142944,
				["coordX"] = 0.6072679758071899,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567005715,
			},
			[291201] = {
				["mapID"] = 896,
				["coordY"] = 0.262031614780426,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6186909079551697,
				["artID"] = 921,
				["foundTime"] = 1565787428,
			},
			[142088] = {
				["mapID"] = 942,
				["coordY"] = 0.4236922562122345,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4681112766265869,
				["artID"] = 967,
				["foundTime"] = 1566320752,
			},
			[273956] = {
				["mapID"] = 895,
				["coordY"] = 0.2673676311969757,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5617231130599976,
				["artID"] = 920,
				["foundTime"] = 1567000118,
			},
			[154225] = {
				["mapID"] = 1462,
				["coordY"] = 0.5838,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5721,
				["artID"] = 1276,
				["foundTime"] = 1564244742,
			},
			[152756] = {
				["mapID"] = 1355,
				["coordY"] = 0.3336013555526733,
				["foundTime"] = 1563891485,
				["coordX"] = 0.7082117795944214,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[144644] = {
				["mapID"] = 1355,
				["coordY"] = 0.5041728019714355,
				["foundTime"] = 1566137453,
				["coordX"] = 0.4513707756996155,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[291204] = {
				["mapID"] = 896,
				["coordY"] = 0.204302653670311,
				["foundTime"] = 1566739539,
				["coordX"] = 0.6155473589897156,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[152182] = {
				["mapID"] = 1462,
				["coordY"] = 0.7917572855949402,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6583449840545654,
				["artID"] = 1276,
				["foundTime"] = 1565878658,
			},
			[139152] = {
				["mapID"] = 895,
				["coordY"] = 0.8100727796554565,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7243191003799438,
				["artID"] = 920,
				["foundTime"] = 1565927625,
			},
			[139280] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.131802096962929,
				["coordX"] = 0.667342483997345,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565915671,
			},
			[153205] = {
				["mapID"] = 1462,
				["coordY"] = 0.6982120275497437,
				["foundTime"] = 1566576436,
				["coordX"] = 0.5719438195228577,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[139472] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4218864440917969,
				["coordX"] = 0.6037552356719971,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567008091,
			},
			[135959] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.4354857206344605,
				["coordX"] = 0.6970322132110596,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565919747,
			},
			[152567] = {
				["mapID"] = 1355,
				["coordY"] = 0.695204496383667,
				["foundTime"] = 1564802929,
				["coordX"] = 0.5017485618591309,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[154739] = {
				["mapID"] = 1462,
				["coordY"] = 0.5345146059989929,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6917940974235535,
				["artID"] = 1276,
				["foundTime"] = 1566391528,
			},
			[140559] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.4523815512657166,
				["coordX"] = 0.6541941165924072,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564240925,
			},
			[140112] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.377318799495697,
				["coordX"] = 0.488379180431366,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564242174,
			},
			[145286] = {
				["mapID"] = 1161,
				["coordY"] = 0.8878280520439148,
				["foundTime"] = 1563718113,
				["coordX"] = 0.8182379007339478,
				["artID"] = 1138,
				["atlasName"] = "VignetteKill",
			},
			[139410] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564583243,
				["coordX"] = 0.5867190361022949,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.442463219165802,
			},
			[139474] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1564922610,
				["coordX"] = 0.5932462811470032,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3883950114250183,
			},
			[138516] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.8274484276771545,
				["coordX"] = 0.6082821488380432,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924878,
			},
			[145287] = {
				["mapID"] = 1161,
				["coordY"] = 0.8912746906280518,
				["foundTime"] = 1563718128,
				["coordX"] = 0.81960529088974,
				["artID"] = 1138,
				["atlasName"] = "VignetteKill",
			},
			[145415] = {
				["mapID"] = 942,
				["coordY"] = 0.4765941202640533,
				["foundTime"] = 1566321849,
				["coordX"] = 0.3779283463954926,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[152697] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3812071681022644,
				["coordX"] = 0.8351465463638306,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564073893,
			},
			[139475] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564582186,
				["coordX"] = 0.4208597540855408,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5431439876556396,
			},
			[139539] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.6365309953689575,
				["coordX"] = 0.6454522609710693,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564921739,
			},
			[153313] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.2334645390510559,
				["coordX"] = 0.4183965921401978,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564909124,
			},
			[273901] = {
				["mapID"] = 1169,
				["coordY"] = 0.5015817880630493,
				["foundTime"] = 1566736980,
				["coordX"] = 0.2896124124526978,
				["artID"] = 974,
				["atlasName"] = "VignetteLoot",
			},
			[138828] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.490866482257843,
				["coordX"] = 0.5160455703735352,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007737,
			},
			[145161] = {
				["mapID"] = 1161,
				["coordY"] = 0.6578572392463684,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3085604608058929,
				["artID"] = 1138,
				["foundTime"] = 1566581896,
			},
			[146247] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564581955,
				["coordX"] = 0.6257898807525635,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4569714665412903,
			},
			[153305] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563804895,
				["coordX"] = 0.684,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.33400002,
			},
			[147061] = {
				["mapID"] = 895,
				["coordY"] = 0.3492601811885834,
				["foundTime"] = 1566581682,
				["coordX"] = 0.8445457816123962,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[139285] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1563536451,
				["coordX"] = 0.551244556903839,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.324088424444199,
			},
			[131262] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.153003871440887,
				["coordX"] = 0.388924062252045,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564904072,
			},
			[146844] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4563124179840088,
				["coordX"] = 0.3839726448059082,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567004229,
			},
			[139988] = {
				["mapID"] = 942,
				["artID"] = 967,
				["coordY"] = 0.6064436435699463,
				["coordX"] = 0.7351427674293518,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563978728,
			},
			[138634] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.3334884643554688,
				["coordX"] = 0.4774917960166931,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564242144,
			},
			[135925] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.5963016152381897,
				["coordX"] = 0.5676091909408569,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567005728,
			},
			[151933] = {
				["mapID"] = 1462,
				["coordY"] = 0.4125272035598755,
				["foundTime"] = 1566575263,
				["coordX"] = 0.6175290942192078,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[132068] = {
				["mapID"] = 895,
				["coordY"] = 0.3035782277584076,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3450413942337036,
				["artID"] = 920,
				["foundTime"] = 1566649907,
			},
			[141175] = {
				["mapID"] = 942,
				["coordY"] = 0.3222707509994507,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.708605170249939,
				["artID"] = 967,
				["foundTime"] = 1566133902,
			},
			[153658] = {
				["mapID"] = 1355,
				["coordY"] = 0.1595726013183594,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4116085767745972,
				["artID"] = 1186,
				["foundTime"] = 1564238648,
			},
			[139414] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564921748,
				["coordX"] = 0.6118149757385254,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4477077722549439,
			},
			[138432] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1565798445,
				["coordX"] = 0.6404674053192139,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7200030088424683,
			},
			[146110] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.2483599185943604,
				["coordX"] = 0.5397177934646606,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564240781,
			},
			[151870] = {
				["mapID"] = 1355,
				["coordY"] = 0.4635750651359558,
				["foundTime"] = 1566653910,
				["coordX"] = 0.6354210376739502,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[151934] = {
				["mapID"] = 1462,
				["coordY"] = 0.405854195356369,
				["foundTime"] = 1566742970,
				["coordX"] = 0.5260941982269287,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[291213] = {
				["mapID"] = 896,
				["coordY"] = 0.4441965520381928,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5472766160964966,
				["artID"] = 921,
				["foundTime"] = 1566741364,
			},
			[139287] = {
				["mapID"] = 1161,
				["coordY"] = 0.3705306351184845,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7683212161064148,
				["artID"] = 1138,
				["foundTime"] = 1564802241,
			},
			[143439] = {
				["mapID"] = 1044,
				["coordY"] = 0.7295337915420532,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5167011022567749,
				["artID"] = 968,
				["foundTime"] = 1567171099,
			},
			[139415] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1567004800,
				["coordX"] = 0.588968813419342,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4217178821563721,
			},
			[135931] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582731,
				["coordX"] = 0.483020007610321,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.595107913017273,
			},
			[139321] = {
				["mapID"] = 896,
				["coordY"] = 0.595876932144165,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2763534486293793,
				["artID"] = 921,
				["foundTime"] = 1566649650,
			},
			[275071] = {
				["mapID"] = 895,
				["coordY"] = 0.7839559316635132,
				["foundTime"] = 1566735379,
				["coordX"] = 0.8840499520301819,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[145292] = {
				["mapID"] = 1161,
				["coordY"] = 0.8868507146835327,
				["foundTime"] = 1563718101,
				["coordX"] = 0.8208204507827759,
				["artID"] = 1138,
				["atlasName"] = "VignetteKill",
			},
			[137180] = {
				["mapID"] = 895,
				["coordY"] = 0.1937957108020783,
				["foundTime"] = 1566583433,
				["coordX"] = 0.6430521011352539,
				["artID"] = 920,
				["atlasName"] = "VignetteEvent",
			},
			[280619] = {
				["mapID"] = 942,
				["coordY"] = 0.4723159372806549,
				["foundTime"] = 1564274417,
				["coordX"] = 0.4285467863082886,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[132127] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.221902117133141,
				["coordX"] = 0.601013600826263,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1566485454,
			},
			[151680] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920346,
				["coordX"] = 0.2978854179382324,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4073823094367981,
			},
			[138484] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4743258357048035,
				["coordX"] = 0.406054675579071,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924648,
			},
			[148231] = {
				["mapID"] = 862,
				["coordY"] = 0.3620046079158783,
				["foundTime"] = 1565296586,
				["coordX"] = 0.7643251419067383,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[152794] = {
				["mapID"] = 1355,
				["coordY"] = 0.1304193735122681,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3505994081497192,
				["artID"] = 1186,
				["foundTime"] = 1564909090,
			},
			[152892] = {
				["mapID"] = 1462,
				["artID"] = 1276,
				["foundTime"] = 1566391316,
				["coordX"] = 0.7069134712219238,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3852438926696777,
			},
			[135648] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582567,
				["coordX"] = 0.4200963377952576,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8000352382659912,
			},
			[145932] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.4264104962348938,
				["coordX"] = 0.6043267250061035,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925320,
			},
			[275070] = {
				["mapID"] = 895,
				["coordY"] = 0.1758910119533539,
				["foundTime"] = 1566649001,
				["coordX"] = 0.5733789801597595,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[151681] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.5952246189117432,
				["coordX"] = 0.4011715054512024,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565926121,
			},
			[291225] = {
				["mapID"] = 896,
				["coordY"] = 0.2525788545608521,
				["foundTime"] = 1566741486,
				["coordX"] = 0.2522372901439667,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[140450] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1567005846,
				["coordX"] = 0.4336100816726685,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5733608603477478,
			},
			[152290] = {
				["mapID"] = 1355,
				["coordY"] = 0.512630820274353,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6455634832382202,
				["artID"] = 1186,
				["foundTime"] = 1563808227,
			},
			[152448] = {
				["mapID"] = 1355,
				["coordY"] = 0.5611850023269653,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4722558856010437,
				["artID"] = 1186,
				["foundTime"] = 1566137483,
			},
			[291226] = {
				["mapID"] = 896,
				["coordY"] = 0.1327390521764755,
				["foundTime"] = 1566741498,
				["coordX"] = 0.2734809815883637,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[291267] = {
				["mapID"] = 942,
				["coordY"] = 0.5117460489273071,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6089920401573181,
				["artID"] = 967,
				["foundTime"] = 1566129929,
			},
			[280751] = {
				["mapID"] = 895,
				["coordY"] = 0.149866133928299,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4329716265201569,
				["artID"] = 920,
				["foundTime"] = 1566649940,
			},
			[291246] = {
				["mapID"] = 942,
				["coordY"] = 0.4137649834156036,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6738020777702332,
				["artID"] = 967,
				["foundTime"] = 1566133894,
			},
			[291227] = {
				["mapID"] = 896,
				["coordY"] = 0.3756971657276154,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.2459297329187393,
				["artID"] = 921,
				["foundTime"] = 1566649679,
			},
			[281646] = {
				["mapID"] = 942,
				["coordY"] = 0.7114048004150391,
				["foundTime"] = 1566648808,
				["coordX"] = 0.6655718088150024,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[135924] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1564922704,
				["coordX"] = 0.6793426871299744,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6504858732223511,
			},
			[132182] = {
				["mapID"] = 895,
				["coordY"] = 0.7894518971443176,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7491134405136108,
				["artID"] = 920,
				["foundTime"] = 1565916268,
			},
			[140760] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.2760408520698547,
				["coordX"] = 0.5592336654663086,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567006396,
			},
			[141088] = {
				["mapID"] = 942,
				["coordY"] = 0.759826123714447,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.570468544960022,
				["artID"] = 967,
				["foundTime"] = 1566648827,
			},
			[138844] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564924516,
				["coordX"] = 0.4708366394042969,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3777996301651001,
			},
			[281903] = {
				["mapID"] = 862,
				["coordY"] = 0.7651941776275635,
				["foundTime"] = 1564235440,
				["coordX"] = 0.4088299572467804,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[152359] = {
				["mapID"] = 1355,
				["coordY"] = 0.5483675003051758,
				["foundTime"] = 1566934302,
				["coordX"] = 0.7164038419723511,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[154342] = {
				["mapID"] = 1462,
				["coordY"] = 0.4062241613864899,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5264180302619934,
				["artID"] = 1276,
				["foundTime"] = 1564244930,
			},
			[150342] = {
				["mapID"] = 1462,
				["coordY"] = 0.2405987530946732,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6408148407936096,
				["artID"] = 1276,
				["foundTime"] = 1566572816,
			},
			[281904] = {
				["mapID"] = 862,
				["coordY"] = 0.379704624414444,
				["foundTime"] = 1566650787,
				["coordX"] = 0.4216816127300263,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[291230] = {
				["mapID"] = 896,
				["coordY"] = 0.6178849935531616,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3927716016769409,
				["artID"] = 921,
				["foundTime"] = 1566741407,
			},
			[134764] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582458,
				["coordX"] = 0.3050875067710877,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.71254563331604,
			},
			[148154] = {
				["mapID"] = 1203,
				["coordY"] = 0.3520309925079346,
				["foundTime"] = 1563628197,
				["coordX"] = 0.5649635791778564,
				["artID"] = 1165,
				["atlasName"] = "VignetteKill",
			},
			[145041] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3504912257194519,
				["coordX"] = 0.4584248661994934,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007413,
			},
			[155836] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.6553937792778015,
				["coordX"] = 0.4939302206039429,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564236175,
			},
			[152323] = {
				["mapID"] = 1355,
				["coordY"] = 0.2900329828262329,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2944130301475525,
				["artID"] = 1186,
				["foundTime"] = 1566138119,
			},
			[137057] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582657,
				["coordX"] = 0.4551339745521545,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7005612850189209,
			},
			[151940] = {
				["mapID"] = 1462,
				["coordY"] = 0.2214440107345581,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5796273946762085,
				["artID"] = 1276,
				["foundTime"] = 1566575630,
			},
			[291244] = {
				["mapID"] = 942,
				["coordY"] = 0.5702658891677856,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6994632482528687,
				["artID"] = 967,
				["foundTime"] = 1567174860,
			},
			[149653] = {
				["mapID"] = 1355,
				["coordY"] = 0.4171630144119263,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.547032356262207,
				["artID"] = 1186,
				["foundTime"] = 1564236448,
			},
			[137824] = {
				["mapID"] = 896,
				["coordY"] = 0.6902610659599304,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2922166585922241,
				["artID"] = 921,
				["foundTime"] = 1566649606,
			},
			[153200] = {
				["mapID"] = 1462,
				["coordY"] = 0.5108755826950073,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5058590173721313,
				["artID"] = 1276,
				["foundTime"] = 1566572951,
			},
			[144722] = {
				["mapID"] = 895,
				["coordY"] = 0.3759651482105255,
				["foundTime"] = 1563718171,
				["coordX"] = 0.7924480438232422,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[138511] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1567007632,
				["coordX"] = 0.4935778379440308,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.293592095375061,
			},
			[149359] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.550769567489624,
				["coordX"] = 0.4259355068206787,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925980,
			},
			[281397] = {
				["mapID"] = 895,
				["coordY"] = 0.5814225077629089,
				["foundTime"] = 1565927837,
				["coordX"] = 0.724904477596283,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[132076] = {
				["mapID"] = 895,
				["coordY"] = 0.2064892500638962,
				["foundTime"] = 1564914716,
				["coordX"] = 0.4685119688510895,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[144915] = {
				["mapID"] = 942,
				["coordY"] = 0.4908104836940765,
				["foundTime"] = 1565915345,
				["coordX"] = 0.4972397089004517,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[139486] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920199,
				["coordX"] = 0.2100303173065186,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4873050451278687,
			},
			[134823] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4133331775665283,
				["coordX"] = 0.5637351870536804,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567005041,
			},
			[155838] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.509932816028595,
				["coordX"] = 0.791060209274292,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564236292,
			},
			[281494] = {
				["mapID"] = 942,
				["coordY"] = 0.8410260677337646,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.489747017621994,
				["artID"] = 967,
				["foundTime"] = 1563977593,
			},
			[134298] = {
				["mapID"] = 863,
				["coordY"] = 0.8116368651390076,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5414788126945496,
				["artID"] = 888,
				["foundTime"] = 1564240381,
			},
			[287531] = {
				["mapID"] = 942,
				["coordY"] = 0.6378964781761169,
				["foundTime"] = 1566133871,
				["coordX"] = 0.6154956817626953,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[155583] = {
				["mapID"] = 1462,
				["coordY"] = 0.7772676348686218,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8229547142982483,
				["artID"] = 1276,
				["foundTime"] = 1566133455,
			},
			[153228] = {
				["mapID"] = 1462,
				["coordY"] = 0.5180505514144897,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5857169032096863,
				["artID"] = 1276,
				["foundTime"] = 1566392327,
			},
			[151623] = {
				["mapID"] = 1462,
				["coordY"] = 0.5012,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7227,
				["artID"] = 1276,
				["foundTime"] = 1566573816,
			},
			[151687] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920488,
				["coordX"] = 0.6183640956878662,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4767789840698242,
			},
			[136876] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1564922721,
				["coordX"] = 0.657328188419342,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6265261769294739,
			},
			[146849] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1565926145,
				["coordX"] = 0.6668627262115479,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4395135045051575,
			},
			[291211] = {
				["mapID"] = 896,
				["coordY"] = 0.221609964966774,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5289109349250793,
				["artID"] = 921,
				["foundTime"] = 1567000160,
			},
			[273955] = {
				["mapID"] = 895,
				["coordY"] = 0.3133111894130707,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5304228663444519,
				["artID"] = 920,
				["foundTime"] = 1567000128,
			},
			[154180] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.5921164751052856,
				["coordX"] = 0.3799697160720825,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564075747,
			},
			[146131] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.45807945728302,
				["coordX"] = 0.3808413743972778,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924652,
			},
			[153304] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563890396,
				["coordX"] = 0.682,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.33,
			},
			[130138] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.454817533493042,
				["coordX"] = 0.599422335624695,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1566741281,
			},
			[155840] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3220067024230957,
				["coordX"] = 0.4742978811264038,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565920988,
			},
			[131520] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1564914594,
				["coordX"] = 0.479090541601181,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.226362377405167,
			},
			[291224] = {
				["mapID"] = 896,
				["coordY"] = 0.1949394941329956,
				["foundTime"] = 1567000220,
				["coordX"] = 0.3431304693222046,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[284469] = {
				["mapID"] = 895,
				["coordY"] = 0.4039365649223328,
				["foundTime"] = 1567171724,
				["coordX"] = 0.7432176470756531,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[139233] = {
				["mapID"] = 895,
				["coordY"] = 0.5590100288391113,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5784597992897034,
				["artID"] = 920,
				["foundTime"] = 1563551204,
			},
			[140360] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.8168452978134155,
				["coordX"] = 0.3435608744621277,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564925129,
			},
			[151625] = {
				["mapID"] = 1462,
				["coordY"] = 0.4900919497013092,
				["foundTime"] = 1563800760,
				["coordX"] = 0.7103789448738098,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[138481] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.5227176547050476,
				["coordX"] = 0.4933848381042481,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565920426,
			},
			[155841] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1564430603,
				["coordX"] = 0.734,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.314,
			},
			[139420] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564921815,
				["coordX"] = 0.5969768166542053,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4893783926963806,
			},
			[152001] = {
				["mapID"] = 1462,
				["coordY"] = 0.278483122587204,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.662093997001648,
				["artID"] = 1276,
				["foundTime"] = 1566223280,
			},
			[275074] = {
				["mapID"] = 895,
				["coordY"] = 0.1696648746728897,
				["foundTime"] = 1566648849,
				["coordX"] = 0.7046692371368408,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[50138] = {
				["mapID"] = 241,
				["artID"] = 252,
				["coordY"] = 0.744,
				["coordX"] = 0.492,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1566132822,
			},
			[139809] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564582244,
				["coordX"] = 0.3981276154518127,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5952268242835999,
			},
			[139431] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564581351,
				["coordX"] = 0.615311861038208,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4813365936279297,
			},
			[152712] = {
				["mapID"] = 1355,
				["coordY"] = 0.8254230618476868,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3740364909172058,
				["artID"] = 1186,
				["foundTime"] = 1566999293,
			},
			[136183] = {
				["mapID"] = 942,
				["coordY"] = 0.5552466511726379,
				["foundTime"] = 1566129912,
				["coordX"] = 0.5125221014022827,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[129181] = {
				["mapID"] = 895,
				["coordY"] = 0.8293412923812866,
				["foundTime"] = 1565927743,
				["coordX"] = 0.7608619332313538,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[139419] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565919792,
				["coordX"] = 0.5685067176818848,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6901346445083618,
			},
			[137183] = {
				["mapID"] = 895,
				["coordY"] = 0.1963558048009872,
				["foundTime"] = 1566140080,
				["coordX"] = 0.6403713226318359,
				["artID"] = 920,
				["atlasName"] = "VignetteEvent",
			},
			[140768] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.5706084966659546,
				["coordX"] = 0.4928805232048035,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564242208,
			},
			[151684] = {
				["mapID"] = 1462,
				["coordY"] = 0.4471794962882996,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7724449634552002,
				["artID"] = 1276,
				["foundTime"] = 1566742661,
			},
			[151627] = {
				["mapID"] = 1462,
				["coordY"] = 0.6144568920135498,
				["foundTime"] = 1566391913,
				["coordX"] = 0.6102732419967651,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[279042] = {
				["mapID"] = 942,
				["coordY"] = 0.8387717008590698,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5859931111335754,
				["artID"] = 967,
				["foundTime"] = 1565915622,
			},
			[140300] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1564922610,
				["coordX"] = 0.5932462811470032,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3883950114250183,
			},
			[151308] = {
				["mapID"] = 1462,
				["coordY"] = 0.2696628868579865,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5555583238601685,
				["artID"] = 1276,
				["foundTime"] = 1566575463,
			},
			[146773] = {
				["mapID"] = 895,
				["coordY"] = 0.4760339856147766,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8477122187614441,
				["artID"] = 920,
				["foundTime"] = 1567006689,
			},
			[138843] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4133331775665283,
				["coordX"] = 0.5637351870536804,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567005057,
			},
			[140769] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.6850020885467529,
				["coordX"] = 0.5687972903251648,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567005581,
			},
			[153206] = {
				["mapID"] = 1462,
				["coordY"] = 0.3437756597995758,
				["foundTime"] = 1566575066,
				["coordX"] = 0.5663586854934692,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[136809] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.6960573196411133,
				["coordX"] = 0.356592059135437,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564242362,
			},
			[131252] = {
				["mapID"] = 895,
				["coordY"] = 0.1687140464782715,
				["foundTime"] = 1564914812,
				["coordX"] = 0.4313379228115082,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[139417] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564583254,
				["coordX"] = 0.6067830324172974,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4394235610961914,
			},
			[132913] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565916818,
				["coordX"] = 0.4165741801261902,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3827662467956543,
			},
			[154701] = {
				["mapID"] = 1462,
				["coordY"] = 0.5430490970611572,
				["foundTime"] = 1566574925,
				["coordX"] = 0.7003786563873291,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[150937] = {
				["mapID"] = 1462,
				["coordY"] = 0.8028293251991272,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.1940868645906448,
				["artID"] = 1276,
				["foundTime"] = 1566742975,
			},
			[137704] = {
				["mapID"] = 896,
				["coordY"] = 0.1986713856458664,
				["foundTime"] = 1566739618,
				["coordX"] = 0.3484510183334351,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[139812] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565919801,
				["coordX"] = 0.5750276446342468,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7118301391601563,
			},
			[140387] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564582032,
				["coordX"] = 0.5054986476898193,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.376514732837677,
			},
			[153226] = {
				["mapID"] = 1462,
				["coordY"] = 0.7737317681312561,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2545179724693298,
				["artID"] = 1276,
				["foundTime"] = 1566573578,
			},
			[297892] = {
				["mapID"] = 896,
				["coordY"] = 0.2769678831100464,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4421927034854889,
				["artID"] = 921,
				["foundTime"] = 1563977702,
			},
			[138288] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.4630273580551148,
				["coordX"] = 0.6968731880187988,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565927405,
			},
			[275076] = {
				["mapID"] = 895,
				["coordY"] = 0.2351714968681335,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4640699326992035,
				["artID"] = 920,
				["foundTime"] = 1566130391,
			},
			[145308] = {
				["mapID"] = 895,
				["coordY"] = 0.4251548647880554,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.860230565071106,
				["artID"] = 920,
				["foundTime"] = 1567006638,
			},
			[115226] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.4448662400245667,
				["coordX"] = 0.5779024362564087,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925381,
			},
			[140429] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4089969396591187,
				["coordX"] = 0.486330509185791,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567004172,
			},
			[144987] = {
				["mapID"] = 942,
				["coordY"] = 0.5195040106773376,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3644067645072937,
				["artID"] = 967,
				["foundTime"] = 1564274365,
			},
			[139430] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565799596,
				["coordX"] = 0.4724639654159546,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3261980414390564,
			},
			[140982] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.327782928943634,
				["coordX"] = 0.6705145239830017,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007537,
			},
			[146852] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.4822253584861755,
				["coordX"] = 0.6036513447761536,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007596,
			},
			[152397] = {
				["mapID"] = 1355,
				["coordY"] = 0.2462955713272095,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7808642983436584,
				["artID"] = 1186,
				["foundTime"] = 1564073630,
			},
			[150394] = {
				["mapID"] = 1462,
				["coordY"] = 0.4545035362243652,
				["foundTime"] = 1566391646,
				["coordX"] = 0.5490601062774658,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[302954] = {
				["mapID"] = 895,
				["coordY"] = 0.2021649330854416,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.795835554599762,
				["artID"] = 920,
				["foundTime"] = 1567171913,
			},
		},
		["rares_loot"] = {
			[152359] = {
				155609, -- [1]
				158859, -- [2]
			},
			[154153] = {
			},
			[153296] = {
				160935, -- [1]
				160926, -- [2]
			},
			[137183] = {
			},
			[325659] = {
				169129, -- [1]
			},
			[144915] = {
			},
			[325660] = {
				169122, -- [1]
			},
			[152567] = {
				155603, -- [1]
			},
			[151202] = {
			},
			[325661] = {
				169126, -- [1]
			},
			[325662] = {
				167790, -- [1]
				169850, -- [2]
			},
			[139233] = {
			},
			[325663] = {
				169124, -- [1]
			},
			[151870] = {
			},
			[151124] = {
				169145, -- [1]
			},
			[153315] = {
			},
			[151934] = {
			},
			[144997] = {
			},
			[155840] = {
			},
			[325666] = {
			},
			[153205] = {
			},
			[325667] = {
			},
			[153301] = {
			},
			[152682] = {
			},
			[153206] = {
			},
			[152397] = {
				158745, -- [1]
			},
			[153302] = {
			},
			[137824] = {
			},
			[150937] = {
			},
			[152414] = {
			},
			[151684] = {
			},
			[153304] = {
			},
			[132127] = {
			},
			[145415] = {
			},
			[152448] = {
			},
			[151702] = {
			},
			[138288] = {
			},
			[152290] = {
				158760, -- [1]
			},
			[153314] = {
			},
			[326409] = {
				170098, -- [1]
			},
			[154148] = {
			},
			[145020] = {
			},
			[145161] = {
			},
			[152291] = {
				158760, -- [1]
			},
			[139280] = {
			},
			[293962] = {
				161204, -- [1]
			},
			[153228] = {
			},
			[152795] = {
			},
			[291264] = {
				161203, -- [1]
			},
			[151940] = {
			},
			[153226] = {
			},
			[152323] = {
			},
			[151308] = {
			},
			[293964] = {
				161201, -- [1]
			},
			[152681] = {
				158874, -- [1]
			},
			[139152] = {
			},
			[325668] = {
			},
			[147562] = {
			},
			[153309] = {
				170174, -- [1]
				170170, -- [2]
			},
			[145308] = {
			},
			[325665] = {
				169129, -- [1]
			},
			[151627] = {
			},
			[153658] = {
				155598, -- [1]
			},
			[326415] = {
				170097, -- [1]
			},
			[325664] = {
				169850, -- [1]
				168832, -- [2]
			},
			[148198] = {
			},
			[275076] = {
				163091, -- [1]
			},
			[153310] = {
			},
			[148451] = {
				157842, -- [1]
			},
			[153313] = {
				158778, -- [1]
			},
			[152360] = {
				158859, -- [1]
				155609, -- [2]
			},
			[153303] = {
				154805, -- [1]
			},
			[150342] = {
			},
			[155583] = {
			},
			[151933] = {
			},
			[148231] = {
			},
			[153200] = {
			},
			[137665] = {
			},
			[146773] = {
			},
		},
		["rare_names"] = {
			["koKR"] = {
				[85767] = "저주받은 선구자",
				[139766] = "전직 항해사 더블린",
				[136183] = "파게",
				[107266] = "사령관 소락스",
				[88071] = "전략가 안코르",
				[139767] = "\"망원경\" 마리",
				[88583] = "숲 감시자 얄",
				[126462] = "포즈루크",
				[98309] = "해바람",
				[139768] = "해적단원 단",
				[90887] = "핏빛의 돌그",
				[124927] = "준티",
				[121088] = "뒤틀린 공허군주",
				[152566] = "아네모나르",
				[85001] = "정예근위병 밀그라",
				[134651] = "의술사 하브라두",
				[152567] = "물풀버들",
				[140794] = "흉터갈퀴",
				[99846] = "분노하는 대지",
				[152568] = "우르두우",
				[84746] = "사로잡힌 고르보쉬 바위구체자",
				[126208] = "바르가",
				[63240] = "어둠의 주인 사이도우",
				[89865] = "파도를 가르는 자 아옳옳옳",
				[98311] = "가옳아옳",
				[136189] = "이끼왕",
				[107269] = "심문관 티보스",
				[121090] = "실성한 쉬바라",
				[88586] = "모가마고",
				[109317] = "룰프 본스냅퍼",
				[85771] = "고위 흑마술사 카스",
				[90122] = "육중한 조우그",
				[140798] = "바위까악",
				[79629] = "천둥발 크리고",
				[92682] = "지옥어귀 약탈자",
				[109318] = "룬의 현자 시그비드",
				[50828] = "보노보스",
				[110342] = "랍사흐",
				[147966] = "아만",
				[78606] = "창백한 생선탐식자",
				[121092] = "변형된 주시자",
				[80398] = "케라브노스",
				[109575] = "목마른 발라카르",
				[101641] = "미타나",
				[134147] = "괴물윙윙",
				[116230] = "이국적인 무희",
				[129027] = "골로나르",
				[129283] = "대왕 모래게",
				[153088] = "반짝이는 메카거미",
				[138244] = "장미나무 방어병",
				[147970] = "아옳마르",
				[91661] = "빈예티",
				[92429] = "무리군주 익스코르",
				[92685] = "대장 브르벳",
				[92941] = "고라보쉬",
				[50062] = "애오낙스",
				[85264] = "롤코르",
				[85520] = "무리잎새",
				[110346] = "시든꽃잎 아오드",
				[140296] = "사향 축축털",
				[145415] = "대장 고로크",
				[145927] = "별비명꾼 엘라나",
				[91663] = "말썽이",
				[140297] = "노크아라크",
				[145928] = "스카비스 나이트스토커",
				[140298] = "흉포한 골쿤",
				[78867] = "질식자",
				[124680] = "줄조로스",
				[140299] = "유령송곳니",
				[149513] = "크로즈 블러드레이지",
				[50831] = "할퀴",
				[50959] = "카르킨",
				[140300] = "파쇄찢개",
				[149514] = "험악뿔",
				[91921] = "고룡벌레",
				[140301] = "흉터발",
				[145932] = "셀레스트라 브라이트문",
				[139278] = "란쟈",
				[103183] = "로크나쉬",
				[149516] = "깜장발",
				[88083] = "영혼술사 나일라나",
				[149517] = "아가테 웜우드",
				[50832] = "울부짖는 자",
				[139280] = "날쌘돌이 시디안",
				[107023] = "니소그",
				[101649] = "서리조각",
				[86549] = "강철엄니",
				[124684] = "고문관의 눈",
				[92180] = "시어세이",
				[129803] = "채찍덩굴",
				[109584] = "피오르둔",
				[154640] = "최고사령관 트렘블레이드",
				[151569] = "깊은물 아귀괴수",
				[90901] = "무리군주 야옹부엉",
				[78872] = "클리킥스",
				[154641] = "대장군 볼라스",
				[139285] = "맹독의 부들비늘",
				[125453] = "어미 가시도치",
				[93205] = "쏜드락스",
				[77081] = "란티코어",
				[94485] = "악취나는 폴로우스",
				[139287] = "톱이빨",
				[92694] = "피범벅발톱",
				[129805] = "비숄",
				[122639] = "고대의 르갈",
				[139289] = "표류자 텐튤로스",
				[92951] = "사냥개조련사 엘리",
				[126223] = "비술사 칼송곳니",
				[142361] = "역병깃털",
				[139290] = "소라게 메종",
				[70429] = "감염된 플레시록",
				[58769] = "무쇠턱",
				[140828] = "아침이슬",
				[83483] = "부싯돌가죽",
				[132127] = "여우굴 하늘공포",
				[140829] = "가을바람",
				[77085] = "어둠의 발산물",
				[78621] = "분노의 회오리바람",
				[115732] = "믿음직스러운 요르빌드",
				[108822] = "여사냥꾼 에스트리드",
				[50836] = "잽싼 익익",
				[69664] = "뭄타",
				[147998] = "공허지배자 이븐셰이드",
				[148510] = "드록사르 모가르",
				[108823] = "하프단",
				[133155] = "그나아트",
				[89884] = "선장잡이 플로그",
				[139298] = "핑쿠숀",
				[139810] = "투자회사 중간 관리자",
				[107544] = "니소그",
				[99610] = "가르브룰그",
				[87837] = "뼈파괴자",
				[147489] = "선장 그린세일즈",
				[139811] = "투자회사 부선임",
				[58771] = "퀴드",
				[82207] = "오색날개",
				[140836] = "밝은불길",
				[133158] = "무리어미 키말",
				[134694] = "추방자 모르파니",
				[92189] = "상상의 공포",
				[139813] = "선임 생산자 직시",
				[144420] = "[DNT] - Sabertron Vignette Marker",
				[110361] = "비명의 전령",
				[139814] = "합병 전문가 허즐",
				[127765] = "암컷 사우로리스크",
				[138279] = "아드하라 화이트",
				[135720] = "달빛 깃든 암사냥호랑이",
				[140327] = "여왕 돌엄니",
				[109594] = "폭풍깃털",
				[101660] = "분노의 부패자",
				[130581] = "모래눈이",
				[135721] = "아샤네",
				[121112] = "흐릿한 여명",
				[92703] = "지옥어귀 약탈자",
				[133163] = "티아카완",
				[110363] = "썩은눈",
				[135723] = "달발톱",
				[140330] = "해골딸깍이",
				[140842] = "엡",
				[124440] = "감독관 이베다",
				[135724] = "수풀추적자",
				[140331] = "깊은굴 복병",
				[85026] = "영혼왜곡사 토렉",
				[110364] = "창백한 공포날개",
				[139820] = "부사장 핏지 제트젬",
				[140332] = "깔짝파개",
				[140844] = "제피스",
				[124185] = "골라칸",
				[139821] = "부사장 프랭키 G.",
				[140333] = "강철껍질",
				[130584] = "가시박이",
				[106526] = "여군주 리반타스",
				[103199] = "라고울",
				[97057] = "감독관 브루타그",
				[50840] = "상사 내너스",
				[138288] = "심연의 유령",
				[135217] = "북녘골의 맥시밀리언",
				[70440] = "모나라",
				[134706] = "죽음뚜껑",
				[92451] = "저주받은 바릭스",
				[97058] = "백작 네파리우스",
				[113694] = "파샤",
				[77095] = "길추적자 드라가",
				[150575] = "우레바위",
				[134707] = "여군주 세이린",
				[140338] = "군집 경비병 진칼로",
				[99362] = "칡괴수",
				[150576] = "톱니바퀴",
				[104481] = "알라와쉬테",
				[152624] = "왕 가쿨라",
				[97059] = "왕 보라스",
				[63510] = "우론",
				[152113] = "고철모이왕",
				[86566] = "배신자 다즈고",
				[87846] = "구덩이 학살자",
				[92197] = "렐고르",
				[84263] = "자갈니",
				[140341] = "구름박박이",
				[92965] = "어둠그늘",
				[101411] = "대게 고움",
				[140854] = "흐름물",
				[111649] = "대사 디브윈",
				[79145] = "칼날흉터 야가",
				[139319] = "폐수범벅",
				[125214] = "크럽스",
				[140343] = "칼날날개",
				[140855] = "낙수령",
				[135225] = "풍차의 가이른",
				[140344] = "하늘 독사",
				[144951] = "창백털 포식자",
				[92199] = "우르속의 형상",
				[140345] = "폭풍비명",
				[144952] = "고리송곳니",
				[150583] = "바위물풀 비틀괴물",
				[122912] = "사령관 사스레나엘",
				[140858] = "화염족속",
				[145465] = "기술자 볼트홀드",
				[138299] = "피아귀",
				[92200] = "우르솔의 형상",
				[50331] = "고칸",
				[144954] = "피의 탐식자",
				[130079] = "와가 스날터스크",
				[134717] = "엄브라릭스",
				[86058] = "개리슨 포드",
				[143931] = "하늘빛나래",
				[127776] = "비늘발톱 무리어미",
				[139325] = "Void Essence Kill Credit",
				[140861] = "흙떨이",
				[153658] = "소멸자 쉬즈나라스",
				[93993] = "만족을 모르는 먹보",
				[86571] = "증오의 두르프",
				[144957] = "샬라이",
				[111653] = "미아수",
				[116004] = "비행 조련사 볼나스",
				[103975] = "제이드 다크헤이븐",
				[50332] = "코르다 토로스",
				[58778] = "애타",
				[109606] = "발리토스",
				[77614] = "광포한 골렘",
				[139328] = "호랑트론",
				[140864] = "낄낄발작",
				[148031] = "그렌 토른퍼",
				[130338] = "먼지송곳니",
				[87597] = "폭격수 구고크",
				[50333] = "황소 론",
				[134213] = "집행자 블랙웰",
				[78128] = "그론추적자 다원",
				[86574] = "발명가 블라모",
				[133190] = "비수이빨",
				[138309] = "끄적이",
				[92205] = "가장 어두운 공포",
				[140357] = "맹독절단자",
				[140358] = "비탄부름",
				[82992] = "지옥불꽃 악녀",
				[116008] = "카르준",
				[139335] = "호랑트론",
				[50334] = "파괴자 닥",
				[140359] = "천둥매 포식자",
				[97069] = "격노군주 레코스",
				[154180] = "어스름길잡이 야르가",
				[138824] = "할피드 아이언아이",
				[139336] = "호랑트론",
				[140360] = "태양등",
				[144967] = "빈예티",
				[87344] = "고르탁 스틸그립",
				[91695] = "대흑마법사 네더쿠르스",
				[138825] = "인가토라 블러드드링커",
				[140361] = "흉조의 검은그림자",
				[129830] = "거수 딸각발톱",
				[97326] = "날치기 하틀리",
				[138826] = "용감한 레이크니르",
				[151623] = "고철왕",
				[140362] = "반짝날개",
				[99886] = "잠잠해진 대지",
				[138827] = "강한 보달프",
				[151624] = "태엽돌이 거인",
				[72245] = "제스쿠아",
				[138828] = "용맹한 베르힐드",
				[151625] = "고철왕",
				[123689] = "흉측한 탈레스트라",
				[138829] = "교활한 잉겔",
				[92465] = "검은송곳니",
				[92977] = "강철 사냥개조련사",
				[89650] = "폭풍인도자 발리야카",
				[89906] = "빈예티",
				[151627] = "고쳐줘 씨",
				[148044] = "오윈 그라독",
				[86579] = "검귀 로고르",
				[86835] = "젤가나크",
				[128553] = "아제르토르",
				[138831] = "홀벌드 오션사이드",
				[50336] = "요릭 샤프아이",
				[139344] = "드라카니 죽음부패자",
				[78134] = "길잡이 자로그",
				[148558] = "바위분노",
				[91187] = "모래젓개",
				[87348] = "흰 서리",
				[83509] = "선혈꽃잎",
				[134738] = "되살아난 자 하카비",
				[139345] = "죽음전령 쿨루",
				[71992] = "달송곳니",
				[140369] = "지하수색자",
				[90164] = "전쟁인도자 목스나",
				[82486] = "탐험가 노잔드",
				[82742] = "에나브라",
				[82998] = "죄악의 여제",
				[142418] = "물결치는 거수",
				[139347] = "광전사 골라",
				[140371] = "알지기 니식크",
				[129835] = "뿔꼬챙이",
				[93236] = "어둠갈퀴",
				[97587] = "광기 어린 마법사",
				[126508] = "스케틱",
				[139348] = "서리방패 바가",
				[140372] = "둥지 수호자 크쉭스",
				[124717] = "집행자 바알",
				[139349] = "무덤소환사 무자",
				[121134] = "공작 시티지",
				[140373] = "여왕 모래껍질",
				[129836] = "주문을 뒤트는 모에퍼스",
				[139350] = "아나하 위더브레스",
				[140374] = "둥지 수호자 익스닐",
				[87351] = "어미 고렌",
				[151124] = "메카곤식 종결자",
				[139351] = "어둠예언자 안고로",
				[50338] = "밤의 포악자 코르나스",
				[126254] = "부관 자카아르",
				[142423] = "감독관 크릭스",
				[77626] = "무리어미 하미",
				[139352] = "죽음소환사 마줄리",
				[87352] = "겁쟁이 지블렛",
				[139353] = "죽지 못하는 용사",
				[130350] = "샘터의 수호자",
				[138842] = "공명생성자 타킬",
				[139354] = "뼈절단자 부툰",
				[90936] = "피사냥꾼 줄크",
				[138843] = "날개지도자 스라키크",
				[139355] = "서리검사 구란",
				[125232] = "대장 무칼라",
				[132701] = "티제인",
				[109620] = "속삭이는 자",
				[73277] = "낙엽치유사",
				[138844] = "황제의 칼날 야비크",
				[139356] = "호랑트론",
				[144987] = "어둠사냥꾼 무툼바",
				[138845] = "사령관 조바크",
				[138846] = "호박석날개 정신노래꾼",
				[139358] = "접대원",
				[103223] = "헤르타 그림도티르",
				[138847] = "전투 치유사 카바즈",
				[139359] = "호랑트론",
				[139871] = "혈길잡이 킬틱스",
				[62881] = "영혼절단자 가오훈",
				[137824] = "전깃불이",
				[73279] = "영원아귀",
				[138848] = "칼춤꾼 졸라크",
				[98361] = "피투성이 까마귀",
				[139872] = "수호자 자카르",
				[136801] = "측량사 꼬질소금",
				[137825] = "눈사태",
				[138849] = "둥지군주 빅스익크",
				[139873] = "파멸끼긱",
				[140385] = "보석껍질 무리지기",
				[136802] = "석탄깨물",
				[142433] = "포즈루크",
				[139874] = "공포습격",
				[140386] = "토파즈 딱정벌레",
				[87357] = "발코르",
				[142434] = "루아이",
				[50085] = "대군주 가리분노",
				[139875] = "동굴 과부거미",
				[140387] = "보석 박힌 여왕",
				[136804] = "자갈척추",
				[72769] = "비취불꽃의 영혼",
				[142435] = "역병깃털",
				[90173] = "비전 사냥개",
				[139876] = "밤흡혈거미",
				[140388] = "루비 청소부",
				[136805] = "바위댕강",
				[142436] = "분노부리",
				[139877] = "알지기 카하스즈",
				[109113] = "침식된 낙하바위",
				[136806] = "돌마법사 바르그",
				[73282] = "갈니아",
				[139878] = "늙은 아칼아잔",
				[140390] = "마노 담즙포식자",
				[144997] = "구린 스톤바인더",
				[83008] = "걸신들린 하쿤",
				[142438] = "베노마루스",
				[134760] = "암흑예언자 졸라",
				[140391] = "에메랄드 심연수색자",
				[136808] = "모래거죽",
				[89407] = "고룡혓바닥 강탈자",
				[85568] = "눈사태",
				[77634] = "탈라도란튤라",
				[139880] = "무리순찰자 탈나딕스",
				[140392] = "천굴 공포딱정벌레",
				[136809] = "바위포식자 돌턱",
				[111674] = "잿불날개",
				[142440] = "요구르사",
				[79938] = "그림자껍질",
				[139881] = "무리감시자 탈림라",
				[139882] = "무리감시자 아눕아칼",
				[83522] = "둥지 여왕 스크리카",
				[134764] = "따닥이껍질",
				[139883] = "예언자 바키즈아샤",
				[147562] = "박격포 대장 잽프릿츠",
				[127288] = "사냥개조련사 케락스",
				[152681] = "왕자 타이포너스",
				[82755] = "야생의 붉은발톱",
				[87362] = "기비",
				[134766] = "파도뱉기게",
				[148075] = "야수 조련사 왓킨스",
				[152682] = "왕자 보르트란",
				[136814] = "넝마꼬리",
				[134767] = "죽음발톱 알어미",
				[90434] = "세락사스",
				[140398] = "제리타르즈",
				[138863] = "자매 마사",
				[50344] = "놀락스",
				[125498] = "감독관 이모르나",
				[136816] = "감독관 스놀글",
				[97345] = "굶주린 크로슈크",
				[85572] = "그르브르글",
				[134769] = "톱니 발톱",
				[127290] = "머그",
				[107327] = "흉악뿔",
				[124475] = "휘청거리는 복병",
				[79686] = "은빛잎새 고대정령",
				[139889] = "보러스아라크",
				[132211] = "악취부리",
				[136818] = "감독관 화염핥기",
				[138866] = "맥",
				[78151] = "전문사냥꾼 쿠앙",
				[136819] = "감독관 쥐꼬리",
				[83526] = "루클라",
				[104513] = "디필리아",
				[135796] = "선장 리드피스트",
				[153200] = "부글앗뜨",
				[50985] = "두드림주먹",
				[110656] = "비전술사 리란드레",
				[82247] = "나스 던블린",
				[95044] = "공포주먹",
				[154225] = "녹슨 왕자",
				[84807] = "두르카스 스틸마",
				[97348] = "아베샤",
				[138870] = "믹",
				[90438] = "여군주 오란",
				[141942] = "무쇠주먹 몰로크",
				[154739] = "부식성 기계수액",
				[138871] = "어니",
				[112705] = "아크로노스",
				[148597] = "강철 주술사 그림비어드",
				[97093] = "샤라 펠브레스",
				[77642] = "업화술사 진드라",
				[153205] = "보석사 거미",
				[124479] = "물집아귀",
				[139385] = "긴송곳니",
				[152182] = "녹슨깃털",
				[153206] = "늙은 왕엄니",
				[151159] = "OOX-날쌘발/MG",
				[139386] = "뱀혓바닥",
				[111939] = "라이사니스 셰이드소울",
				[120641] = "스컬굴로스",
				[104517] = "마와트아키",
				[129343] = "졸로탈의 화신",
				[84810] = "피범벅 칼로스",
				[73293] = "휘지그",
				[139388] = "제스에즈",
				[152697] = "울매스",
				[83019] = "구그톨",
				[96072] = "두르구스",
				[112708] = "그림토템 용사",
				[80204] = "지옥껍질",
				[109125] = "야생의 카소우",
				[140925] = "의사 마르틴스",
				[139390] = "비늘경비병 사리스즈",
				[90442] = "여주인 타브라",
				[82764] = "가르루아",
				[116036] = "제왕 구름날개",
				[79693] = "은빛잎새 고대정령",
				[139391] = "암흑파도 암살자",
				[125250] = "고대 턱파괴자",
				[93002] = "마그위아",
				[89675] = "지휘관 오르그모크",
				[122947] = "여군주 일센드라",
				[128578] = "주조스걸",
				[136834] = "무두장이 바주울루",
				[126019] = "지나치게 자란 아귀마귀",
				[138370] = "호르코",
				[85837] = "조각아귀",
				[98890] = "잠탱이",
				[136835] = "킨토가 비스트베인",
				[104521] = "알테리아",
				[50349] = "영혼도둑 캉",
				[136836] = "암흑파괴자 우르줄라",
				[50733] = "스키티크",
				[77648] = "불꽃의 대모 타르가",
				[151681] = "투척꾼 짤딸꼬리",
				[131718] = "덤불날개",
				[136837] = "맹독술사 앤트수",
				[128580] = "칼날턱",
				[104522] = "셀레니",
				[132743] = "화염비늘 파도돌격병",
				[109641] = "일급 비전골렘",
				[138374] = "모래털이",
				[134791] = "영롱한 엉금게",
				[78161] = "하이페리우스",
				[136839] = "므로건",
				[138375] = "스무스",
				[151684] = "턱파괴자",
				[50350] = "모르긴 크랙팡",
				[136840] = "조가",
				[105547] = "로우렌",
				[50990] = "천둥발굽 나크",
				[134793] = "반짝가시",
				[151685] = "군내털 굴어미",
				[140424] = "낫뿔이",
				[95054] = "복수",
				[107595] = "음침한 부패곰",
				[116041] = "보물 고블린",
				[91727] = "집행관 라일로스",
				[134794] = "어둠잠복",
				[104524] = "오르마그로그",
				[96590] = "망치주먹 구르보그",
				[92751] = "상아 파수꾼",
				[97102] = "람파그",
				[138890] = "영혼수색자 다르걸프",
				[151687] = "비명쟁이",
				[140426] = "달수염",
				[140938] = "두껍이",
				[107596] = "음침한 부패곰",
				[120393] = "공성전문가 보라안",
				[134796] = "가시집게 왕게",
				[139403] = "침략자 아라사즈",
				[50351] = "존다르",
				[152712] = "유리비늘",
				[93264] = "대장 그록마르",
				[77140] = "아마우콰",
				[142475] = "매혹적인 카자",
				[134797] = "해변 그늘게",
				[139404] = "고위 사제 마사스",
				[140428] = "협곡도약자",
				[95056] = "파멸바퀴",
				[128584] = "버그수스",
				[134798] = "심연 엉금게",
				[139405] = "파도인도자 세제스안",
				[140429] = "재빠른 급류폴짝이",
				[153226] = "강철 노래꾼 프레자",
				[134799] = "심연집게",
				[139406] = "핏빛비늘 하산",
				[136335] = "격노한 크롤러스크",
				[103247] = "울타녹스",
				[108366] = "기억 저편의 히포그리프",
				[54319] = "마그리아",
				[50352] = "쿠나스",
				[136336] = "스콜폭스",
				[80725] = "유황손아귀",
				[93778] = "빛나는 꽃",
				[134801] = "깨진 껍질 거북",
				[122955] = "대사 테릭",
				[145039] = "눈추적자",
				[134802] = "칼날등껍질 거북",
				[108879] = "휴몽그리스",
				[136338] = "시로카르",
				[136850] = "무쇠가죽 듈란",
				[139410] = "조용한 칼날의 비스즈",
				[132244] = "키보쿠",
				[136851] = "누루 엠버브레이드",
				[83542] = "숀 화이트시",
				[134804] = "영겁의 룬껍질거북",
				[54320] = "반탈로스",
				[136340] = "유물사냥꾼 하자아크",
				[72537] = "나뭇잎예언자 쿠리",
				[109648] = "의술사 아옳옳옳",
				[134293] = "아제라이트가 주입된 화산바위",
				[134805] = "떠도는 거대 거북",
				[139412] = "가샤스즈",
				[135829] = "먼지바람",
				[140436] = "킁킁발굽",
				[136853] = "소머리 전쟁수염",
				[134294] = "격노한 물의 정령",
				[134806] = "피절단거북",
				[139413] = "진창매복 오아시스예언자",
				[135830] = "강풍분노",
				[140437] = "느린 올로",
				[136854] = "바룬 플린트후프",
				[149651] = "깜장발",
				[134807] = "고대 가시갑옷",
				[139414] = "늪 사제 바스즈",
				[78169] = "구름예언자 데이버",
				[140438] = "늙은 긴이빨",
				[136855] = "녹아내린 보르도",
				[149652] = "아가테 웜우드",
				[134296] = "루실레",
				[54321] = "솔릭스",
				[50354] = "하바크",
				[140439] = "사향몸통 무리지도자",
				[136856] = "잿불뿔",
				[149653] = "육식 덩굴손",
				[138392] = "보노",
				[139416] = "볼샤스",
				[140440] = "뿔난 핏빛털",
				[115537] = "로르탈륨",
				[95318] = "페렉스",
				[134298] = "아제라이트가 주입된 정령",
				[151702] = "파올 폰드웨이더",
				[135834] = "썩은구름",
				[136346] = "선장 스테프 \"골수\" 쿠인",
				[136858] = "잔리",
				[149655] = "크로즈 블러드레이지",
				[139418] = "부패한 자",
				[136859] = "붉은머리",
				[149656] = "험악뿔",
				[139419] = "대점쟁이 아사이자",
				[50355] = "카흐티르",
				[132253] = "지아라크",
				[136860] = "추적자 부카",
				[50739] = "가르로크",
				[139420] = "늪 수호자 바스자쉬",
				[135837] = "소용돌이 부관",
				[152729] = "달의 여사제 리아라",
				[136861] = "황혼추적자 쿨리",
				[149658] = "그림자발톱",
				[139421] = "이끼비늘 게카즈",
				[108885] = "아이기르 파도파괴자",
				[149147] = "알 도둑 느찰라",
				[149659] = "오웰 스티븐슨",
				[82268] = "암흑스승 고비드",
				[136863] = "위대한 모타",
				[149660] = "깜장발",
				[100184] = "선원의 악몽",
				[131233] = "레이즈",
				[50356] = "칼날의 크롤",
				[148637] = "어둠사냥꾼 볼트리스",
				[136864] = "공포의 우구우",
				[149661] = "크로즈 블러드레이지",
				[130897] = "대장 레이저스파인",
				[136865] = "모래약탈자 우잔",
				[91227] = "핏빛 달의 잔재",
				[99929] = "바다떠돌이",
				[135842] = "군주 프루자안",
				[92763] = "이름 없는 왕",
				[97370] = "장군 볼로스",
				[135843] = "군주 무달",
				[140450] = "눈먼 두누",
				[149664] = "오웰 스티븐슨",
				[54324] = "화염발이",
				[92508] = "어스름갈퀴",
				[152736] = "수호자 탄닌",
				[149665] = "비늘마귀",
				[130643] = "뒤틀린 레잔의 자식",
				[77664] = "아르코",
				[135845] = "군주 카메트",
				[140452] = "잠자는 창뿔",
				[151202] = "부정한 현신",
				[140453] = "나무털 무리지도자",
				[101467] = "거북신",
				[130644] = "칼니악어",
				[134823] = "깨지지 않는 수정가시",
				[139430] = "영원한 사냥개 잘리즈",
				[140454] = "늙은 땋은머리",
				[155811] = "사령관 민제라",
				[50358] = "고장난 선리버 피조물",
				[136872] = "우프 브레인배셔",
				[139432] = "루시",
				[136873] = "타액사수",
				[154277] = "Test Creature",
				[83553] = "인샤타르",
				[88672] = "사냥꾼 발라",
				[136874] = "봉크",
				[93279] = "용서받지 못한 크리스카르",
				[97630] = "영혼곯이",
				[122456] = "공허아귀",
				[151719] = "심연의 목소리",
				[148648] = "무리주인 스위프트애로우",
				[140970] = "바위파열자",
				[91232] = "지휘관 크라그고스",
				[120665] = "군사령관 질리어스",
				[135852] = "아크타르",
				[136876] = "공포의 어윽",
				[126040] = "푸실라",
				[122457] = "암흑소환사",
				[136877] = "바바 구파",
				[116059] = "제왕 구름날개",
				[142508] = "나뭇가지군주 알드루스",
				[72294] = "잿불아귀",
				[136878] = "머리상모",
				[139438] = "영혼인도자 토간",
				[111197] = "아낙스",
				[136879] = "용암포식자 마부투",
				[116316] = "지룩스",
				[139439] = "황혼결속자 주운",
				[140975] = "어린위장",
				[77926] = "불세로스",
				[111454] = "베스트릭스",
				[146607] = "옴거 둠보우",
				[143536] = "대장군 볼라스",
				[72808] = "차보카",
				[137906] = "주입된 기반암",
				[143025] = "얼라이언스 여마술사",
				[131252] = "메리아나이",
				[148144] = "크로즈 블러드레이지",
				[70249] = "집중하는 눈",
				[140978] = "파멸땅굴",
				[133812] = "잔시브",
				[139443] = "척추술사 쿤타이",
				[117086] = "잿불불꽃",
				[117342] = "지옥사냥개",
				[93028] = "드리스 바일",
				[139444] = "강령군주 지안",
				[110944] = "수호자 토르엘",
				[107105] = "무리어미 리작스",
				[107617] = "늙은 불곰",
				[146611] = "튼튼팔 존",
				[139445] = "투마트",
				[92517] = "고요한 크렐",
				[136886] = "깃발운반자 코랄",
				[97380] = "댓개비",
				[132280] = "꽉꽉이",
				[140982] = "얼음파괴자",
				[152756] = "단도이빨 공포광치",
				[93030] = "무쇠가지",
				[97381] = "빽빽이",
				[97637] = "투견 바락스",
				[69996] = "하늘발톱 쿠라이",
				[136889] = "칼날소환사 투크",
				[117089] = "심문관 칠베인",
				[136890] = "무쇠 오르카스",
				[138938] = "바다파괴자 스콜로스",
				[69997] = "프로제니투스",
				[140474] = "심연의 신봉자",
				[136891] = "흉터 입은 엄니분쇄자",
				[80235] = "구룬",
				[140987] = "탐욕의 살점융해자",
				[130143] = "가시뭉치",
				[90217] = "퇴위된 노르만티스",
				[69998] = "고다",
				[140988] = "강철파쇄",
				[83819] = "벽돌집",
				[148155] = "머크럭",
				[97384] = "세가세디",
				[98408] = "지옥 감독관 머드럼프",
				[69999] = "괴물신 라무크",
				[103271] = "크락사",
				[146109] = "밤빛깔 돌진엘크",
				[138431] = "해일여제 나줄라",
				[120675] = "안티나",
				[50364] = "학살자 날라크",
				[152764] = "산화된 갈취짐승",
				[140991] = "골수천공",
				[130401] = "바시커르",
				[138432] = "해일여제 네사",
				[110438] = "공성전문가 에이드린",
				[155836] = "사술사 니타라",
				[139968] = "타락한 파도돌고래",
				[136385] = "아주레토스",
				[140992] = "시체파열자",
				[91243] = "토가르 고어피스트",
				[146111] = "20 점짜리",
				[128610] = "슐 나그루스의 아귀",
				[117093] = "지옥소환사 자르토크",
				[146112] = "검은털 거수",
				[155838] = "여주술사 바지나",
				[70001] = "척추파쇄자 우루",
				[111463] = "부르빈켈",
				[146113] = "천둥발굽",
				[108136] = "근육덩어리",
				[72049] = "학포식자",
				[140995] = "폐허추적자",
				[97387] = "마나 흡입자",
				[146114] = "쇄도의 바람",
				[138436] = "군주 갈퀴지느러미",
				[138948] = "우까까꾸",
				[155840] = "전쟁군주 잘자르",
				[70002] = "루반",
				[107113] = "보르탁스",
				[140996] = "심연천공",
				[138437] = "침략자 스제리스",
				[155841] = "그림자술사 아티사",
				[117095] = "공포칼날 파멸자",
				[136390] = "거대한 알",
				[140997] = "추방자 세베루스",
				[97388] = "줄로락스",
				[138438] = "파도약탈자 강철송곳니",
				[127333] = "미늘가시 여왕",
				[148676] = "짐마차 지휘관 베로니카",
				[103787] = "베이컨리스크",
				[138439] = "뱀여왕 발라",
				[155331] = "아제라이트 거수",
				[117096] = "물약의 달인 글룹",
				[76914] = "서리엄니",
				[138440] = "여군주 아사나",
				[155332] = "빛나는 아제라이트보석 수정등",
				[143559] = "최고사령관 트렘블레이드",
				[136393] = "혈날개 뼈다귀청소부",
				[138441] = "심연의 여가수",
				[124775] = "사령관 엔닥시스",
				[143560] = "작전사령관 가브리엘",
				[80242] = "한기송곳니",
				[109163] = "선장 다르건",
				[97390] = "도둑질하는 건달",
				[138442] = "파도돌격병",
				[139466] = "코발트 바위경비병",
				[138443] = "비늘경비병 불레스",
				[120681] = "지옥 절멸자",
				[139467] = "화강암주먹 킨수",
				[126056] = "토템 제작자 자쉬가",
				[138444] = "장군 베스파라크",
				[139468] = "척추절단자 쿠콘",
				[139980] = "파도울음 타자",
				[74613] = "무리어미 리그아크",
				[138445] = "공작 스줄",
				[139469] = "천둥의 주산",
				[109677] = "수석 회계사 자브릴",
				[138446] = "심해소환사 젤리사",
				[139470] = "용 조련사 시쇼",
				[138447] = "여전사 살라리아",
				[139471] = "육체파괴자 부간",
				[76918] = "원시술사 멀오그",
				[106351] = "기술병 로테어",
				[139472] = "바위군주 킨쇼",
				[106863] = "되살아난 바다수염",
				[78710] = "승리의 카라조스",
				[133842] = "전쟁삼엽충 카키티스",
				[87668] = "관찰자 오루모",
				[139473] = "바위 기계공 누신",
				[88436] = "수호자 파르토스",
				[133843] = "일등항해사 낭만부리",
				[139474] = "대지소환사 코르신",
				[138963] = "둥지 어미 아카다",
				[139475] = "비취형성 뼈다귀싸움꾼",
				[153296] = "폭풍혓바닥 샬란알리",
				[127084] = "사령관 텍스라즈",
				[139988] = "모래송곳니",
				[153297] = "REUSE",
				[146131] = "잠복자 바르토크",
				[120686] = "일리스틴드리아",
				[117103] = "지옥소환사 젤타이",
				[153298] = "REUSE",
				[127341] = "영원히 타오르는 파멸인도자",
				[153299] = "뼈파괴자 스준",
				[112497] = "순백의 마이아",
				[153300] = "강철의 조코",
				[97653] = "타우르슨",
				[98421] = "코트르 본디르",
				[153301] = "쉬라케스 별길잡이",
				[148695] = "의사 라제인",
				[153302] = "빙하 마법사 지엘라",
				[110451] = "악몽 수정",
				[86137] = "태양발톱",
				[78715] = "학살의 여제 시크티스",
				[111731] = "카르탁스",
				[54338] = "안트리스",
				[58817] = "라오페의 영혼",
				[50883] = "질주발굽",
				[136413] = "지배자 사이라원",
				[153305] = "잔지르 야만전사",
				[146139] = "금빛가시",
				[146651] = "운무사 니엔",
				[112756] = "소랄루스",
				[132319] = "증오송곳니 어미",
				[129904] = "어미 솜꼬리토끼",
				[146140] = "가시도저",
				[139486] = "하늘틈새",
				[152795] = "모래집게 돌딱지",
				[153307] = "풀려난 비전마귀",
				[79485] = "갈퀴사제 조르크라",
				[112757] = "마법학자 바일사",
				[153308] = "아즈샤라의 격분",
				[127090] = "제독 렐바르",
				[107127] = "브롤고스",
				[153309] = "천둥의 화살 알자나",
				[146143] = "칼가시",
				[112758] = "감사관 에시엘",
				[153310] = "얼음의 창 칼리나",
				[153311] = "뱀갈퀴 아잔즈",
				[103801] = "아르스파엘",
				[134884] = "라그나",
				[112759] = "아즈자타르",
				[132837] = "해변거인",
				[70530] = "라샤",
				[112760] = "의지파괴자 볼샥스",
				[152290] = "한깊가오리",
				[141029] = "발로뻥",
				[152291] = "심해가오리",
				[153315] = "엘다나르",
				[138984] = "흉터비늘",
				[122999] = "가르조스",
				[148198] = "정찰대장 그리즐놉",
				[70276] = "폭풍예언자 노쿠",
				[138473] = "스티지아",
				[138985] = "늙은 굶그옳",
				[85121] = "여군주 템테사",
				[154342] = "포획꾼 기계거미",
				[138474] = "엄브랄리온",
				[138986] = "수색자 보글",
				[82050] = "바라샤",
				[133356] = "템페스트리아",
				[138475] = "타이런티온",
				[138987] = "흙지느러미 대점쟁이",
				[136428] = "어둠의 기록가",
				[125816] = "하늘의 여왕",
				[58949] = "도살자 바이진",
				[51015] = "미끈거죽",
				[138988] = "뽀글눈알",
				[127096] = "모두를 보는 자 자나리안",
				[91009] = "퓨트레타르",
				[95872] = "해골모자",
				[138989] = "짭짤지느러미",
				[93057] = "그란노크",
				[138990] = "눈먼 우르글",
				[138479] = "흑요석 대군주",
				[100224] = "브리쿨 대지여전사 영혼",
				[104831] = "자브릭스",
				[129657] = "여왕의 검 자아마르",
				[141039] = "얼음 낫",
				[134897] = "경멸받은 다그러스",
				[69768] = "잔달라 전투정찰병",
				[136945] = "코르버스",
				[138481] = "크로미투스",
				[138993] = "걸락",
				[138482] = "연금술사 칼루리악",
				[98178] = "아랫바위",
				[69769] = "잔달라 전쟁인도자",
				[135923] = "가즈란의 사냥개",
				[107136] = "사냥개조련사 스트록시스",
				[138483] = "흑요석 괴물",
				[138995] = "씨앗지기 운간",
				[135924] = "타오르는 격노",
				[141043] = "잔인한 자칼라",
				[138484] = "흑요석 예언자",
				[138996] = "대지예언자 주와",
				[82311] = "불타는 차르",
				[149746] = "녹슨 메카거미",
				[138485] = "실험가 누조리악",
				[138997] = "광기의 그르렁채찍",
				[135926] = "이글심장",
				[129660] = "고대 방어구",
				[138486] = "알루리악",
				[134903] = "흡혈 공포 거미",
				[138487] = "흑요석 날개 분리병",
				[138999] = "늙은 오르돌",
				[147701] = "참수자 목소",
				[84872] = "복수심에 불타는 오스키라",
				[109954] = "마법학자 패드리스",
				[139000] = "늙은 유르",
				[135929] = "화염남작 블레이즈할로우",
				[135930] = "라바로크",
				[90248] = "퇴위된 노르만티스",
				[135931] = "잿빛돌",
				[103045] = "역병아귀",
				[82826] = "광분로봇 T-300 시리즈 마크 II",
				[100230] = "\"명사수\" 아르니",
				[96647] = "야수살육자 얼노크",
				[125824] = "카자두움",
				[133373] = "되살아난 작스텝",
				[134909] = "딸깍거리는 물레그물 거미",
				[86410] = "실드로스",
				[91529] = "길마르 아이언피스트",
				[134910] = "흐린빛그물 거미",
				[135934] = "군주 인신디바르",
				[80524] = "감독관 블러드메인",
				[84875] = "고대 불지옥",
				[109957] = "망치 이셀",
				[97928] = "길든 산호등",
				[134911] = "어둠굴 과부거미",
				[147708] = "애스리쿠스 나라신",
				[135935] = "군주 마그마르",
				[78733] = "전쟁마법사 바르골",
				[137983] = "부제독 헤인스워스",
				[100232] = "라이엘 돈드리프터",
				[108678] = "샤르토스",
				[135936] = "군주 아마르잔",
				[149245] = "호드 대장",
				[109702] = "심해집게",
				[126338] = "분노군주 야레즈",
				[110726] = "카드래우스",
				[141056] = "파도 군주 마쿠나",
				[140545] = "여왕거미 플레어네이",
				[141057] = "파도 군주 보르샤스즈",
				[81038] = "푸른 화염의 겔고르",
				[94347] = "공포기수 코르티스",
				[135939] = "덩굴예언자 라타",
				[140546] = "여왕거미 빌틸락",
				[141058] = "파도 군주 스주니스",
				[124548] = "벳지",
				[151296] = "OOX-복수자/MG",
				[84110] = "코르살 소울고져",
				[129411] = "추방자 주나쉬",
				[140547] = "여왕거미 신드릭스",
				[141059] = "무식한 음산도끼눈",
				[146178] = "하늘가시",
				[126852] = "사냥꾼 크라보스",
				[90253] = "퇴위된 노르만티스",
				[123269] = "쿡",
				[140548] = "잿불송곳니 복병",
				[115847] = "아리아드네",
				[150786] = "기계식 거미전차",
				[140549] = "용암그물 포식자",
				[138502] = "나로비악 고룡술사",
				[98188] = "인내하는 자 에길",
				[123270] = "주방장 그루",
				[140550] = "화염딸깍이",
				[127877] = "긴송곳니",
				[138503] = "황혼의 감독관",
				[50766] = "셀레나",
				[138504] = "장군 다카리온",
				[139016] = "가시가죽",
				[63691] = "후오슈앙",
				[142088] = "휘리릭날개",
				[138505] = "진화한 무리감독관",
				[120712] = "라리시아",
				[139529] = "무클라이",
				[148231] = "공성파괴자 볼가르",
				[140553] = "여왕거미 슈자스즈",
				[138506] = "진홍비늘",
				[77715] = "망치이빨",
				[139530] = "대지세공 공성파괴자",
				[148744] = "양조달인 린",
				[145161] = "공성 기술자 크래클블룸",
				[138507] = "전쟁군주 울트리스",
				[120713] = "와글루르",
				[140555] = "화염 투견",
				[132877] = "축축비늘",
				[109708] = "하급 그렐 우두머리",
				[130439] = "애쉬메인",
				[138508] = "불굴의 소용돌이",
				[139020] = "난폭한 으르렁심연",
				[140556] = "연기사냥개",
				[83603] = "사냥꾼 블랙투스",
				[139021] = "피추적꾼",
				[100495] = "엄습하는 어둠",
				[140557] = "안면절단자",
				[132879] = "수정 거인",
				[146188] = "불길의 통솔자",
				[138510] = "황혼의 파멸소환사",
				[85907] = "벨소라",
				[140558] = "지옥불 공포",
				[138511] = "청금비늘",
				[151308] = "뽀각 스컬배쉬",
				[140559] = "화산개",
				[50768] = "컬니스 워터스트라이더",
				[138512] = "토리시오나",
				[139024] = "밤깃털",
				[140560] = "불꽃추적자",
				[127882] = "수집가 빅스",
				[115853] = "파멸덩굴손",
				[138513] = "바이란티온",
				[120716] = "공포예언자 세릴리스",
				[138514] = "아티오나",
				[77719] = "미명날개",
				[139538] = "벽파괴자 하비크",
				[82326] = "바룬",
				[95123] = "노파 그렐다",
				[138515] = "엔달리온",
				[120717] = "여군주 도미닉스",
				[139539] = "여제의 망치 타보크",
				[148753] = "프팅고",
				[93076] = "대장 아이언비어드",
				[50769] = "추방자 자이",
				[130443] = "둥지어미 크락시",
				[138516] = "황혼의 진화론자",
				[126860] = "창백한 카아라",
				[135958] = "공작석",
				[84887] = "벳시 붐바스켓",
				[134935] = "어미 비쉬스",
				[135959] = "우레정령 진동발",
				[103827] = "왕 모르갈라쉬",
				[134936] = "킬틸락",
				[135448] = "악취가 나는 골탄",
				[135960] = "군주 자그러크",
				[105619] = "사이릴린",
				[126862] = "피에 굶주린 바루우트",
				[127118] = "세계분열자 스쿠울",
				[90519] = "야생의 불꽃 신드랄",
				[148759] = "폭풍소환사 모르카",
				[126095] = "빌리스",
				[98198] = "루크두그",
				[132892] = "방정나뭇잎",
				[107924] = "어둠마귀 고문관",
				[84378] = "학살자 아크옥스",
				[84890] = "구린꽃",
				[126864] = "머핀 도둑 피즐",
				[127376] = "수석 연금술사 먼큘러스",
				[90777] = "대사제 이크잔",
				[91289] = "케일린 페일둠",
				[140061] = "회색털 소굴어미",
				[136990] = "저주받은 안칼리",
				[126865] = "감시자 타노스",
				[140062] = "공포철퇴",
				[136991] = "혈사냥꾼 다잘아이",
				[103575] = "산호초 군주 라즈히스",
				[107926] = "도살자 한느발",
				[139039] = "심연사냥꾼 에소",
				[140063] = "식인 박살아귀",
				[50772] = "에셜론",
				[138016] = "다록크",
				[139040] = "심연 점쟁이 우나니",
				[140064] = "피에 젖은 회색털",
				[141088] = "돌풍",
				[142112] = "한파의 코르그레쉬",
				[91803] = "파스니르",
				[139041] = "정령사 루슈",
				[96410] = "위풍당당한 늙은뿔 순록",
				[117141] = "말그라조스",
				[84893] = "피엄니",
				[122004] = "엄브라진",
				[134947] = "뻣뻣가시 무리여왕",
				[147744] = "호박집게",
				[140066] = "도끼발톱",
				[134948] = "수풀 추적거미",
				[148257] = "죽음경비대장 다니엘",
				[134949] = "점판땅거미",
				[151841] = "전령 버그톡",
				[134950] = "공포의 송곳니",
				[148259] = "죽음경비대장 딜라일라",
				[126101] = "황혼거죽 암호랑이",
				[126869] = "대장 파루크",
				[140070] = "추적자 핏내음",
				[94877] = "힘세고 강한 브로그룰",
				[92574] = "내장을 가르는 쓰로마",
				[122519] = "드레그마르 룬브랜드",
				[147750] = "대포 장인 굿윈",
				[140072] = "약탈자 공포걸음",
				[147751] = "산산파편",
				[140073] = "광기아귀",
				[122520] = "얼음주먹",
				[147240] = "히드라스",
				[152359] = "떼어미 진흙추적꾼",
				[86689] = "스니블",
				[147241] = "싸이클라러스",
				[140075] = "카누스",
				[93088] = "흉포발톱",
				[122521] = "해골도살자",
				[139564] = "낭만부리",
				[152361] = "떼아비 악독비늘",
				[79524] = "최면개구리",
				[151850] = "사령관 딜리크",
				[121242] = "꿀꺽아귀",
				[148779] = "빛벼림 기갑전투복",
				[153898] = "바다군주 아쿠아투스",
				[122522] = "얼음파괴자",
				[102303] = "사령관 스트라스마르",
				[127129] = "그로즈고어",
				[140079] = "밀림비명꾼",
				[132913] = "군도 거인",
				[141615] = "불타는 거수",
				[118172] = "군주 히드로니쿠스",
				[82085] = "바시오크",
				[140080] = "머리분쇄자",
				[141616] = "우레의 거수",
				[151854] = "죽음의수색꾼 로소크",
				[140081] = "왕 루까",
				[140593] = "잠 못 드는 공포",
				[109727] = "분쇄자 도르바쉬",
				[122524] = "피발굽",
				[140082] = "기브",
				[141618] = "물결치는 거수",
				[103841] = "그림자깃",
				[124572] = "화염술사 볼라알",
				[128923] = "샤키",
				[140083] = "천둥발 쿨라",
				[109728] = "거인",
				[154416] = "히스카리",
				[140084] = "박살주먹",
				[107169] = "호룩스",
				[141620] = "요동치는 거수",
				[129180] = "전쟁인도자 호지크",
				[148787] = "알라쉬아니르",
				[109729] = "격노",
				[118175] = "폭풍의 정령",
				[126621] = "뼈돌풍",
				[148276] = "파도결속자 마카",
				[107170] = "조룩스",
				[127901] = "헨리 브레이크워터",
				[138039] = "어둠 순찰자 클리아",
				[75434] = "어미 바람송곳니 늑대",
				[50138] = "카로마",
				[100516] = "굶주린 릴린",
				[84392] = "라고르 드리프트스토커",
				[84904] = "오라그로",
				[118176] = "천둥충격",
				[111010] = "사에퍼",
				[137529] = "배신당한 자 아르본",
				[75435] = "이그드렐",
				[112802] = "마르투라",
				[135994] = "군주 아미타이트",
				[72364] = "용암먹보 고르그악",
				[129950] = "발톱새",
				[90024] = "하사관 모르그락",
				[140090] = "아나타쉬",
				[148792] = "하늘선장 써모스파크",
				[131389] = "테레스",
				[135996] = "군주 콜슬레이트",
				[90281] = "대사제 이크잔",
				[140092] = "긴걸음사슴",
				[140093] = "솔먹이 새끼어미",
				[77741] = "라칸",
				[135999] = "헬리오도르",
				[147261] = "그라노크",
				[136000] = "베릴러스",
				[152892] = "녹슨 메카거미",
				[97449] = "뾰족털 망치발",
				[109990] = "잊혀진 닐라트리아",
				[127906] = "황혼전령 타루울",
				[128674] = "탐욕의 거트거트",
				[128930] = "로흔코르",
				[151870] = "모래성",
				[140097] = "거대 먼지배",
				[129954] = "가즈랄카",
				[126115] = "벤오른",
				[140098] = "흉포한 흉터가죽",
				[127651] = "꼭집게",
				[124580] = "동굴 거북",
				[140099] = "시끄러운 천둥주둥이",
				[138564] = "크슈운",
				[139588] = "막을 수 없는 고르쿨",
				[94636] = "음험한 칼라지우스",
				[119718] = "임프 어미 브루바",
				[79024] = "전투대장 블러그톨",
				[138565] = "미리스",
				[139589] = "황천술사 욱크",
				[88494] = "군단 선봉대원",
				[84911] = "데미도스",
				[146244] = "찌르는 마귀",
				[138566] = "닐소즈",
				[126885] = "엄브랄리스",
				[140102] = "칼니멧돼지",
				[70323] = "크락카논",
				[86959] = "카로쉬 블랙윈드",
				[146245] = "파닥날개",
				[138567] = "응징자 샤스호스",
				[139591] = "혓바닥천지 오론",
				[92590] = "후크",
				[84912] = "가시가름쇠",
				[50782] = "사르낙",
				[146246] = "독벌 오빅스",
				[138568] = "정복사 슈크슈군",
				[139592] = "역술사 고로",
				[146247] = "백색죽음",
				[138569] = "선구자 보르직스",
				[108715] = "늙은 얼리",
				[92591] = "싱커",
				[138570] = "전령 라자퀴",
				[126887] = "아탁쏜",
				[139594] = "투사 고르",
				[136011] = "피바위",
				[127911] = "공허칼날 제다아트",
				[83634] = "정찰병 포크하르",
				[128935] = "말라킬리",
				[139595] = "고위 경비병 마카그",
				[136012] = "요지부동 산덩치",
				[145226] = "스트로프니르",
				[50783] = "살리인 전투정찰병",
				[138572] = "장군 우보쉬",
				[139596] = "점쟁이 고르도",
				[78260] = "대왕 수액괴물",
				[138573] = "장군 누가스",
				[139597] = "용암주먹 오그고그",
				[140109] = "무장한 죽음갈퀴",
				[145228] = "발리아",
				[138574] = "장군 에르줄",
				[126889] = "비운의 소롤리스",
				[139598] = "척추파쇄자 바하하",
				[111021] = "수액 면상",
				[145229] = "스로프니르",
				[138575] = "장군 슐아콸",
				[116652] = "보물 고블린",
				[139599] = "검투사 오르투그",
				[140111] = "독창 스칼딕스",
				[148813] = "토마스 반더그리프",
				[129961] = "아탈줄 괴수",
				[102064] = "토렌티우스",
				[98225] = "파스니르",
				[131410] = "거대 맹독비늘",
				[152397] = "오로누",
				[90803] = "지옥불정령 군주",
				[137553] = "장군 크라탁스",
				[128426] = "거트립",
				[139601] = "고위주술사 모르그",
				[140113] = "맹독채찍",
				[145232] = "스쿨리",
				[133971] = "드루켄구",
				[126635] = "혈사제 자크라르",
				[139602] = "막을 수 없는 스커르",
				[140114] = "챙강발톱",
				[82614] = "몰트노마",
				[79543] = "쉬르지르",
				[84406] = "만드라코",
				[144722] = "토고스 크루얼암",
				[97203] = "텐파크 플레임토템",
				[80312] = "약탈자 그루투쉬",
				[76473] = "어미 아라네애",
				[126637] = "칸다크",
				[78265] = "거대한 뼈발톱 미늘벌레",
				[82616] = "성큼턱",
				[146773] = "일등항해사 말론",
				[116912] = "모아그 투사",
				[141143] = "수녀 앱신테",
				[93622] = "모티퍼러스",
				[82617] = "시체탐식자 회색엄니",
				[149334] = "지층 아제라이트",
				[83385] = "공허현자 카룰그",
				[128686] = "덫사냥꾼 카미드",
				[116657] = "분노한 바다 거인",
				[92599] = "피추적자 우두머리",
				[149335] = "격동의 아제라이트",
				[149847] = "광기 어린 트로그",
				[82362] = "모르바 소울트위스터",
				[82618] = "토르고로스",
				[149336] = "현무암 아제라이트",
				[103605] = "장막수색꾼",
				[142682] = "마른나무껍질 잘라스",
				[140123] = "무기달인 할루",
				[149337] = "응축된 아제라이트",
				[50787] = "비늘의 아르네스",
				[154968] = "무장한 금고봇",
				[126896] = "혼돈의 전령",
				[149338] = "불안정한 아제라이트",
				[142684] = "코보르크",
				[149339] = "스며든 아제라이트",
				[78269] = "옹이턱",
				[82620] = "고라말의 아들",
				[82876] = "최고사령관 트렘블레이드",
				[142686] = "뒤뚱발이",
				[92090] = "공포의 대상 쉬아마",
				[129969] = "혈마녀 이신나",
				[126898] = "사부울",
				[132450] = "구린장화",
				[82877] = "대장군 볼라스",
				[91579] = "파멸의 군주 카즈로크",
				[142688] = "다벨 몬트로즈",
				[152414] = "장로 우누",
				[84925] = "병참장교 허샤크",
				[93371] = "모르드빅비오른",
				[126899] = "제드힌 우승자 보루스크",
				[152415] = "눈이 먼 알가",
				[82878] = "작전사령관 가브리엘",
				[107960] = "알루바논",
				[142690] = "싱어",
				[152416] = "선지자 오마킬",
				[84926] = "불타는 힘",
				[93372] = "분노한 대지하수인",
				[126900] = "교관 타라흐나",
				[148322] = "블링키 기즈모스파크",
				[137061] = "바람조련사 술루즈",
				[141668] = "미즈라엘의 메아리",
				[142692] = "학살자 니마르",
				[137062] = "혈사냥꾼 아칼",
				[73666] = "화염의 대제사장",
				[82880] = "작전사령관 카쉬 스톰포지",
				[92606] = "실리사",
				[109498] = "잰더",
				[89016] = "라빈드라스",
				[132182] = "회계 감사관 돌프",
				[155660] = "General Purpose Bunny JMF (Look 2 - Flying, Infinite AOI)",
				[150342] = "대지파괴자 걸록",
				[154949] = "잔지르 야만전사",
				[127844] = "걸신들린 예티",
				[147955] = "대지보주",
				[152671] = "웨케마라",
				[84854] = "미끄러운 진흙괴물",
				[152360] = "우두머리 맹독이빨",
				[121016] = "아퀘욱스",
				[84417] = "무타펜",
				[122958] = "물집아귀",
				[149351] = "망간광",
				[144644] = "수렁 바다달팽이",
				[133995] = "데인저펄",
				[151688] = "멜론파괴꾼",
				[77763] = "저격수 키지",
				[151862] = "영혼방랑자 페살",
				[136043] = "염수정령",
				[151690] = "그슬이빨",
				[82882] = "장군 에이브드",
				[137579] = "속박 풀린 아제라이트",
				[154701] = "게걸스러운 기계포식자",
				[151845] = "부관 느오트",
				[116666] = "심연의 잿불",
				[103785] = "배불리 먹은 곰",
				[136044] = "맹독팽창",
				[151672] = "메카란툴라",
				[109500] = "자크",
				[50791] = "벼리는 자 실트리스",
				[73157] = "바위 이끼",
				[117090] = "화염조각사 조로군",
				[139769] = "이등항해사 바나비",
				[151884] = "광란의 버섯",
				[136045] = "분쇄파도",
				[148842] = "공성트론",
				[86978] = "눈길",
				[87234] = "브루타그 그림블레이드",
				[145112] = "자그 브로큰아이",
				[152569] = "광기 어린 트로그",
				[151689] = "도약꾼 할퀴발톱",
				[84805] = "바위눈길",
				[136046] = "군주 어비시안",
				[148723] = "저격수 매독",
				[109501] = "다크풀",
				[138308] = "우끼아끼",
				[73158] = "에메랄드 학",
				[70003] = "몰소르",
				[90050] = "수정수염",
				[144946] = "숲군주 이부스",
				[136047] = "얼음심장",
				[148295] = "부패한 이부스",
				[149356] = "격노한 아제라이트보석 수정등",
				[147664] = "짐카가",
				[79725] = "대장 아이언비어드",
				[105739] = "사나아르",
				[116668] = "영혼구속자 모르텍",
				[151916] = "제그라 샤프액스",
				[136048] = "군주 메르큐리어스",
				[145063] = "폭풍부리",
				[97209] = "에라키스",
				[145242] = "비늘마귀",
				[140273] = "룬발굽 소굴지기",
				[147951] = "알칼리니우스",
				[98241] = "리라스 문페더",
				[151917] = "타르알 본스피터",
				[136049] = "알게논",
				[86724] = "은둔자 창백가죽",
				[149358] = "거대한 아제라이트보석 수정등",
				[126815] = "영혼이 뒤틀린 흉물",
				[134002] = "지하군주 제르직스",
				[136862] = "올고",
				[146110] = "차오름달",
				[151918] = "북녘의 라즈카",
				[136050] = "핏빛기류",
				[148103] = "공병 오데트",
				[149359] = "아제라이트 거수",
				[84838] = "독의 대가 볼터스크",
				[73160] = "무쇠가죽 강철뿔",
				[145041] = "날렵꼬리 추적자",
				[126907] = "전쟁북장이 주룰라",
				[86213] = "아쿠아릴",
				[82374] = "라이보쉬",
				[140658] = "뾰족털",
				[149360] = "덩치 큰 아제라이트",
				[152557] = "도전장교",
				[116158] = "탑의 무희",
				[128699] = "피불룩이",
				[145077] = "공포날개",
				[148147] = "오웰 스티븐슨",
				[140147] = "위대한 우르수",
				[140659] = "분노쿵쿵",
				[109504] = "분노아귀",
				[149873] = "스탠리",
				[73161] = "거대거북 분노등딱지",
				[149346] = "퍼진 아제라이트",
				[126908] = "다중인격의 줄탄",
				[147758] = "오누",
				[140148] = "광란의 회색털",
				[140660] = "거대뿔",
				[146134] = "날쌘돌이",
				[109653] = "거대한 마블럽",
				[116159] = "교활한 추종자",
				[145466] = "분쇄트론-2000",
				[116671] = "잿불이",
				[100864] = "코라카르",
				[92613] = "여사제 리자",
				[140661] = "골짜기천둥",
				[97220] = "아루",
				[148739] = "마법학자 크리스탈린",
				[149657] = "맛간깃털",
				[142709] = "야수기수 카마",
				[149512] = "그림자발톱",
				[140427] = "산악발굽 무리아비",
				[148494] = "모래결속사 소디르",
				[140662] = "늙은 거대털",
				[145269] = "반짝가시",
				[87239] = "크랄 데드아이",
				[144956] = "섬뜩이빨",
				[148674] = "역병 전문가 허버트",
				[152555] = "원로생명체 날라아다",
				[149352] = "영롱한 아제라이트보석 수정등",
				[132746] = "서리미늘 무리어미",
				[140663] = "산의 제왕 그럼",
				[141175] = "노래 여군주 다달리아",
				[126142] = "바지아타",
				[73163] = "황실 비단뱀",
				[148651] = "비대해진 고대정령",
				[126910] = "사령관 제스가",
				[70243] = "대의식술사 켈라다",
				[123464] = "자매 서브버시아",
				[136323] = "송곳니소환사 조레스",
				[145271] = "험악뿔",
				[76380] = "고룸",
				[83401] = "황천의 전령",
				[135997] = "군주 지르콘",
				[88951] = "추악발톱",
				[147435] = "텔라르 문스트라이크",
				[148343] = "공룡사냥꾼 와일드비어드",
				[147061] = "그럽",
				[145272] = "깜장발",
				[127300] = "공허 감시자 발수란",
				[147958] = "대지활성 굴절체",
				[138618] = "폭주 골렘",
				[108541] = "공포의 해적",
				[125951] = "흑요석 죽음수호자",
				[152553] = "심홍비늘",
				[86729] = "광포발굽",
				[108827] = "무덤의 한기 피욜랙",
				[136887] = "바늘갈기",
				[145040] = "영리한 로린",
				[80471] = "제나디안",
				[147321] = "맹독턱",
				[50823] = "포악 군",
				[140155] = "광포한 썩은발톱",
				[104523] = "샬라스아만",
				[145934] = "미치광이 아이반",
				[72909] = "무리인도자 구치",
				[152552] = "샤시라",
				[85250] = "석화된 화석나무",
				[126912] = "파멸의 스크리그",
				[98503] = "정복자 그릃븛굴",
				[140156] = "썩은아귀",
				[148717] = "심문관 에릭",
				[148264] = "공룡술사 다징고",
				[92495] = "영혼절개자",
				[150394] = "무장한 금고봇",
				[142716] = "인간수집가 로그",
				[139600] = "화산 같은 마루크",
				[146675] = "하트포드 스턴바흐",
				[140157] = "새끼포식자 썩은발톱",
				[101063] = "왕 포르갈라쉬",
				[149662] = "험악뿔",
				[148456] = "진타고",
				[85451] = "말고쉬 섀도우키퍼",
				[142419] = "우레의 거수",
				[126913] = "최후의 슬리쏜",
				[146942] = "최고사령관 퓨리",
				[140158] = "담즙에 젖은 썩은발톱",
				[148860] = "그리즈왈드",
				[149654] = "반짝가시",
				[120003] = "전쟁군주 다르자",
				[136817] = "감독관 강철주둥이",
				[146813] = "회색빛의 군터",
				[139135] = "심연의 아옳옳",
				[58474] = "피돌기",
				[140159] = "고름투성이 공포으르렁",
				[140671] = "난폭한 야생발톱",
				[145278] = "공룡술사 자쿠루",
				[149344] = "광란이 주입된 아제라이트",
				[73167] = "후오론",
				[139885] = "예언자 녹스티르",
				[86732] = "벨그루",
				[151933] = "고장난 야수로봇",
				[140160] = "분노의 끓는가죽",
				[148862] = "질리 운더렌치",
				[63977] = "바이락시스",
				[149886] = "스탠리",
				[138393] = "깨물끼끼",
				[148308] = "에릭 콰이엇피스트",
				[149343] = "광란이 주입된 아제라이트",
				[151934] = "포획꾼 기계거미",
				[140161] = "모래구덩이꾼",
				[140673] = "분노으르렁",
				[149241] = "얼라이언스 대장",
				[149887] = "스탠리",
				[77519] = "거인잡이",
				[146816] = "바튼 브릭햄 경",
				[135043] = "흉포한 톱니이빨",
				[69841] = "잔달라 전쟁인도자",
				[140162] = "증오의 와그작독침",
				[140674] = "깊은울음",
				[127939] = "영원의 토라스케",
				[145020] = "돌리자이트",
				[116166] = "구르그의 눈",
				[128707] = "서리바위",
				[135044] = "게걸스러운 분쇄아귀 악어",
				[121029] = "무리어미 닉스",
				[152448] = "오색 반짝껍질",
				[140675] = "무리어미 무고",
				[110024] = "타락자 말드레스",
				[77776] = "떠도는 구원자",
				[73169] = "오르도의 자쿠르",
				[94313] = "다니엘 \"폭탄광\" 보릭",
				[135045] = "척추똑딱",
				[69842] = "잔달라 전쟁인도자",
				[149355] = "변종 아제라이트보석 수정등",
				[140676] = "거대한 돌부리",
				[63978] = "크리촌",
				[90057] = "칼부리",
				[148550] = "짐마차 우두머리",
				[138629] = "성직자 드조사",
				[135046] = "엉금악어",
				[84431] = "교활한 그렐드록",
				[129476] = "불어오른 크롤러스크",
				[137704] = "대모 모라나",
				[69843] = "짜오초",
				[149349] = "석회화된 아제라이트",
				[73170] = "감시자 오수",
				[142725] = "끔찍한 원혼",
				[147332] = "바위결속자 스라베스",
				[94413] = "망치 이셀",
				[152548] = "비늘 여군주 그라티낙스",
				[147941] = "파도현자 클라리사",
				[149141] = "방화기 마크 V",
				[147845] = "사령관 드랄드",
				[132921] = "해일여제 세르아",
				[138631] = "길잡이 콰딤",
				[128965] = "구속된 우로쿠",
				[151940] = "트로그 삼촌",
				[92274] = "고통의 여왕 셀로라",
				[123189] = "전쟁인도자 모그라",
				[145286] = "모테가 블러드쉴드",
				[140774] = "얼어붙은 돌군주",
				[73171] = "검은 불꽃의 용사",
				[138632] = "수호자 아수다",
				[136799] = "절벽파괴자",
				[94414] = "키라니스 더스크위스퍼",
				[140168] = "늙은 가슴쾅",
				[140680] = "광포한 냉동뿔 웬디고",
				[145287] = "센진의 준조",
				[96323] = "아라크니스",
				[83409] = "오피스",
				[138633] = "수사 마트",
				[139145] = "블랙쏜",
				[147957] = "아제크리살리스",
				[140169] = "난폭한 모그카",
				[140681] = "게걸스러운 구루두",
				[149383] = "지즈 것섕크",
				[148679] = "비전술사 퀸트릴",
				[73172] = "바위군주 가이란",
				[138634] = "예언자 라피사",
				[77620] = "크로 플레쉬렌더",
				[131704] = "코아티",
				[140170] = "늙은 모카",
				[140682] = "빙하주먹",
				[145062] = "쉬샤린",
				[115914] = "육중한 토름",
				[152794] = "자수정 돌돌껍질",
				[138635] = "사령관 후산",
				[100302] = "퍽",
				[147849] = "비취섬광",
				[140171] = "안개털",
				[140683] = "부수는 자 어둠털",
				[148451] = "자동공성로봇 9000",
				[54318] = "안카",
				[73173] = "소작술사 우르두르",
				[138636] = "왕자 아바리",
				[85970] = "학살발톱",
				[139322] = "휘트니 \"철발톱\" 람세이",
				[111052] = "은빛 뱀",
				[140684] = "분쇄쿵쿵",
				[82899] = "고대의 검귀",
				[95440] = "트렘블레이드",
				[135838] = "오염바람",
				[138637] = "헤페트",
				[100303] = "제노비아",
				[140100] = "전쟁주둥이",
				[84435] = "핀치 아저씨",
				[140685] = "늙은뿔",
				[145292] = "알시안 비스트레스",
				[131717] = "생명갈취자 자욜린",
				[73174] = "화염의 대제사장",
				[138638] = "드자르",
				[140370] = "시체포식자",
				[77513] = "비탄에 잠긴 한기발굽",
				[102863] = "우걱턱",
				[139044] = "물결치유사 아샤",
				[123282] = "전쟁군주 모고쉬",
				[124362] = "쥬에",
				[99792] = "엘프 학살자",
				[138639] = "아센누",
				[108494] = "영혼마귀 다게르마",
				[147853] = "벽파괴자 하비크",
				[92626] = "죽음경비병 아담스",
				[140329] = "시체유린자 바일릭스",
				[138640] = "토러스",
				[136857] = "무리두목 운돌",
				[73175] = "잿불폭포",
				[77526] = "정찰병 고어시커",
				[139152] = "칼라 스머크",
				[147854] = "칼춤꾼 졸라크",
				[136838] = "야만전사 즈고르도",
				[134745] = "하늘조각사 크라킷",
				[134912] = "보라색 땅거미",
				[120012] = "드레사노스",
				[119629] = "군주 헬누라스",
				[50734] = "추적자 리시크",
				[96210] = "칼날의 크롤",
				[139346] = "영혼예언자 갈라니",
				[92627] = "렌드락",
				[128893] = "빈예티",
				[72775] = "부포",
				[126868] = "또렷한 의식의 투레크",
				[138830] = "별의 인도를 받는 트로바스트",
				[77527] = "으깨주먹",
				[139819] = "부사장 젠니 뉴콤",
				[131476] = "자유스",
				[111055] = "기괴한 역병 쥐",
				[139815] = "부사장 랙스 블라스템",
				[147857] = "대포전문가 아를린",
				[120013] = "공포의 추적자",
				[152464] = "어둠동굴 공포",
				[126451] = "아작집게",
				[139668] = "파도결속사 고르글",
				[121037] = "그로시르",
				[125388] = "배신당한 자 바가스",
				[140180] = "난폭핏물",
				[129995] = "에밀리 메이빌",
				[140769] = "황금광맥",
				[140339] = "계곡의 공포",
				[142739] = "기사대장 알드린",
				[77784] = "로마그 죠크러셔",
				[147858] = "배 없는 지미",
				[152465] = "바늘가시",
				[140692] = "피구렁이",
				[91093] = "지옥가시덩굴",
				[92604] = "용사 엘로디",
				[138477] = "갈퀴수호병 브리키스",
				[147860] = "토러스",
				[96212] = "코르다 토로스",
				[139669] = "주술사 가르믈",
				[140181] = "험준엄니",
				[140693] = "쉬익카라스",
				[84951] = "꿀꺽이빨",
				[133527] = "흉터 입은 쥬바",
				[105938] = "지옥날개",
				[77529] = "소각술사 야즈히라",
				[139025] = "달빛노래",
				[139670] = "모옳곡",
				[111057] = "쥐들의 왕",
				[140694] = "탐욕의 우걱턱",
				[87356] = "고대의 브록",
				[139593] = "문맹탈출 버크",
				[140768] = "태산파괴자 구우루",
				[75482] = "벨로스",
				[128973] = "성질 나쁜 워가블",
				[139671] = "상어학살자 머글룩",
				[140183] = "늙은 똥가죽",
				[140695] = "백색 공포의 송곳니",
				[140182] = "밀림지진 나뭇잎납작이",
				[135649] = "질풍발톱",
				[93654] = "스컬브락스",
				[138648] = "수의작공 시그리드",
				[126926] = "맹독턱",
				[123087] = "알아바스",
				[101077] = "세칸",
				[140696] = "공포의 나주",
				[147862] = "아센누",
				[74971] = "화염격노 거인",
				[68317] = "메이비스 함즈",
				[138649] = "벌프 스톰쇼어",
				[128974] = "여왕 츠시키크",
				[139673] = "이빨많록",
				[92631] = "어둠 순찰자 제스",
				[140697] = "썩은 독뱀",
				[140389] = "굴지기 키닉스",
				[133531] = "주바",
				[118993] = "공포눈",
				[89816] = "무쇠 지느러미 골자",
				[78144] = "거인사냥꾼 킴라",
				[139674] = "심연비늘",
				[140088] = "돌진사슴 돌뿔",
				[135648] = "평원거죽 호랑이",
				[138994] = "팀버피스트",
				[90244] = "아르카벨루스",
				[128497] = "궤변론자 바지아니",
				[138651] = "실베리아 리프콜러",
				[136841] = "추악한 쑤준",
				[139675] = "심연수색자",
				[97589] = "썩은 알",
				[68318] = "달란 나이트브레이커",
				[80190] = "그루크",
				[150937] = "바다모래톱",
				[138652] = "파도저주 여군주",
				[51059] = "블랙후프",
				[131687] = "탐바노",
				[147866] = "피의 탐식자",
				[139022] = "수호자 쏜퍼",
				[142301] = "베노마루스",
				[107477] = "기계다람쥐",
				[134924] = "Taloc IGC",
				[145308] = "선임하사 스틸팽",
				[138653] = "부패하는 선체의 호스비르",
				[75071] = "대모 옴라",
				[139677] = "심연소환사",
				[92633] = "암살자 휴위",
				[68319] = "디샤 피어워든",
				[84955] = "포자먹보 지아스카",
				[93401] = "약탈자 우르게브",
				[125479] = "타르 살포자",
				[138654] = "누더기 돛의 베스타르",
				[138998] = "두껍가죽",
				[139678] = "여울방랑자",
				[74206] = "살육아귀",
				[111573] = "굶주리는 코수모스",
				[91098] = "지옥불꽃",
				[120019] = "희미한 자 률",
				[134048] = "부쿠바",
				[146845] = "톱니의 자레드",
				[83643] = "말로크 스톤선더",
				[147869] = "수의작공 시그리드",
				[92634] = "연금술사 페레즈",
				[68320] = "그늘의 우분티",
				[136051] = "파도머스",
				[122062] = "카뮬 클라우드송",
				[134049] = "이상한 알",
				[140425] = "매운발",
				[147870] = "파도저주 여군주",
				[139680] = "어두컴컴 사냥꾼",
				[123347] = "대지술사 말란",
				[124582] = "협곡사냥꾼",
				[135645] = "우두머리 무리어미",
				[120020] = "에르두발",
				[150430] = "너두호그",
				[146847] = "소환사 라니엘라",
				[82058] = "깊은뿌리",
				[139681] = "싸늘지느러미",
				[109015] = "라제르타",
				[68321] = "카르 워메이커",
				[140112] = "바위채찍",
				[133539] = "로쿠노",
				[126419] = "나로우아",
				[146848] = "으스스한 융합체",
				[139389] = "강철비늘 볼샤시스",
				[147872] = "여왕거미 빌틸락",
				[138851] = "영혼 사냥꾼",
				[120021] = "물풀주먹",
				[91100] = "브로고조그",
				[145825] = "짐마차 우두머리",
				[99802] = "아르스파엘",
				[146849] = "영혼의 대가 로웨나",
				[136003] = "그레블러스",
				[147873] = "여왕거미 신드릭스",
				[92636] = "밤의 유령",
				[68322] = "무에르타",
				[127700] = "편대 사령관 비샥스",
				[50805] = "옴니스 그린록",
				[135644] = "여명추적자",
				[146850] = "거장 울리치",
				[139227] = "간수 운다리우스",
				[135589] = "괴저 흉물",
				[50347] = "암흑의 인도자 카르",
				[86750] = "칠흑발톱",
				[137025] = "무리어미",
				[120022] = "심연아귀",
				[121073] = "광기 어린 서큐버스",
				[140862] = "포세이큰 역병 수레",
				[83591] = "투라아카",
				[121046] = "수사 배다틴",
				[132007] = "광포폭풍",
				[144955] = "피폭식자 잘지",
				[147928] = "대지파편",
				[120998] = "플루르로크르",
				[153304] = "운다나 프로스트바브",
				[146852] = "노예사냥꾼 콘라드",
				[122838] = "흑마술사 보룬",
				[130138] = "네버모어",
				[138509] = "역술사 울루라",
				[139042] = "창의 달인 카샤이",
				[82912] = "회색아귀",
				[80057] = "영혼송곳니",
				[83680] = "척후병 듀레사",
				[146853] = "파헤쳐진 케폴키스",
				[110378] = "냉혈의 드루곤",
				[147877] = "거장 울리치",
				[124722] = "준장 칼호운",
				[134932] = "썩은그물 무리여왕",
				[134106] = "벌목손아귀 파수병",
				[50806] = "애꾸눈 몰도",
				[119000] = "공포수염",
				[146854] = "스텔라 다크포우",
				[108251] = "덩어리불의 지배자 셀리아",
				[147878] = "파헤쳐진 케폴키스",
				[148390] = "제시벨 문쉴드",
				[144855] = "연금술사 제로드",
				[86520] = "난폭발굽",
				[88072] = "대마법사 테카르",
				[124375] = "속이 꽉 찬 사우로리스크",
				[91871] = "파괴자 아르고쉬",
				[70096] = "전쟁신 도카",
				[116953] = "타락한 뼈파괴자",
				[139431] = "무덤 수호자",
				[140799] = "급류추적자",
				[148477] = "야수군주 드라카라",
				[72045] = "첼론",
				[92423] = "테리시아",
				[134571] = "하늘소환사 테스크리스",
				[77795] = "울림의 메아리",
				[147880] = "영혼수색자 다르걸프",
				[138307] = "와장창면상",
				[127703] = "파멸술사 수프락스",
				[141226] = "망치의 헤이골",
				[139018] = "잠든 산",
				[138667] = "파멸의 흉물",
				[75492] = "맹독그늘",
				[138389] = "스마샤",
				[147881] = "선견자 우불드",
				[148393] = "고대 수호정령",
				[153000] = "불꽃여왕 전파거미",
				[153314] = "알드란티스",
				[139415] = "뱀비늘",
				[142251] = "요구르사",
				[140089] = "늙은 황혼발굽",
				[90081] = "암흑의 소환사 렌드크라",
				[104484] = "선박파괴자 올로크",
				[122899] = "데스 메탈 기사",
				[127704] = "영혼치유사 비덱스",
				[92609] = "사냥꾼 잭",
				[50086] = "비열한 타르부스",
				[77561] = "글룸 박사",
				[83683] = "만드라고라스터",
				[153313] = "정신지배자 비즈올고",
				[129181] = "바텐더 빌",
				[142437] = "두개골절단자",
				[89846] = "대장 볼로렌",
				[80868] = "먹보",
				[126169] = "밀림의 왕 룬투",
				[108881] = "거북",
				[140851] = "크라그",
				[50789] = "예언자 네소스",
				[139694] = "냉혹껍질",
				[111069] = "사에퍼",
				[127705] = "대모 로줄라",
				[72048] = "해골엄니",
				[84196] = "거미줄에 뒤덮인 병사",
				[83428] = "바람소환사 코라스트",
				[91874] = "칼날돌풍",
				[134946] = "거대한 수렵거미",
				[139695] = "잽잽집게",
				[86577] = "홀그",
				[140756] = "샘터의 수호자",
				[84833] = "상그리카스",
				[50808] = "걷는 자 우로비",
				[138630] = "성직자 이자드",
				[50341] = "보르긴 다크피스트",
				[112712] = "금박 수호자",
				[125820] = "임프 어미 라글라스",
				[107487] = "별사슴",
				[127706] = "현자 레지라",
				[133042] = "하늘 치안대장 가브리엘",
				[137649] = "살충기 마크 II",
				[79334] = "노로쉬",
				[108255] = "비전술의 여제 쿠라",
				[139026] = "월식소환사",
				[139697] = "고위주술사 클락시카르",
				[50830] = "스프리긴",
				[80614] = "칼춤꾼 에이릭스",
				[133043] = "대장군 볼라스",
				[148642] = "짐마차 우두머리",
				[126427] = "나뭇가지군주 알드루스",
				[50388] = "토릭에디스",
				[73704] = "구린수염",
				[139698] = "점쟁이 클래터크로",
				[143314] = "숲의 파멸자",
				[134822] = "우두머리 돌장갑",
				[133044] = "최고사령관 트렘블레이드",
				[136893] = "지면진동자 아간",
				[134902] = "그림자술사 거미",
				[138675] = "포식한 멧돼지",
				[58768] = "따닥송곳니",
				[154153] = "집행자 KX-T57",
				[137057] = "장로 구르타니",
				[117470] = "시바쉬",
				[137140] = "큰덩치 돌진자",
				[142741] = "파멸기수 헬그림",
				[143313] = "포타킬로",
				[81639] = "가시왕 필리",
				[139188] = "무쇠가죽",
				[139700] = "바닷물비늘 바다 주술사",
				[50340] = "독기 어린 가른",
				[116395] = "밤샘 풍수사",
				[95204] = "곤봉꾼 아웁돕",
				[134800] = "강화된 무쇠턱거북",
				[127820] = "정찰병 스크라스니스",
				[100067] = "히드라논",
				[139189] = "고대의 벌목발톱",
				[139701] = "바닷물비늘 수련 점쟁이",
				[148403] = "차원문 수호자 로미르",
				[109281] = "말리산드라",
				[139818] = "보안 장교 더크",
				[116185] = "수행원 관리자",
				[106532] = "심문관 볼리틱스",
				[98276] = "펜리",
				[139190] = "재빠른 가지도약꾼",
				[88208] = "구덩이 야수",
				[97933] = "게 기수 우옳옳",
				[111329] = "대모 하가사",
				[82920] = "군주 코리낙",
				[127873] = "수컷 강탈랩터",
				[127581] = "다면의 포식자",
				[146869] = "맹독의 자이룸",
				[139191] = "덤불랑이",
				[127001] = "저주받은 그워그너그",
				[98268] = "타르벤",
				[96997] = "케스라조르",
				[141239] = "피범벅 오스카",
				[132088] = "선장 윈터세일",
				[110562] = "바하가르",
				[146870] = "역술사 오나재",
				[90087] = "강철 대장 아르가",
				[131735] = "현자 이데지",
				[88210] = "적출자 크루드",
				[63101] = "장군 테무자",
				[107657] = "비전술사 샬이만",
				[103203] = "바다 부랑자",
				[119103] = "칠흑의 집행자",
				[146871] = "여군주 나스나야",
				[106165] = "악몽 감시관소환 안 됨",
				[121056] = "기괴한 공포수호병",
				[92647] = "지옥기술자 다모르카",
				[140863] = "루비바람 악동",
				[134908] = "붉은송곳니",
				[90088] = "오르마크 블러드볼트",
				[83990] = "태양 확대경",
				[146872] = "추방당한 카초타",
				[139194] = "부패아귀",
				[137060] = "모래술사 무나",
				[86771] = "잔혹한 가그로그",
				[148428] = "담즙발",
				[82922] = "파괴자 조티어",
				[70430] = "공포의 바위",
				[140797] = "시체수확자",
				[146873] = "흉악한 폭풍우 정령",
				[140800] = "살해약탈 구름날개",
				[147897] = "음험한 소고스",
				[50776] = "날라쉬 베르단티스",
				[144826] = "인간탐식자",
				[139417] = "저주박은 부패나무",
				[50811] = "나스라 스팟하이드",
				[126432] = "요동치는 거수",
				[146874] = "바람소환사 마리아",
				[90089] = "그롭톡 스컬브레이커",
				[105632] = "여왕 슈말리스",
				[82411] = "어둠발톱",
				[144827] = "늪트림꾼",
				[91113] = "파도 거수",
				[124804] = "선택자 테렉",
				[132047] = "강화된 선체파괴자",
				[146875] = "흉포한 발리모크",
				[120583] = "탄오탈리온",
				[73281] = "공포의 유령선 바주비어스호",
				[139038] = "카이후",
				[109054] = "샬안",
				[130016] = "에밀리 메이빌",
				[140981] = "이빨 가는 공포",
				[146876] = "야만적인 마치투",
				[98024] = "알먹보 루굿",
				[140110] = "히드라러크",
				[131520] = "고약한 컬렛",
				[139884] = "예언자 둠라",
				[144829] = "천둥꺼비",
				[91114] = "파도 거수",
				[115226] = "라베니안",
				[136888] = "흙예언자 바룰",
				[70000] = "천리안 알타빔",
				[88043] = "소크레타르의 화신",
				[71919] = "시큼한 주곤",
				[73166] = "괴물 가시집게",
				[144830] = "포식자 야자",
				[82758] = "위엄깃털",
				[117091] = "지옥아귀 잿불마귀",
				[118244] = "번개발",
				[129832] = "따개비게",
				[126946] = "심문관 베스로즈",
				[136852] = "가마솥지기 오도",
				[120899] = "쿨크라잔",
				[144831] = "거대 쟁기발개구리",
				[91115] = "파도 거수",
				[137665] = "영혼 골리앗",
				[140071] = "늙은 외송곳니",
				[87788] = "둘그 스파인크러셔",
				[138388] = "컹",
				[82975] = "덥석니",
				[138391] = "투척자 노르코",
				[98199] = "푸그",
				[118192] = "노르고르",
				[134754] = "효기",
				[152007] = "살해톱",
				[126691] = "티라노사우루스 렉스",
				[146880] = "수수께끼의 골브란",
				[136042] = "군주 아쿠아노스",
				[134904] = "밤배회거미",
				[144833] = "찰싹혀",
				[132750] = "NAME",
				[92140] = "무성한 만드라고라",
				[135933] = "군주 가즈란",
				[146881] = "예언자 브린불프",
				[96235] = "제미르콜",
				[84465] = "껑충 고렌",
				[140065] = "사향가죽",
				[134782] = "살해부리",
				[50780] = "산 타이드헌터",
				[92117] = "피부리",
				[72362] = "공허현자 쿠탈그",
				[146882] = "거대한 황폐사냥개",
				[98283] = "드라쿰",
				[110824] = "파도집게",
				[82415] = "신리",
				[90782] = "라스더",
				[97504] = "망령발톱",
				[117094] = "영혼지킴이 말로러스",
				[138387] = "망골",
				[146883] = "사냥개조련사 앵그볼드",
				[139205] = "P4-N73R4",
				[140435] = "희끗털",
				[131404] = "현장감독 스크립스",
				[146884] = "전쟁군주 혤슈카르트",
				[137158] = "속박된 번개 정령",
				[126181] = "어둠의 라무트",
				[90094] = "항만관리자 코라크",
				[130788] = "타기라",
				[98284] = "곤다르",
				[139027] = "초승달 점쟁이",
				[86562] = "광기 어린 마드가드",
				[150468] = "보르코스",
				[110870] = "연금술사 폴드런",
				[91374] = "포들링군주 와카왐",
				[134088] = "자이발란 포식자",
				[146885] = "구린절규",
				[99899] = "흉포한 고래상어",
				[108010] = "화약장인 마크린",
				[71721] = "협곡 얼음어미",
				[110486] = "전문사냥꾼 헉로스",
				[93166] = "실성한 팁톡",
				[97517] = "공포수렁",
				[49822] = "비취송곳니",
				[146886] = "악취나는 흐롤슈칼트",
				[98285] = "스매셤 그랩",
				[117140] = "무리방랑자 살레단",
				[120715] = "라가유트",
				[139023] = "야생의 피아귀",
				[135844] = "군주 수마르",
				[152001] = "뼈다귀청소부",
				[121107] = "여군주 엘드라스",
				[146887] = "썩은 자 게른",
				[85029] = "어둠예언자 니르",
				[153228] = "장비 검수자 코그스타",
				[80370] = "렐니아",
				[155583] = "고철집게발",
				[71665] = "거인학살자 쿨",
				[117136] = "파멸인도자 자르토즈",
				[93679] = "정복자 가테나크",
				[121108] = "파멸의 거대마귀",
				[139210] = "맹독대두",
				[86257] = "바스텐",
				[126866] = "감시자 쿠로",
				[98200] = "구크",
				[82930] = "암흑불길 공포인도자",
				[84775] = "부서진 테스카",
				[139666] = "토템 신봉자 올그를",
				[139019] = "분노등짝",
				[139211] = "영원만개",
				[139442] = "척추파쇄자 주칸",
				[80371] = "티폰",
				[72156] = "포식자 보로크",
				[93168] = "지옥바위",
				[50815] = "스카르",
				[131262] = "무리 우두머리 아세냐",
				[130791] = "쿠트인",
				[139212] = "포도채찍",
				[86258] = "눌트라",
				[87019] = "걸신들린 거인",
				[139411] = "우글송곳니",
				[87026] = "기계 약탈자",
				[105657] = "노트가른",
				[92657] = "피눈물 공포전사",
				[136341] = "밀림그물 사냥꾼",
				[139213] = "열매쿵",
				[83691] = "판토라",
				[80372] = "에키드나",
				[72606] = "바위발굽",
				[70126] = "윌리 와일더",
				[122090] = "약탈자 사라샤스",
				[106990] = "쓴소금물 족장",
				[123293] = "제왕 모래 게",
				[142662] = "흙점쟁이 플린트대거",
				[86259] = "발스틸",
				[132048] = "전쟁 세발차",
				[82676] = "에나브라",
				[87027] = "어둠의 거한",
				[82988] = "쿨로쉬 둠팽",
				[135719] = "그늘길잡이",
				[110367] = "엘디스",
				[139387] = "냉혈한 나사",
				[91795] = "폭풍날개 어미",
				[85555] = "나기드나",
				[111007] = "란드릴",
				[126867] = "맹독꼬리 하늘지느러미",
				[50816] = "루운 고스트포우",
				[139045] = "예언자 주치",
				[138647] = "히아나 포그브링어",
				[143311] = "사악독버섯",
				[117850] = "매혹의 시몬",
				[139817] = "선임기술자 제지",
				[50339] = "술리크쇼르",
				[63695] = "불태우는 자 바오라이",
				[137681] = "왕 딸깍똑딱",
				[148253] = "죽음경비대장 데세카",
				[137058] = "사술사 마고다",
				[139217] = "늙은 막핀나무",
				[121068] = "불안정한 임프",
				[137059] = "머리사냥꾼 가하",
				[92645] = "밤의 유령",
				[135925] = "화염불꽃",
				[126187] = "시체인도자 얄카르",
				[110340] = "묘닉스",
				[82536] = "고리박스",
				[139218] = "생명지기 올바리우스",
				[111651] = "디그렌",
				[132052] = "볼짐",
				[138991] = "겔겔이",
				[127979] = "잃어버린 염소",
				[108256] = "서리바람의 지배자 퀸엘",
				[108016] = "강령마법사 톨드레다르",
				[91892] = "영주 무자비한 이르글로브",
				[139219] = "나시라 모닝프로스트",
				[87600] = "평화주의자 잘루크",
				[140271] = "절단뿔",
				[140979] = "큰송곳니",
				[122911] = "사령관 베카야",
				[50817] = "방랑자 아혼",
				[86774] = "아오겍손",
				[71864] = "스페럴크",
				[139220] = "바이야 크리스탈블룸",
				[110832] = "고르그로스",
				[91788] = "껍질아귀",
				[103154] = "하티",
				[107431] = "무기화한 로봇토끼",
				[121051] = "불안정한 심연불정령",
				[124397] = "칼드락사",
				[95988] = "덩어리",
				[143316] = "해골모자",
				[147923] = "기사대장 조시프",
				[100231] = "다르고크 썬더루인",
				[140757] = "포즈루크",
				[92887] = "무쇠주둥이",
				[92552] = "벨고르크",
				[96208] = "쥬베이토스",
				[122606] = "하늘빛나래",
				[110577] = "흉측한 오레스",
				[147924] = "대지조각",
				[102092] = "전쟁군주 바틸라쉬",
				[92725] = "피머리의 아들",
				[95221] = "광기의 헨릭",
				[90888] = "드리브눌",
				[139321] = "브래단 화이트월",
				[121049] = "재앙의 기사대장",
				[129005] = "왕 쿠바",
				[105899] = "격노의 오글록",
				[140857] = "비취섬광",
				[153312] = "심연예언자 킥스줄",
				[140091] = "눈송이발굽",
				[140672] = "지저분한 먼지가죽",
				[93686] = "꿰뚫는 자 지니키",
				[146855] = "아키나",
				[123001] = "암흑의 물 정령",
				[121124] = "아포크론",
				[140248] = "재빠른 달추적자",
				[140760] = "대지생명 거인",
				[140451] = "애정어린 새끼어미",
				[101596] = "그슬린깃털",
				[124399] = "감염된 공포뿔",
				[140795] = "싸늘한 모래빙빙",
				[108531] = "공포의 유령선 크라자토아호",
				[80122] = "가즈올다",
				[140249] = "점판가죽",
				[109994] = "폭풍발톱",
				[86582] = "모르고 케인",
				[103214] = "만족할 줄 모르는 하르케스",
				[78150] = "야수조각사 사라모르",
				[148025] = "사령관 랄에쉬",
				[139226] = "자매 아나나",
				[135643] = "렌키리",
				[136304] = "여가수 나흐진",
				[153303] = "공허칼날 카사르",
				[132076] = "토테스",
				[132448] = "양초지기 서리수염",
				[91640] = "빈예티",
				[50051] = "유령게",
				[92152] = "하얀물 태풍",
				[92408] = "영생의 잔지스",
				[139679] = "앓그를",
				[140763] = "설언덕 거인",
				[137180] = "Merchant Attack Controller",
				[136813] = "금광킁킁",
				[134109] = "지배당한 히드라",
				[122609] = "자비녹스",
				[134795] = "장막의 은둔자 게",
				[86266] = "베놀라식스",
				[140252] = "우박 피조물",
				[140764] = "용암 거인",
				[100223] = "브리쿨 대지창조자 영혼",
				[50749] = "역병의 칼티크",
				[135839] = "늪가스",
				[145268] = "그림자발톱",
				[139229] = "알루나 리프시스터",
				[135646] = "분쇄의 피얼룩 호랑이",
				[146844] = "계악자 올프크리그",
				[140765] = "요동치는 거수",
				[139407] = "송곳니공포",
				[91780] = "어미 딸깍이",
				[126449] = "모래토쟁이",
				[89850] = "예언자",
				[139676] = "파도예언자 옮르그",
				[135647] = "이투아키",
				[111434] = "바다왕 티드로스",
				[140974] = "왕꿀꺽이",
				[137183] = "꿀 발린 뱀장어",
				[138433] = "해일여제 베사나",
				[134112] = "대모 크리스티안",
				[140860] = "벼랑주자",
				[139231] = "짓밟는 마이어우드",
				[108790] = "무리어미 이르바",
				[136010] = "바위얼굴 대지파괴자",
				[147864] = "쉬익카라스",
				[138650] = "파도잠식 용사",
				[50820] = "율 와일드포우",
				[77310] = "미친 \"왕\" 스포리온",
				[134625] = "전쟁어미 포로",
				[139672] = "쫑알지느러미",
				[86268] = "알칼리",
				[148446] = "늑대우두머리 스크로그",
				[132578] = "크로쉐익스",
				[97593] = "발톱비명 민타",
				[134905] = "그늘그물 사냥거미",
				[86743] = "데콜한",
				[130508] = "무리어미 라조라",
				[139233] = "걸리버",
				[92411] = "대군주 마그루스",
				[152542] = "비늘 여군주 조디아",
				[117493] = "그림토템 전사",
				[139667] = "예언자 그를글록",
				[90429] = "임프소환사 발레사",
				[81406] = "바하메이",
				[140449] = "뭉툭몸통",
				[139809] = "투자회사 인수 전문가",
				[132179] = "사나운 증기정령",
				[132068] = "바쉬무",
				[132580] = "신크릭스",
				[82942] = "여군주 뎀라쉬",
				[82883] = "장군 녹틴",
				[135932] = "볼카나르",
				[59369] = "의사 테올렌 크라스티노브",
				[139235] = "거북턱",
				[121077] = "희미한 지옥사냥꾼",
				[72193] = "카르카노스",
				[94113] = "룩크마즈",
				[140074] = "뾰족니",
				[50821] = "아이리 스카이미러",
				[50159] = "삼바스",
				[77768] = "원소술사 우트라",
				[98299] = "탐욕스러운 보다쉬",
				[90139] = "심문관 에른스텐보크",
				[152545] = "비늘 여군주 바이나라",
				[131984] = "두 마음의 피조물",
				[138889] = "선견자 우불드",
				[79104] = "얼어붙은 우글로크",
				[134821] = "썩은응시 돌바실리스크",
				[142683] = "루울 원스톤",
				[148154] = "아가테 웜우드",
				[104698] = "콜레리안",
				[117239] = "브루탈루스",
				[140773] = "깊은바다 파도잡이",
				[117303] = "말리피쿠스",
				[90437] = "작스조르",
				[138563] = "부닥스",
				[139812] = "투자회사 생산자",
				[50992] = "고로크",
				[91087] = "제텔엘",
				[148037] = "아실 듀파이어",
				[132584] = "자르셰지",
				[141286] = "밀렵꾼 제인",
				[93125] = "글럽글록",
				[79692] = "은빛잎새 고대정령",
				[50981] = "루크호크",
				[149341] = "유리화된 아제라이트",
				[108794] = "장막수색꾼의 그림자",
				[54533] = "왕자 라크마",
				[136892] = "야만주둥이",
				[78713] = "갈조마르",
				[50822] = "변화하는 구름의 아이란",
				[85504] = "마귀버섯",
				[51078] = "퍼디난드",
				[139017] = "거친갈기",
				[147942] = "황혼의 예언자 그래미",
				[128951] = "네즈아라",
				[148563] = "혹한의 공작 부인 폴른송",
				[125497] = "감독관 이소르나",
				[140163] = "전쟁인도자 예나즈",
				[142312] = "두개골절단자",
				[83713] = "티타루스",
				[50359] = "어골락스",
				[136875] = "무역상 우두",
				[93001] = "뒤틀린 스지레크",
				[140777] = "보석파편 거인",
				[134768] = "냉혹한 모래집게",
				[126199] = "브락스툴",
				[54322] = "데스틸락",
				[153928] = "바다군주 디스퍼시우스",
				[104519] = "콜레리안",
				[146238] = "검은쐐기",
				[140266] = "고대의 부서진뿔",
				[107846] = "검을들고덤비게",
				[54323] = "키릭스",
				[95053] = "죽음갈퀴",
				[145076] = "인르",
				[149353] = "빛나는 아제라이트보석 수정등",
				[109692] = "리데론",
				[139755] = "일등항해사 맥넬리",
				[140267] = "거대뿔 우와누",
				[147260] = "컨플라그로스",
				[85078] = "공허약탈자 우르네이",
				[137708] = "돌 골렘",
				[144915] = "화염감시자 바이턴 다크플레어",
				[134637] = "인간사냥꾼 리자",
				[77828] = "울림의 메아리",
				[139756] = "자객 쉴라",
				[140268] = "숲지기 아노",
				[148534] = "영원한 자 이브존",
				[127291] = "감시자 에이발",
				[70238] = "깜박이지 않는 눈",
				[91649] = "여왕벌 즈살라",
				[134638] = "전쟁군주 조딕스",
				[112636] = "사악한 지맥질주마",
				[139757] = "확인사살 존슨",
				[140269] = "울루테일",
				[132591] = "미치광이 오그모트",
				[82778] = "광적인 옹이발굽",
				[149510] = "오웰 스티븐슨",
				[148092] = "날레이스 페더시커",
				[85763] = "저주받은 칼날발톱",
				[146979] = "오르민 로켓밥",
				[139758] = "총알둘 애니",
				[140270] = "야생사슴",
				[62880] = "무쇠주먹 고차오",
				[140101] = "늪뒹굴이",
				[50363] = "크락시크",
				[145250] = "맛간깃털",
				[149663] = "그림자발톱",
				[112637] = "악마의 태양질주마",
				[139759] = "반란자 잘리아",
				[152556] = "수렁 귀신뱀",
				[149354] = "기괴한 아제라이트보석 수정등",
				[139043] = "물결잡이 오초",
				[116034] = "젖소왕",
				[97793] = "불꽃비늘",
				[50750] = "애티스",
				[84836] = "발톱파괴자",
				[139760] = "선임 항해사 프랭클린",
				[140272] = "숲성큼걸이",
				[109630] = "이몰리안",
				[145391] = "짐마차 우두머리",
				[90505] = "시포누스",
				[92611] = "잠복꾼 단도엄니",
				[81001] = "노크 카로쉬",
				[108543] = "공포의 선장 테돈",
				[139761] = "부두주임 오루어크",
				[88580] = "화마 그라쉬",
				[147507] = "하늘조각사 크라킷",
				[145392] = "대사 게인스",
				[105728] = "낫의 달인 실라만",
				[142321] = "분노부리",
				[134643] = "전사 블옳를옳",
				[135722] = "황혼 배회자",
				[139762] = "청소부 페이스",
				[109195] = "영혼술사 할도라",
				[90884] = "투척자 빌코르",
				[150191] = "아바리우스",
				[127289] = "사우로리스크 조련사 머그",
				[124412] = "사냥개몰이꾼 오록스",
				[152570] = "광기 어린 트로그",
				[147222] = "놀탐식자",
				[139763] = "대포전문가 아를린",
				[148146] = "인간사냥꾼 줄아키",
				[92040] = "펜리",
				[96621] = "토로크의 아들 멜로크",
				[87666] = "무그라",
				[126460] = "오염된 수호자",
				[85766] = "저주받은 뾰족발톱",
				[155333] = "고동치는 아제라이트 정동석",
				[139764] = "커틀라스꾼 제임",
				[132086] = "검은 눈의 바트",
				[90885] = "추적자 로곤드",
				[145395] = "카트리아나",
				[151686] = "도둑 약삭발이",
				[151680] = "주홍이빨",
				[154148] = "해일여제 레스신드라",
				[84856] = "역병포자",
				[139765] = "배 없는 지미",
				[88582] = "날쌘 칠흑색 칼날발톱",
				[136410] = "테드 슈메이커",
				[152323] = "왕 가쿨라",
				[72970] = "골가나르",
				[135497] = "버섯",
				[143439] = "왕노다지차",
			},
		},
		["dbversion"] = {
			{
				["locale"] = "koKR",
				["version"] = 5,
			}, -- [1]
		},
		["recentlySeen"] = {
		},
		["containers_reseteable"] = {
			[291264] = true,
		},
		["loot_info"] = {
			[163678] = {
				"|cff0070dd|Hitem:163678::::::::120:262::::::|h[핑쿠숀의 관통장창]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661331, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[163934] = {
				"|cffa335ee|Hitem:163934::::::::120:262::::::|h[비틀린 기분의 반지]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FINGER", -- [3]
				1011901, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[170200] = {
				"|cff1eff00|Hitem:170200::::::::120:577::::::|h[바다폭풍 토템]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				538570, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169433] = {
				"|cff1eff00|Hitem:169433::::::::120:577::::::|h[파도분쇄 큰망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2967512, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161377] = {
				"|cffa335ee|Hitem:161377::::::::120:262::::::|h[아주레토스의 그을린 깃털]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103829, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169689] = {
				"|cff1eff00|Hitem:169689::::::::120:577::::::|h[음반: 미미론의 번뜩이는 생각]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163679] = {
				"|cff0070dd|Hitem:163679::::::::120:262::::::|h[세베루스의 손목띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1698803, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163935] = {
				"|cffa335ee|Hitem:163935::::::::120:577::::::|h[란도이의 철저]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1100023, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[170201] = {
				"|cff1eff00|Hitem:170201::::::::120:577::::::|h[깊은바다 두루마리]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				2830981, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169434] = {
				"|cff1eff00|Hitem:169434::::::::120:577::::::|h[미끈껍질 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2902640, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161378] = {
				"|cffa335ee|Hitem:161378::::::::120:262::::::|h[바다새의 깃]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103806, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169690] = {
				"|cff1eff00|Hitem:169690::::::::120:577::::::|h[음반: 놈리건 전투]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163680] = {
				"|cff0070dd|Hitem:163680::::::::120:262::::::|h[역병이빨의 발걸음]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1698802, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158821] = {
				"|cff9d9d9d|Hitem:158821::::::::120:262::::::|h[쪼개진 가면]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133792, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169435] = {
				"|cff1eff00|Hitem:169435::::::::120:577::::::|h[깊은바다 외투]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2973333, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161379] = {
				"|cffa335ee|Hitem:161379::::::::120:262::::::|h[폭풍의 부리]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				952507, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169691] = {
				"|cff1eff00|Hitem:169691::::::::120:262::::::|h[음반: 울두아르 깊은 곳]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163937] = {
				"|cffa335ee|Hitem:163937::::::::120:577::::::|h[리쇼크의 위대한 장치]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2000858, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[154858] = {
				"|cff1eff00|Hitem:154858::::::::120:577::::::|h[무덤둔덕 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1726329, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159206] = {
				"|cff1eff00|Hitem:159206::::::::120:262::::::|h[뾰족털 어깨덧대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1733699, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160485] = {
				"|cffffffff|Hitem:160485::::::::120:577::::::|h[잊을 수 없는 점심]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1529266, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159590] = {
				"|cff1eff00|Hitem:159590::::::::120:262::::::|h[함선좌초자 칼날]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729265, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[163938] = {
				"|cffa335ee|Hitem:163938::::::::120:577::::::|h[칼리브의 발길질 장화]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				462524, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154859] = {
				"|cff1eff00|Hitem:154859::::::::120:262::::::|h[무덤둔덕 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1726331, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159207] = {
				"|cff1eff00|Hitem:159207::::::::120:262::::::|h[뾰족털 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1733691, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154476] = {
				"|cff0070dd|Hitem:154476::::::::120:262::::::|h[꿀 바른 완갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1727709, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163939] = {
				"|cffa335ee|Hitem:163939::::::::120:577::::::|h[말루소프의 안정적인 통바지]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				1017828, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154860] = {
				"|cff1eff00|Hitem:154860::::::::120:262::::::|h[무덤둔덕 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1726333, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[162661] = {
				"|cff9d9d9d|Hitem:162661::::::::120:262::::::|h[닳아해진 해골]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133730, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163940] = {
				"|cffa335ee|Hitem:163940::::::::120:577::::::|h[빛나는 초경량 장식끈]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				414282, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162662] = {
				"|cff9d9d9d|Hitem:162662::::::::120:262::::::|h[글이 새겨진 가면]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133113, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155629] = {
				"|cff9d9d9d|Hitem:155629::::::::120:262::::::|h[낡은 갈기털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237419, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168161] = {
				"|cff1eff00|Hitem:168161::::::::120:577::::::|h[탈피된 껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1508497, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[162663] = {
				"|cff9d9d9d|Hitem:162663::::::::120:262::::::|h[부러진 창머리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135125, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163942] = {
				"|cffa335ee|Hitem:163942::::::::120:262::::::|h[제멋대로인 요정의 끌신]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				1627511, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154863] = {
				"|cff1eff00|Hitem:154863::::::::120:577::::::|h[무덤둔덕 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1726335, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159211] = {
				"|cff1eff00|Hitem:159211::::::::120:262::::::|h[어스름 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1726330, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168802] = {
				"|cff1eff00|Hitem:168802::::::::120:577::::::|h[나즈자타 전투 훈장]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1594746, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[155631] = {
				"|cff9d9d9d|Hitem:155631::::::::120:262::::::|h[마력을 잃은 돌]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135233, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163943] = {
				"|cffa335ee|Hitem:163943::::::::120:577::::::|h[넬레모어의 무늬새김 다리보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				457940, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154864] = {
				"|cff1eff00|Hitem:154864::::::::120:262::::::|h[무덤둔덕 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1726336, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159212] = {
				"|cff1eff00|Hitem:159212::::::::120:262::::::|h[어스름 코이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1726334, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163944] = {
				"|cffa335ee|Hitem:163944::::::::120:577::::::|h[와타의 이중매듭 장식끈]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				514333, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154865] = {
				"|cff1eff00|Hitem:154865::::::::120:262::::::|h[무덤둔덕 쇠사슬갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1726332, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170466] = {
				"|cffa335ee|Hitem:170466::::::::120:577::::::|h[고철장 고문기]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2618150, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[168804] = {
				"|cff0070dd|Hitem:168804::::::::120:577::::::|h[동력이 공급된 물고기 조달 균형대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2909707, -- [4]
				2, -- [5]
				20, -- [6]
			},
			[163945] = {
				"|cffa335ee|Hitem:163945::::::::120:577::::::|h[미스트라의 멋진 긴장갑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				795962, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[170467] = {
				"|cffa335ee|Hitem:170467::::::::120:577::::::|h[예리한 사슬칼날]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2618146, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[158831] = {
				"|cff9d9d9d|Hitem:158831::::::::120:577::::::|h[바짝 마른 벌집]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500973, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162028] = {
				"|cffffffff|Hitem:162028::::::::120:262::::::|h[각인 기법: 파도돌고래]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				11, -- [6]
			},
			[169317] = {
				"|cffa335ee|Hitem:169317::::::::120:577::::::|h[속박꾼의 귀속석]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				973909, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[170468] = {
				"|cffa335ee|Hitem:170468::::::::120:577::::::|h[초고전압 충격기]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				2735166, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[155635] = {
				"|cff9d9d9d|Hitem:155635::::::::120:262::::::|h[튼튼한 날개]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134002, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163947] = {
				"|cffa335ee|Hitem:163947::::::::120:577::::::|h[디누사의 억센 다리싸개]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				422806, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169318] = {
				"|cffa335ee|Hitem:169318::::::::120:577::::::|h[전격아귀의 송곳니]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1526597, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[170086] = {
				"|cff9d9d9d|Hitem:170086::::::::120:577::::::|h[산호얼룩 성배]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132789, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170470] = {
				"|cffa335ee|Hitem:170470::::::::120:577::::::|h[강화된 기름 방패]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHIELD", -- [3]
				2902485, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[159473] = {
				"|cff1eff00|Hitem:159473::::::::120:262::::::|h[조선소 도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[170087] = {
				"|cff9d9d9d|Hitem:170087::::::::120:577::::::|h[오색 \"식초\"]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132798, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159218] = {
				"|cff1eff00|Hitem:159218::::::::120:262::::::|h[현자의 영지 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159474] = {
				"|cff1eff00|Hitem:159474::::::::120:262::::::|h[파도수호병 손도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[167786] = {
				"|cffffffff|Hitem:167786::::::::120:577::::::|h[싹틔우는 씨앗]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				464030, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170088] = {
				"|cffa335ee|Hitem:170088::::::::120:577::::::|h[울매스의 영혼추적자]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_RANGED", -- [3]
				2924349, -- [4]
				2, -- [5]
				2, -- [6]
			},
			[170472] = {
				"|cff0070dd|Hitem:170472::::::::120:577::::::|h[딱딱한 동전]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2744751, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159475] = {
				"|cff1eff00|Hitem:159475::::::::120:577::::::|h[함선좌초자 도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[162672] = {
				"|cff9d9d9d|Hitem:162672::::::::120:577::::::|h[의술사의 부적 묵주]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1535057, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170089] = {
				"|cffa335ee|Hitem:170089::::::::120:577::::::|h[리아라의 뾰족지팡이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2921481, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[159220] = {
				"|cff1eff00|Hitem:159220::::::::120:262::::::|h[현자의 영지 예복]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				1698805, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159604] = {
				"|cff1eff00|Hitem:159604::::::::120:262::::::|h[찬비늘 막대봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1697864, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[170090] = {
				"|cffa335ee|Hitem:170090::::::::120:577::::::|h[무자비한 쪽집게]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2997789, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[159349] = {
				"|cff0070dd|Hitem:159349::::::::120:262::::::|h[용거북 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1726333, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163569] = {
				"|cffffffff|Hitem:163569::::::::120:577::::::|h[단열 배선]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133243, -- [4]
				7, -- [5]
				1, -- [6]
			},
			[159605] = {
				"|cff1eff00|Hitem:159605::::::::120:262::::::|h[강철문장 지휘봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1697864, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[158710] = {
				"|cff0070dd|Hitem:158710::::::::120:262::::::|h[뿔꼬챙이의 철퇴]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[163953] = {
				"|cffa335ee|Hitem:163953::::::::120:577::::::|h[줄라의 쾌활한 외투]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2054623, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159222] = {
				"|cff1eff00|Hitem:159222::::::::120:262::::::|h[현자의 영지 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1698809, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[167790] = {
				"|cff1eff00|Hitem:167790::::::::120:262::::::|h[물감이 든 병: 화염구 적색]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				413575, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158839] = {
				"|cff9d9d9d|Hitem:158839::::::::120:577::::::|h[두꺼운 집게발]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1508493, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159223] = {
				"|cff1eff00|Hitem:159223::::::::120:262::::::|h[현자의 영지 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1698803, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163699] = {
				"|cffffffff|Hitem:163699::::::::120:577::::::|h[열처리한 꿀 아뮬렛]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				632830, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163955] = {
				"|cffa335ee|Hitem:163955::::::::120:577::::::|h[늑대의 검 카연]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				841309, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[160119] = {
				"|cff1eff00|Hitem:160119::::::::120:577::::::|h[공포뿔 주름장식 가슴보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1672317, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170477] = {
				"|cffa335ee|Hitem:170477::::::::120:577::::::|h[마디바스의 누구든 떠받드는 가방]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				133660, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[161398] = {
				"|cffa335ee|Hitem:161398::::::::120:262::::::|h[갈퀴에 마모된 청금석 완갑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				2054626, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[167792] = {
				"|cff1eff00|Hitem:167792::::::::120:577::::::|h[물감이 든 병: 지옥 박하 녹색]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				413575, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163956] = {
				"|cffa335ee|Hitem:163956::::::::120:262::::::|h[트레이야의 빛나는 기둥지팡이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1617802, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[160120] = {
				"|cff1eff00|Hitem:160120::::::::120:262::::::|h[공포뿔 주름장식 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163573] = {
				"|cffa335ee|Hitem:163573::::::::120:577::::::|h[황금갈기의 고삐]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				132261, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[167793] = {
				"|cff1eff00|Hitem:167793::::::::120:577::::::|h[물감이 든 병: 지나치게 진한 주황색]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				413575, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[152576] = {
				"|cffffffff|Hitem:152576::::::::120:262::::::|h[파도안개 리넨]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2067081, -- [4]
				7, -- [5]
				5, -- [6]
			},
			[170095] = {
				"|cffa335ee|Hitem:170095::::::::120:577::::::|h[달의 여사제의 지휘봉]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2735968, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[160121] = {
				"|cff1eff00|Hitem:160121::::::::120:262::::::|h[공포뿔 주름장식 철갑허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[152577] = {
				"|cff1eff00|Hitem:152577::::::::120:262::::::|h[심해 명주]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2067080, -- [4]
				7, -- [5]
				5, -- [6]
			},
			[163958] = {
				"|cffa335ee|Hitem:163958::::::::120:577::::::|h[프리지의 거품퐁퐁 단도]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				968649, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[166260] = {
				"|cffffffff|Hitem:166260::::::::120:262::::::|h[도면: 모네라이트로 굳힌 발굽보호대]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				4, -- [6]
			},
			[170097] = {
				"|cff9d9d9d|Hitem:170097::::::::120:577::::::|h[버려진 쿠엘도레이 고서]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133735, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[171248] = {
				"|cffffffff|Hitem:171248::::::::120:262::::::|h[시험생산형 주입물]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				986489, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160123] = {
				"|cff1eff00|Hitem:160123::::::::120:577::::::|h[공포뿔 주름장식 다리갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1672320, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168435] = {
				"|cffa335ee|Hitem:168435::::::::120:577::::::|h[원격조종 회로 우회기]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134390, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[162681] = {
				"|cff9d9d9d|Hitem:162681::::::::120:262::::::|h[구부러진 낫]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1060561, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170098] = {
				"|cff9d9d9d|Hitem:170098::::::::120:577::::::|h[녹슨 가지장식 귀걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133348, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158078] = {
				"|cff9d9d9d|Hitem:158078::::::::120:262::::::|h[금이 간 대군주의 홀]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPON", -- [3]
				454053, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[162682] = {
				"|cff9d9d9d|Hitem:162682::::::::120:262::::::|h[빛바랜 장검]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135274, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170099] = {
				"|cff9d9d9d|Hitem:170099::::::::120:577::::::|h[부식된 품위있는 열쇠]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134240, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160125] = {
				"|cff1eff00|Hitem:160125::::::::120:577::::::|h[공포뿔 주름장식 디딤장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163962] = {
				"|cffa335ee|Hitem:163962::::::::120:577::::::|h[알리레자의 참수검]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1115730, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[169333] = {
				"|cff0070dd|Hitem:169333::::::::120:577::::::|h[수상한 화산 바위]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132847, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[162684] = {
				"|cff9d9d9d|Hitem:162684::::::::120:262::::::|h[글이 새겨진 갑판 밧줄걸이 막대]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135544, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163963] = {
				"|cffa335ee|Hitem:163963::::::::120:577::::::|h[실리리온의 고기 방망이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1084300, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[169334] = {
				"|cff0070dd|Hitem:169334::::::::120:577::::::|h[수상한 해양 퇴적물]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				628267, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[168823] = {
				"|cffa335ee|Hitem:168823::::::::120:577::::::|h[녹슨 메카거미]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2620863, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[158849] = {
				"|cff9d9d9d|Hitem:158849::::::::120:262::::::|h[톱니 턱뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1729493, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160128] = {
				"|cff1eff00|Hitem:160128::::::::120:577::::::|h[브루토사우루스가죽 팔보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1674412, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158210] = {
				"|cff9d9d9d|Hitem:158210::::::::120:577::::::|h[무시무시한 발톱]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1508515, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169591] = {
				"|cff1eff00|Hitem:169591::::::::120:262::::::|h[금이 간 수식 실린더]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237445, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163581] = {
				"|cff9d9d9d|Hitem:163581::::::::120:577::::::|h[부실한 스톰윈드 왕궁 모형]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1033989, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168824] = {
				"|cff0070dd|Hitem:168824::::::::120:262::::::|h[바다 시뮬레이터]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2923993, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158850] = {
				"|cff9d9d9d|Hitem:158850::::::::120:577::::::|h[흩날리는 깃털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132925, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168185] = {
				"|cffffffff|Hitem:168185::::::::120:577::::::|h[오스미나이트 광석]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2543233, -- [4]
				7, -- [5]
				7, -- [6]
			},
			[160129] = {
				"|cff1eff00|Hitem:160129::::::::120:577::::::|h[브루토사우루스가죽 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1674411, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169848] = {
				"|cff0070dd|Hitem:169848::::::::120:262::::::|h[미니 아제로스 묶음 상품: 본도의 야적장]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134143, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158851] = {
				"|cff9d9d9d|Hitem:158851::::::::120:262::::::|h[병 속의 돌풍]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463545, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160130] = {
				"|cff1eff00|Hitem:160130::::::::120:577::::::|h[브루토사우루스가죽 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169593] = {
				"|cff1eff00|Hitem:169593::::::::120:577::::::|h[대량의 기록 조각]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[167931] = {
				"|cff0070dd|Hitem:167931::::::::120:577::::::|h[메카곤식 톱날]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134427, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[163967] = {
				"|cffa335ee|Hitem:163967::::::::120:262::::::|h[슈터프의 측정창]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1097922, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[160131] = {
				"|cff1eff00|Hitem:160131::::::::120:262::::::|h[브루토사우루스가죽 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[170489] = {
				"|cffffffff|Hitem:170489::::::::120:577::::::|h[마디바스의 손수 만든 손가방]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133644, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169594] = {
				"|cff1eff00|Hitem:169594::::::::120:577::::::|h[녹으로 뒤덮인 원반]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132999, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169850] = {
				"|cff0070dd|Hitem:169850::::::::120:262::::::|h[미니 아제로스 묶음 상품: 메카곤]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134142, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160132] = {
				"|cff1eff00|Hitem:160132::::::::120:577::::::|h[브루토사우루스가죽 얼굴보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1674415, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[155273] = {
				"|cff0070dd|Hitem:155273::::::::120:262::::::|h[상어이빨 손도끼]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[158598] = {
				"|cff0070dd|Hitem:158598::::::::120:262::::::|h[들끓는 현신의 고리]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1379208, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[163969] = {
				"|cffa335ee|Hitem:163969::::::::120:577::::::|h[아밀튼의 총알투척기]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				985703, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[161028] = {
				"|cff0070dd|Hitem:161028::::::::120:262::::::|h[맹독 악어 가죽바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160133] = {
				"|cff1eff00|Hitem:160133::::::::120:262::::::|h[브루토사우루스가죽 조끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1674413, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158215] = {
				"|cff0070dd|Hitem:158215::::::::120:262::::::|h[휘리릭날개의 깃털]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103843, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159494] = {
				"|cff1eff00|Hitem:159494::::::::120:262::::::|h[윈터세일 연발 석궁]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1695549, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[168062] = {
				"|cff0070dd|Hitem:168062::::::::120:577::::::|h[도면: 녹슨나사 축음기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158856] = {
				"|cff9d9d9d|Hitem:158856::::::::120:262::::::|h[거대한 개구리 다리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237396, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158857] = {
				"|cff9d9d9d|Hitem:158857::::::::120:262::::::|h[타락하지 않은 버들]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135645, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160136] = {
				"|cff1eff00|Hitem:160136::::::::120:577::::::|h[황금 도시 인장 반지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391713, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[158218] = {
				"|cff0070dd|Hitem:158218::::::::120:577::::::|h[다달리아의 날개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103910, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159497] = {
				"|cff1eff00|Hitem:159497::::::::120:262::::::|h[심연지기 발화총]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1773651, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[168832] = {
				"|cffa335ee|Hitem:168832::::::::120:577::::::|h[전류 발진기]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1405815, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[167042] = {
				"|cff0070dd|Hitem:167042::::::::120:262::::::|h[도면: 고철 덫]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169216] = {
				"|cffffffff|Hitem:169216::::::::120:577::::::|h[은 손칼]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				454059, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163590] = {
				"|cff9d9d9d|Hitem:163590::::::::120:262::::::|h[근심 가득한 로아 조각상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134452, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163718] = {
				"|cff9d9d9d|Hitem:163718::::::::120:262::::::|h[블랙볼의 금지된 뱃노래]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500866, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158859] = {
				"|cff9d9d9d|Hitem:158859::::::::120:262::::::|h[톱니 송곳니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518091, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160138] = {
				"|cff1eff00|Hitem:160138::::::::120:577::::::|h[라바사우루스비늘 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163591] = {
				"|cff9d9d9d|Hitem:163591::::::::120:262::::::|h[황금 함대 해도]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237387, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158860] = {
				"|cff9d9d9d|Hitem:158860::::::::120:262::::::|h[숫돌 어금니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518089, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169218] = {
				"|cff0070dd|Hitem:169218::::::::120:577::::::|h[낡고 녹슨 열쇠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134245, -- [4]
				13, -- [5]
				0, -- [6]
			},
			[160139] = {
				"|cff1eff00|Hitem:160139::::::::120:577::::::|h[라바사우루스비늘 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163592] = {
				"|cff9d9d9d|Hitem:163592::::::::120:577::::::|h[의식용 코걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1408444, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163848] = {
				"|cff9d9d9d|Hitem:163848::::::::120:577::::::|h[과다사용 부두 인형]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				458256, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170114] = {
				"|cff1eff00|Hitem:170114::::::::120:577::::::|h[갈고리 철퇴]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2735968, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[154897] = {
				"|cffffffff|Hitem:154897::::::::120:577::::::|h[힘줄 굵은 허릿살]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066020, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[169347] = {
				"|cff0070dd|Hitem:169347::::::::120:577::::::|h[메카곤의 심판]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133866, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169475] = {
				"|cff1eff00|Hitem:169475::::::::120:577::::::|h[따개비가 붙은 금고]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				644388, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163593] = {
				"|cff9d9d9d|Hitem:163593::::::::120:577::::::|h[잔달라 무역풍 지도]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163849] = {
				"|cff9d9d9d|Hitem:163849::::::::120:577::::::|h[나쁜 트롤의 연시]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134332, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170115] = {
				"|cff1eff00|Hitem:170115::::::::120:577::::::|h[거대한 녹빛 발톱]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2997789, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[154898] = {
				"|cffffffff|Hitem:154898::::::::120:577::::::|h[살이 많은 볼깃살]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066012, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[162571] = {
				"|cffffffff|Hitem:162571::::::::120:262::::::|h[눅눅한 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[163850] = {
				"|cff9d9d9d|Hitem:163850::::::::120:577::::::|h[사냥터지기의 피투성이 팔]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				999951, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170116] = {
				"|cff1eff00|Hitem:170116::::::::120:577::::::|h[어둠 깃든 절단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2829897, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[168198] = {
				"|cffffffff|Hitem:168198::::::::120:577::::::|h[맹독 방울]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				132108, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169477] = {
				"|cffa335ee|Hitem:169477::::::::120:577::::::|h[해저 요대]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002873, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[158864] = {
				"|cff9d9d9d|Hitem:158864::::::::120:262::::::|h[끈적거리는 거미줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237431, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163084] = {
				"|cff9d9d9d|Hitem:163084::::::::120:262::::::|h[금도금 커틀라스]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135396, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168327] = {
				"|cffa335ee|Hitem:168327::::::::120:262::::::|h[사슬 작열코일]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1405814, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169478] = {
				"|cffa335ee|Hitem:169478::::::::120:577::::::|h[해저 팔보호구]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002875, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[155284] = {
				"|cff0070dd|Hitem:155284::::::::120:262::::::|h[싸늘한 언덕 강타자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[163852] = {
				"|cffffffff|Hitem:163852::::::::120:577::::::|h[토르톨란 순례자의 두루마리]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1500871, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170118] = {
				"|cff1eff00|Hitem:170118::::::::120:577::::::|h[백인대장의 쇼트소드]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				3004118, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[163085] = {
				"|cff9d9d9d|Hitem:163085::::::::120:577::::::|h[양파 머리띠]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				651595, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160144] = {
				"|cff1eff00|Hitem:160144::::::::120:577::::::|h[라바사우루스비늘 흉갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1690121, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169479] = {
				"|cffa335ee|Hitem:169479::::::::120:577::::::|h[해저 투구]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002878, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[158866] = {
				"|cff9d9d9d|Hitem:158866::::::::120:262::::::|h[기름진 지방 덩어리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				970839, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169224] = {
				"|cffffffff|Hitem:169224::::::::120:577::::::|h[큰 적색 단추]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				986488, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160145] = {
				"|cff1eff00|Hitem:160145::::::::120:577::::::|h[사우리드깃털 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1762573, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169480] = {
				"|cffa335ee|Hitem:169480::::::::120:577::::::|h[해저 가슴보호대]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002876, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[170120] = {
				"|cff1eff00|Hitem:170120::::::::120:577::::::|h[시녀의 긴지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2921481, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[169225] = {
				"|cff1eff00|Hitem:169225::::::::120:577::::::|h[멈추지 않는 초시계]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132995, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169481] = {
				"|cffa335ee|Hitem:169481::::::::120:577::::::|h[해저 망토]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1625010, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[155543] = {
				"|cff0070dd|Hitem:155543::::::::120:262::::::|h[투스카르 고래잡이의 작살]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661331, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[169226] = {
				"|cff0070dd|Hitem:169226::::::::120:577::::::|h[찢어진 악보]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1392954, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160147] = {
				"|cff1eff00|Hitem:160147::::::::120:577::::::|h[사우리드깃털 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1762577, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170505] = {
				"|cffa335ee|Hitem:170505::::::::120:577::::::|h[때 묻은 마나진주 팔찌]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				415050, -- [4]
				0, -- [5]
				0, -- [6]
			},
			[163856] = {
				"|cffffffff|Hitem:163856::::::::120:577::::::|h[고대 순례자의 두루마리통]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				454060, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169227] = {
				"|cffffffff|Hitem:169227::::::::120:577::::::|h[방사능에 노출된 볼트]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133008, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160148] = {
				"|cff1eff00|Hitem:160148::::::::120:577::::::|h[사우리드깃털 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169483] = {
				"|cffa335ee|Hitem:169483::::::::120:577::::::|h[해저 발보호대]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002874, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169611] = {
				"|cff1eff00|Hitem:169611::::::::120:577::::::|h[조제법: 진모래말미꽃]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[158870] = {
				"|cff9d9d9d|Hitem:158870::::::::120:262::::::|h[털북숭이 털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134352, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169228] = {
				"|cff1eff00|Hitem:169228::::::::120:577::::::|h[위험한 용기]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237030, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160149] = {
				"|cff1eff00|Hitem:160149::::::::120:262::::::|h[사우리드깃털 의복]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				1762576, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169484] = {
				"|cffa335ee|Hitem:169484::::::::120:577::::::|h[해저 어깨덮개]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002881, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169612] = {
				"|cffffffff|Hitem:169612::::::::120:577::::::|h[도안: 오스미나이트 광맥]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[154779] = {
				"|cff9d9d9d|Hitem:154779::::::::120:577::::::|h[파열된 판금 디딤장화]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_FEET", -- [3]
				132589, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169229] = {
				"|cffffffff|Hitem:169229::::::::120:577::::::|h[배기관 향료]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133020, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160150] = {
				"|cff1eff00|Hitem:160150::::::::120:577::::::|h[사우리드깃털 발보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1762574, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169485] = {
				"|cffa335ee|Hitem:169485::::::::120:577::::::|h[해저 건틀릿]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002877, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169613] = {
				"|cffffffff|Hitem:169613::::::::120:577::::::|h[도안: 오스미나이트 융기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[162580] = {
				"|cffffffff|Hitem:162580::::::::120:262::::::|h[색 바랜 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158872] = {
				"|cff9d9d9d|Hitem:158872::::::::120:577::::::|h[불안정한 정수]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132867, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169230] = {
				"|cffffffff|Hitem:169230::::::::120:577::::::|h[반사의 철판]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133022, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160151] = {
				"|cff1eff00|Hitem:160151::::::::120:577::::::|h[사우리드깃털 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1762580, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[155164] = {
				"|cff0070dd|Hitem:155164::::::::120:577::::::|h[녹주석 파도 큰망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1698804, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162581] = {
				"|cffffffff|Hitem:162581::::::::120:262::::::|h[누렇게 변한 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158745] = {
				"|cff9d9d9d|Hitem:158745::::::::120:577::::::|h[영롱한 비늘]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				642723, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169231] = {
				"|cff0070dd|Hitem:169231::::::::120:577::::::|h[시각 효과 무효화 드라이브]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				321487, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169359] = {
				"|cff0070dd|Hitem:169359::::::::120:577::::::|h[날라아다의 후손]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027953, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[158874] = {
				"|cff9d9d9d|Hitem:158874::::::::120:262::::::|h[부글거리는 증기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132837, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169232] = {
				"|cffffffff|Hitem:169232::::::::120:577::::::|h[미작동 폭발통]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1405814, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160153] = {
				"|cff1eff00|Hitem:160153::::::::120:262::::::|h[폭풍제련사 가슴갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1672317, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158363] = {
				"|cff0070dd|Hitem:158363::::::::120:262::::::|h[거미털 머리장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1698807, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169872] = {
				"|cff0070dd|Hitem:169872::::::::120:262::::::|h[무쇠파도 금고 열쇠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				136058, -- [4]
				13, -- [5]
				0, -- [6]
			},
			[167059] = {
				"|cff1eff00|Hitem:167059::::::::120:577::::::|h[미끼]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				350570, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169233] = {
				"|cff1eff00|Hitem:169233::::::::120:577::::::|h[무한 회전 용수철]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				134065, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169361] = {
				"|cff0070dd|Hitem:169361::::::::120:577::::::|h[단도이빨 광포어]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2564610, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[170512] = {
				"|cffffffff|Hitem:170512::::::::120:577::::::|h[하급 해저 비전수정]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1033170, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[162584] = {
				"|cffffffff|Hitem:162584::::::::120:262::::::|h[그을린 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169873] = {
				"|cff0070dd|Hitem:169873::::::::120:262::::::|h[기계 보급품 열쇠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				348541, -- [4]
				13, -- [5]
				0, -- [6]
			},
			[163096] = {
				"|cff9d9d9d|Hitem:163096::::::::120:262::::::|h[납유리 손거울]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				794852, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160155] = {
				"|cff1eff00|Hitem:160155::::::::120:577::::::|h[폭풍제련사 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159260] = {
				"|cff1eff00|Hitem:159260::::::::120:262::::::|h[뾰족털 큰망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1733694, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154273] = {
				"|cff0070dd|Hitem:154273::::::::120:262::::::|h[바위막이 가슴보호갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1727710, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166805] = {
				"|cff1eff00|Hitem:166805::::::::120:577::::::|h[피에 젖은 초대장]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133675, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163097] = {
				"|cff9d9d9d|Hitem:163097::::::::120:577::::::|h[조각한 토끼 입상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716879, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160156] = {
				"|cff1eff00|Hitem:160156::::::::120:262::::::|h[폭풍제련사 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1672319, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160924] = {
				"|cff9d9d9d|Hitem:160924::::::::120:262::::::|h[오래된 새긴자국 검]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPON", -- [3]
				135643, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[169236] = {
				"|cff1eff00|Hitem:169236::::::::120:577::::::|h[걸쇠와 자물쇠 연결 장치]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1405812, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160157] = {
				"|cff1eff00|Hitem:160157::::::::120:577::::::|h[폭풍제련사 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1672320, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158751] = {
				"|cff9d9d9d|Hitem:158751::::::::120:577::::::|h[헝클어진 가죽]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134363, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169237] = {
				"|cffffffff|Hitem:169237::::::::120:577::::::|h[고동치는 대리석]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057562, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[159519] = {
				"|cff1eff00|Hitem:159519::::::::120:262::::::|h[강철문장 나이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720215, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[158752] = {
				"|cff9d9d9d|Hitem:158752::::::::120:262::::::|h[잘린 발]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1509634, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160926] = {
				"|cff9d9d9d|Hitem:160926::::::::120:577::::::|h[부서진 철곤봉]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				133476, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[168215] = {
				"|cffffffff|Hitem:168215::::::::120:577::::::|h[기계 장치 조립체]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				986486, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169366] = {
				"|cff0070dd|Hitem:169366::::::::120:577::::::|h[꾸물이]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2763647, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[159264] = {
				"|cff1eff00|Hitem:159264::::::::120:262::::::|h[어스름 단망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1726328, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159520] = {
				"|cff1eff00|Hitem:159520::::::::120:262::::::|h[산호껍질 단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720215, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[163740] = {
				"|cff0070dd|Hitem:163740::::::::120:262::::::|h[드러스트 의식용 나이프]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				940537, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169239] = {
				"|cff0070dd|Hitem:169239::::::::120:577::::::|h[알 수 없는 큐브]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2000858, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169495] = {
				"|cffa335ee|Hitem:169495::::::::120:577::::::|h[조제법: 최상급 민첩의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[159521] = {
				"|cff1eff00|Hitem:159521::::::::120:262::::::|h[조선소 단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720214, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[168217] = {
				"|cffffffff|Hitem:168217::::::::120:577::::::|h[경화 용수철]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134065, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160161] = {
				"|cff1eff00|Hitem:160161::::::::120:577::::::|h[부정한 하늘망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1729479, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169496] = {
				"|cffa335ee|Hitem:169496::::::::120:577::::::|h[조제법: 최상급 강철피부 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[159522] = {
				"|cff1eff00|Hitem:159522::::::::120:262::::::|h[사슴심장 나이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720214, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[163742] = {
				"|cff0070dd|Hitem:163742::::::::120:577::::::|h[심장파멸 흑마법서]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2101967, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160929] = {
				"|cff9d9d9d|Hitem:160929::::::::120:262::::::|h[깨진 대포 망치]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				133049, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[169241] = {
				"|cffffffff|Hitem:169241::::::::120:262::::::|h[가문의 장신구]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133299, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160162] = {
				"|cff1eff00|Hitem:160162::::::::120:577::::::|h[모래정찰병 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1674412, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169497] = {
				"|cffa335ee|Hitem:169497::::::::120:577::::::|h[조제법: 최상급 지능의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[169370] = {
				"|cff0070dd|Hitem:169370::::::::120:577::::::|h[비늘떼 히드라]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				463493, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169498] = {
				"|cffa335ee|Hitem:169498::::::::120:577::::::|h[조제법: 최상급 체력의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[168603] = {
				"|cffa335ee|Hitem:168603::::::::120:577::::::|h[안식 없는 영혼의 망토]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2912996, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159524] = {
				"|cff1eff00|Hitem:159524::::::::120:262::::::|h[함선좌초자 나이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720213, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[167836] = {
				"|cff0070dd|Hitem:167836::::::::120:577::::::|h[도면: 송사리 통조림]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154793] = {
				"|cff9d9d9d|Hitem:154793::::::::120:577::::::|h[실밥이 풀린 천 아미스]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				135040, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169371] = {
				"|cff0070dd|Hitem:169371::::::::120:577::::::|h[머르글]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3004140, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169499] = {
				"|cffa335ee|Hitem:169499::::::::120:577::::::|h[조제법: 최상급 힘의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[158758] = {
				"|cff9d9d9d|Hitem:158758::::::::120:577::::::|h[로열젤리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500971, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162978] = {
				"|cff9d9d9d|Hitem:162978::::::::120:577::::::|h[혈마법 의식용 접시]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133748, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160165] = {
				"|cff1eff00|Hitem:160165::::::::120:577::::::|h[모래정찰병 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161444] = {
				"|cff0070dd|Hitem:161444::::::::120:262::::::|h[얼어붙은 갈퀴깃털 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1698809, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154411] = {
				"|cff0070dd|Hitem:154411::::::::120:577::::::|h[블라로스 라이플]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1719413, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[158759] = {
				"|cff9d9d9d|Hitem:158759::::::::120:262::::::|h[피가 밴 주머니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134343, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162979] = {
				"|cff9d9d9d|Hitem:162979::::::::120:262::::::|h[그랄이 아낀 아스트롤라베]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				254118, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169373] = {
				"|cff0070dd|Hitem:169373::::::::120:577::::::|h[염수석 해초정령]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				960692, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[158760] = {
				"|cff9d9d9d|Hitem:158760::::::::120:262::::::|h[지느러미줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134882, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162980] = {
				"|cff9d9d9d|Hitem:162980::::::::120:262::::::|h[금빛 항해실 타래]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				348562, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169246] = {
				"|cffffffff|Hitem:169246::::::::120:262::::::|h[이상한 양념을 친 고기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1046249, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169374] = {
				"|cff0070dd|Hitem:169374::::::::120:577::::::|h[피어나는 해초정령]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				960692, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169886] = {
				"|cff0070dd|Hitem:169886::::::::120:577::::::|h[분무로봇 0D]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2735924, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160935] = {
				"|cff9d9d9d|Hitem:160935::::::::120:577::::::|h[역발하는 나팔총]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				135616, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[169247] = {
				"|cffffffff|Hitem:169247::::::::120:262::::::|h[투척용 돌]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1044087, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169375] = {
				"|cff0070dd|Hitem:169375::::::::120:577::::::|h[산호 덩굴손]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027890, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[154798] = {
				"|cff9d9d9d|Hitem:154798::::::::120:577::::::|h[바스러지는 사슬 갑옷]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_CHEST", -- [3]
				132627, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169248] = {
				"|cffffffff|Hitem:169248::::::::120:262::::::|h[망가진 덧신]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				132579, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169376] = {
				"|cff0070dd|Hitem:169376::::::::120:577::::::|h[새끼 뱀장어]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133898, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160937] = {
				"|cff9d9d9d|Hitem:160937::::::::120:577::::::|h[화살 박힌 아이기스]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_SHIELD", -- [3]
				134955, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[169249] = {
				"|cffffffff|Hitem:169249::::::::120:262::::::|h[상어이빨 목걸이]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				338666, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160170] = {
				"|cff1eff00|Hitem:160170::::::::120:577::::::|h[메마른 짐마차 고리]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391713, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161034] = {
				"|cff0070dd|Hitem:161034::::::::120:577::::::|h[천둥울음 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[153713] = {
				"|cff1eff00|Hitem:153713::::::::120:577::::::|h[강력한 쿠빌라인]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1990981, -- [4]
				3, -- [5]
				6, -- [6]
			},
			[155055] = {
				"|cff0070dd|Hitem:155055::::::::120:262::::::|h[영혼저주 집행자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				948427, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[168099] = {
				"|cffffffff|Hitem:168099::::::::120:577::::::|h[깊은산호 주머니]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				960695, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169250] = {
				"|cffffffff|Hitem:169250::::::::120:262::::::|h[조잡한 식기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				794853, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160171] = {
				"|cff1eff00|Hitem:160171::::::::120:577::::::|h[뼈다귀청소부 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163951] = {
				"|cffa335ee|Hitem:163951::::::::120:577::::::|h[성인군자 사령관의 허리띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				529876, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159593] = {
				"|cff1eff00|Hitem:159593::::::::120:262::::::|h[파도술사 커틀라스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729265, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[170199] = {
				"|cff0070dd|Hitem:170199::::::::120:577::::::|h[잔지르 무기 선반]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2735968, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[155568] = {
				"|cff0070dd|Hitem:155568::::::::120:262::::::|h[돌풍바람 풍경]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				458244, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160152] = {
				"|cff1eff00|Hitem:160152::::::::120:262::::::|h[사우리드깃털 손목싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169123] = {
				"|cff9d9d9d|Hitem:169123::::::::120:577::::::|h[기능성 조작전환기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1888317, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169251] = {
				"|cffffffff|Hitem:169251::::::::120:262::::::|h[고대 벌레]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				516338, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160172] = {
				"|cff1eff00|Hitem:160172::::::::120:577::::::|h[뼈다귀청소부 손목보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[155381] = {
				"|cff0070dd|Hitem:155381::::::::120:262::::::|h[바다가름 선장의 사파이어 반지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1048292, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159204] = {
				"|cff1eff00|Hitem:159204::::::::120:577::::::|h[뾰족털 두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1733697, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169124] = {
				"|cff9d9d9d|Hitem:169124::::::::120:577::::::|h[장식용 뱅글톱니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				2437246, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163717] = {
				"|cff9d9d9d|Hitem:163717::::::::120:577::::::|h[조세푸스의 금지된 뱃노래]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500866, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[170475] = {
				"|cff1eff00|Hitem:170475::::::::120:577::::::|h[마디바스의 차원 차압 창작품]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_BAG", -- [3]
				134430, -- [4]
				1, -- [5]
				0, -- [6]
			},
			[170147] = {
				"|cff1eff00|Hitem:170147::::::::120:577::::::|h[페인트 통: 고블린 초록]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				463860, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169252] = {
				"|cffffffff|Hitem:169252::::::::120:262::::::|h[공명의 진주]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				464023, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160173] = {
				"|cff1eff00|Hitem:160173::::::::120:262::::::|h[뼈다귀청소부 손보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163090] = {
				"|cff9d9d9d|Hitem:163090::::::::120:577::::::|h[경화 연기잡초 상자]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134186, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154853] = {
				"|cff1eff00|Hitem:154853::::::::120:577::::::|h[진홍숲 수도두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1733697, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168741] = {
				"|cffa335ee|Hitem:168741::::::::120:577::::::|h[강인한 정제 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[167846] = {
				"|cff0070dd|Hitem:167846::::::::120:262::::::|h[도면: 기계 간식]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163932] = {
				"|cffa335ee|Hitem:163932::::::::120:262::::::|h[늑대모피 큰망토]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1589459, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169125] = {
				"|cff9d9d9d|Hitem:169125::::::::120:577::::::|h[음파 나사못]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134069, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169253] = {
				"|cffffffff|Hitem:169253::::::::120:262::::::|h[조개뿔]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1498844, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160174] = {
				"|cff1eff00|Hitem:160174::::::::120:262::::::|h[뼈다귀청소부 발등덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[162664] = {
				"|cff9d9d9d|Hitem:162664::::::::120:262::::::|h[움푹 파인 흉갑]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132738, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168303] = {
				"|cffffffff|Hitem:168303::::::::120:577::::::|h[질긴 옆구리살]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				3007465, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[159535] = {
				"|cff1eff00|Hitem:159535::::::::120:577::::::|h[파도술사 철퇴]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1733923, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[167847] = {
				"|cff0070dd|Hitem:167847::::::::120:577::::::|h[도면: 안전보증 순간이동기: 메카곤]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154774] = {
				"|cff9d9d9d|Hitem:154774::::::::120:262::::::|h[갈라진 생가죽 바지]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_LEGS", -- [3]
				134582, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169126] = {
				"|cff9d9d9d|Hitem:169126::::::::120:577::::::|h[과충전 그래픽 톱니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				321487, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160176] = {
				"|cff1eff00|Hitem:160176::::::::120:577::::::|h[뼈다귀청소부 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1690124, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169382] = {
				"|cff0070dd|Hitem:169382::::::::120:262::::::|h[잊혀진 악력로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1521022, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[168487] = {
				"|cffffffff|Hitem:168487::::::::120:577::::::|h[진모래말미꽃]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2563958, -- [4]
				7, -- [5]
				9, -- [6]
			},
			[163946] = {
				"|cffa335ee|Hitem:163946::::::::120:577::::::|h[가영의 온화한 발걸음]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				132556, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168743] = {
				"|cffa335ee|Hitem:168743::::::::120:577::::::|h[강인한 능률적 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[160175] = {
				"|cff1eff00|Hitem:160175::::::::120:577::::::|h[뼈다귀청소부 보호모]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1690123, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[152631] = {
				"|cffffffff|Hitem:152631::::::::120:577::::::|h[빙해 고기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066003, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[169127] = {
				"|cff9d9d9d|Hitem:169127::::::::120:577::::::|h[맛있는 냄새가 나는 기름]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135447, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169255] = {
				"|cffffffff|Hitem:169255::::::::120:262::::::|h[빨간 털 뭉치]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237421, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161199] = {
				"|cff9d9d9d|Hitem:161199::::::::120:262::::::|h[은판 술잔]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132790, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163036] = {
				"|cffffffff|Hitem:163036::::::::120:262::::::|h[광택나는 애완동물 부적]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2004597, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159839] = {
				"|cffffffff|Hitem:159839::::::::120:262::::::|h[거미줄]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237430, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168744] = {
				"|cffa335ee|Hitem:168744::::::::120:577::::::|h[최적화된 능률적 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[158224] = {
				"|cff0070dd|Hitem:158224::::::::120:262::::::|h[폭풍의 약병]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				134800, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[158770] = {
				"|cff9d9d9d|Hitem:158770::::::::120:262::::::|h[끈끈한 어란]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1387651, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154806] = {
				"|cff1eff00|Hitem:154806::::::::120:262::::::|h[토르가껍질 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1672317, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169692] = {
				"|cff1eff00|Hitem:169692::::::::120:577::::::|h[음반: 놈리건의 승리]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161200] = {
				"|cff9d9d9d|Hitem:161200::::::::120:262::::::|h[눈물방울 진주]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237370, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162666] = {
				"|cff9d9d9d|Hitem:162666::::::::120:262::::::|h[찢어진 가방]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133656, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162660] = {
				"|cff9d9d9d|Hitem:162660::::::::120:262::::::|h[빛나는 방패]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				454049, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168745] = {
				"|cffa335ee|Hitem:168745::::::::120:577::::::|h[최적화된 유효 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[169429] = {
				"|cff1eff00|Hitem:169429::::::::120:577::::::|h[파도분쇄 손목보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2973479, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163952] = {
				"|cffa335ee|Hitem:163952::::::::120:577::::::|h[오프레스쿠의 화려한 손길]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				367889, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154807] = {
				"|cff1eff00|Hitem:154807::::::::120:262::::::|h[토르가껍질 분쇄장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169257] = {
				"|cffffffff|Hitem:169257::::::::120:262::::::|h[이빠진 룬]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134417, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161201] = {
				"|cff9d9d9d|Hitem:161201::::::::120:262::::::|h[인어의 망원경]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				458243, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168490] = {
				"|cff0070dd|Hitem:168490::::::::120:262::::::|h[도면: 프로토콜 이전 장치]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154851] = {
				"|cff1eff00|Hitem:154851::::::::120:262::::::|h[진홍숲 짧은바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1733698, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168746] = {
				"|cffa335ee|Hitem:168746::::::::120:577::::::|h[최적화된 적응성 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[161047] = {
				"|cff0070dd|Hitem:161047::::::::120:577::::::|h[암흑 바람 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[155618] = {
				"|cff9d9d9d|Hitem:155618::::::::120:262::::::|h[버려진 허물]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134306, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169130] = {
				"|cff9d9d9d|Hitem:169130::::::::120:577::::::|h[휘어진 맞물림톱니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134064, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163089] = {
				"|cff9d9d9d|Hitem:163089::::::::120:577::::::|h[오랜 시간 막힌 배출관]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134374, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161202] = {
				"|cff9d9d9d|Hitem:161202::::::::120:262::::::|h[잘 닦인 놋쇠 육분의]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716858, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168491] = {
				"|cff0070dd|Hitem:168491::::::::120:262::::::|h[도면: 개인용 시간 재배열기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158844] = {
				"|cff9d9d9d|Hitem:158844::::::::120:577::::::|h[반짝먼지]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463877, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168747] = {
				"|cffa335ee|Hitem:168747::::::::120:577::::::|h[고성능 적응성 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[169355] = {
				"|cff1eff00|Hitem:169355::::::::120:577::::::|h[딱딱가시 바늘게]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1508493, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[159198] = {
				"|cff1eff00|Hitem:159198::::::::120:262::::::|h[소금물 작업장 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1727709, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154809] = {
				"|cff1eff00|Hitem:154809::::::::120:262::::::|h[토르가껍질 보호모]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1672319, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163092] = {
				"|cff9d9d9d|Hitem:163092::::::::120:262::::::|h[수놓인 매사냥 두건]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237038, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161203] = {
				"|cff9d9d9d|Hitem:161203::::::::120:577::::::|h[뱃노래 악보]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1506451, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154850] = {
				"|cff1eff00|Hitem:154850::::::::120:577::::::|h[진홍숲 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1733692, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163078] = {
				"|cff9d9d9d|Hitem:163078::::::::120:577::::::|h[반짝이는 귀걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133857, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168748] = {
				"|cffa335ee|Hitem:168748::::::::120:577::::::|h[고성능 정제 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[160126] = {
				"|cff1eff00|Hitem:160126::::::::120:262::::::|h[공포뿔 주름장식 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1672315, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154805] = {
				"|cff9d9d9d|Hitem:154805::::::::120:577::::::|h[썩은나무 육척봉]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				135201, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[154810] = {
				"|cff1eff00|Hitem:154810::::::::120:262::::::|h[토르가껍질 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1672320, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160053] = {
				"|cff0070dd|Hitem:160053::::::::120:262::::::|h[전투 흉터 증강의 룬]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				840006, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[160181] = {
				"|cff1eff00|Hitem:160181::::::::120:577::::::|h[하늘소환사 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1762577, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163959] = {
				"|cffa335ee|Hitem:163959::::::::120:577::::::|h[씽의 자동회전 단도]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1966587, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[170112] = {
				"|cff1eff00|Hitem:170112::::::::120:577::::::|h[파도분쇄 장창]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2735992, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[168749] = {
				"|cffa335ee|Hitem:168749::::::::120:577::::::|h[고성능 유효 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[159756] = {
				"|cff9d9d9d|Hitem:159756::::::::120:577::::::|h[고갈된 아제라이트]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237007, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158775] = {
				"|cff9d9d9d|Hitem:158775::::::::120:577::::::|h[꾸덕한 벌집밀랍]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500915, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154811] = {
				"|cff1eff00|Hitem:154811::::::::120:262::::::|h[토르가껍질 어깨보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1672321, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168358] = {
				"|cffa335ee|Hitem:168358::::::::120:577::::::|h[물속에 잠긴 자의 가슴보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CHEST", -- [3]
				2909753, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168366] = {
				"|cffa335ee|Hitem:168366::::::::120:577::::::|h[해일잠복자의 철갑투구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HEAD", -- [3]
				2901583, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163954] = {
				"|cffa335ee|Hitem:163954::::::::120:577::::::|h[오스웨인의 냉정한 수호 방패]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHIELD", -- [3]
				510886, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[158813] = {
				"|cff9d9d9d|Hitem:158813::::::::120:262::::::|h[소시지 껍질]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237412, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168750] = {
				"|cffa335ee|Hitem:168750::::::::120:577::::::|h[다목적 정제 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[169122] = {
				"|cff9d9d9d|Hitem:169122::::::::120:577::::::|h[지브롤티안 몽키스패너]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134520, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159799] = {
				"|cff1eff00|Hitem:159799::::::::120:262::::::|h[윈터세일 보루 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723691, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[154812] = {
				"|cff1eff00|Hitem:154812::::::::120:262::::::|h[토르가껍질 전쟁장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160182] = {
				"|cff1eff00|Hitem:160182::::::::120:262::::::|h[하늘소환사 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161206] = {
				"|cff9d9d9d|Hitem:161206::::::::120:577::::::|h[빛바랜 보물 지도]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237384, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169372] = {
				"|cff0070dd|Hitem:169372::::::::120:577::::::|h[어린 죽음지느러미 멀록]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				970832, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[163087] = {
				"|cff9d9d9d|Hitem:163087::::::::120:262::::::|h[핏빛 오렌지가 든 가방]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				915544, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168751] = {
				"|cffa335ee|Hitem:168751::::::::120:577::::::|h[다목적 유효 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[169426] = {
				"|cff1eff00|Hitem:169426::::::::120:577::::::|h[파도분쇄 경갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2966770, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170094] = {
				"|cffa335ee|Hitem:170094::::::::120:577::::::|h[사원 수호자의 사브르]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				3004118, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[169135] = {
				"|cff9d9d9d|Hitem:169135::::::::120:577::::::|h[왜곡된 충격 흡수기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134518, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154848] = {
				"|cff1eff00|Hitem:154848::::::::120:262::::::|h[심장파멸 큰망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1698804, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161207] = {
				"|cff9d9d9d|Hitem:161207::::::::120:262::::::|h[제독의 흑럼주]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134758, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158338] = {
				"|cff0070dd|Hitem:158338::::::::120:262::::::|h[날쌘여행 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[152546] = {
				"|cffffffff|Hitem:152546::::::::120:577::::::|h[줄돔]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057313, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[168752] = {
				"|cffa335ee|Hitem:168752::::::::120:577::::::|h[다목적 능률적 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[158650] = {
				"|cff0070dd|Hitem:158650::::::::120:262::::::|h[바다스컬지 대날검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1722409, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[158778] = {
				"|cff9d9d9d|Hitem:158778::::::::120:577::::::|h[점액질 촉수]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134895, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154814] = {
				"|cff1eff00|Hitem:154814::::::::120:262::::::|h[늪 추적자의 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2055323, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160185] = {
				"|cff1eff00|Hitem:160185::::::::120:577::::::|h[하늘소환사 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1762580, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169392] = {
				"|cff0070dd|Hitem:169392::::::::120:262::::::|h[뼈도독]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027842, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[170093] = {
				"|cffa335ee|Hitem:170093::::::::120:577::::::|h[티르마르의 대검]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2835966, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[170091] = {
				"|cffa335ee|Hitem:170091::::::::120:577::::::|h[결의술사의 미늘창]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2735992, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[159540] = {
				"|cff1eff00|Hitem:159540::::::::120:262::::::|h[산호껍질 망치]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[168370] = {
				"|cffa335ee|Hitem:168370::::::::120:577::::::|h[고물더미 동그랑쇠 열쇠]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2902998, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[169169] = {
				"|cff0070dd|Hitem:169169::::::::120:577::::::|h[도면: 파란색 분무로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154815] = {
				"|cff1eff00|Hitem:154815::::::::120:577::::::|h[고름뿌리 손목띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1674412, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169351] = {
				"|cff1eff00|Hitem:169351::::::::120:577::::::|h[모래집게 둥지추적자]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2027879, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[161209] = {
				"|cff9d9d9d|Hitem:161209::::::::120:262::::::|h[서약단 꿈갈무리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716836, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169393] = {
				"|cff0070dd|Hitem:169393::::::::120:262::::::|h[기계거미 발발로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2493081, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[170096] = {
				"|cff9d9d9d|Hitem:170096::::::::120:577::::::|h[흠뻑 젖은 명가 그림]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134944, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154862] = {
				"|cff1eff00|Hitem:154862::::::::120:262::::::|h[무덤둔덕 코이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1726334, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154808] = {
				"|cff1eff00|Hitem:154808::::::::120:262::::::|h[토르가껍질 철갑허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159803] = {
				"|cff1eff00|Hitem:159803::::::::120:262::::::|h[찬비늘 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723673, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[154816] = {
				"|cff1eff00|Hitem:154816::::::::120:262::::::|h[고름뿌리 성큼장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1674411, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159194] = {
				"|cff1eff00|Hitem:159194::::::::120:262::::::|h[소금물 작업장 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1727712, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161210] = {
				"|cff9d9d9d|Hitem:161210::::::::120:262::::::|h[집에서 만든 어린이용 인형]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716867, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169368] = {
				"|cff0070dd|Hitem:169368::::::::120:577::::::|h[폭풍격노]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				236154, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169168] = {
				"|cff0070dd|Hitem:169168::::::::120:577::::::|h[도면: 초록색 분무로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170196] = {
				"|cff0070dd|Hitem:170196::::::::120:577::::::|h[쉬라케스 경고 표지]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134426, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169350] = {
				"|cff1eff00|Hitem:169350::::::::120:577::::::|h[반짝이는 금강껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2027870, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160167] = {
				"|cff1eff00|Hitem:160167::::::::120:577::::::|h[모래정찰병 튜닉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1674413, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169139] = {
				"|cff9d9d9d|Hitem:169139::::::::120:262::::::|h[막힌 거미줄 직조기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133027, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159219] = {
				"|cff1eff00|Hitem:159219::::::::120:262::::::|h[현자의 영지 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1698808, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161211] = {
				"|cff9d9d9d|Hitem:161211::::::::120:577::::::|h[병 안의 배]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1126431, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159805] = {
				"|cff1eff00|Hitem:159805::::::::120:262::::::|h[산호껍질 방벽 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723673, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[159193] = {
				"|cff1eff00|Hitem:159193::::::::120:262::::::|h[소금물 작업장 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1727707, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169779] = {
				"|cffffffff|Hitem:169779::::::::120:577::::::|h[찌그러진 바위비늘]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1526633, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[155841] = {
				"|cff9d9d9d|Hitem:155841::::::::120:577::::::|h[손상된 조각상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134896, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163897] = {
				"|cff9d9d9d|Hitem:163897::::::::120:577::::::|h[개인 양념 보관함]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133877, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154818] = {
				"|cff1eff00|Hitem:154818::::::::120:577::::::|h[고름뿌리 손아귀]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169167] = {
				"|cff0070dd|Hitem:169167::::::::120:577::::::|h[도면: 주황색 분무로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161212] = {
				"|cff9d9d9d|Hitem:161212::::::::120:577::::::|h[파도예언자의 별자리표]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1519351, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159806] = {
				"|cff1eff00|Hitem:159806::::::::120:262::::::|h[조선소 타지 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723673, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[152543] = {
				"|cffffffff|Hitem:152543::::::::120:577::::::|h[모래 꼬물치]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057315, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[159217] = {
				"|cff1eff00|Hitem:159217::::::::120:262::::::|h[현자의 영지 머리장식]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1698807, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159283] = {
				"|cff1eff00|Hitem:159283::::::::120:262::::::|h[무덤둔덕 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1726328, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158783] = {
				"|cff9d9d9d|Hitem:158783::::::::120:262::::::|h[하얀 비단 깃털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132914, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154819] = {
				"|cff1eff00|Hitem:154819::::::::120:577::::::|h[고름뿌리 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1674415, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169332] = {
				"|cff0070dd|Hitem:169332::::::::120:577::::::|h[수상한 무기물 해수]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132774, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[161213] = {
				"|cff9d9d9d|Hitem:161213::::::::120:262::::::|h[현자의 영지 성가집]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				354719, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169422] = {
				"|cff1eff00|Hitem:169422::::::::120:577::::::|h[파도분쇄 파쇄장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2966766, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154855] = {
				"|cff1eff00|Hitem:154855::::::::120:262::::::|h[진홍숲 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1733699, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159551] = {
				"|cff1eff00|Hitem:159551::::::::120:262::::::|h[파도수호병 마울]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1720432, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[154844] = {
				"|cff1eff00|Hitem:154844::::::::120:577::::::|h[콜레인 경갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1727713, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163112] = {
				"|cff9d9d9d|Hitem:163112::::::::120:577::::::|h[임프의 혓바닥 부적]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				648547, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154820] = {
				"|cff1eff00|Hitem:154820::::::::120:262::::::|h[고름뿌리 웃옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1674413, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168247] = {
				"|cffffffff|Hitem:168247::::::::120:577::::::|h[치악룡 발톱]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134294, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169398] = {
				"|cff1eff00|Hitem:169398::::::::120:577::::::|h[깊은바다 끌신]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2973324, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163113] = {
				"|cff9d9d9d|Hitem:163113::::::::120:262::::::|h[부식된 구리 솥]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				629057, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160447] = {
				"|cff0070dd|Hitem:160447::::::::120:262::::::|h[영혼기둥 등불]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				1723696, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160177] = {
				"|cff1eff00|Hitem:160177::::::::120:577::::::|h[뼈다귀청소부 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1690125, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163111] = {
				"|cff9d9d9d|Hitem:163111::::::::120:262::::::|h[검은돌 고양이 동상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133236, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155843] = {
				"|cff9d9d9d|Hitem:155843::::::::120:577::::::|h[부서질 듯한 의식용 목걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1535082, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155844] = {
				"|cff9d9d9d|Hitem:155844::::::::120:577::::::|h[불안정한 자철광]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135253, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168248] = {
				"|cff0070dd|Hitem:168248::::::::120:262::::::|h[도면: 머머리-371]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169399] = {
				"|cff1eff00|Hitem:169399::::::::120:577::::::|h[깊은바다 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2973328, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159191] = {
				"|cff1eff00|Hitem:159191::::::::120:262::::::|h[소금물 작업장 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1727710, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160140] = {
				"|cff1eff00|Hitem:160140::::::::120:577::::::|h[라바사우루스비늘 성큼장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161599] = {
				"|cff0070dd|Hitem:161599::::::::120:262::::::|h[기계 고양이 발톱]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1730356, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[170188] = {
				"|cff0070dd|Hitem:170188::::::::120:577::::::|h[따개비가 붙은 물건 자루]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133662, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[166970] = {
				"|cff0070dd|Hitem:166970::::::::120:577::::::|h[마력 전지]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2902386, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[154822] = {
				"|cff1eff00|Hitem:154822::::::::120:262::::::|h[고름뿌리 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1674410, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159284] = {
				"|cff1eff00|Hitem:159284::::::::120:262::::::|h[콜레인 단망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1727718, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169400] = {
				"|cff1eff00|Hitem:169400::::::::120:577::::::|h[깊은바다 덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2973329, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161344] = {
				"|cffffffff|Hitem:161344::::::::120:262::::::|h[심연의 조각]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				132885, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160449] = {
				"|cff0070dd|Hitem:160449::::::::120:262::::::|h[유령 복수자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1712022, -- [4]
				2, -- [5]
				9, -- [6]
			},
			[167738] = {
				"|cff1eff00|Hitem:167738::::::::120:577::::::|h[황금빛 바다직물]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2821693, -- [4]
				7, -- [5]
				5, -- [6]
			},
			[154803] = {
				"|cff9d9d9d|Hitem:154803::::::::120:577::::::|h[마모된 큰망치]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				133053, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[166971] = {
				"|cff1eff00|Hitem:166971::::::::120:262::::::|h[고갈된 마력 전지]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2902385, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[154823] = {
				"|cff1eff00|Hitem:154823::::::::120:262::::::|h[새김 뼈 반지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391713, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161208] = {
				"|cff9d9d9d|Hitem:161208::::::::120:262::::::|h[해적의 코담배갑]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132596, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169401] = {
				"|cff1eff00|Hitem:169401::::::::120:577::::::|h[깊은바다 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2973330, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168742] = {
				"|cffa335ee|Hitem:168742::::::::120:577::::::|h[강인한 적응성 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[170193] = {
				"|cff1eff00|Hitem:170193::::::::120:577::::::|h[바다 토템]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				971076, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159214] = {
				"|cff1eff00|Hitem:159214::::::::120:262::::::|h[어스름 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1726336, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169235] = {
				"|cff1eff00|Hitem:169235::::::::120:577::::::|h[혼돈의 용수철 상자]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132997, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154842] = {
				"|cff1eff00|Hitem:154842::::::::120:262::::::|h[콜레인 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1727707, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154824] = {
				"|cff1eff00|Hitem:154824::::::::120:262::::::|h[잘라마르 사슬띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169402] = {
				"|cff1eff00|Hitem:169402::::::::120:577::::::|h[깊은바다 아미스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2973331, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159172] = {
				"|cff1eff00|Hitem:159172::::::::120:262::::::|h[자유지대 웃옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[155609] = {
				"|cff9d9d9d|Hitem:155609::::::::120:262::::::|h[탄력 넘치는 눈알]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237297, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160451] = {
				"|cff0070dd|Hitem:160451::::::::120:577::::::|h[바텐더 꼬챙이]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				132797, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[160168] = {
				"|cff1eff00|Hitem:160168::::::::120:577::::::|h[모래정찰병 어깨가죽]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1674417, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159587] = {
				"|cff1eff00|Hitem:159587::::::::120:262::::::|h[조선소 커틀라스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729266, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[157844] = {
				"|cff9d9d9d|Hitem:157844::::::::120:577::::::|h[무지갯빛 입자]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132872, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170170] = {
				"|cff1eff00|Hitem:170170::::::::120:577::::::|h[발효된 돌연변이 물고기]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				350650, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169419] = {
				"|cff1eff00|Hitem:169419::::::::120:577::::::|h[암초지기 사슬]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2915282, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169403] = {
				"|cff1eff00|Hitem:169403::::::::120:577::::::|h[깊은바다 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2973322, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163093] = {
				"|cff9d9d9d|Hitem:163093::::::::120:577::::::|h[마녀의 의식용 분필]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133751, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160452] = {
				"|cff0070dd|Hitem:160452::::::::120:262::::::|h[염소의 가방]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_BAG", -- [3]
				133646, -- [4]
				1, -- [5]
				0, -- [6]
			},
			[170186] = {
				"|cff1eff00|Hitem:170186::::::::120:577::::::|h[심연 진주]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				463858, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[155593] = {
				"|cff9d9d9d|Hitem:155593::::::::120:262::::::|h[뒤집힌 복장뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133727, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158790] = {
				"|cff9d9d9d|Hitem:158790::::::::120:262::::::|h[납골당 재]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134380, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170171] = {
				"|cff1eff00|Hitem:170171::::::::120:577::::::|h[대왕게 다리]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1508493, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[116415] = {
				"|cffffffff|Hitem:116415::::::::120:262::::::|h[반짝이는 애완동물 부적]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				413584, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169404] = {
				"|cff1eff00|Hitem:169404::::::::120:577::::::|h[깊은바다 소매장식]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2973325, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170172] = {
				"|cff1eff00|Hitem:170172::::::::120:577::::::|h[밝은가시 껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1499541, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[166846] = {
				"|cff1eff00|Hitem:166846::::::::120:262::::::|h[예비 부품]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2915723, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159558] = {
				"|cff1eff00|Hitem:159558::::::::120:577::::::|h[표백된 해골파쇄기]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1692757, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[159265] = {
				"|cff1eff00|Hitem:159265::::::::120:262::::::|h[소금물 작업장 외투]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1727718, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169674] = {
				"|cff1eff00|Hitem:169674::::::::120:577::::::|h[초록 페인트 채운 주머니]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1567722, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[154827] = {
				"|cff1eff00|Hitem:154827::::::::120:577::::::|h[잘라마르 경갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163088] = {
				"|cff9d9d9d|Hitem:163088::::::::120:577::::::|h[정말 평범한 빗자루]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				655994, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169405] = {
				"|cff1eff00|Hitem:169405::::::::120:577::::::|h[미끈껍질 조끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				2902641, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169149] = {
				"|cff9d9d9d|Hitem:169149::::::::120:577::::::|h[닳은 미세-톱니 모양 앞니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518088, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154847] = {
				"|cff1eff00|Hitem:154847::::::::120:577::::::|h[콜레인 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1727709, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170185] = {
				"|cff0070dd|Hitem:170185::::::::120:577::::::|h[온전한 나가 해골]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133719, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[167871] = {
				"|cff0070dd|Hitem:167871::::::::120:577::::::|h[도면: G99.99 땅상어]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158792] = {
				"|cff9d9d9d|Hitem:158792::::::::120:577::::::|h[위산]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132108, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154828] = {
				"|cff1eff00|Hitem:154828::::::::120:262::::::|h[잘라마르 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1690123, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163091] = {
				"|cff9d9d9d|Hitem:163091::::::::120:262::::::|h[보석 박힌 망원경]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133033, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169406] = {
				"|cff1eff00|Hitem:169406::::::::120:577::::::|h[미끈껍질 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2902638, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161350] = {
				"|cffa335ee|Hitem:161350::::::::120:262::::::|h[바람소환사의 간편한 손등싸개]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				2059676, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154821] = {
				"|cff1eff00|Hitem:154821::::::::120:262::::::|h[고름뿌리 어깨덧대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1674417, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[170174] = {
				"|cff1eff00|Hitem:170174::::::::120:577::::::|h[거름 수액괴물]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1500942, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169673] = {
				"|cff1eff00|Hitem:169673::::::::120:577::::::|h[파란 페인트 채운 주머니]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1567722, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169129] = {
				"|cff9d9d9d|Hitem:169129::::::::120:577::::::|h[사랑스럽게 닳은 랜치]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				2437249, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154829] = {
				"|cff1eff00|Hitem:154829::::::::120:262::::::|h[잘라마르 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1690124, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[157842] = {
				"|cff9d9d9d|Hitem:157842::::::::120:262::::::|h[녹슨 장비]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134064, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169407] = {
				"|cff1eff00|Hitem:169407::::::::120:577::::::|h[미끈껍질반장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2902642, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154843] = {
				"|cff1eff00|Hitem:154843::::::::120:262::::::|h[콜레인 철갑투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1727712, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160456] = {
				"|cff0070dd|Hitem:160456::::::::120:262::::::|h[표백된 까마귀깃털 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170184] = {
				"|cff0070dd|Hitem:170184::::::::120:577::::::|h[고대 암초지기 껍질]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				615629, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154475] = {
				"|cff0070dd|Hitem:154475::::::::120:262::::::|h[염소털 손목띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1698803, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158794] = {
				"|cff9d9d9d|Hitem:158794::::::::120:577::::::|h[상아 엄니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				236697, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154830] = {
				"|cff1eff00|Hitem:154830::::::::120:262::::::|h[잘라마르 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1690125, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163790] = {
				"|cff1eff00|Hitem:163790::::::::120:262::::::|h[으스스한 주문]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				134937, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169408] = {
				"|cff1eff00|Hitem:169408::::::::120:577::::::|h[미끈껍질삼각모자]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2902643, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161352] = {
				"|cffa335ee|Hitem:161352::::::::120:262::::::|h[광포한 바람의 가슴보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CHEST", -- [3]
				2021683, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[162000] = {
				"|cff1eff00|Hitem:162000::::::::120:577::::::|h[돼지코]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2114667, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[170176] = {
				"|cff1eff00|Hitem:170176::::::::120:577::::::|h[심해 가오리 날개]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1547467, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163782] = {
				"|cffffffff|Hitem:163782::::::::120:262::::::|h[저주받은 허벅지 고기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134005, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[155598] = {
				"|cff9d9d9d|Hitem:155598::::::::120:262::::::|h[분리된 턱뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237393, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154831] = {
				"|cff1eff00|Hitem:154831::::::::120:262::::::|h[잘라마르 쇠사슬갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1690121, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169482] = {
				"|cffa335ee|Hitem:169482::::::::120:577::::::|h[해저 다리보호구]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002879, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169409] = {
				"|cff1eff00|Hitem:169409::::::::120:577::::::|h[미끈껍질 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2902644, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[162633] = {
				"|cff9d9d9d|Hitem:162633::::::::120:577::::::|h[석화된 밀림 난초]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237578, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160458] = {
				"|cff0070dd|Hitem:160458::::::::120:262::::::|h[깃털처럼 가벼운 고대 끌신]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1698802, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162632] = {
				"|cff9d9d9d|Hitem:162632::::::::120:577::::::|h[화려한 세스랄리스 조각상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237234, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170183] = {
				"|cff1eff00|Hitem:170183::::::::120:577::::::|h[암초지기 껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				959845, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170167] = {
				"|cff1eff00|Hitem:170167::::::::120:577::::::|h[뱀장어 살토막]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				134032, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170177] = {
				"|cff1eff00|Hitem:170177::::::::120:577::::::|h[노출된 생선]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237301, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[154449] = {
				"|cff0070dd|Hitem:154449::::::::120:262::::::|h[파도결속 가슴보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169410] = {
				"|cff1eff00|Hitem:169410::::::::120:577::::::|h[미끈껍질 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2902645, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[170502] = {
				"|cffa335ee|Hitem:170502::::::::120:577::::::|h[물에 젖은 도구상자]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1529271, -- [4]
				0, -- [5]
				0, -- [6]
			},
			[160459] = {
				"|cff0070dd|Hitem:160459::::::::120:577::::::|h[양봉가의 벌침방지 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1698801, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159564] = {
				"|cff1eff00|Hitem:159564::::::::120:262::::::|h[사슴심장 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1694053, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[154833] = {
				"|cff1eff00|Hitem:154833::::::::120:262::::::|h[혈사술 두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1762578, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159820] = {
				"|cff1eff00|Hitem:159820::::::::120:262::::::|h[강철문장 초롱]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				1723696, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[170178] = {
				"|cff1eff00|Hitem:170178::::::::120:577::::::|h[으뜸 지느러미]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1547460, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[161053] = {
				"|cffffffff|Hitem:161053::::::::120:577::::::|h[짭짤한 바다 크래커]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				646175, -- [4]
				15, -- [5]
				1, -- [6]
			},
			[169411] = {
				"|cff1eff00|Hitem:169411::::::::120:577::::::|h[미끈껍질 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2902637, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169415] = {
				"|cff1eff00|Hitem:169415::::::::120:577::::::|h[암초지기 손싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2915287, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154835] = {
				"|cff1eff00|Hitem:154835::::::::120:262::::::|h[혈사술 다리싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162634] = {
				"|cff9d9d9d|Hitem:162634::::::::120:577::::::|h[고대 나즈마니 주화]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1416740, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155601] = {
				"|cff9d9d9d|Hitem:155601::::::::120:262::::::|h[날카로운 곤충 다리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133571, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[132200] = {
				"|cff9d9d9d|Hitem:132200::::::::120:577::::::|h[잿빛 반지]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				803856, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[154834] = {
				"|cff1eff00|Hitem:154834::::::::120:262::::::|h[혈사술 손장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1762577, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161100] = {
				"|cff0070dd|Hitem:161100::::::::120:577::::::|h[마력 깃든 잿가루 요대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169412] = {
				"|cff1eff00|Hitem:169412::::::::120:577::::::|h[미끈껍질 팔보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2902639, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161356] = {
				"|cffa335ee|Hitem:161356::::::::120:262::::::|h[깃털장식 풍력 벼슬]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HEAD", -- [3]
				1991836, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168645] = {
				"|cffffffff|Hitem:168645::::::::120:577::::::|h[촉촉한 살코기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				3007464, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[170182] = {
				"|cff0070dd|Hitem:170182::::::::120:577::::::|h[전기비늘 보호막]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				237456, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160461] = {
				"|cff0070dd|Hitem:160461::::::::120:262::::::|h[두꺼운 공룡가죽 바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1733698, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168155] = {
				"|cffffffff|Hitem:168155::::::::120:577::::::|h[미끼]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				350570, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170180] = {
				"|cff1eff00|Hitem:170180::::::::120:577::::::|h[서슬껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				839982, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[161101] = {
				"|cff0070dd|Hitem:161101::::::::120:262::::::|h[뼈 공포의 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169413] = {
				"|cff1eff00|Hitem:169413::::::::120:577::::::|h[암초지기 갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				2915286, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168063] = {
				"|cff0070dd|Hitem:168063::::::::120:262::::::|h[도면: 녹슨나사 맥주 냉장고]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168138] = {
				"|cff0070dd|Hitem:168138::::::::120:577::::::|h[앞선 자의 영혼]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				878157, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169925] = {
				"|cffa335ee|Hitem:169925::::::::120:577::::::|h[뱀비늘 물튀김단화]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2906594, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[155603] = {
				"|cff9d9d9d|Hitem:155603::::::::120:577::::::|h[부슬부슬한 물고기 비늘]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1526611, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169414] = {
				"|cff1eff00|Hitem:169414::::::::120:577::::::|h[암초지기 성큼장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2915283, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154836] = {
				"|cff1eff00|Hitem:154836::::::::120:262::::::|h[혈사술 예복]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				1762576, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170181] = {
				"|cff1eff00|Hitem:170181::::::::120:577::::::|h[해일 파수꾼]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237584, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[166345] = {
				"|cff1eff00|Hitem:166345::::::::120:577::::::|h[잔달라 랩터 알]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				236997, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[168519] = {
				"|cffffffff|Hitem:168519::::::::120:577::::::|h[히드라 비늘]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				443382, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154832] = {
				"|cff1eff00|Hitem:154832::::::::120:262::::::|h[혈사술 장식끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1762573, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154453] = {
				"|cff0070dd|Hitem:154453::::::::120:577::::::|h[박사의 공기쿠션 장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1733692, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169926] = {
				"|cffa335ee|Hitem:169926::::::::120:577::::::|h[살아나는 수호병의 허리띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				2912993, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158801] = {
				"|cff9d9d9d|Hitem:158801::::::::120:262::::::|h[조밀한 톱니 이빨]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518086, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154837] = {
				"|cff1eff00|Hitem:154837::::::::120:262::::::|h[혈사술 발목보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1762574, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170179] = {
				"|cff0070dd|Hitem:170179::::::::120:577::::::|h[치악룡 분비선]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				237414, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159185] = {
				"|cff1eff00|Hitem:159185::::::::120:577::::::|h[여우굴 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168216] = {
				"|cffffffff|Hitem:168216::::::::120:577::::::|h[담금질한 판]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				463887, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160464] = {
				"|cff0070dd|Hitem:160464::::::::120:262::::::|h[공포 언덕 늑대장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1733692, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[132199] = {
				"|cff9d9d9d|Hitem:132199::::::::120:577::::::|h[응고된 지옥피]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1117883, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169927] = {
				"|cffa335ee|Hitem:169927::::::::120:577::::::|h[심연소환사의 죔쇠띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				2909745, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[132204] = {
				"|cff9d9d9d|Hitem:132204::::::::120:577::::::|h[불안정한 끈끈이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463853, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[154838] = {
				"|cff1eff00|Hitem:154838::::::::120:262::::::|h[혈사술 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1762580, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154448] = {
				"|cff0070dd|Hitem:154448::::::::120:262::::::|h[표류하는 메두사의 쇠사슬갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1726332, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169416] = {
				"|cff1eff00|Hitem:169416::::::::120:577::::::|h[암초지기 코이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2915288, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161360] = {
				"|cffa335ee|Hitem:161360::::::::120:262::::::|h[보금자리 수호자의 다리보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				2054630, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166888] = {
				"|cff1eff00|Hitem:166888::::::::120:577::::::|h[싹틔우는 씨앗]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				464030, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[155842] = {
				"|cff9d9d9d|Hitem:155842::::::::120:577::::::|h[\"보존된\" 음식]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132934, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169928] = {
				"|cffa335ee|Hitem:169928::::::::120:577::::::|h[웨케마라의 전쟁장화]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2901579, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159280] = {
				"|cff1eff00|Hitem:159280::::::::120:262::::::|h[진홍숲 외투]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1733694, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154839] = {
				"|cff1eff00|Hitem:154839::::::::120:262::::::|h[혈사술 완장]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169238] = {
				"|cff0070dd|Hitem:169238::::::::120:577::::::|h[변형된 라디오 수신기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1405806, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169417] = {
				"|cff1eff00|Hitem:169417::::::::120:577::::::|h[암초지기 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2915289, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[160159] = {
				"|cff1eff00|Hitem:160159::::::::120:577::::::|h[폭풍제련사 발덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168650] = {
				"|cffffffff|Hitem:168650::::::::120:577::::::|h[바위비늘]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2032177, -- [4]
				7, -- [5]
				6, -- [6]
			},
			[170092] = {
				"|cffa335ee|Hitem:170092::::::::120:577::::::|h[황천춤꾼의 손칼]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2829897, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[169128] = {
				"|cff9d9d9d|Hitem:169128::::::::120:577::::::|h[냉각 가열 부품]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				236869, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169132] = {
				"|cff9d9d9d|Hitem:169132::::::::120:577::::::|h[깨진 회전의]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132998, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154840] = {
				"|cff1eff00|Hitem:154840::::::::120:577::::::|h[콜레인 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1727710, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154845] = {
				"|cff1eff00|Hitem:154845::::::::120:262::::::|h[콜레인 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1727714, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169418] = {
				"|cff1eff00|Hitem:169418::::::::120:577::::::|h[암초지기 어깨받이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2915290, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[152698] = {
				"|cffffffff|Hitem:152698::::::::120:262::::::|h[오염돌 스튜]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387641, -- [4]
				0, -- [5]
				5, -- [6]
			},
			[160467] = {
				"|cff0070dd|Hitem:160467::::::::120:262::::::|h[히드라사냥꾼 다리보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1726335, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[158861] = {
				"|cff9d9d9d|Hitem:158861::::::::120:577::::::|h[질긴 눈자루]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135503, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155608] = {
				"|cff9d9d9d|Hitem:155608::::::::120:262::::::|h[더럽혀진 뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				442733, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154826] = {
				"|cff1eff00|Hitem:154826::::::::120:577::::::|h[잘라마르 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169163] = {
				"|cffa335ee|Hitem:169163::::::::120:577::::::|h[조용한 글라이더]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2620777, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[154825] = {
				"|cff1eff00|Hitem:154825::::::::120:262::::::|h[잘라마르 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159189] = {
				"|cff1eff00|Hitem:159189::::::::120:262::::::|h[여우굴 아미스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1698809, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161363] = {
				"|cffa335ee|Hitem:161363::::::::120:262::::::|h[타닥거리는 분노의 덧신]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2059673, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169675] = {
				"|cff1eff00|Hitem:169675::::::::120:577::::::|h[주황 페인트 채운 주머니]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1567722, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[154458] = {
				"|cff0070dd|Hitem:154458::::::::120:262::::::|h[껍질파괴자 전쟁투구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1727712, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168908] = {
				"|cff0070dd|Hitem:168908::::::::120:577::::::|h[도안: 모험가를 위한 실험용 증강상자]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158806] = {
				"|cff9d9d9d|Hitem:158806::::::::120:262::::::|h[갈고리 갈퀴]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1509625, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170187] = {
				"|cff0070dd|Hitem:170187::::::::120:577::::::|h[그늘비늘]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1526603, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[167077] = {
				"|cff1eff00|Hitem:167077::::::::120:577::::::|h[탐지돌]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				528693, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169420] = {
				"|cff1eff00|Hitem:169420::::::::120:577::::::|h[암초지기 고리]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2915284, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161198] = {
				"|cff9d9d9d|Hitem:161198::::::::120:262::::::|h[늙은 선원의 연감]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133736, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160143] = {
				"|cff1eff00|Hitem:160143::::::::120:262::::::|h[라바사우루스비늘 어깨보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1690125, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169145] = {
				"|cff9d9d9d|Hitem:169145::::::::120:577::::::|h[녹슨 정밀 포착기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133863, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155610] = {
				"|cff9d9d9d|Hitem:155610::::::::120:577::::::|h[뾰족한 쐐기풀]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134439, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154183] = {
				"|cff0070dd|Hitem:154183::::::::120:262::::::|h[보랄러스 선장의 사슬 장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1726330, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163027] = {
				"|cff1eff00|Hitem:163027::::::::120:577::::::|h[도안: 수놓은 심해 가방]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387620, -- [4]
				9, -- [5]
				2, -- [6]
			},
			[158867] = {
				"|cff9d9d9d|Hitem:158867::::::::120:262::::::|h[바늘 같은 부리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133707, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169421] = {
				"|cff1eff00|Hitem:169421::::::::120:577::::::|h[파도분쇄 가슴갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				2966767, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161365] = {
				"|cffa335ee|Hitem:161365::::::::120:262::::::|h[휘감기는 폭풍의 발보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2021679, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160470] = {
				"|cff0070dd|Hitem:160470::::::::120:262::::::|h[무리걸음 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1726331, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154460] = {
				"|cff0070dd|Hitem:154460::::::::120:262::::::|h[보물 수색꾼의 잠수모]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1726334, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169138] = {
				"|cff9d9d9d|Hitem:169138::::::::120:262::::::|h[부서진 인성 모듈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134070, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158808] = {
				"|cff9d9d9d|Hitem:158808::::::::120:262::::::|h[두꺼운 힘줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				645112, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170189] = {
				"|cff0070dd|Hitem:170189::::::::120:262::::::|h[보이지 않는 눈]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1500930, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[154899] = {
				"|cffffffff|Hitem:154899::::::::120:577::::::|h[무식하게 두꺼운 스테이크]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066022, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[159192] = {
				"|cff1eff00|Hitem:159192::::::::120:262::::::|h[소금물 작업장 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1727711, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169369] = {
				"|cff0070dd|Hitem:169369::::::::120:577::::::|h[모래성 정령]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				796636, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[159602] = {
				"|cff1eff00|Hitem:159602::::::::120:262::::::|h[골 오시그 마법봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1697864, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[154461] = {
				"|cff0070dd|Hitem:154461::::::::120:262::::::|h[저주받은 멧돼지가죽 투구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1733697, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163796] = {
				"|cff1eff00|Hitem:163796::::::::120:577::::::|h[새끼 늑대 척추]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133720, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158834] = {
				"|cff9d9d9d|Hitem:158834::::::::120:262::::::|h[윈치 고리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132998, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170190] = {
				"|cff0070dd|Hitem:170190::::::::120:577::::::|h[마디바스의 억제의 가방]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133666, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[161111] = {
				"|cff0070dd|Hitem:161111::::::::120:577::::::|h[습지여왕의 분쇄장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169423] = {
				"|cff1eff00|Hitem:169423::::::::120:577::::::|h[파도분쇄 분쇄장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2966768, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158836] = {
				"|cff9d9d9d|Hitem:158836::::::::120:577::::::|h[날카로운 독침]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237142, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160472] = {
				"|cff0070dd|Hitem:160472::::::::120:577::::::|h[꿀 바른 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1727711, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154817] = {
				"|cff1eff00|Hitem:154817::::::::120:577::::::|h[고름뿌리 짧은바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[152544] = {
				"|cffffffff|Hitem:152544::::::::120:577::::::|h[미끈 고등어]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057316, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[158810] = {
				"|cff9d9d9d|Hitem:158810::::::::120:262::::::|h[웅웅거리는 이슬]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463570, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170191] = {
				"|cff0070dd|Hitem:170191::::::::120:577::::::|h[해골 손]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				615099, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159215] = {
				"|cff1eff00|Hitem:159215::::::::120:262::::::|h[어스름 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1726332, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169424] = {
				"|cff1eff00|Hitem:169424::::::::120:577::::::|h[파도분쇄 머리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2966769, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160178] = {
				"|cff1eff00|Hitem:160178::::::::120:262::::::|h[뼈다귀청소부 속갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1690121, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[160473] = {
				"|cff0070dd|Hitem:160473::::::::120:262::::::|h[버들가시 디딤장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1727708, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169352] = {
				"|cff0070dd|Hitem:169352::::::::120:577::::::|h[진줏빛 반짝껍질]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027919, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[152545] = {
				"|cffffffff|Hitem:152545::::::::120:577::::::|h[광포한 송곳니 청어]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057311, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[160186] = {
				"|cff1eff00|Hitem:160186::::::::120:577::::::|h[하늘소환사 소매장식]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170192] = {
				"|cff1eff00|Hitem:170192::::::::120:577::::::|h[진흙 붕대]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				236155, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159163] = {
				"|cff1eff00|Hitem:159163::::::::120:262::::::|h[애쉬베인 무역회사 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1727714, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169425] = {
				"|cff1eff00|Hitem:169425::::::::120:577::::::|h[깊은바다 로브]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				2973326, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161369] = {
				"|cffa335ee|Hitem:161369::::::::120:262::::::|h[날개 달린 태풍의 손목띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				1991832, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[162673] = {
				"|cff9d9d9d|Hitem:162673::::::::120:262::::::|h[매듭장식 뱃머리 밧줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1119938, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158556] = {
				"|cff0070dd|Hitem:158556::::::::120:262::::::|h[세이렌의 혀]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1508509, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[155615] = {
				"|cff9d9d9d|Hitem:155615::::::::120:577::::::|h[전염성 분뇨]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500940, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[166313] = {
				"|cffffffff|Hitem:166313::::::::120:262::::::|h[도안: 거친 가죽 마갑]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				1, -- [6]
			},
			[169170] = {
				"|cff0070dd|Hitem:169170::::::::120:577::::::|h[도면: 다용도 기계손톱]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163960] = {
				"|cffa335ee|Hitem:163960::::::::120:262::::::|h[불타는 진실의 철퇴]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1113523, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[159196] = {
				"|cff1eff00|Hitem:159196::::::::120:262::::::|h[소금물 작업장 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1727714, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168081] = {
				"|cffffffff|Hitem:168081::::::::120:577::::::|h[염수석 곡괭이]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1064765, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160475] = {
				"|cff0070dd|Hitem:160475::::::::120:262::::::|h[나무절단자 요대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1727707, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160163] = {
				"|cff1eff00|Hitem:160163::::::::120:577::::::|h[모래정찰병 발등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1674411, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168340] = {
				"|cffa335ee|Hitem:168340::::::::120:577::::::|h[나가 의식술사의 어깨덧옷]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2906601, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170066] = {
				"|cff1eff00|Hitem:170066::::::::120:577::::::|h[무두질 기법: 들춤 가죽]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[170194] = {
				"|cff1eff00|Hitem:170194::::::::120:577::::::|h[폭풍 토템]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1020304, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[161205] = {
				"|cff9d9d9d|Hitem:161205::::::::120:262::::::|h[나무 말 조각]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716869, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169427] = {
				"|cff1eff00|Hitem:169427::::::::120:577::::::|h[파도분쇄 어깨철갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2966771, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[162671] = {
				"|cff9d9d9d|Hitem:162671::::::::120:262::::::|h[부러진 석궁]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135535, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160476] = {
				"|cff0070dd|Hitem:160476::::::::120:262::::::|h[안개파도 전쟁장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1727708, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161204] = {
				"|cff9d9d9d|Hitem:161204::::::::120:262::::::|h[기름 낀 유리 안구]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				970832, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158862] = {
				"|cff9d9d9d|Hitem:158862::::::::120:262::::::|h[고대 무덤 티끌]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133852, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170067] = {
				"|cff1eff00|Hitem:170067::::::::120:577::::::|h[무두질 기법: 바위비늘]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[170195] = {
				"|cff0070dd|Hitem:170195::::::::120:577::::::|h[공허술사의 보급품 가방]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133667, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159539] = {
				"|cff1eff00|Hitem:159539::::::::120:262::::::|h[강철문장 곤봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[169428] = {
				"|cff1eff00|Hitem:169428::::::::120:577::::::|h[파도분쇄 죔쇠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2966765, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169356] = {
				"|cff0070dd|Hitem:169356::::::::120:262::::::|h[암흑동굴 악몽게]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1508492, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[168351] = {
				"|cffa335ee|Hitem:168351::::::::120:577::::::|h[바늘장착 어깨보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2913001, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[162651] = {
				"|cff9d9d9d|Hitem:162651::::::::120:262::::::|h[녹슨 사슬]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132507, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[152549] = {
				"|cffffffff|Hitem:152549::::::::120:577::::::|h[붉은꼬리 미꾸라지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057314, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[170068] = {
				"|cff0070dd|Hitem:170068::::::::120:577::::::|h[마디바스의 훌륭한 탈염 주머니]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132825, -- [4]
				0, -- [5]
				5, -- [6]
			},
			[169173] = {
				"|cff0070dd|Hitem:169173::::::::120:577::::::|h[도면: 반중력 추진기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169595] = {
				"|cff1eff00|Hitem:169595::::::::120:577::::::|h[그을린 자료 원반]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133862, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[159199] = {
				"|cff1eff00|Hitem:159199::::::::120:262::::::|h[현자의 영지 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1698804, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162659] = {
				"|cff9d9d9d|Hitem:162659::::::::120:262::::::|h[낡은 철퇴]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133476, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160154] = {
				"|cff1eff00|Hitem:160154::::::::120:262::::::|h[폭풍제련사 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163966] = {
				"|cffa335ee|Hitem:163966::::::::120:577::::::|h[미기 양의 커다란 탑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				615328, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[158863] = {
				"|cff9d9d9d|Hitem:158863::::::::120:577::::::|h[키틴질 외골격]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1499546, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163931] = {
				"|cffa335ee|Hitem:163931::::::::120:262::::::|h[혹사된 경외심의 사슬 고리띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				973881, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169174] = {
				"|cff0070dd|Hitem:169174::::::::120:577::::::|h[도면: 녹슨나사 소형 포탑]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[155271] = {
				"|cff0070dd|Hitem:155271::::::::120:262::::::|h[원숭이의 앞발 절단 도끼]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[159200] = {
				"|cff1eff00|Hitem:159200::::::::120:262::::::|h[뾰족털 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1733693, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163948] = {
				"|cffa335ee|Hitem:163948::::::::120:577::::::|h[모아스의 거친사슬 건틀릿]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				422802, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169363] = {
				"|cff0070dd|Hitem:169363::::::::120:577::::::|h[자수정 연갑달팽이]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2530493, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[159584] = {
				"|cff1eff00|Hitem:159584::::::::120:262::::::|h[찬비늘 사브르]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729266, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[170117] = {
				"|cff1eff00|Hitem:170117::::::::120:577::::::|h[파도결속사의 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				2829934, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[159840] = {
				"|cffa335ee|Hitem:159840::::::::120:262::::::|h[티부의 이글거리는 직검]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				135323, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[170198] = {
				"|cff0070dd|Hitem:170198::::::::120:577::::::|h[영원한 궁전 식기 묶음]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2264901, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[170119] = {
				"|cff1eff00|Hitem:170119::::::::120:577::::::|h[미끈껍질 전투검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2904097, -- [4]
				2, -- [5]
				9, -- [6]
			},
			[169431] = {
				"|cff1eff00|Hitem:169431::::::::120:577::::::|h[암초지기 단망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2915285, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160127] = {
				"|cff1eff00|Hitem:160127::::::::120:577::::::|h[테러닥스가죽 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1672316, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160166] = {
				"|cff1eff00|Hitem:160166::::::::120:577::::::|h[모래정찰병 면갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1674415, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159585] = {
				"|cff1eff00|Hitem:159585::::::::120:262::::::|h[강철문장 검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729266, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[159205] = {
				"|cff1eff00|Hitem:159205::::::::120:262::::::|h[뾰족털 조끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163933] = {
				"|cffa335ee|Hitem:163933::::::::120:577::::::|h[아구아스의 전조 고리]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FINGER", -- [3]
				2000807, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[154854] = {
				"|cff1eff00|Hitem:154854::::::::120:262::::::|h[진홍숲 웃옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159140] = {
				"|cff9d9d9d|Hitem:159140::::::::120:577::::::|h[생기 없는 점토]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134111, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159202] = {
				"|cff1eff00|Hitem:159202::::::::120:262::::::|h[뾰족털 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1733698, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[167012] = {
				"|cff1eff00|Hitem:167012::::::::120:577::::::|h[염수석 곡괭이]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1064765, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169688] = {
				"|cff1eff00|Hitem:169688::::::::120:262::::::|h[음반: 놈리건은 영원하리]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[153710] = {
				"|cff1eff00|Hitem:153710::::::::120:577::::::|h[치명적인 태양돌]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1990980, -- [4]
				3, -- [5]
				5, -- [6]
			},
		},
	},
	["profiles"] = {
		["무시중한디 - 굴단"] = {
		},
		["뉘시빨라마 - 굴단"] = {
		},
	},
}
