
BlueItemInfo3DB = {
	["code"] = "Rt2",
	["py"] = 81.9199142456055,
	["px"] = 8.19223403930664,
	["minimapButton"] = {
		["show"] = false,
	},
}
BlueItemInfo3ItemNameDB = {
}
