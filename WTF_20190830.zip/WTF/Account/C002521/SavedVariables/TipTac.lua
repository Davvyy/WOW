
TipTac_Config = {
	["showUnitTip"] = true,
	["showRealm"] = "show",
	["selfBuffsOnly"] = false,
	["barHeight"] = 6,
	["manaBarColor"] = {
		0.3, -- [1]
		0.55, -- [2]
		0.9, -- [3]
		1, -- [4]
	},
	["rare"] = "%s|r (희귀)",
	["anchorPoint"] = "BOTTOMRIGHT",
	["colReactBack1"] = {
		0.2, -- [1]
		0.2, -- [2]
		0.2, -- [3]
		1, -- [4]
	},
	["backdropEdgeSize"] = 16,
	["worldboss"] = "%s|r (우두머리)",
	["powerBar"] = false,
	["fontFlags"] = "",
	["showAuraCooldown"] = false,
	["colReactBack7"] = {
		0.05, -- [1]
		0.05, -- [2]
		0.05, -- [3]
		1, -- [4]
	},
	["showDebuffs"] = false,
	["powerBarText"] = "value",
	["colReactText1"] = "|cffc0c0c0",
	["healthBarClassColor"] = false,
	["barFontFlags"] = "OUTLINE",
	["tipTacBorderColor"] = {
		1, -- [1]
		0.980392156862745, -- [2]
		0.356862745098039, -- [3]
		1, -- [4]
	},
	["hideTipsInCombat"] = false,
	["classification_rare"] = "%s희귀",
	["colReactBack2"] = {
		0.3, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["optionsBottom"] = 373.999969482422,
	["elite"] = "+%s|r (정예)",
	["colReactText3"] = "|cffff7f00",
	["updateFreq"] = 0.5,
	["manaBar"] = false,
	["gradientColor"] = {
		0.709803921568628, -- [1]
		0.709803921568628, -- [2]
		0.709803921568628, -- [3]
		0.410000026226044, -- [4]
	},
	["fadeTime"] = 0,
	["targetYouText"] = "<<YOU>>",
	["anchorPointUnit"] = "BOTTOMLEFT",
	["itemQualityBorder"] = true,
	["barFontFace"] = "Fonts\\2002.TTF",
	["anchorFrameUnitPoint"] = "BOTTOMLEFT",
	["anchorFrameTipPoint"] = "BOTTOMLEFT",
	["barFontSize"] = 11,
	["classification_elite"] = "%s정예+",
	["showGuild"] = "guild",
	["left"] = 1453.71318230321,
	["gttScale"] = 1,
	["top"] = 247.472551268706,
	["reactColoredBackdrop"] = false,
	["optionsLeft"] = 201.000061035156,
	["modifyFonts"] = false,
	["overrideFade"] = true,
	["colReactBack3"] = {
		0.3, -- [1]
		0.15, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["preFadeTime"] = 0,
	["hideWorldTips"] = true,
	["showTarget"] = "first",
	["reactText"] = false,
	["colReactText2"] = "|cffff0000",
	["gradientTip"] = true,
	["tipBackdropBG"] = "Interface\\Tooltips\\UI-Tooltip-Background",
	["healthBarColor"] = {
		0.192156862745098, -- [1]
		1, -- [2]
		0.23921568627451, -- [3]
		1, -- [4]
	},
	["tipColor"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["colRace"] = "|cffffffff",
	["mouseOffsetX"] = 20,
	["healthBarText"] = "percent",
	["classColoredBorder"] = false,
	["aurasAtBottom"] = false,
	["auraMaxRows"] = 2,
	["colLevel"] = "|cffc0c0c0",
	["mouseOffsetY"] = 10,
	["anchorWorldTipPoint"] = "BOTTOMLEFT",
	["classification_normal"] = "%s",
	["colReactText6"] = "|cff27ff69",
	["colReactText5"] = "|cff00ff00",
	["colSameGuild"] = "|cffff32ff",
	["rareelite"] = "+%s|r (희귀-정예)",
	["classification_worldboss"] = "%s우두머리++",
	["manaBarText"] = "percent",
	["fontSize"] = 12,
	["anchorWorldTipType"] = "mouse",
	["anchorFrameTipType"] = "mouse",
	["showTargetedBy"] = false,
	["anchorTypeUnit"] = "mouse",
	["tipTacColor"] = {
		0, -- [1]
		0, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["showStatus"] = false,
	["classification_rareelite"] = "%s희귀정예+",
	["selfDebuffsOnly"] = false,
	["anchorWorldUnitPoint"] = "BOTTOMLEFT",
	["showBuffs"] = false,
	["backdropInsets"] = 5,
	["anchorType"] = "normal",
	["healthBar"] = true,
	["tipScale"] = 1,
	["showTalents"] = true,
	["colorNameByClass"] = false,
	["barTexture"] = "Interface\\Addons\\mySharedMedia\\statusbar\\Minimalist",
	["auraSize"] = 18,
	["anchorWorldUnitType"] = "mouse",
	["colReactBack4"] = {
		0.3, -- [1]
		0.3, -- [2]
		0, -- [3]
		1, -- [4]
	},
	["tipBorderColor"] = {
		1, -- [1]
		0.929411764705882, -- [2]
		0.32156862745098, -- [3]
		1, -- [4]
	},
	["tipBackdropEdge"] = "Interface\\Tooltips\\UI-Tooltip-Border",
	["colReactBack5"] = {
		0, -- [1]
		0.3, -- [2]
		0.1, -- [3]
		1, -- [4]
	},
	["pvpName"] = false,
	["fontFace"] = "Fonts\\2002.TTF",
	["hookTips"] = true,
	["colReactBack6"] = {
		0, -- [1]
		0, -- [2]
		0.5, -- [3]
		1, -- [4]
	},
	["colReactText7"] = "|cff808080",
	["anchorFrameUnitType"] = "mouse",
	["colReactText4"] = "|cffffff00",
}
