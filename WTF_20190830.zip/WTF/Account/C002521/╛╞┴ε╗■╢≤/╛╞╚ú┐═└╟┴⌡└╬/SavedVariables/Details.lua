
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 157,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007601,
							["damage_from"] = {
							},
							["targets"] = {
								["아호와의증인"] = 138,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 138.007601,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 138.007601,
							["end_time"] = 1559927370,
							["friendlyfire_total"] = 0,
							["nome"] = "역병해골 약탈자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 138,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 138,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 138,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 14,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-3153-530-15-15654-00007A8D82",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927364,
							["damage_taken"] = 0.007601,
							["start_time"] = 1559927347,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003519,
							["on_hold"] = false,
							["damage_from"] = {
								["역병해골 약탈자"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["end_time"] = 1559927370,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003519,
							["spec"] = 269,
							["dps_started"] = false,
							["total"] = 0.003519,
							["classe"] = "MONK",
							["serial"] = "Player-205-075D70FA",
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 138.003519,
							["start_time"] = 1559927370,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 157,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 157,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 157,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["tipo"] = 4,
							["spell_cast"] = {
								[109132] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 157,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1559927347,
				["enemy"] = "역병해골 약탈자",
				["combat_counter"] = 166,
				["playing_solo"] = true,
				["totals"] = {
					138, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 11462.402,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:09:07",
				["end_time"] = 11462.402,
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 157,
				["TotalElapsedCombatTime"] = 11462.402,
				["frags_need_refresh"] = false,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 0.003519,
						}, -- [1]
					},
				},
				["frags"] = {
				},
				["data_fim"] = "02:09:30",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 11439.917,
				["contra"] = "역병해골 약탈자",
				["TimeData"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 156,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007207,
							["damage_from"] = {
								["실버문 수호병"] = true,
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 25,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 25.007207,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927311,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "긴발톱 갈기발 스라소니",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["아호와의증인"] = 25,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 25,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 25,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 25.007207,
							["serial"] = "Creature-0-3153-530-15-15651-00007A9577",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927311,
							["damage_taken"] = 99.007207,
							["start_time"] = 1559927307,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007124,
							["damage_from"] = {
								["긴발톱 갈기발 스라소니"] = true,
							},
							["targets"] = {
								["긴발톱 갈기발 스라소니"] = 51,
							},
							["total"] = 51.007124,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 51.007124,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927311,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 18,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 27,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 27,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 27,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 24,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 24,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 15.3914073627023,
							["custom"] = 0,
							["last_event"] = 1559927310,
							["damage_taken"] = 25.007124,
							["start_time"] = 1559927309,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 156,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 156,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.005948,
							["resource"] = 3.005948,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.005948,
							["total"] = 0.005948,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.005948,
							["last_event"] = 1559927310,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.005948,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 156,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 156,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11439.342,
				["tempo_start"] = 1559927307,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 165,
				["playing_solo"] = true,
				["totals"] = {
					75.993954, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					51, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:08:31",
				["cleu_timeline"] = {
				},
				["enemy"] = "긴발톱 갈기발 스라소니",
				["TotalElapsedCombatTime"] = 11403.739,
				["CombatEndedAt"] = 11403.739,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 51.007124,
						}, -- [1]
					},
				},
				["end_time"] = 11403.739,
				["combat_id"] = 156,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:08:28",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["긴발톱 갈기발 스라소니"] = 1,
				},
				["start_time"] = 11400.105,
				["TimeData"] = {
				},
				["contra"] = "긴발톱 갈기발 스라소니",
			}, -- [2]
			{
				{
					["combatId"] = 155,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002172,
							["damage_from"] = {
								["긴발톱 갈기발 스라소니"] = true,
							},
							["targets"] = {
							},
							["on_hold"] = false,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002172,
							["spec"] = 269,
							["dps_started"] = false,
							["total"] = 0.002172,
							["classe"] = "MONK",
							["serial"] = "Player-205-075D70FA",
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["end_time"] = 1559927302,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 9.002172,
							["start_time"] = 1559927302,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003324,
							["damage_from"] = {
							},
							["targets"] = {
								["아호와의증인"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 9.003324,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927302,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "긴발톱 갈기발 스라소니",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["아호와의증인"] = 9,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 9.003324,
							["serial"] = "Creature-0-3153-530-15-15651-00007A9830",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927292,
							["damage_taken"] = 0.003324,
							["start_time"] = 1559927301,
							["delay"] = 1559927292,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 155,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 155,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 155,
					["tipo"] = 9,
					["_ActorTable"] = {
					},
				}, -- [4]
				{
					["combatId"] = 155,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11398.876,
				["tempo_start"] = 1559927292,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 164,
				["playing_solo"] = true,
				["totals"] = {
					9, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["data_fim"] = "02:08:22",
				["cleu_timeline"] = {
				},
				["enemy"] = "긴발톱 갈기발 스라소니",
				["TotalElapsedCombatTime"] = 11394.359,
				["CombatEndedAt"] = 11394.359,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 0.002172,
						}, -- [1]
					},
				},
				["end_time"] = 11394.359,
				["combat_id"] = 155,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:08:12",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 11384.711,
				["TimeData"] = {
				},
				["contra"] = "긴발톱 갈기발 스라소니",
			}, -- [3]
			{
				{
					["combatId"] = 154,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004028,
							["damage_from"] = {
							},
							["targets"] = {
								["아호와의증인"] = 47,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 47.004028,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927262,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "긴발톱 갈기발 스라소니",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["아호와의증인"] = 47,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 47,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 47,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 47.004028,
							["serial"] = "Creature-0-3153-530-15-15651-00007A9335",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927253,
							["damage_taken"] = 0.004028,
							["start_time"] = 1559927245,
							["delay"] = 1559927241,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002031,
							["damage_from"] = {
								["긴발톱 갈기발 스라소니"] = true,
								["영원노래 뜰지기"] = true,
							},
							["targets"] = {
							},
							["on_hold"] = false,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002031,
							["spec"] = 269,
							["dps_started"] = false,
							["total"] = 0.002031,
							["classe"] = "MONK",
							["serial"] = "Player-205-075D70FA",
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["end_time"] = 1559927262,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 52.002031,
							["start_time"] = 1559927262,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006961,
							["damage_from"] = {
							},
							["targets"] = {
								["아호와의증인"] = 5,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5.006961,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927262,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "영원노래 뜰지기",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["아호와의증인"] = 5,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 5.006961,
							["serial"] = "Creature-0-3153-530-15-15635-00007A921C",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927239,
							["damage_taken"] = 0.006961,
							["start_time"] = 1559927261,
							["delay"] = 1559927239,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 154,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 154,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 154,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["tipo"] = 4,
							["spell_cast"] = {
								[109132] = 2,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 154,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11383.482,
				["tempo_start"] = 1559927233,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 163,
				["playing_solo"] = true,
				["totals"] = {
					52, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["data_fim"] = "02:07:42",
				["cleu_timeline"] = {
				},
				["enemy"] = "긴발톱 갈기발 스라소니",
				["TotalElapsedCombatTime"] = 11354.304,
				["CombatEndedAt"] = 11354.304,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 0.002031,
						}, -- [1]
					},
				},
				["end_time"] = 11354.304,
				["combat_id"] = 154,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:07:13",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 11325.208,
				["TimeData"] = {
				},
				["contra"] = "긴발톱 갈기발 스라소니",
			}, -- [4]
			{
				{
					["combatId"] = 153,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00434,
							["damage_from"] = {
								["긴발톱 갈기발 스라소니"] = true,
							},
							["targets"] = {
								["긴발톱 갈기발 스라소니"] = 109,
							},
							["total"] = 109.00434,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 109.00434,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927222,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 39,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 39,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 39,
										["c_max"] = 0,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 34,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 34,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 34,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 36,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 36,
										["n_min"] = 36,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 36,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 22.0611900424983,
							["custom"] = 0,
							["last_event"] = 1559927221,
							["damage_taken"] = 16.00434,
							["start_time"] = 1559927216,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001457,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 16,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 16.001457,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927222,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "긴발톱 갈기발 스라소니",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["아호와의증인"] = 16,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 16,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 16,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 16.001457,
							["serial"] = "Creature-0-3153-530-15-15651-00007A9318",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927220,
							["damage_taken"] = 109.001457,
							["start_time"] = 1559927217,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 153,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 8.006982,
							["total_without_pet"] = 16.006982,
							["total"] = 16.006982,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.006982,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 24,
							},
							["totalover_without_pet"] = 0.006982,
							["healing_taken"] = 16.006982,
							["fight_component"] = true,
							["end_time"] = 1559927222,
							["targets_overheal"] = {
								["아호와의증인"] = 8,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 8,
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 16,
										},
										["n_min"] = 4,
										["counter"] = 2,
										["overheal"] = 8,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 16,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927221,
							["custom"] = 0,
							["last_event"] = 1559927221,
							["spec"] = 269,
							["totaldenied"] = 0.006982,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 153,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.003011,
							["resource"] = 4.003011,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.003011,
							["fight_component"] = true,
							["total"] = 0.003011,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.003011,
							["last_event"] = 1559927221,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.003011,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 153,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 153,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11324.006,
				["tempo_start"] = 1559927216,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 162,
				["playing_solo"] = true,
				["totals"] = {
					125, -- [1]
					16, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					109, -- [1]
					16, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:07:02",
				["cleu_timeline"] = {
				},
				["enemy"] = "긴발톱 갈기발 스라소니",
				["TotalElapsedCombatTime"] = 11314.285,
				["CombatEndedAt"] = 11314.285,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 16.006982,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 109.00434,
						}, -- [1]
					},
				},
				["end_time"] = 11314.285,
				["combat_id"] = 153,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:06:56",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["긴발톱 갈기발 스라소니"] = 1,
				},
				["start_time"] = 11308.876,
				["TimeData"] = {
				},
				["contra"] = "긴발톱 갈기발 스라소니",
			}, -- [5]
			{
				{
					["combatId"] = 152,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004299,
							["damage_from"] = {
								["광포한 용매"] = true,
							},
							["targets"] = {
								["광포한 용매"] = 165,
							},
							["total"] = 165.004299,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 165.004299,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927201,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["광포한 용매"] = 29,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 29,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 29,
										["c_max"] = 0,
										["MISS"] = 4,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["광포한 용매"] = 22,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 22,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 76,
										["g_amt"] = 0,
										["n_max"] = 38,
										["targets"] = {
											["광포한 용매"] = 114,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 38,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 114,
										["c_max"] = 76,
										["MISS"] = 1,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 76,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 31.0333456836509,
							["custom"] = 0,
							["last_event"] = 1559927200,
							["damage_taken"] = 25.004299,
							["start_time"] = 1559927194,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.008082,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 25,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 25.008082,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 25.008082,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-3153-530-15-15650-00007918B5",
							["nome"] = "광포한 용매",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["아호와의증인"] = 25,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 25,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 25,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1559927201,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 165.008082,
							["start_time"] = 1559927194,
							["delay"] = 0,
							["last_event"] = 1559927198,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 152,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 0.006739,
							["total_without_pet"] = 24.006739,
							["total"] = 24.006739,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.006739,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 24,
							},
							["totalover_without_pet"] = 0.006739,
							["healing_taken"] = 24.006739,
							["fight_component"] = true,
							["end_time"] = 1559927201,
							["targets_overheal"] = {
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 24,
										},
										["n_min"] = 12,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 24,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927200,
							["custom"] = 0,
							["last_event"] = 1559927200,
							["spec"] = 269,
							["totaldenied"] = 0.006739,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 152,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.005646,
							["resource"] = 6.005646,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.005646,
							["fight_component"] = true,
							["total"] = 0.005646,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.005646,
							["last_event"] = 1559927216,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.005646,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 152,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
								[100784] = 3,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 152,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11308.181,
				["tempo_start"] = 1559927194,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 161,
				["playing_solo"] = true,
				["totals"] = {
					190, -- [1]
					24, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					165, -- [1]
					24, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:06:41",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "광포한 용매",
				["TotalElapsedCombatTime"] = 6.14500000000044,
				["CombatEndedAt"] = 11293.249,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 24.006739,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 165.004299,
						}, -- [1]
					},
				},
				["end_time"] = 11293.249,
				["combat_id"] = 152,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "02:06:35",
				["start_time"] = 11287.104,
				["TimeData"] = {
				},
				["frags"] = {
					["광포한 용매"] = 1,
				},
			}, -- [6]
			{
				{
					["combatId"] = 151,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003536,
							["damage_from"] = {
								["긴발톱 갈기발 스라소니"] = true,
							},
							["targets"] = {
								["긴발톱 갈기발 스라소니"] = 99,
							},
							["total"] = 99.003536,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 99.003536,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927182,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 39,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 39,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 39,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 22,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 22,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 38,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 38,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 38,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 38,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 31.1429808115751,
							["custom"] = 0,
							["last_event"] = 1559927182,
							["damage_taken"] = 15.003536,
							["start_time"] = 1559927179,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00238,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 15,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 15.00238,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927182,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "긴발톱 갈기발 스라소니",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["아호와의증인"] = 15,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 15,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 15.00238,
							["serial"] = "Creature-0-3153-530-15-15651-00007A7CAF",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927180,
							["damage_taken"] = 99.00238,
							["start_time"] = 1559927179,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 151,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 9.001927,
							["total_without_pet"] = 15.001927,
							["total"] = 15.001927,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.001927,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 24,
							},
							["totalover_without_pet"] = 0.001927,
							["healing_taken"] = 15.001927,
							["fight_component"] = true,
							["end_time"] = 1559927182,
							["targets_overheal"] = {
								["아호와의증인"] = 9,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 9,
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 15,
										},
										["n_min"] = 3,
										["counter"] = 2,
										["overheal"] = 9,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 15,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927182,
							["custom"] = 0,
							["last_event"] = 1559927182,
							["spec"] = 269,
							["totaldenied"] = 0.001927,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 151,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.003897,
							["resource"] = 2.003897,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.003897,
							["fight_component"] = true,
							["total"] = 0.003897,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.003897,
							["last_event"] = 1559927180,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.003897,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 151,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 1,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 151,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1559927179,
				["enemy"] = "긴발톱 갈기발 스라소니",
				["combat_counter"] = 160,
				["playing_solo"] = true,
				["totals"] = {
					114, -- [1]
					15, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 11274.555,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:06:19",
				["end_time"] = 11274.555,
				["totals_grupo"] = {
					99, -- [1]
					15, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 151,
				["TotalElapsedCombatTime"] = 11274.555,
				["frags_need_refresh"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 15.001927,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 99.003536,
						}, -- [1]
					},
				},
				["frags"] = {
					["긴발톱 갈기발 스라소니"] = 1,
				},
				["data_fim"] = "02:06:22",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 11271.242,
				["contra"] = "긴발톱 갈기발 스라소니",
				["TimeData"] = {
				},
			}, -- [7]
			{
				{
					["combatId"] = 150,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005072,
							["damage_from"] = {
							},
							["targets"] = {
								["광포한 용매"] = 107,
							},
							["total"] = 107.005072,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 107.005072,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927153,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 38,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["광포한 용매"] = 47,
											["긴발톱 갈기발 스라소니"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 47,
										["c_max"] = 38,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 38,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["광포한 용매"] = 23,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 23,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["광포한 용매"] = 37,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 37,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 50.9790719390147,
							["custom"] = 0,
							["last_event"] = 1559927178,
							["damage_taken"] = 0.005072,
							["start_time"] = 1559927151,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.005047,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005047,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.005047,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-3153-530-15-15650-00007A9958",
							["nome"] = "광포한 용매",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["아호와의증인"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1559927153,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 107.005047,
							["start_time"] = 1559927153,
							["delay"] = 0,
							["last_event"] = 1559927153,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 150,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 13.004262,
							["total_without_pet"] = 11.004262,
							["total"] = 11.004262,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.004262,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 12,
							},
							["totalover_without_pet"] = 0.004262,
							["healing_taken"] = 11.004262,
							["fight_component"] = true,
							["end_time"] = 1559927153,
							["targets_overheal"] = {
								["아호와의증인"] = 13,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 13,
										},
										["n_max"] = 11,
										["targets"] = {
											["아호와의증인"] = 11,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 13,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 11,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927153,
							["custom"] = 0,
							["last_event"] = 1559927153,
							["spec"] = 269,
							["totaldenied"] = 0.004262,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 150,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.001553,
							["resource"] = 4.001553,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.001553,
							["fight_component"] = true,
							["total"] = 0.001553,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.001553,
							["last_event"] = 1559927179,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.001553,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 150,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 1,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 150,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11270.948,
				["tempo_start"] = 1559927151,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 159,
				["playing_solo"] = true,
				["totals"] = {
					106.98884, -- [1]
					11, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					107, -- [1]
					11, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:05:53",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "광포한 용매",
				["TotalElapsedCombatTime"] = 2.09900000000016,
				["CombatEndedAt"] = 11245.839,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 11.004262,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 107.005072,
						}, -- [1]
					},
				},
				["end_time"] = 11245.839,
				["combat_id"] = 150,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "02:05:51",
				["start_time"] = 11243.74,
				["TimeData"] = {
				},
				["frags"] = {
					["광포한 용매"] = 1,
				},
			}, -- [8]
			{
				{
					["combatId"] = 149,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006937,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 8,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 8.006937,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927137,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "긴발톱 갈기발 스라소니",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["아호와의증인"] = 8,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 8,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 8.006937,
							["serial"] = "Creature-0-3153-530-15-15651-00007A9953",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927137,
							["damage_taken"] = 108.006937,
							["start_time"] = 1559927135,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003531,
							["damage_from"] = {
								["긴발톱 갈기발 스라소니"] = true,
								["광포한 용매"] = true,
							},
							["targets"] = {
								["긴발톱 갈기발 스라소니"] = 108,
							},
							["total"] = 108.003531,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 108.003531,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927137,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 39,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 48,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 48,
										["c_max"] = 39,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 39,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 22,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 22,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 38,
										["targets"] = {
											["긴발톱 갈기발 스라소니"] = 38,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 38,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 38,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 49.294172067533,
							["custom"] = 0,
							["last_event"] = 1559927137,
							["damage_taken"] = 19.003531,
							["start_time"] = 1559927135,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 149,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 16.001677,
							["total_without_pet"] = 8.001677,
							["total"] = 8.001677,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.001677,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 12,
							},
							["totalover_without_pet"] = 0.001677,
							["healing_taken"] = 8.001677,
							["fight_component"] = true,
							["end_time"] = 1559927137,
							["targets_overheal"] = {
								["아호와의증인"] = 16,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 16,
										},
										["n_max"] = 8,
										["targets"] = {
											["아호와의증인"] = 8,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 16,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 8,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927137,
							["custom"] = 0,
							["last_event"] = 1559927137,
							["spec"] = 269,
							["totaldenied"] = 0.001677,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 149,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.006021,
							["resource"] = 6.006021,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.006021,
							["fight_component"] = true,
							["total"] = 0.006021,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.006021,
							["last_event"] = 1559927151,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.006021,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 149,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 149,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1559927135,
				["enemy"] = "긴발톱 갈기발 스라소니",
				["combat_counter"] = 158,
				["playing_solo"] = true,
				["totals"] = {
					115.993726, -- [1]
					8, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["아호와의증인"] = {
						{
							true, -- [1]
							1, -- [2]
							11, -- [3]
							1559927151.374, -- [4]
							585, -- [5]
							"광포한 용매", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 11230.084,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:05:35",
				["end_time"] = 11230.084,
				["totals_grupo"] = {
					108, -- [1]
					8, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 149,
				["TotalElapsedCombatTime"] = 11230.084,
				["frags_need_refresh"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 8.001677,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 108.003531,
						}, -- [1]
					},
				},
				["frags"] = {
					["긴발톱 갈기발 스라소니"] = 1,
				},
				["data_fim"] = "02:05:38",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 11227.626,
				["contra"] = "긴발톱 갈기발 스라소니",
				["TimeData"] = {
				},
			}, -- [9]
			{
				{
					["combatId"] = 148,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.0032,
							["spec"] = 269,
							["damage_from"] = {
								["버림받은 엘프 난동자"] = true,
								["버림받은 엘프 암살자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 난동자"] = 107,
								["버림받은 엘프 암살자"] = 110,
							},
							["pets"] = {
							},
							["colocacao"] = 1,
							["end_time"] = 1559927072,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 217.0032,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 217.0032,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 18,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["버림받은 엘프 난동자"] = 47,
											["버림받은 엘프 암살자"] = 46,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 75,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 93,
										["c_max"] = 18,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["r_amt"] = 0,
										["c_min"] = 18,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13,
										["targets"] = {
											["버림받은 엘프 난동자"] = 22,
											["버림받은 엘프 암살자"] = 26,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 48,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 48,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 38,
										["targets"] = {
											["버림받은 엘프 난동자"] = 38,
											["버림받은 엘프 암살자"] = 38,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 76,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 76,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 16.3062218214597,
							["custom"] = 0,
							["last_event"] = 1559927072,
							["damage_taken"] = 61.0032,
							["start_time"] = 1559927062,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008165,
							["damage_from"] = {
								["욤매"] = true,
								["조용한파도"] = true,
								["아호와의증인"] = true,
							},
							["targets"] = {
								["조용한파도"] = 29,
								["아호와의증인"] = 54,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3153-530-15-16162-00007A945D",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 83.008165,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 83.008165,
							["end_time"] = 1559927135,
							["friendlyfire_total"] = 0,
							["nome"] = "버림받은 엘프 난동자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["조용한파도"] = 29,
											["아호와의증인"] = 54,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 83,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 83,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927080,
							["damage_taken"] = 215.008165,
							["start_time"] = 1559927112,
							["delay"] = 1559927080,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006372,
							["damage_from"] = {
								["욤매"] = true,
								["조용한파도"] = true,
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 7,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3153-530-15-15645-00007A94E6",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7.006372,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 7.006372,
							["end_time"] = 1559927072,
							["friendlyfire_total"] = 0,
							["nome"] = "버림받은 엘프 암살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["아호와의증인"] = 7,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 7,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 7,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927064,
							["damage_taken"] = 218.006372,
							["start_time"] = 1559927062,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 148,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 0.003772,
							["total_without_pet"] = 47.003772,
							["total"] = 47.003772,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.003772,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 47,
							},
							["totalover_without_pet"] = 0.003772,
							["healing_taken"] = 47.003772,
							["fight_component"] = true,
							["end_time"] = 1559927072,
							["targets_overheal"] = {
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 47,
										},
										["n_min"] = 11,
										["counter"] = 4,
										["overheal"] = 0,
										["total"] = 47,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 47,
										["n_amt"] = 4,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927065,
							["custom"] = 0,
							["last_event"] = 1559927072,
							["spec"] = 269,
							["totaldenied"] = 0.003772,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 148,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.001956,
							["resource"] = 8.001956,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.001956,
							["fight_component"] = true,
							["total"] = 0.001956,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.001956,
							["last_event"] = 1559927072,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.001956,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 148,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 4,
								[100784] = 2,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 148,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11226.423,
				["tempo_start"] = 1559927058,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 157,
				["playing_solo"] = true,
				["totals"] = {
					306.98364, -- [1]
					47, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					217, -- [1]
					47, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:04:32",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 난동자",
				["TotalElapsedCombatTime"] = 11164.415,
				["CombatEndedAt"] = 11164.415,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 47.003772,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 217.0032,
						}, -- [1]
					},
				},
				["end_time"] = 11164.415,
				["combat_id"] = 148,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:04:19",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 난동자"] = 1,
					["버림받은 엘프 암살자"] = 1,
				},
				["start_time"] = 11151.107,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 난동자",
			}, -- [10]
			{
				{
					["combatId"] = 147,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002158,
							["damage_from"] = {
								["버림받은 엘프 난동자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 난동자"] = 102,
							},
							["total"] = 102.002158,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 102.002158,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927024,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 39,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["버림받은 엘프 난동자"] = 39,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 39,
										["c_max"] = 20,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 19,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["버림받은 엘프 난동자"] = 24,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 24,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 39,
										["targets"] = {
											["버림받은 엘프 난동자"] = 39,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 39,
										["n_min"] = 39,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 39,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 16.5911122316221,
							["custom"] = 0,
							["last_event"] = 1559927024,
							["damage_taken"] = 18.002158,
							["start_time"] = 1559927021,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002322,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 18,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 18.002322,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927024,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 난동자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["아호와의증인"] = 18,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 18,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 18,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 18.002322,
							["serial"] = "Creature-0-3153-530-15-16162-0000FA92F8",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927022,
							["damage_taken"] = 102.002322,
							["start_time"] = 1559927018,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 147,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 6.005284,
							["total_without_pet"] = 18.005284,
							["total"] = 18.005284,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.005284,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 24,
							},
							["totalover_without_pet"] = 0.005284,
							["healing_taken"] = 18.005284,
							["fight_component"] = true,
							["end_time"] = 1559927024,
							["targets_overheal"] = {
								["아호와의증인"] = 6,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 6,
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 18,
										},
										["n_min"] = 6,
										["counter"] = 2,
										["overheal"] = 6,
										["total"] = 18,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 18,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927024,
							["custom"] = 0,
							["last_event"] = 1559927024,
							["spec"] = 269,
							["totaldenied"] = 0.005284,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 147,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.002666,
							["resource"] = 1.002666,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.002666,
							["fight_component"] = true,
							["total"] = 0.002666,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.002666,
							["last_event"] = 1559927022,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.002666,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 147,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 147,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11149.811,
				["tempo_start"] = 1559927018,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 156,
				["playing_solo"] = true,
				["totals"] = {
					119.983974, -- [1]
					18, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					102, -- [1]
					18, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:03:45",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 난동자",
				["TotalElapsedCombatTime"] = 11117.081,
				["CombatEndedAt"] = 11117.081,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 18.005284,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 102.002158,
						}, -- [1]
					},
				},
				["end_time"] = 11117.081,
				["combat_id"] = 147,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:03:38",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 난동자"] = 1,
				},
				["start_time"] = 11110.933,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 난동자",
			}, -- [11]
			{
				{
					["combatId"] = 146,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008067,
							["damage_from"] = {
								["환경피해 (낙하 충격)"] = true,
								["버림받은 엘프 암살자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 암살자"] = 100,
							},
							["total"] = 100.008067,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 100.008067,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559927006,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 21,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["버림받은 엘프 암살자"] = 40,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 19,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 40,
										["c_max"] = 21,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 21,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["버림받은 엘프 암살자"] = 22,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 22,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 38,
										["targets"] = {
											["버림받은 엘프 암살자"] = 38,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 38,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 38,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 29.1144299854483,
							["custom"] = 0,
							["last_event"] = 1559927006,
							["damage_taken"] = 41.008067,
							["start_time"] = 1559927004,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = -2147483648,
							["totalabsorbed"] = 0.002119,
							["damage_from"] = {
							},
							["targets"] = {
								["아호와의증인"] = 32,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 32.002119,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 32.002119,
							["classe"] = "UNKNOW",
							["serial"] = "",
							["nome"] = "환경피해 (낙하 충격)",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[3] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32,
										["targets"] = {
											["아호와의증인"] = 32,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 32,
										["n_min"] = 32,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 32,
										["c_max"] = 0,
										["id"] = 3,
										["r_dmg"] = 0,
										["spellschool"] = 3,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1559927006,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002119,
							["start_time"] = 1559927003,
							["delay"] = 0,
							["last_event"] = 1559927003,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007211,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 9.007211,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559927006,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 암살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["아호와의증인"] = 9,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 9.007211,
							["serial"] = "Creature-0-3153-530-15-15645-00007A956B",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559927004,
							["damage_taken"] = 100.007211,
							["start_time"] = 1559927004,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 146,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 0.007009,
							["total_without_pet"] = 24.007009,
							["total"] = 24.007009,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.007009,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 24,
							},
							["totalover_without_pet"] = 0.007009,
							["healing_taken"] = 24.007009,
							["fight_component"] = true,
							["end_time"] = 1559927006,
							["targets_overheal"] = {
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 24,
										},
										["n_min"] = 12,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 24,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559927006,
							["custom"] = 0,
							["last_event"] = 1559927006,
							["spec"] = 269,
							["totaldenied"] = 0.007009,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 146,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.004768,
							["resource"] = 3.004768,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.004768,
							["fight_component"] = true,
							["total"] = 0.004768,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.004768,
							["last_event"] = 1559927006,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.004768,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 146,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 146,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11109.81,
				["tempo_start"] = 1559927003,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 155,
				["playing_solo"] = true,
				["totals"] = {
					140.979999, -- [1]
					24, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					100, -- [1]
					24, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:03:26",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 암살자",
				["TotalElapsedCombatTime"] = 11098.855,
				["CombatEndedAt"] = 11098.855,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 24.007009,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 100.008067,
						}, -- [1]
					},
				},
				["end_time"] = 11098.855,
				["combat_id"] = 146,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "02:03:23",
				["start_time"] = 11095.42,
				["TimeData"] = {
				},
				["frags"] = {
					["버림받은 엘프 암살자"] = 1,
				},
			}, -- [12]
			{
				{
					["combatId"] = 145,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006264,
							["damage_from"] = {
								["버림받은 엘프 난동자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 난동자"] = 90,
							},
							["total"] = 90.006264,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 90.006264,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559926993,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 18,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["버림받은 엘프 난동자"] = 66,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 48,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 66,
										["c_max"] = 18,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 18,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["버림받은 엘프 난동자"] = 24,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 24,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 25.613620944798,
							["custom"] = 0,
							["last_event"] = 1559926993,
							["damage_taken"] = 17.006264,
							["start_time"] = 1559926989,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002542,
							["damage_from"] = {
								["욤매"] = true,
								["조용한파도"] = true,
								["아호와의증인"] = true,
							},
							["targets"] = {
								["조용한파도"] = 7,
								["아호와의증인"] = 17,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 24.002542,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926993,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 난동자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["조용한파도"] = 7,
											["아호와의증인"] = 17,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 24,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 24.002542,
							["serial"] = "Creature-0-3153-530-15-16162-00007A94B7",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926992,
							["damage_taken"] = 202.002542,
							["start_time"] = 1559926990,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 145,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 7.00339,
							["total_without_pet"] = 17.00339,
							["total"] = 17.00339,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.00339,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 24,
							},
							["totalover_without_pet"] = 0.00339,
							["healing_taken"] = 17.00339,
							["fight_component"] = true,
							["end_time"] = 1559926993,
							["targets_overheal"] = {
								["아호와의증인"] = 7,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 7,
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 17,
										},
										["n_min"] = 5,
										["counter"] = 2,
										["overheal"] = 7,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 17,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559926993,
							["custom"] = 0,
							["last_event"] = 1559926993,
							["spec"] = 269,
							["totaldenied"] = 0.00339,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 145,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.001548,
							["resource"] = 2.001548,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.001548,
							["fight_component"] = true,
							["total"] = 0.001548,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.001548,
							["last_event"] = 1559926991,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.001548,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 145,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 145,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11095.206,
				["tempo_start"] = 1559926989,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 154,
				["playing_solo"] = true,
				["totals"] = {
					113.992384, -- [1]
					17, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					90, -- [1]
					17, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:03:13",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 난동자",
				["TotalElapsedCombatTime"] = 11085.453,
				["CombatEndedAt"] = 11085.453,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 17.00339,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 90.006264,
						}, -- [1]
					},
				},
				["end_time"] = 11085.453,
				["combat_id"] = 145,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:03:09",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 난동자"] = 1,
				},
				["start_time"] = 11081.939,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 난동자",
			}, -- [13]
			{
				{
					["combatId"] = 144,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001246,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 15,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 15.001246,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926983,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 난동자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["아호와의증인"] = 15,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 15,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 15.001246,
							["serial"] = "Creature-0-3153-530-15-16162-00017A93A2",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926980,
							["damage_taken"] = 100.001246,
							["start_time"] = 1559926978,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006612,
							["damage_from"] = {
								["버림받은 엘프 난동자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 난동자"] = 100,
							},
							["total"] = 100.006612,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 100.006612,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559926983,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 20,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["버림받은 엘프 난동자"] = 50,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 30,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 50,
										["c_max"] = 20,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 20,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 13,
										["targets"] = {
											["버림받은 엘프 난동자"] = 13,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 13,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 13,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["버림받은 엘프 난동자"] = 37,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 37,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 26.3591491829213,
							["custom"] = 0,
							["last_event"] = 1559926982,
							["damage_taken"] = 15.006612,
							["start_time"] = 1559926979,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 144,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 9.002133,
							["total_without_pet"] = 15.002133,
							["total"] = 15.002133,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.002133,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 24,
							},
							["totalover_without_pet"] = 0.002133,
							["healing_taken"] = 15.002133,
							["fight_component"] = true,
							["end_time"] = 1559926983,
							["targets_overheal"] = {
								["아호와의증인"] = 9,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 9,
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 15,
										},
										["n_min"] = 3,
										["counter"] = 2,
										["overheal"] = 9,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 15,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559926982,
							["custom"] = 0,
							["last_event"] = 1559926982,
							["spec"] = 269,
							["totaldenied"] = 0.002133,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 144,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.006502,
							["resource"] = 4.006502,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.006502,
							["fight_component"] = true,
							["total"] = 0.006502,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.006502,
							["last_event"] = 1559926989,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.006502,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 144,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 1,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 144,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11081.739,
				["tempo_start"] = 1559926978,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 153,
				["playing_solo"] = true,
				["totals"] = {
					115, -- [1]
					15, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					100, -- [1]
					15, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:03:03",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 난동자",
				["TotalElapsedCombatTime"] = 11075.741,
				["CombatEndedAt"] = 11075.741,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 15.002133,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 100.006612,
						}, -- [1]
					},
				},
				["end_time"] = 11075.741,
				["combat_id"] = 144,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:02:58",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 난동자"] = 2,
				},
				["start_time"] = 11070.824,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 난동자",
			}, -- [14]
			{
				{
					["combatId"] = 143,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006349,
							["damage_from"] = {
								["버림받은 엘프 난동자"] = true,
								["버림받은 엘프 암살자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 난동자"] = 119,
								["버림받은 엘프 암살자"] = 105,
							},
							["total"] = 224.006349,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 224.006349,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559926976,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 57,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["버림받은 엘프 난동자"] = 10,
											["버림받은 엘프 암살자"] = 57,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 10,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 67,
										["c_max"] = 38,
										["MISS"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 19,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["버림받은 엘프 난동자"] = 33,
											["버림받은 엘프 암살자"] = 11,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 44,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 44,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 38,
										["targets"] = {
											["버림받은 엘프 난동자"] = 76,
											["버림받은 엘프 암살자"] = 37,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 113,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 113,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 24.9228247663518,
							["custom"] = 0,
							["last_event"] = 1559926975,
							["damage_taken"] = 32.006349,
							["start_time"] = 1559926967,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006931,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 9.006931,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926976,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 암살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["아호와의증인"] = 9,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 9,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 9.006931,
							["serial"] = "Creature-0-3153-530-15-15645-00007A9472",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926967,
							["damage_taken"] = 105.006931,
							["start_time"] = 1559926967,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005407,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 23,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 23.005407,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926976,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 난동자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["아호와의증인"] = 23,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 23,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 23.005407,
							["serial"] = "Creature-0-3153-530-15-16162-00027A93A2",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926974,
							["damage_taken"] = 119.005407,
							["start_time"] = 1559926970,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 143,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 19.001211,
							["total_without_pet"] = 23.001211,
							["total"] = 23.001211,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.001211,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 23,
							},
							["totalover_without_pet"] = 0.001211,
							["healing_taken"] = 23.001211,
							["fight_component"] = true,
							["end_time"] = 1559926976,
							["targets_overheal"] = {
								["아호와의증인"] = 19,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 19,
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 23,
										},
										["n_min"] = 11,
										["counter"] = 4,
										["overheal"] = 19,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 23,
										["n_amt"] = 4,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559926968,
							["custom"] = 0,
							["last_event"] = 1559926975,
							["spec"] = 269,
							["totaldenied"] = 0.001211,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 143,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.00236,
							["resource"] = 6.00236,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.00236,
							["fight_component"] = true,
							["total"] = 0.00236,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.00236,
							["last_event"] = 1559926974,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.00236,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 143,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100784] = 3,
								[100780] = 3,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 143,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11069.661,
				["tempo_start"] = 1559926967,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 152,
				["playing_solo"] = true,
				["totals"] = {
					256, -- [1]
					23, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					224, -- [1]
					23, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:02:56",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 암살자",
				["TotalElapsedCombatTime"] = 11068.873,
				["CombatEndedAt"] = 11068.873,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 23.001211,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 224.006349,
						}, -- [1]
					},
				},
				["end_time"] = 11068.873,
				["combat_id"] = 143,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:02:47",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 난동자"] = 1,
					["버림받은 엘프 암살자"] = 1,
				},
				["start_time"] = 11059.231,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 암살자",
			}, -- [15]
			{
				{
					["combatId"] = 142,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001815,
							["damage_from"] = {
								["버림받은 엘프 난동자"] = true,
								["버림받은 엘프 암살자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 난동자"] = 113,
								["버림받은 엘프 암살자"] = 104,
							},
							["total"] = 217.001815,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 217.001815,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559926961,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 95,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["버림받은 엘프 난동자"] = 67,
											["버림받은 엘프 암살자"] = 47,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 19,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 114,
										["c_max"] = 38,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 19,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["버림받은 엘프 난동자"] = 11,
											["버림받은 엘프 암살자"] = 22,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 33,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 33,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 35,
										["targets"] = {
											["버림받은 엘프 난동자"] = 35,
											["버림받은 엘프 암살자"] = 35,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 70,
										["n_min"] = 35,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 70,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 28.7457696383662,
							["custom"] = 0,
							["last_event"] = 1559926961,
							["damage_taken"] = 37.001815,
							["start_time"] = 1559926954,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004796,
							["damage_from"] = {
								["조용한파도"] = true,
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 19,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19.004796,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926961,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 난동자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["아호와의증인"] = 19,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 19,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 19.004796,
							["serial"] = "Creature-0-3153-530-15-16162-00007A936F",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926956,
							["damage_taken"] = 179.004796,
							["start_time"] = 1559926954,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004544,
							["damage_from"] = {
								["욤매"] = true,
								["조용한파도"] = true,
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 18,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 18.004544,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926961,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 암살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["아호와의증인"] = 18,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 18,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 18,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 18.004544,
							["serial"] = "Creature-0-3153-530-15-15645-00007A92F8",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926960,
							["damage_taken"] = 176.004544,
							["start_time"] = 1559926958,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 142,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 5.001165,
							["total_without_pet"] = 40.001165,
							["total"] = 40.001165,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.001165,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 45,
							},
							["totalover_without_pet"] = 0.001165,
							["healing_taken"] = 40.001165,
							["fight_component"] = true,
							["end_time"] = 1559926961,
							["targets_overheal"] = {
								["아호와의증인"] = 5,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 5,
										},
										["n_max"] = 11,
										["targets"] = {
											["아호와의증인"] = 40,
										},
										["n_min"] = 7,
										["counter"] = 4,
										["overheal"] = 5,
										["total"] = 40,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 40,
										["n_amt"] = 4,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559926957,
							["custom"] = 0,
							["last_event"] = 1559926961,
							["spec"] = 269,
							["totaldenied"] = 0.001165,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 142,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.001649,
							["resource"] = 6.001649,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.001649,
							["fight_component"] = true,
							["total"] = 0.001649,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.001649,
							["last_event"] = 1559926967,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.001649,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 142,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100784] = 2,
								[100780] = 2,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 142,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11059.084,
				["tempo_start"] = 1559926954,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 151,
				["playing_solo"] = true,
				["totals"] = {
					253.988271, -- [1]
					40, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					217, -- [1]
					40, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:02:41",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 난동자",
				["TotalElapsedCombatTime"] = 11053.902,
				["CombatEndedAt"] = 11053.902,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 40.001165,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 217.001815,
						}, -- [1]
					},
				},
				["end_time"] = 11053.902,
				["combat_id"] = 142,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:02:34",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 난동자"] = 1,
					["버림받은 엘프 암살자"] = 1,
				},
				["start_time"] = 11046.353,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 난동자",
			}, -- [16]
			{
				{
					["combatId"] = 141,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004362,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 34,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 34.004362,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926950,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 암살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["아호와의증인"] = 34,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 34,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 34,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 34.004362,
							["serial"] = "Creature-0-3153-530-15-15645-0000FA936F",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926949,
							["damage_taken"] = 114.004362,
							["start_time"] = 1559926943,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006732,
							["damage_from"] = {
								["버림받은 엘프 암살자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 암살자"] = 114,
							},
							["total"] = 114.006732,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 114.006732,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559926950,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["버림받은 엘프 암살자"] = 55,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 55,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 55,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["버림받은 엘프 암살자"] = 22,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 22,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["버림받은 엘프 암살자"] = 37,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 37,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 17.813551874996,
							["custom"] = 0,
							["last_event"] = 1559926949,
							["damage_taken"] = 34.006732,
							["start_time"] = 1559926944,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 141,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 0.002675,
							["total_without_pet"] = 22.002675,
							["total"] = 22.002675,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.002675,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 22,
							},
							["totalover_without_pet"] = 0.002675,
							["healing_taken"] = 22.002675,
							["fight_component"] = true,
							["end_time"] = 1559926950,
							["targets_overheal"] = {
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 11,
										["targets"] = {
											["아호와의증인"] = 22,
										},
										["n_min"] = 11,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 22,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559926949,
							["custom"] = 0,
							["last_event"] = 1559926949,
							["spec"] = 269,
							["totaldenied"] = 0.002675,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 141,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.003384,
							["resource"] = 6.003384,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.003384,
							["fight_component"] = true,
							["total"] = 0.003384,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.003384,
							["last_event"] = 1559926954,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.003384,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 141,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 141,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11045.405,
				["tempo_start"] = 1559926943,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 150,
				["playing_solo"] = true,
				["totals"] = {
					148, -- [1]
					22, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					114, -- [1]
					22, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:02:30",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 암살자",
				["TotalElapsedCombatTime"] = 11042.945,
				["CombatEndedAt"] = 11042.945,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 22.002675,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 114.006732,
						}, -- [1]
					},
				},
				["end_time"] = 11042.945,
				["combat_id"] = 141,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:02:23",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 암살자"] = 1,
				},
				["start_time"] = 11035.623,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 암살자",
			}, -- [17]
			{
				{
					["combatId"] = 140,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005331,
							["damage_from"] = {
								["버림받은 엘프 난동자"] = true,
							},
							["targets"] = {
								["버림받은 엘프 난동자"] = 152,
							},
							["total"] = 152.005331,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "MONK",
							["raid_targets"] = {
							},
							["total_without_pet"] = 152.005331,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1559926935,
							["friendlyfire_total"] = 0,
							["spec"] = 269,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["버림받은 엘프 난동자"] = 57,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 57,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 57,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[100780] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["버림받은 엘프 난동자"] = 22,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 22,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 100780,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[100784] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 73,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["버림받은 엘프 난동자"] = 73,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 73,
										["c_max"] = 73,
										["id"] = 100784,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 73,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075D70FA",
							["last_dps"] = 43.0732023235989,
							["custom"] = 0,
							["last_event"] = 1559926935,
							["damage_taken"] = 18.005331,
							["start_time"] = 1559926931,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008087,
							["damage_from"] = {
								["아호와의증인"] = true,
							},
							["targets"] = {
								["아호와의증인"] = 18,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 18.008087,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1559926935,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "버림받은 엘프 난동자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 9,
										["targets"] = {
											["아호와의증인"] = 18,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 18,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 18,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 18.008087,
							["serial"] = "Creature-0-3153-530-15-16162-00007A94A3",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1559926934,
							["damage_taken"] = 152.008087,
							["start_time"] = 1559926932,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 140,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["아호와의증인"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MONK",
							["totalover"] = 5.00607,
							["total_without_pet"] = 18.00607,
							["total"] = 18.00607,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075D70FA",
							["totalabsorb"] = 0.00607,
							["last_hps"] = 0,
							["targets"] = {
								["아호와의증인"] = 23,
							},
							["totalover_without_pet"] = 0.00607,
							["healing_taken"] = 18.00607,
							["fight_component"] = true,
							["end_time"] = 1559926935,
							["targets_overheal"] = {
								["아호와의증인"] = 5,
							},
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["아호와의증인"] = 5,
										},
										["n_max"] = 12,
										["targets"] = {
											["아호와의증인"] = 18,
										},
										["n_min"] = 6,
										["counter"] = 2,
										["overheal"] = 5,
										["total"] = 18,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 18,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1559926935,
							["custom"] = 0,
							["last_event"] = 1559926935,
							["spec"] = 269,
							["totaldenied"] = 0.00607,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 140,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.006426,
							["resource"] = 4.006426,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MONK",
							["passiveover"] = 0.006426,
							["fight_component"] = true,
							["total"] = 0.006426,
							["nome"] = "아호와의증인",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 12,
							["flag_original"] = 1297,
							["alternatepower"] = 0.006426,
							["last_event"] = 1559926934,
							["spec"] = 269,
							["tipo"] = 3,
							["serial"] = "Player-205-075D70FA",
							["totalover"] = 0.006426,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 140,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "아호와의증인",
							["spec"] = 269,
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MONK",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[100780] = 2,
								[100784] = 1,
							},
							["serial"] = "Player-205-075D70FA",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 140,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["아호와의증인"] = true,
				},
				["CombatStartedAt"] = 11034.407,
				["tempo_start"] = 1559926931,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 149,
				["playing_solo"] = true,
				["totals"] = {
					170, -- [1]
					18, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					152, -- [1]
					18, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:02:15",
				["cleu_timeline"] = {
				},
				["enemy"] = "버림받은 엘프 난동자",
				["TotalElapsedCombatTime"] = 11027.528,
				["CombatEndedAt"] = 11027.528,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["아호와의증인"] = 18.00607,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["아호와의증인"] = 152.005331,
						}, -- [1]
					},
				},
				["end_time"] = 11027.528,
				["combat_id"] = 140,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:02:11",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["버림받은 엘프 난동자"] = 1,
				},
				["start_time"] = 11023.892,
				["TimeData"] = {
				},
				["contra"] = "버림받은 엘프 난동자",
			}, -- [18]
		},
	},
	["last_version"] = "v8.1.5.7129",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["nextreset"] = 1561046075,
		["last_version"] = 11,
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 0,
	["active_profile"] = "아호와의증인-아즈샤라",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 1,
			["enabled"] = true,
			["animate"] = false,
			["useplayercolor"] = false,
			["author"] = "Details! Team",
			["useclasscolors"] = false,
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["showamount"] = false,
		},
		["DETAILS_PLUGIN_RAIDCHECK"] = {
			["enabled"] = true,
			["food_tier1"] = true,
			["mythic_1_4"] = true,
			["food_tier2"] = true,
			["author"] = "Details! Team",
			["use_report_panel"] = true,
			["pre_pot_healers"] = false,
			["pre_pot_tanks"] = false,
			["food_tier3"] = true,
		},
		["DETAILS_PLUGIN_VANGUARD"] = {
			["enabled"] = true,
			["tank_block_color"] = {
				0.24705882, -- [1]
				0.0039215, -- [2]
				0, -- [3]
				0.8, -- [4]
			},
			["tank_block_texture"] = "Details Serenity",
			["show_inc_bars"] = false,
			["author"] = "Details! Team",
			["first_run"] = false,
			["tank_block_size"] = 150,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["author"] = "Details! Team",
			["window_scale"] = 1,
			["encounter_timers_dbm"] = {
			},
			["show_icon"] = 5,
			["opened"] = 0,
			["hide_on_combat"] = false,
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 160,
				["radius"] = 160,
				["hide"] = false,
			},
			["arrow_anchor_x"] = 0,
			["row_texture"] = "Details Serenity",
			["arrow_anchor_y"] = 0,
			["main_frame_locked"] = false,
			["main_frame_strata"] = "LOW",
			["enabled"] = false,
			["arrow_size"] = 10,
			["y"] = 4.577636718750e-05,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["author"] = "Details! Team",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = 3.05175781250e-05,
				["x"] = 3.05175781250e-05,
				["attribute_type"] = 1,
				["update_speed"] = 0.05,
				["size"] = 32,
			},
			["font_size"] = 10,
			["x"] = 0,
			["font_face"] = "Friz Quadrata TT",
			["use_spark"] = true,
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["point"] = "CENTER",
			["row_height"] = 20,
			["scale"] = 1,
		},
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["last_day"] = "08",
	["cached_talents"] = {
		["Player-205-075D70FA"] = {
		},
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["character_data"] = {
		["logons"] = 6,
	},
	["combat_id"] = 157,
	["savedStyles"] = {
	},
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = true,
			["isLocked"] = false,
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -371.809921264648,
					["x"] = -686.475891113281,
					["w"] = 310.000061035156,
					["h"] = 157.99983215332,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["force_font_outline"] = "",
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.844429,
					["on_hold"] = false,
					["damage_from"] = {
						["비전 망령"] = true,
						["환경피해 (낙하 충격)"] = true,
						["추방자 펠렌드렌"] = true,
						["마나 망령"] = true,
						["마나 지룡"] = true,
						["역병해골 약탈자"] = true,
						["뜰지기"] = true,
						["광포한 용매"] = true,
						["영원노래 뜰지기"] = true,
						["아호와의증인"] = true,
						["버림받은 엘프 암살자"] = true,
						["버림받은 엘프 난동자"] = true,
						["마나 추적자"] = true,
						["욕망의 탤리스"] = true,
						["새끼 갈기발 스라소니"] = true,
						["조사단 앤빌워드"] = true,
						["비전 순찰자"] = true,
						["사나운 뜰지기"] = true,
						["다르나서스 정찰병"] = true,
						["갈기발 스라소니"] = true,
						["버림받은 엘프"] = true,
						["긴발톱 갈기발 스라소니"] = true,
					},
					["targets"] = {
						["비전 망령"] = 846,
						["추방자 펠렌드렌"] = 121,
						["마나 망령"] = 379,
						["마나 지룡"] = 1348,
						["뜰지기"] = 713,
						["광포한 용매"] = 1094,
						["갈기발 스라소니"] = 282,
						["버림받은 엘프 암살자"] = 533,
						["버림받은 엘프 난동자"] = 783,
						["마나 추적자"] = 515,
						["욕망의 탤리스"] = 139,
						["새끼 갈기발 스라소니"] = 259,
						["사나운 뜰지기"] = 547,
						["비전 순찰자"] = 514,
						["조사단 앤빌워드"] = 191,
						["다르나서스 정찰병"] = 163,
						["긴발톱 갈기발 스라소니"] = 1437,
						["버림받은 엘프"] = 963,
						["오염된 비전 망령"] = 131,
					},
					["pets"] = {
					},
					["serial"] = "Player-205-075D70FA",
					["friendlyfire"] = {
						["아호와의증인"] = {
							["spells"] = {
								[254409] = 0,
							},
							["total"] = 358,
						},
					},
					["classe"] = "MONK",
					["raid_targets"] = {
					},
					["total_without_pet"] = 10958.844429,
					["dps_started"] = false,
					["fight_component"] = true,
					["end_time"] = 1559750559,
					["friendlyfire_total"] = 358,
					["total"] = 10958.844429,
					["nome"] = "아호와의증인",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 83,
								["b_amt"] = 0,
								["c_dmg"] = 1895,
								["g_amt"] = 0,
								["n_max"] = 20,
								["targets"] = {
									["비전 망령"] = 391,
									["추방자 펠렌드렌"] = 55,
									["마나 망령"] = 157,
									["마나 지룡"] = 644,
									["뜰지기"] = 511,
									["광포한 용매"] = 428,
									["갈기발 스라소니"] = 188,
									["버림받은 엘프 암살자"] = 245,
									["버림받은 엘프 난동자"] = 336,
									["마나 추적자"] = 216,
									["욕망의 탤리스"] = 65,
									["새끼 갈기발 스라소니"] = 187,
									["사나운 뜰지기"] = 401,
									["비전 순찰자"] = 190,
									["조사단 앤빌워드"] = 93,
									["다르나서스 정찰병"] = 145,
									["긴발톱 갈기발 스라소니"] = 577,
									["버림받은 엘프"] = 399,
									["오염된 비전 망령"] = 55,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3388,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 460,
								["total"] = 5283,
								["c_max"] = 39,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 68,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 309,
								["a_amt"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[100780] = {
								["c_amt"] = 35,
								["b_amt"] = 0,
								["c_dmg"] = 616,
								["g_amt"] = 0,
								["n_max"] = 13,
								["targets"] = {
									["비전 망령"] = 247,
									["추방자 펠렌드렌"] = 41,
									["마나 망령"] = 68,
									["마나 지룡"] = 380,
									["뜰지기"] = 202,
									["광포한 용매"] = 226,
									["갈기발 스라소니"] = 94,
									["버림받은 엘프 암살자"] = 103,
									["버림받은 엘프 난동자"] = 149,
									["마나 추적자"] = 148,
									["욕망의 탤리스"] = 18,
									["새끼 갈기발 스라소니"] = 72,
									["사나운 뜰지기"] = 146,
									["비전 순찰자"] = 119,
									["조사단 앤빌워드"] = 32,
									["다르나서스 정찰병"] = 18,
									["긴발톱 갈기발 스라소니"] = 281,
									["버림받은 엘프"] = 229,
									["오염된 비전 망령"] = 24,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1981,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 265,
								["total"] = 2597,
								["c_max"] = 24,
								["id"] = 100780,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 228,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							[100784] = {
								["c_amt"] = 9,
								["b_amt"] = 0,
								["c_dmg"] = 608,
								["g_amt"] = 0,
								["n_max"] = 39,
								["targets"] = {
									["비전 망령"] = 208,
									["추방자 펠렌드렌"] = 25,
									["버림받은 엘프 암살자"] = 185,
									["버림받은 엘프 난동자"] = 298,
									["마나 추적자"] = 151,
									["욕망의 탤리스"] = 56,
									["마나 망령"] = 154,
									["광포한 용매"] = 440,
									["비전 순찰자"] = 205,
									["긴발톱 갈기발 스라소니"] = 579,
									["조사단 앤빌워드"] = 66,
									["마나 지룡"] = 324,
									["버림받은 엘프"] = 335,
									["오염된 비전 망령"] = 52,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2470,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 91,
								["total"] = 3078,
								["c_max"] = 76,
								["id"] = 100784,
								["r_dmg"] = 0,
								["MISS"] = 3,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 79,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["spec"] = 269,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 2262.844429,
					["start_time"] = 1559750000,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [1]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.168855,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 88,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 88.168855,
					["end_time"] = 1559750559,
					["fight_component"] = true,
					["total"] = 88.168855,
					["serial"] = "Creature-0-3058-530-21-15274-000077E697",
					["damage_taken"] = 1348.168855,
					["nome"] = "마나 지룡",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["아호와의증인"] = 88,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 88,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 32,
								["DODGE"] = 4,
								["r_amt"] = 0,
								["c_max"] = 0,
								["a_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["c_min"] = 0,
								["n_amt"] = 21,
								["MISS"] = 6,
								["total"] = 88,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["friendlyfire"] = {
					},
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1559750519,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [2]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.034597,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 79,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 79.034597,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 79.034597,
					["serial"] = "Creature-0-3058-530-21-15372-000077E465",
					["damage_taken"] = 282.034597,
					["nome"] = "갈기발 스라소니",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6,
								["targets"] = {
									["아호와의증인"] = 79,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 79,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 19,
								["total"] = 79,
								["c_max"] = 0,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 16,
								["a_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["end_time"] = 1559750600,
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1559750556,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [3]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.030532,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 42,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 42.030532,
					["damage_taken"] = 259.030532,
					["fight_component"] = true,
					["end_time"] = 1559750600,
					["serial"] = "Creature-0-3058-530-21-15366-000077E465",
					["last_dps"] = 0,
					["nome"] = "새끼 갈기발 스라소니",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["아호와의증인"] = 42,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 42,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 42,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 10,
								["a_amt"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 42.030532,
					["dps_started"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1559750569,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [4]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.062809,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 93,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 93.062809,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 93.062809,
					["serial"] = "Creature-0-3058-530-21-15294-000077E4BC",
					["damage_taken"] = 547.062809,
					["nome"] = "사나운 뜰지기",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6,
								["targets"] = {
									["아호와의증인"] = 93,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 93,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["total"] = 93,
								["c_max"] = 0,
								["a_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 19,
								["a_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["end_time"] = 1559751047,
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1559751005,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [5]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.079652,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 118,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 118.079652,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 118.079652,
					["serial"] = "Creature-0-3058-530-21-15271-000077E883",
					["damage_taken"] = 713.079652,
					["nome"] = "뜰지기",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7,
								["targets"] = {
									["아호와의증인"] = 118,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 118,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 28,
								["a_amt"] = 0,
								["r_amt"] = 0,
								["c_max"] = 0,
								["MISS"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["c_min"] = 0,
								["n_amt"] = 23,
								["DODGE"] = 2,
								["total"] = 118,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["end_time"] = 1559751056,
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1559751003,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [6]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.062624,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["구라탱"] = 0,
						["또왕안"] = 0,
						["아호와의증인"] = 89,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 89.062624,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["end_time"] = 1559752600,
					["serial"] = "Creature-0-3058-530-21-15273-000077E429",
					["damage_taken"] = 846.062624,
					["nome"] = "비전 망령",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7,
								["targets"] = {
									["구라탱"] = 0,
									["또왕안"] = 0,
									["아호와의증인"] = 89,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 89,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["a_amt"] = 0,
								["r_amt"] = 0,
								["c_max"] = 0,
								["DODGE"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["c_min"] = 0,
								["n_amt"] = 17,
								["MISS"] = 2,
								["total"] = 89,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["friendlyfire"] = {
					},
					["total"] = 89.062624,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1559752572,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [7]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.009555,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.009555,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1559754364,
					["serial"] = "Creature-0-3058-530-21-15298-000077F5C0",
					["last_dps"] = 0,
					["nome"] = "오염된 비전 망령",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["아호와의증인"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 131.009555,
					["total"] = 0.009555,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1559754361,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [8]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.013187,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 20,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 20.013187,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1559754401,
					["serial"] = "Creature-0-3058-530-21-15367-000077F56A",
					["last_dps"] = 0,
					["nome"] = "추방자 펠렌드렌",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7,
								["targets"] = {
									["아호와의증인"] = 20,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 20,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 20,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["c_min"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 121.013187,
					["total"] = 20.013187,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1559754392,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [9]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.060326,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 205,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 205.060326,
					["delay"] = 0,
					["fight_component"] = true,
					["total"] = 205.060326,
					["classe"] = "UNKNOW",
					["damage_taken"] = 963.060326,
					["nome"] = "버림받은 엘프",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9,
								["targets"] = {
									["아호와의증인"] = 205,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 205,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 31,
								["total"] = 205,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 29,
								["a_amt"] = 0,
								["DODGE"] = 1,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["monster"] = true,
					["end_time"] = 1559835061,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1559835007,
					["serial"] = "Creature-0-3153-530-15-15644-0000792FDA",
					["dps_started"] = false,
				}, -- [10]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.032759,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 60,
					},
					["pets"] = {
					},
					["monster"] = true,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 60.032759,
					["delay"] = 0,
					["fight_component"] = true,
					["total"] = 60.032759,
					["friendlyfire"] = {
					},
					["damage_taken"] = 514.032759,
					["nome"] = "비전 순찰자",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["아호와의증인"] = 60,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 60,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["total"] = 60,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 8,
								["a_dmg"] = 0,
								["a_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["end_time"] = 1559835088,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1559835066,
					["serial"] = "Creature-0-3153-530-15-15638-000079313B",
					["dps_started"] = false,
				}, -- [11]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.005661,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 35,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 35.005661,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1559835178,
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["nome"] = "욕망의 탤리스",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["아호와의증인"] = 35,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 35,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 35,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_dmg"] = 0,
								["MISS"] = 1,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["total"] = 35.005661,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 139.005661,
					["start_time"] = 1559835164,
					["serial"] = "Creature-0-3153-530-15-15949-0000793058",
					["monster"] = true,
				}, -- [12]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.044344,
					["damage_from"] = {
						["웃는얼굴에반하다"] = true,
						["아호와의증인"] = true,
					},
					["targets"] = {
						["웃는얼굴에반하다"] = 6,
						["아호와의증인"] = 107,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 113.044344,
					["delay"] = 0,
					["monster"] = true,
					["total"] = 113.044344,
					["classe"] = "UNKNOW",
					["damage_taken"] = 561.044344,
					["nome"] = "마나 추적자",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["웃는얼굴에반하다"] = 6,
									["아호와의증인"] = 92,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 98,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 98,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 15,
								["MISS"] = 1,
								["DODGE"] = 1,
							}, -- [1]
							[15798] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7,
								["targets"] = {
									["아호와의증인"] = 15,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 15,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 15,
								["c_max"] = 0,
								["id"] = 15798,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 4,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["fight_component"] = true,
					["end_time"] = 1559835640,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1559835604,
					["serial"] = "Creature-0-3153-530-15-15647-00007930E7",
					["dps_started"] = false,
				}, -- [13]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.035775,
					["damage_from"] = {
						["웃는얼굴에반하다"] = true,
						["마고루피"] = true,
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 58,
						["웃는얼굴에반하다"] = 8,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 66.035775,
					["delay"] = 0,
					["monster"] = true,
					["total"] = 66.035775,
					["classe"] = "UNKNOW",
					["damage_taken"] = 470.035775,
					["nome"] = "마나 망령",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9,
								["targets"] = {
									["아호와의증인"] = 58,
									["웃는얼굴에반하다"] = 8,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 66,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 66,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 9,
								["MISS"] = 1,
								["a_amt"] = 0,
							}, -- [1]
							[29109] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 29109,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							[25602] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 25602,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["fight_component"] = true,
					["end_time"] = 1559835650,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1559835625,
					["serial"] = "Creature-0-3153-530-15-15648-0000792FA2",
					["dps_started"] = false,
				}, -- [14]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.02223,
					["damage_from"] = {
						["웃는얼굴에반하다"] = true,
						["아호와의증인"] = true,
						["마고루피"] = true,
						["볼구프"] = true,
					},
					["targets"] = {
						["웃는얼굴에반하다"] = 17,
						["아호와의증인"] = 38,
						["볼구프"] = 8,
					},
					["pets"] = {
					},
					["monster"] = true,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 63.02223,
					["delay"] = 0,
					["fight_component"] = true,
					["total"] = 63.02223,
					["friendlyfire"] = {
					},
					["damage_taken"] = 402.02223,
					["nome"] = "다르나서스 정찰병",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9,
								["targets"] = {
									["웃는얼굴에반하다"] = 17,
									["아호와의증인"] = 38,
									["볼구프"] = 8,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 63,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 63,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 8,
								["a_dmg"] = 0,
								["a_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["end_time"] = 1559835698,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1559835676,
					["serial"] = "Creature-0-3153-530-15-15968-0000792965",
					["dps_started"] = false,
				}, -- [15]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.012157,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 20,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 20.012157,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1559836015,
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["nome"] = "조사단 앤빌워드",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 7,
								["targets"] = {
									["아호와의증인"] = 20,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 20,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 20,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 3,
								["DODGE"] = 1,
								["MISS"] = 1,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["total"] = 20.012157,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 191.012157,
					["start_time"] = 1559836005,
					["serial"] = "Creature-0-3153-530-15-15420-00007931EE",
					["monster"] = true,
				}, -- [16]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.075572,
					["dps_started"] = false,
					["damage_from"] = {
						["실버문 수호병"] = true,
						["아호와의증인"] = true,
					},
					["targets"] = {
						["실버문 수호병"] = 0,
						["아호와의증인"] = 287,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 287.075572,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 287.075572,
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["nome"] = "긴발톱 갈기발 스라소니",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 9,
								["targets"] = {
									["실버문 수호병"] = 0,
									["아호와의증인"] = 287,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 287,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 41,
								["total"] = 287,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 38,
								["a_dmg"] = 0,
								["DODGE"] = 3,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["delay"] = 0,
					["end_time"] = 1559836299,
					["last_dps"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 1485.075572,
					["start_time"] = 1559836232,
					["serial"] = "Creature-0-3153-530-15-15651-00007932CB",
					["friendlyfire"] = {
					},
				}, -- [17]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.061033,
					["damage_from"] = {
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 149,
					},
					["pets"] = {
					},
					["end_time"] = 1559926664,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 149.061033,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 149.061033,
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["nome"] = "광포한 용매",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["아호와의증인"] = 149,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 149,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 149,
								["c_max"] = 0,
								["MISS"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 17,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-3153-530-15-15650-00007A0743",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1559926628,
					["delay"] = 0,
					["damage_taken"] = 1094.061033,
				}, -- [18]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.040275,
					["damage_from"] = {
						["욤매"] = true,
						["조용한파도"] = true,
						["아호와의증인"] = true,
					},
					["targets"] = {
						["조용한파도"] = 7,
						["아호와의증인"] = 164,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 171.040275,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 171.040275,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "버림받은 엘프 난동자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["조용한파도"] = 7,
									["아호와의증인"] = 164,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 171,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 22,
								["total"] = 171,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 20,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1559926935,
					["serial"] = "Creature-0-3153-530-15-16162-00007A94A3",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1559926888,
					["delay"] = 0,
					["damage_taken"] = 827.040275,
				}, -- [19]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.033351,
					["damage_from"] = {
						["욤매"] = true,
						["조용한파도"] = true,
						["아호와의증인"] = true,
					},
					["targets"] = {
						["아호와의증인"] = 77,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 77.033351,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 77.033351,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "버림받은 엘프 암살자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 10,
								["targets"] = {
									["아호와의증인"] = 77,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 77,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 77,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 9,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1559926950,
					["serial"] = "Creature-0-3153-530-15-15645-0000FA936F",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1559926916,
					["delay"] = 0,
					["damage_taken"] = 675.033351,
				}, -- [20]
				{
					["flag_original"] = -2147483648,
					["totalabsorbed"] = 0.003164,
					["damage_from"] = {
					},
					["targets"] = {
						["아호와의증인"] = 32,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 32.003164,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1559927006,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "환경피해 (낙하 충격)",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							[3] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 32,
								["targets"] = {
									["아호와의증인"] = 32,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 32,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 32,
								["c_max"] = 0,
								["id"] = 3,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire_total"] = 0,
					["total"] = 32.003164,
					["serial"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.003164,
					["start_time"] = 1559927000,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [21]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.00876,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["아호와의증인"] = 5,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 5.00876,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1559927262,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "영원노래 뜰지기",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["아호와의증인"] = 5,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 5,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 5,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["monster"] = true,
					["total"] = 5.00876,
					["serial"] = "Creature-0-3153-530-15-15635-00007A921C",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.00876,
					["start_time"] = 1559927258,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [22]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.015941,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["아호와의증인"] = 138,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 138.015941,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1559927370,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "역병해골 약탈자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 12,
								["targets"] = {
									["아호와의증인"] = 138,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 138,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 138,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 14,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["monster"] = true,
					["total"] = 138.015941,
					["serial"] = "Creature-0-3153-530-15-15654-00007A8D82",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.015941,
					["start_time"] = 1559927344,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [23]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["healing_from"] = {
						["아호와의증인"] = true,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "MONK",
					["totalover"] = 1068.745431,
					["total_without_pet"] = 1539.745431,
					["total"] = 1539.745431,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-205-075D70FA",
					["totalabsorb"] = 0.745431,
					["last_hps"] = 0,
					["targets"] = {
						["아호와의증인"] = 734,
					},
					["totalover_without_pet"] = 0.745431,
					["healing_taken"] = 1539.745431,
					["fight_component"] = true,
					["end_time"] = 1559750559,
					["targets_overheal"] = {
						["아호와의증인"] = 258,
					},
					["nome"] = "아호와의증인",
					["spells"] = {
						["_ActorTable"] = {
							[59913] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["아호와의증인"] = 995,
								},
								["n_max"] = 12,
								["targets"] = {
									["아호와의증인"] = 1533,
								},
								["n_min"] = 0,
								["counter"] = 310,
								["overheal"] = 995,
								["total"] = 1533,
								["c_max"] = 0,
								["id"] = 59913,
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 1533,
								["n_amt"] = 310,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							[116670] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["아호와의증인"] = 73,
								},
								["n_max"] = 6,
								["targets"] = {
									["아호와의증인"] = 6,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 73,
								["total"] = 6,
								["c_max"] = 0,
								["id"] = 116670,
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 6,
								["n_amt"] = 1,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["heal_enemy_amt"] = 0,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 2,
					["start_time"] = 1559750398,
					["totaldenied"] = 0.745431,
					["delay"] = 0,
					["spec"] = 269,
				}, -- [1]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["resource"] = 444.824802,
					["targets"] = {
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MONK",
					["totalover"] = 0.008507,
					["fight_component"] = true,
					["alternatepower"] = 0.55727,
					["nome"] = "아호와의증인",
					["spec"] = 269,
					["grupo"] = true,
					["received"] = 0.55727,
					["passiveover"] = 0.008507,
					["resource_type"] = 12,
					["last_event"] = 0,
					["total"] = 0.55727,
					["tipo"] = 3,
					["serial"] = "Player-205-075D70FA",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 7,
					},
				}, -- [1]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["dispell"] = 1.004079,
					["pets"] = {
					},
					["classe"] = "MONK",
					["dispell_targets"] = {
						["사나운 뜰지기"] = 1,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							[129597] = {
								["dispell"] = 1,
								["id"] = 129597,
								["dispell_oque"] = {
									[31325] = 1,
								},
								["targets"] = {
									["사나운 뜰지기"] = 1,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["nome"] = "아호와의증인",
					["spec"] = 269,
					["grupo"] = true,
					["spell_cast"] = {
						[116670] = 1,
						[100780] = 186,
						[100784] = 88,
						[109132] = 4,
						[254409] = 1,
						[129597] = 5,
					},
					["buff_uptime"] = 20,
					["tipo"] = 4,
					["last_event"] = 0,
					["buff_uptime_targets"] = {
					},
					["dispell_oque"] = {
						[31325] = 1,
					},
					["serial"] = "Player-205-075D70FA",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[254409] = {
								["refreshamt"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = 254409,
								["uptime"] = 20,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
				}, -- [1]
				{
					["fight_component"] = true,
					["nome"] = "사나운 뜰지기",
					["last_event"] = 0,
					["spell_cast"] = {
						[31325] = 6,
					},
					["flag_original"] = 68136,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-3058-530-21-15294-000077E4BC",
					["pets"] = {
					},
				}, -- [2]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "마나 망령",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 68168,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-3153-530-15-15648-0000792FA2",
					["spell_cast"] = {
						[29109] = 1,
						[25602] = 1,
					},
				}, -- [3]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "마나 추적자",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-3153-530-15-15647-0000792AF5",
					["spell_cast"] = {
						[15798] = 1,
					},
				}, -- [4]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1559750555,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["spells_cast_timeline"] = {
		},
		["combat_counter"] = 5,
		["totals"] = {
			12957.628513, -- [1]
			1539.733927, -- [2]
			{
				0, -- [1]
				[0] = 0.543797,
				["alternatepower"] = 0,
				[3] = -0.011086,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 1.004079,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "01:02:35",
		["end_time"] = 11462.402,
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			10958.839474, -- [1]
			1539.742896, -- [2]
			{
				0, -- [1]
				[0] = 0.548763,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 1.004079,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["frags"] = {
		},
		["hasSaved"] = true,
		["segments_added"] = {
			{
				["elapsed"] = 22.4850000000006,
				["type"] = 0,
				["name"] = "역병해골 약탈자",
				["clock"] = "02:09:07",
			}, -- [1]
			{
				["elapsed"] = 3.63400000000001,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:08:28",
			}, -- [2]
			{
				["elapsed"] = 9.64800000000105,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:08:12",
			}, -- [3]
			{
				["elapsed"] = 29.0959999999996,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:07:13",
			}, -- [4]
			{
				["elapsed"] = 5.40899999999965,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:06:56",
			}, -- [5]
			{
				["elapsed"] = 6.14500000000044,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "02:06:35",
			}, -- [6]
			{
				["elapsed"] = 3.3130000000001,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:06:19",
			}, -- [7]
			{
				["elapsed"] = 2.09900000000016,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "02:05:51",
			}, -- [8]
			{
				["elapsed"] = 2.45800000000054,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:05:35",
			}, -- [9]
			{
				["elapsed"] = 13.3080000000009,
				["type"] = 0,
				["name"] = "버림받은 엘프 난동자",
				["clock"] = "02:04:19",
			}, -- [10]
			{
				["elapsed"] = 6.14799999999923,
				["type"] = 0,
				["name"] = "버림받은 엘프 난동자",
				["clock"] = "02:03:38",
			}, -- [11]
			{
				["elapsed"] = 3.43499999999949,
				["type"] = 0,
				["name"] = "버림받은 엘프 암살자",
				["clock"] = "02:03:23",
			}, -- [12]
			{
				["elapsed"] = 3.51399999999921,
				["type"] = 0,
				["name"] = "버림받은 엘프 난동자",
				["clock"] = "02:03:09",
			}, -- [13]
			{
				["elapsed"] = 4.91699999999946,
				["type"] = 0,
				["name"] = "버림받은 엘프 난동자",
				["clock"] = "02:02:58",
			}, -- [14]
			{
				["elapsed"] = 9.64199999999983,
				["type"] = 0,
				["name"] = "버림받은 엘프 암살자",
				["clock"] = "02:02:47",
			}, -- [15]
			{
				["elapsed"] = 7.54899999999907,
				["type"] = 0,
				["name"] = "버림받은 엘프 난동자",
				["clock"] = "02:02:34",
			}, -- [16]
			{
				["elapsed"] = 7.32200000000012,
				["type"] = 0,
				["name"] = "버림받은 엘프 암살자",
				["clock"] = "02:02:23",
			}, -- [17]
			{
				["elapsed"] = 3.63600000000042,
				["type"] = 0,
				["name"] = "버림받은 엘프 난동자",
				["clock"] = "02:02:11",
			}, -- [18]
			{
				["elapsed"] = 2.84600000000137,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:01:58",
			}, -- [19]
			{
				["elapsed"] = 1.61599999999999,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:01:47",
			}, -- [20]
			{
				["elapsed"] = 3.47299999999996,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "02:01:33",
			}, -- [21]
			{
				["elapsed"] = 5.63800000000083,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:01:14",
			}, -- [22]
			{
				["elapsed"] = 5.17100000000028,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "02:01:00",
			}, -- [23]
			{
				["elapsed"] = 4.54099999999926,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "02:00:44",
			}, -- [24]
			{
				["elapsed"] = 2.56500000000051,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "02:00:22",
			}, -- [25]
			{
				["elapsed"] = 2.35100000000057,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "02:00:05",
			}, -- [26]
			{
				["elapsed"] = 1.60300000000098,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "01:59:58",
			}, -- [27]
			{
				["elapsed"] = 3.67400000000089,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "01:59:38",
			}, -- [28]
			{
				["elapsed"] = 6.98699999999917,
				["type"] = 0,
				["name"] = "광포한 용매",
				["clock"] = "01:59:18",
			}, -- [29]
			{
				["elapsed"] = 5.67599999999948,
				["type"] = 0,
				["name"] = "긴발톱 갈기발 스라소니",
				["clock"] = "01:58:33",
			}, -- [30]
		},
		["data_fim"] = "02:09:30",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["start_time"] = 10806.9080000001,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["cleu_timeline"] = {
		},
	},
	["combat_counter"] = 166,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["last_realversion"] = 140,
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-205-075D70FA"] = 269,
	},
}
