
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 40,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003643,
							["damage_from"] = {
							},
							["targets"] = {
								["영혼 거머리"] = 235,
							},
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 235.003643,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1560535740,
							["friendlyfire_total"] = 0,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[192611] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 235,
										["targets"] = {
											["영혼 거머리"] = 235,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 235,
										["n_min"] = 235,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 235,
										["c_max"] = 0,
										["id"] = 192611,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["total"] = 235.003643,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 176.032691385883,
							["custom"] = 0,
							["last_event"] = 1560535738,
							["damage_taken"] = 0.003643,
							["start_time"] = 1560535738,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.001636,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001636,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.001636,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-3057-1481-10216-94655-000003C8C7",
							["nome"] = "영혼 거머리",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1560535740,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 235.001636,
							["start_time"] = 1560535740,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 40,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 40,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 40,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime"] = 2,
							["nome"] = "받아줘요악사",
							["pets"] = {
							},
							["last_event"] = 1560535740,
							["classe"] = "DEMONHUNTER",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 40,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14732.362,
				["tempo_start"] = 1560535738,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 45,
				["playing_solo"] = true,
				["totals"] = {
					235, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					235, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "03:09:01",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "영혼 거머리",
				["TotalElapsedCombatTime"] = 1.33499999999913,
				["CombatEndedAt"] = 14733.697,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 235.003643,
						}, -- [1]
					},
				},
				["end_time"] = 14733.697,
				["combat_id"] = 40,
				["cleu_events"] = {
					["n"] = 1,
				},
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "03:08:59",
				["start_time"] = 14732.362,
				["TimeData"] = {
				},
				["frags"] = {
					["영혼 거머리"] = 1,
				},
			}, -- [1]
			{
				{
					["combatId"] = 39,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007206,
							["total"] = 26175.007206,
							["damage_from"] = {
								["지옥 군주 카자"] = true,
							},
							["targets"] = {
								["지옥 군주 카자"] = 26175,
							},
							["pets"] = {
								"잿빛혓바닥 추적자 <받아줘요악사>", -- [1]
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20667.007206,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560535707,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 1795,
										["g_amt"] = 0,
										["n_max"] = 256,
										["targets"] = {
											["지옥 군주 카자"] = 5214,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3419,
										["n_min"] = 129,
										["g_dmg"] = 0,
										["counter"] = 24,
										["total"] = 5214,
										["c_max"] = 509,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["r_amt"] = 0,
										["c_min"] = 257,
									}, -- [1]
									[192611] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 251,
										["targets"] = {
											["지옥 군주 카자"] = 251,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 251,
										["n_min"] = 251,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 251,
										["c_max"] = 0,
										["id"] = 192611,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[162243] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1150,
										["g_amt"] = 0,
										["n_max"] = 288,
										["targets"] = {
											["지옥 군주 카자"] = 3450,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2300,
										["n_min"] = 287,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 3450,
										["c_max"] = 575,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 575,
									},
									[199547] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 2245,
										["g_amt"] = 0,
										["n_max"] = 395,
										["targets"] = {
											["지옥 군주 카자"] = 8071,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5826,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 8071,
										["c_max"] = 789,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 16,
										["r_amt"] = 0,
										["c_min"] = 667,
									},
									[198030] = {
										["c_amt"] = 15,
										["b_amt"] = 0,
										["c_dmg"] = 3681,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥 군주 카자"] = 3681,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 3681,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 245,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 880.009655930644,
							["custom"] = 0,
							["last_event"] = 1560535706,
							["damage_taken"] = 2784.007206,
							["start_time"] = 1560535676,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004879,
							["damage_from"] = {
								["받아줘요악사"] = true,
								["잿빛혓바닥 추적자 <받아줘요악사>"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 2784,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2784.004879,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535707,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "지옥 군주 카자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 210,
										["targets"] = {
											["받아줘요악사"] = 1078,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1078,
										["a_amt"] = 0,
										["n_min"] = 85,
										["g_dmg"] = 0,
										["counter"] = 11,
										["MISS"] = 1,
										["total"] = 1078,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[197002] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 948,
										["targets"] = {
											["받아줘요악사"] = 948,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 948,
										["n_min"] = 948,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 948,
										["c_max"] = 0,
										["id"] = 197002,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[197184] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["받아줘요악사"] = 112,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 112,
										["n_min"] = 18,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 112,
										["c_max"] = 0,
										["id"] = 197184,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[197180] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 197180,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[196955] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 646,
										["targets"] = {
											["받아줘요악사"] = 646,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 646,
										["n_min"] = 646,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 646,
										["c_max"] = 0,
										["id"] = 196955,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 2784.004879,
							["serial"] = "Creature-0-3057-1481-10216-96441-000003DEB0",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535704,
							["damage_taken"] = 26175.004879,
							["start_time"] = 1560535676,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 8465,
							["totalabsorbed"] = 0.003888,
							["serial"] = "Creature-0-3057-1481-10216-96877-000003E27D",
							["damage_from"] = {
							},
							["targets"] = {
								["지옥 군주 카자"] = 5508,
							},
							["pets"] = {
							},
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5508.003888,
							["dps_started"] = false,
							["total"] = 5508.003888,
							["classe"] = "PET",
							["ownerName"] = "받아줘요악사",
							["nome"] = "잿빛혓바닥 추적자 <받아줘요악사>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 924,
										["g_amt"] = 0,
										["n_max"] = 327,
										["targets"] = {
											["지옥 군주 카자"] = 5508,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4584,
										["n_min"] = 130,
										["g_dmg"] = 0,
										["counter"] = 29,
										["total"] = 5508,
										["c_max"] = 602,
										["MISS"] = 5,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 22,
										["r_amt"] = 0,
										["c_min"] = 322,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1560535707,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.003888,
							["start_time"] = 1560535679,
							["delay"] = 0,
							["last_event"] = 1560535706,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 39,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 39,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.00375,
							["resource"] = 304.00375,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.00375,
							["total"] = 0.00375,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.00375,
							["last_event"] = 1560535705,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.00375,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 39,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["spell_cast"] = {
								[198013] = 1,
								[162243] = 10,
								[162794] = 9,
								[195072] = 1,
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 33,
							["tipo"] = 4,
							["last_event"] = 1560535707,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 31,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[210105] = {
										["activedamt"] = 0,
										["id"] = 210105,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["classe"] = "DEMONHUNTER",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "지옥 군주 카자",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[197180] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-96441-000003DEB0",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 39,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1560535676,
				["enemy"] = "지옥 군주 카자",
				["combat_counter"] = 44,
				["playing_solo"] = true,
				["totals"] = {
					28959, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 14700.772,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "03:07:57",
				["end_time"] = 14700.772,
				["totals_grupo"] = {
					20667, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 39,
				["TotalElapsedCombatTime"] = 14700.772,
				["frags_need_refresh"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 26175.007206,
						}, -- [1]
					},
				},
				["frags"] = {
					["지옥 군주 카자"] = 1,
				},
				["data_fim"] = "03:08:28",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 14670.2,
				["contra"] = "지옥 군주 카자",
				["TimeData"] = {
				},
			}, -- [2]
			{
				{
					["combatId"] = 38,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008959,
							["total"] = 23451.008959,
							["damage_from"] = {
								["[*] 어둠의 칼날"] = true,
								["지옥수호병 도살자"] = true,
								["환경피해 (용암)"] = true,
								["에레다르 마술사"] = true,
							},
							["targets"] = {
								["에레다르 마술사"] = 2719,
								["지옥수호병 도살자"] = 20732,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 23451.008959,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560535657,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 321,
										["targets"] = {
											["에레다르 마술사"] = 624,
											["지옥수호병 도살자"] = 2708,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3332,
										["n_min"] = 140,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 3332,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 14,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[198030] = {
										["c_amt"] = 39,
										["b_amt"] = 0,
										["c_dmg"] = 9025,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥수호병 도살자"] = 9025,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 39,
										["total"] = 9025,
										["c_max"] = 295,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 196,
									},
									[162243] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1912,
										["g_amt"] = 0,
										["n_max"] = 345,
										["targets"] = {
											["에레다르 마술사"] = 1222,
											["지옥수호병 도살자"] = 1379,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 689,
										["n_min"] = 344,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2601,
										["c_max"] = 690,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 611,
									},
									[199547] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 3493,
										["g_amt"] = 0,
										["n_max"] = 474,
										["targets"] = {
											["에레다르 마술사"] = 873,
											["지옥수호병 도살자"] = 4913,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2293,
										["n_min"] = 400,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 5786,
										["c_max"] = 947,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 800,
									},
									[192611] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1805,
										["g_amt"] = 0,
										["n_max"] = 301,
										["targets"] = {
											["지옥수호병 도살자"] = 2707,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 902,
										["n_min"] = 300,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2707,
										["c_max"] = 602,
										["id"] = 192611,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 601,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 962.606065142468,
							["custom"] = 0,
							["last_event"] = 1560535656,
							["damage_taken"] = 19210.008959,
							["start_time"] = 1560535633,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005804,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 14984,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 14984.005804,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535657,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "지옥수호병 도살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 827,
										["g_amt"] = 0,
										["n_max"] = 443,
										["targets"] = {
											["받아줘요악사"] = 14984,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 14157,
										["n_min"] = 298,
										["g_dmg"] = 0,
										["counter"] = 45,
										["MISS"] = 1,
										["total"] = 14984,
										["c_max"] = 827,
										["DODGE"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 40,
										["r_amt"] = 0,
										["c_min"] = 827,
									}, -- [1]
									[200647] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200647,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[200632] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200632,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 14984.005804,
							["serial"] = "Creature-0-3057-1481-10216-96494-000003C924",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535655,
							["damage_taken"] = 20732.005804,
							["start_time"] = 1560535637,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008607,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 1400,
							},
							["serial"] = "",
							["spellicon"] = 136189,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1400.008607,
							["fight_component"] = true,
							["pets"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1560535676,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "[*] 어둠의 칼날",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[200662] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 89,
										["targets"] = {
											["받아줘요악사"] = 1400,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1400,
										["n_min"] = 86,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 1400,
										["c_max"] = 0,
										["id"] = 200662,
										["r_dmg"] = 0,
										["spellschool"] = 32,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 16,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1400.008607,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535663,
							["damage_taken"] = 0.008607,
							["start_time"] = 1560535648,
							["delay"] = 1560535663,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003018,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1348,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1348.003018,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535657,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "에레다르 마술사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 359,
										["targets"] = {
											["받아줘요악사"] = 359,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 359,
										["n_min"] = 359,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 359,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200582] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 989,
										["targets"] = {
											["받아줘요악사"] = 989,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 989,
										["n_min"] = 989,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 989,
										["c_max"] = 0,
										["id"] = 200582,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[200615] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200615,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1348.003018,
							["serial"] = "Creature-0-3057-1481-10216-102726-000003C801",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535645,
							["damage_taken"] = 2719.003018,
							["start_time"] = 1560535654,
							["delay"] = 1560535645,
							["tipo"] = 1,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 38,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["받아줘요악사"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 4604.003612,
							["total_without_pet"] = 17296.003612,
							["total"] = 17296.003612,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075EECC9",
							["totalabsorb"] = 0.003612,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 18250,
							},
							["totalover_without_pet"] = 0.003612,
							["healing_taken"] = 17296.003612,
							["fight_component"] = true,
							["end_time"] = 1560535657,
							["targets_overheal"] = {
								["받아줘요악사"] = 4604,
							},
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[202644] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["받아줘요악사"] = 4604,
										},
										["n_max"] = 3650,
										["targets"] = {
											["받아줘요악사"] = 17296,
										},
										["n_min"] = 0,
										["counter"] = 6,
										["overheal"] = 4604,
										["total"] = 17296,
										["c_max"] = 0,
										["id"] = 202644,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 17296,
										["n_amt"] = 6,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1560535649,
							["custom"] = 0,
							["last_event"] = 1560535657,
							["spec"] = 577,
							["totaldenied"] = 0.003612,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 38,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.00737,
							["resource"] = 189.00737,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.00737,
							["fight_component"] = true,
							["total"] = 0.00737,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.00737,
							["last_event"] = 1560535653,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.00737,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 38,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 44,
							["pets"] = {
							},
							["spell_cast"] = {
								[162794] = 6,
								[195072] = 2,
								[162243] = 5,
								[202719] = 1,
								[198013] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 2,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 2,
										["refreshamt"] = 5,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["last_event"] = 1560535657,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "지옥수호병 도살자",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200647] = 4,
								[200632] = 6,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-96494-000003C973",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["nome"] = "에레다르 마술사",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200615] = 1,
								[200582] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-102726-000003C801",
							["classe"] = "UNKNOW",
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 38,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14668.943,
				["tempo_start"] = 1560535633,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 43,
				["playing_solo"] = true,
				["totals"] = {
					41182.998117, -- [1]
					17296, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					23451, -- [1]
					17296, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "03:07:38",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥수호병 도살자",
				["TotalElapsedCombatTime"] = 24.3619999999992,
				["CombatEndedAt"] = 14651.41,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["받아줘요악사"] = 17296.003612,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 23451.008959,
						}, -- [1]
					},
				},
				["end_time"] = 14651.41,
				["combat_id"] = 38,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
					["받아줘요악사"] = {
						{
							true, -- [1]
							200662, -- [2]
							87, -- [3]
							1560535661.301, -- [4]
							14513, -- [5]
							"[*] 어둠의 칼날", -- [6]
							nil, -- [7]
							32, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							200662, -- [2]
							88, -- [3]
							1560535662.275, -- [4]
							14512, -- [5]
							"[*] 어둠의 칼날", -- [6]
							nil, -- [7]
							32, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							200662, -- [2]
							86, -- [3]
							1560535663.316, -- [4]
							14426, -- [5]
							"[*] 어둠의 칼날", -- [6]
							nil, -- [7]
							32, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
							true, -- [1]
							200662, -- [2]
							88, -- [3]
							1560535664.278, -- [4]
							14485, -- [5]
							"[*] 어둠의 칼날", -- [6]
							nil, -- [7]
							32, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [4]
						{
							true, -- [1]
							200662, -- [2]
							87, -- [3]
							1560535665.321, -- [4]
							14398, -- [5]
							"[*] 어둠의 칼날", -- [6]
							nil, -- [7]
							32, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [5]
						{
							true, -- [1]
							7, -- [2]
							1478, -- [3]
							1560535673.533, -- [4]
							13122, -- [5]
							"환경피해 (용암)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 7,
					},
				},
				["data_inicio"] = "03:07:14",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["에레다르 마술사"] = 1,
					["지옥수호병 도살자"] = 6,
				},
				["start_time"] = 14627.048,
				["TimeData"] = {
				},
				["contra"] = "지옥수호병 도살자",
			}, -- [3]
			{
				{
					["combatId"] = 37,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005822,
							["spec"] = 577,
							["damage_from"] = {
							},
							["targets"] = {
								["에레다르 마술사"] = 301,
								["지옥수호병 도살자"] = 1504,
								["가시발톱 새끼 거미"] = 27587,
							},
							["pets"] = {
							},
							["colocacao"] = 1,
							["end_time"] = 1560535632,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 29392.005822,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 29392.005822,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[192611] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 27587,
										["g_amt"] = 0,
										["n_max"] = 301,
										["targets"] = {
											["에레다르 마술사"] = 301,
											["지옥수호병 도살자"] = 1504,
											["가시발톱 새끼 거미"] = 27587,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1805,
										["n_min"] = 300,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 29392,
										["c_max"] = 27587,
										["id"] = 192611,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["r_amt"] = 0,
										["c_min"] = 27587,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 274691.643196336,
							["custom"] = 0,
							["last_event"] = 1560535631,
							["damage_taken"] = 0.005822,
							["start_time"] = 1560535631,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007953,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007953,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.007953,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-3057-1481-10216-96494-000003C92B",
							["nome"] = "지옥수호병 도살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1560535632,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1504.007953,
							["start_time"] = 1560535632,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004037,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004037,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.004037,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-3057-1481-10216-102726-000003C801",
							["nome"] = "에레다르 마술사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1560535632,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 301.004037,
							["start_time"] = 1560535632,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [3]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.002134,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002134,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.002134,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-3057-1481-10216-99650-000003AAFD",
							["nome"] = "가시발톱 새끼 거미",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["받아줘요악사"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1560535632,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 27587.002134,
							["start_time"] = 1560535632,
							["delay"] = 0,
							["last_event"] = 1560535631,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 37,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 37,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 37,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime"] = 2,
							["nome"] = "받아줘요악사",
							["pets"] = {
							},
							["last_event"] = 1560535632,
							["classe"] = "DEMONHUNTER",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 37,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14624.644,
				["tempo_start"] = 1560535631,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 42,
				["playing_solo"] = true,
				["totals"] = {
					29392, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					29392, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "03:07:12",
				["cleu_timeline"] = {
				},
				["enemy"] = "에레다르 마술사",
				["TotalElapsedCombatTime"] = 0.895000000000437,
				["CombatEndedAt"] = 14625.539,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 29392.005822,
						}, -- [1]
					},
				},
				["end_time"] = 14625.539,
				["combat_id"] = 37,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "03:07:11",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["가시발톱 새끼 거미"] = 1,
				},
				["start_time"] = 14624.644,
				["TimeData"] = {
				},
				["contra"] = "지옥수호병 도살자",
			}, -- [4]
			{
				{
					["combatId"] = 36,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002992,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 705,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 705.002992,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535623,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "지옥수호병 도살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 385,
										["targets"] = {
											["받아줘요악사"] = 705,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 705,
										["n_min"] = 320,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 705,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 705.002992,
							["serial"] = "Creature-0-3057-1481-10216-96494-000003E014",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535621,
							["damage_taken"] = 4189.002992,
							["start_time"] = 1560535619,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.0064,
							["damage_from"] = {
								["지옥수호병 도살자"] = true,
							},
							["targets"] = {
								["지옥수호병 도살자"] = 4189,
							},
							["total"] = 4189.0064,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4189.0064,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1560535623,
							["friendlyfire_total"] = 0,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 580,
										["g_amt"] = 0,
										["n_max"] = 305,
										["targets"] = {
											["지옥수호병 도살자"] = 1042,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 462,
										["n_min"] = 157,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1042,
										["c_max"] = 580,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 580,
									}, -- [1]
									[162243] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1381,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥수호병 도살자"] = 1381,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1381,
										["c_max"] = 691,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 690,
									},
									[198030] = {
										["c_amt"] = 6,
										["b_amt"] = 0,
										["c_dmg"] = 1766,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥수호병 도살자"] = 1766,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1766,
										["c_max"] = 295,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 294,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 1174.37802074602,
							["custom"] = 0,
							["last_event"] = 1560535623,
							["damage_taken"] = 705.0064,
							["start_time"] = 1560535619,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 36,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 36,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.007851,
							["resource"] = 24.007851,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.007851,
							["total"] = 0.007851,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.007851,
							["last_event"] = 1560535620,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.007851,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 36,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 577,
							["grupo"] = true,
							["spell_cast"] = {
								[162243] = 1,
								[198013] = 1,
							},
							["buff_uptime"] = 8,
							["nome"] = "받아줘요악사",
							["pets"] = {
							},
							["last_event"] = 1560535623,
							["classe"] = "DEMONHUNTER",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["actived_at"] = 1560535622,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 4,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 36,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1560535619,
				["enemy"] = "지옥수호병 도살자",
				["combat_counter"] = 41,
				["playing_solo"] = true,
				["totals"] = {
					4894, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 14617.433,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "03:07:00",
				["end_time"] = 14617.433,
				["totals_grupo"] = {
					4189, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 36,
				["TotalElapsedCombatTime"] = 14617.433,
				["frags_need_refresh"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 4189.0064,
						}, -- [1]
					},
				},
				["frags"] = {
					["지옥수호병 도살자"] = 1,
				},
				["data_fim"] = "03:07:04",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 14612.984,
				["contra"] = "지옥수호병 도살자",
				["TimeData"] = {
				},
			}, -- [5]
			{
				{
					["combatId"] = 35,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004813,
							["damage_from"] = {
								["[*] 어둠의 칼날"] = true,
								["지옥수호병 도살자"] = true,
							},
							["targets"] = {
								["에레다르 마술사"] = 2705,
								["지옥수호병 도살자"] = 20048,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 22753.004813,
							["end_time"] = 1560535604,
							["colocacao"] = 1,
							["dps_started"] = false,
							["total"] = 22753.004813,
							["classe"] = "DEMONHUNTER",
							["on_hold"] = false,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 510,
										["g_amt"] = 0,
										["n_max"] = 302,
										["targets"] = {
											["지옥수호병 도살자"] = 2617,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2107,
										["n_min"] = 129,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 2617,
										["c_max"] = 510,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["r_amt"] = 0,
										["c_min"] = 510,
									}, -- [1]
									[198030] = {
										["c_amt"] = 60,
										["b_amt"] = 0,
										["c_dmg"] = 11029,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["에레다르 마술사"] = 2454,
											["지옥수호병 도살자"] = 8575,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 60,
										["total"] = 11029,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 163,
									},
									[162243] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1380,
										["g_amt"] = 0,
										["n_max"] = 345,
										["targets"] = {
											["지옥수호병 도살자"] = 2298,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 918,
										["n_min"] = 286,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2298,
										["c_max"] = 690,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 690,
									},
									[192611] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 251,
										["targets"] = {
											["에레다르 마술사"] = 251,
											["지옥수호병 도살자"] = 1252,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1503,
										["n_min"] = 250,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1503,
										["c_max"] = 0,
										["id"] = 192611,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[199547] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 3627,
										["g_amt"] = 0,
										["n_max"] = 473,
										["targets"] = {
											["지옥수호병 도살자"] = 5306,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1679,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 5306,
										["c_max"] = 947,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 788,
									},
								},
							},
							["grupo"] = true,
							["spec"] = 577,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 1309.52545686331,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 6656.004813,
							["start_time"] = 1560535587,
							["delay"] = 0,
							["last_event"] = 1560535604,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008203,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 6393,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3057-1481-10216-96494-000003DFFE",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6393.008203,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 6393.008203,
							["end_time"] = 1560535604,
							["friendlyfire_total"] = 0,
							["nome"] = "지옥수호병 도살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 430,
										["targets"] = {
											["받아줘요악사"] = 6393,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 6393,
										["n_min"] = 296,
										["g_dmg"] = 0,
										["counter"] = 20,
										["a_amt"] = 0,
										["total"] = 6393,
										["c_max"] = 0,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200647] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200647,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[200632] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200632,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535603,
							["damage_taken"] = 20048.008203,
							["start_time"] = 1560535593,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003651,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003651,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.003651,
							["end_time"] = 1560535604,
							["friendlyfire_total"] = 0,
							["nome"] = "에레다르 마술사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-3057-1481-10216-96473-000003DF4F",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 2705.003651,
							["start_time"] = 1560535604,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003072,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 263,
							},
							["serial"] = "",
							["spellicon"] = 136189,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 263.003072,
							["fight_component"] = true,
							["pets"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1560535604,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "[*] 어둠의 칼날",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[200662] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 89,
										["targets"] = {
											["받아줘요악사"] = 263,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 263,
										["n_min"] = 86,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 263,
										["c_max"] = 0,
										["id"] = 200662,
										["r_dmg"] = 0,
										["spellschool"] = 32,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 263.003072,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535594,
							["damage_taken"] = 0.003072,
							["start_time"] = 1560535600,
							["delay"] = 1560535594,
							["tipo"] = 1,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 35,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["받아줘요악사"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 6717.005093,
							["total_without_pet"] = 4233.005093,
							["total"] = 4233.005093,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075EECC9",
							["totalabsorb"] = 0.005093,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 7300,
							},
							["totalover_without_pet"] = 0.005093,
							["healing_taken"] = 4233.005093,
							["fight_component"] = true,
							["end_time"] = 1560535604,
							["targets_overheal"] = {
								["받아줘요악사"] = 6717,
							},
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[202644] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["받아줘요악사"] = 6717,
										},
										["n_max"] = 3650,
										["targets"] = {
											["받아줘요악사"] = 4233,
										},
										["n_min"] = 3650,
										["counter"] = 3,
										["overheal"] = 6717,
										["total"] = 4233,
										["c_max"] = 0,
										["id"] = 202644,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 4233,
										["n_amt"] = 3,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1560535594,
							["custom"] = 0,
							["last_event"] = 1560535603,
							["spec"] = 577,
							["totaldenied"] = 0.005093,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 35,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.007583,
							["resource"] = 143.007583,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.007583,
							["fight_component"] = true,
							["total"] = 0.007583,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.007583,
							["last_event"] = 1560535619,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.007583,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 35,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 29,
							["pets"] = {
							},
							["spell_cast"] = {
								[198013] = 1,
								[162243] = 5,
								[162794] = 6,
							},
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 17,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["last_event"] = 1560535604,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "지옥수호병 도살자",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200632] = 1,
								[200647] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-96494-000003DFFE",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 35,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14612.984,
				["tempo_start"] = 1560535587,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 40,
				["playing_solo"] = true,
				["totals"] = {
					29409, -- [1]
					4233, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					22753, -- [1]
					4233, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "03:06:45",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥수호병 도살자",
				["TotalElapsedCombatTime"] = 17.8430000000008,
				["CombatEndedAt"] = 14598.415,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["받아줘요악사"] = 4233.005093,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 22753.004813,
						}, -- [1]
					},
				},
				["end_time"] = 14598.415,
				["combat_id"] = 35,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "03:06:27",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["에레다르 마술사"] = 1,
					["지옥수호병 도살자"] = 5,
				},
				["start_time"] = 14580.572,
				["TimeData"] = {
				},
				["contra"] = "지옥수호병 도살자",
			}, -- [6]
			{
				{
					["combatId"] = 34,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006002,
							["total"] = 13609.006002,
							["damage_from"] = {
								["격노용사"] = true,
								["파멸의 학살자"] = true,
							},
							["targets"] = {
								["격노용사"] = 10562,
								["파멸의 학살자"] = 3047,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 13609.006002,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560535528,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 758,
										["g_amt"] = 0,
										["n_max"] = 250,
										["targets"] = {
											["격노용사"] = 1008,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 250,
										["n_min"] = 250,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1008,
										["c_max"] = 502,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 256,
									}, -- [1]
									[198030] = {
										["c_amt"] = 62,
										["b_amt"] = 0,
										["c_dmg"] = 11287,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["격노용사"] = 8585,
											["파멸의 학살자"] = 2702,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 62,
										["total"] = 11287,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 163,
									},
									[199547] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 395,
										["targets"] = {
											["격노용사"] = 395,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 395,
										["n_min"] = 395,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 395,
										["c_max"] = 0,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[162243] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 345,
										["targets"] = {
											["격노용사"] = 574,
											["파멸의 학살자"] = 345,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 919,
										["n_min"] = 287,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 919,
										["c_max"] = 0,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 1807.06493188135,
							["custom"] = 0,
							["last_event"] = 1560535527,
							["damage_taken"] = 2811.006002,
							["start_time"] = 1560535521,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003822,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1420,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1420.003822,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535528,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "파멸의 학살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 410,
										["targets"] = {
											["받아줘요악사"] = 807,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 807,
										["n_min"] = 196,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 807,
										["c_max"] = 0,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200525] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 613,
										["targets"] = {
											["받아줘요악사"] = 613,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 613,
										["n_min"] = 613,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 613,
										["c_max"] = 0,
										["id"] = 200525,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1420.003822,
							["serial"] = "Creature-0-3057-1481-10216-93716-000003D1C5",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535528,
							["damage_taken"] = 3047.003822,
							["start_time"] = 1560535523,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003613,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1391,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1391.003613,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535528,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "격노용사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 407,
										["targets"] = {
											["받아줘요악사"] = 1124,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1124,
										["n_min"] = 198,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1124,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200753] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200753,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[200755] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 54,
										["targets"] = {
											["받아줘요악사"] = 267,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 267,
										["n_min"] = 53,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 267,
										["c_max"] = 0,
										["id"] = 200755,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1391.003613,
							["serial"] = "Creature-0-3057-1481-10216-97034-000003D09E",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535526,
							["damage_taken"] = 10562.003613,
							["start_time"] = 1560535523,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 34,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["받아줘요악사"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 8750.002835,
							["total_without_pet"] = 2200.002835,
							["total"] = 2200.002835,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075EECC9",
							["totalabsorb"] = 0.002835,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 3650,
							},
							["totalover_without_pet"] = 0.002835,
							["healing_taken"] = 2200.002835,
							["fight_component"] = true,
							["end_time"] = 1560535528,
							["targets_overheal"] = {
								["받아줘요악사"] = 8750,
							},
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[202644] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["받아줘요악사"] = 8750,
										},
										["n_max"] = 2200,
										["targets"] = {
											["받아줘요악사"] = 2200,
										},
										["n_min"] = 0,
										["counter"] = 3,
										["overheal"] = 8750,
										["total"] = 2200,
										["c_max"] = 0,
										["id"] = 202644,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 2200,
										["n_amt"] = 3,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1560535526,
							["custom"] = 0,
							["last_event"] = 1560535527,
							["spec"] = 577,
							["totaldenied"] = 0.002835,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 34,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.006935,
							["resource"] = 69.006935,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.006935,
							["fight_component"] = true,
							["total"] = 0.006935,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.006935,
							["last_event"] = 1560535527,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.006935,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 34,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 12,
							["pets"] = {
							},
							["spell_cast"] = {
								[198013] = 1,
								[162243] = 2,
								[162794] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["last_event"] = 1560535528,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "격노용사",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200753] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-97034-000003D106",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 34,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1560535521,
				["enemy"] = "격노용사",
				["combat_counter"] = 39,
				["playing_solo"] = true,
				["totals"] = {
					16420, -- [1]
					2200, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 14522.118,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "03:05:21",
				["end_time"] = 14522.118,
				["totals_grupo"] = {
					13609, -- [1]
					2200, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 34,
				["TotalElapsedCombatTime"] = 14522.118,
				["frags_need_refresh"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["받아줘요악사"] = 2200.002835,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 13609.006002,
						}, -- [1]
					},
				},
				["frags"] = {
					["격노용사"] = 4,
					["파멸의 학살자"] = 1,
				},
				["data_fim"] = "03:05:29",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 14514.587,
				["contra"] = "격노용사",
				["TimeData"] = {
				},
			}, -- [7]
			{
				{
					["combatId"] = 33,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006928,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 2327,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2327.006928,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535356,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "파멸의 학살자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 420,
										["targets"] = {
											["받아줘요악사"] = 2327,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2327,
										["n_min"] = 144,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 2327,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 2327.006928,
							["serial"] = "Creature-0-3057-1481-10216-93716-000003C72F",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535347,
							["damage_taken"] = 0.006928,
							["start_time"] = 1560535336,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00798,
							["damage_from"] = {
								["파멸의 학살자"] = true,
							},
							["targets"] = {
							},
							["on_hold"] = false,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00798,
							["spec"] = 577,
							["dps_started"] = false,
							["total"] = 0.00798,
							["classe"] = "DEMONHUNTER",
							["serial"] = "Player-205-075EECC9",
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["end_time"] = 1560535356,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 2327.00798,
							["start_time"] = 1560535356,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 33,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 33,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.002356,
							["resource"] = 22.002356,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.002356,
							["total"] = 0.002356,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.002356,
							["last_event"] = 1560535521,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.002356,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 33,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 577,
							["grupo"] = true,
							["spell_cast"] = {
								[195072] = 3,
								[131347] = 4,
							},
							["buff_uptime"] = 20,
							["nome"] = "받아줘요악사",
							["pets"] = {
							},
							["last_event"] = 1560535356,
							["classe"] = "DEMONHUNTER",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[131347] = {
										["activedamt"] = 0,
										["id"] = 131347,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 20,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[200175] = {
										["activedamt"] = 1,
										["id"] = 200175,
										["targets"] = {
										},
										["actived_at"] = 1560535336,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 33,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14513.573,
				["tempo_start"] = 1560535336,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 38,
				["playing_solo"] = true,
				["totals"] = {
					2327, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["data_fim"] = "03:02:36",
				["cleu_timeline"] = {
				},
				["enemy"] = "파멸의 학살자",
				["TotalElapsedCombatTime"] = 14349.517,
				["CombatEndedAt"] = 14349.517,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 0.00798,
						}, -- [1]
					},
				},
				["end_time"] = 14349.517,
				["combat_id"] = 33,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "03:02:17",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 14330.046,
				["TimeData"] = {
				},
				["contra"] = "파멸의 학살자",
			}, -- [8]
			{
				{
					["combatId"] = 32,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003195,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 348,
							},
							["pets"] = {
							},
							["serial"] = "Creature-0-3057-1481-10216-94654-000003DE26",
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 348.003195,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 348.003195,
							["end_time"] = 1560535311,
							["friendlyfire_total"] = 0,
							["nome"] = "파멸수호병 파멸자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 348,
										["targets"] = {
											["받아줘요악사"] = 348,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 348,
										["n_min"] = 348,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 348,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535287,
							["damage_taken"] = 0.003195,
							["start_time"] = 1560535310,
							["delay"] = 1560535287,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005577,
							["damage_from"] = {
								["파멸수호병 파멸자"] = true,
								["더러운 지옥사냥개"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005577,
							["on_hold"] = false,
							["end_time"] = 1560535311,
							["dps_started"] = false,
							["total"] = 0.005577,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 577,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 696.005577,
							["start_time"] = 1560535311,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008552,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 348,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 348.008552,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535311,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "더러운 지옥사냥개",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 348,
										["targets"] = {
											["받아줘요악사"] = 348,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 348,
										["n_min"] = 348,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 348,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200417] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200417,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 348.008552,
							["serial"] = "Creature-0-3057-1481-10216-93115-0000038E3C",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535295,
							["damage_taken"] = 0.008552,
							["start_time"] = 1560535310,
							["delay"] = 1560535295,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 32,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 32,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 32,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime"] = 48,
							["nome"] = "받아줘요악사",
							["pets"] = {
							},
							["last_event"] = 1560535311,
							["classe"] = "DEMONHUNTER",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[200175] = {
										["activedamt"] = 1,
										["id"] = 200175,
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "더러운 지옥사냥개",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200417] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93115-0000038E3C",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 32,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14328.831,
				["tempo_start"] = 1560535287,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 37,
				["playing_solo"] = true,
				["totals"] = {
					696, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["data_fim"] = "03:01:52",
				["cleu_timeline"] = {
				},
				["enemy"] = "파멸수호병 파멸자",
				["TotalElapsedCombatTime"] = 14305.302,
				["CombatEndedAt"] = 14305.302,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 0.005577,
						}, -- [1]
					},
				},
				["end_time"] = 14305.302,
				["combat_id"] = 32,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "03:01:27",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 14280.551,
				["TimeData"] = {
				},
				["contra"] = "파멸수호병 파멸자",
			}, -- [9]
			{
				{
					["combatId"] = 31,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001785,
							["total"] = 27348.001785,
							["damage_from"] = {
								["파멸의 사령관 벨라이아쉬"] = true,
								["파멸수호병 파멸자"] = true,
								["[*] 비통의 첨탑"] = true,
							},
							["targets"] = {
								["파멸수호병 파멸자"] = 3907,
								["파멸의 사령관 벨라이아쉬"] = 23441,
							},
							["pets"] = {
								"갈퀴흉터 바다소환사 <받아줘요악사>", -- [1]
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 26961.001785,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560535233,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 14,
										["b_amt"] = 0,
										["c_dmg"] = 5887,
										["g_amt"] = 0,
										["n_max"] = 297,
										["targets"] = {
											["파멸수호병 파멸자"] = 880,
											["파멸의 사령관 벨라이아쉬"] = 7230,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2223,
										["n_min"] = 128,
										["g_dmg"] = 0,
										["counter"] = 29,
										["total"] = 8110,
										["c_max"] = 603,
										["MISS"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 12,
										["r_amt"] = 0,
										["c_min"] = 257,
									}, -- [1]
									[198030] = {
										["c_amt"] = 29,
										["b_amt"] = 0,
										["c_dmg"] = 6380,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["파멸수호병 파멸자"] = 2455,
											["파멸의 사령관 벨라이아쉬"] = 3925,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 29,
										["total"] = 6380,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 163,
									},
									[199547] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 3334,
										["g_amt"] = 0,
										["n_max"] = 474,
										["targets"] = {
											["파멸의 사령관 벨라이아쉬"] = 7673,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4339,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 7673,
										["c_max"] = 946,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 789,
									},
									[162243] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1142,
										["g_amt"] = 0,
										["n_max"] = 343,
										["targets"] = {
											["파멸수호병 파멸자"] = 572,
											["파멸의 사령관 벨라이아쉬"] = 4226,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3656,
										["n_min"] = 285,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 4798,
										["c_max"] = 571,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 12,
										["r_amt"] = 0,
										["c_min"] = 571,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 651.546237790058,
							["custom"] = 0,
							["last_event"] = 1560535233,
							["damage_taken"] = 10445.001785,
							["start_time"] = 1560535191,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004262,
							["damage_from"] = {
								["받아줘요악사"] = true,
								["갈퀴흉터 바다소환사 <받아줘요악사>"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 7381,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7381.004262,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535233,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "파멸의 사령관 벨라이아쉬",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1363,
										["g_amt"] = 0,
										["n_max"] = 425,
										["targets"] = {
											["받아줘요악사"] = 4353,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2990,
										["n_min"] = 292,
										["g_dmg"] = 0,
										["counter"] = 12,
										["a_amt"] = 0,
										["total"] = 4353,
										["c_max"] = 702,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 661,
									}, -- [1]
									[196677] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 769,
										["targets"] = {
											["받아줘요악사"] = 1516,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1516,
										["n_min"] = 747,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1516,
										["c_max"] = 0,
										["id"] = 196677,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[196625] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 196625,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[196403] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 766,
										["targets"] = {
											["받아줘요악사"] = 1512,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1512,
										["n_min"] = 746,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1512,
										["c_max"] = 0,
										["id"] = 196403,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 7381.004262,
							["serial"] = "Creature-0-3057-1481-10216-93221-000003E059",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535233,
							["damage_taken"] = 23441.004262,
							["start_time"] = 1560535194,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003536,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 1863,
							},
							["serial"] = "",
							["spellicon"] = 135802,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1863.003536,
							["fight_component"] = true,
							["pets"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1560535233,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "[*] 비통의 첨탑",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[192603] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 373,
										["targets"] = {
											["받아줘요악사"] = 1863,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1863,
										["n_min"] = 248,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1863,
										["c_max"] = 0,
										["id"] = 192603,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1863.003536,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535222,
							["damage_taken"] = 0.003536,
							["start_time"] = 1560535216,
							["delay"] = 1560535222,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001034,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1201,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1201.001034,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535233,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "파멸수호병 파멸자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 371,
										["targets"] = {
											["받아줘요악사"] = 723,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 723,
										["n_min"] = 352,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 723,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200608] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 193,
										["targets"] = {
											["받아줘요악사"] = 478,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 478,
										["n_min"] = 46,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 478,
										["c_max"] = 0,
										["id"] = 200608,
										["r_dmg"] = 0,
										["spellschool"] = 32,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1201.001034,
							["serial"] = "Creature-0-3057-1481-10216-94654-000003C687",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535199,
							["damage_taken"] = 3907.001034,
							["start_time"] = 1560535224,
							["delay"] = 1560535199,
							["tipo"] = 1,
						}, -- [4]
						{
							["flag_original"] = 8465,
							["totalabsorbed"] = 0.001912,
							["serial"] = "Creature-0-3057-1481-10216-96884-000003E0B9",
							["damage_from"] = {
							},
							["targets"] = {
								["파멸의 사령관 벨라이아쉬"] = 387,
							},
							["pets"] = {
							},
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 387.001912,
							["dps_started"] = false,
							["total"] = 387.001912,
							["classe"] = "PET",
							["ownerName"] = "받아줘요악사",
							["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[197745] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 195,
										["targets"] = {
											["파멸의 사령관 벨라이아쉬"] = 387,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 387,
										["n_min"] = 192,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 387,
										["c_max"] = 0,
										["id"] = 197745,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1560535233,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.001912,
							["start_time"] = 1560535229,
							["delay"] = 0,
							["last_event"] = 1560535232,
						}, -- [5]
					},
				}, -- [1]
				{
					["combatId"] = 31,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["받아줘요악사"] = 124,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 124.00675,
							["total_without_pet"] = 3324.00675,
							["total"] = 3324.00675,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075EECC9",
							["totalabsorb"] = 0.00675,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 3448,
							},
							["totalover_without_pet"] = 0.00675,
							["healing_taken"] = 3324.00675,
							["fight_component"] = true,
							["end_time"] = 1560535233,
							["start_time"] = 1560535232,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[202644] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["받아줘요악사"] = 124,
										},
										["n_max"] = 3324,
										["targets"] = {
											["받아줘요악사"] = 3324,
										},
										["n_min"] = 3324,
										["counter"] = 1,
										["overheal"] = 124,
										["total"] = 3324,
										["c_max"] = 0,
										["id"] = 202644,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 3324,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["healing_from"] = {
								["받아줘요악사"] = true,
							},
							["heal_enemy_amt"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["spec"] = 577,
							["totaldenied"] = 0.00675,
							["delay"] = 1560535197,
							["last_event"] = 1560535197,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 31,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.008647,
							["resource"] = 388.008647,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.008647,
							["fight_component"] = true,
							["total"] = 0.008647,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.008647,
							["last_event"] = 1560535232,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.008647,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 31,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 60,
							["pets"] = {
								"갈퀴흉터 바다소환사 <받아줘요악사>", -- [1]
							},
							["spell_cast"] = {
								[198013] = 2,
								[162243] = 13,
								[162794] = 8,
								[195072] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 2,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 42,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[210093] = {
										["activedamt"] = 0,
										["id"] = 210093,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["last_event"] = 1560535233,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "파멸의 사령관 벨라이아쉬",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[196677] = 2,
								[196625] = 2,
								[196403] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93221-000003E059",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 8465,
							["ownerName"] = "받아줘요악사",
							["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
							["pets"] = {
							},
							["classe"] = "PET",
							["tipo"] = 4,
							["spell_cast"] = {
								[197745] = 2,
							},
							["serial"] = "Creature-0-3057-1481-10216-96884-000003E0B9",
							["last_event"] = 0,
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 31,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14279.256,
				["tempo_start"] = 1560535191,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 36,
				["playing_solo"] = true,
				["totals"] = {
					37793, -- [1]
					3324, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					26961, -- [1]
					3324, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "03:00:34",
				["cleu_timeline"] = {
				},
				["enemy"] = "파멸수호병 파멸자",
				["TotalElapsedCombatTime"] = 14226.948,
				["CombatEndedAt"] = 14226.948,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["받아줘요악사"] = 3324.00675,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 27348.001785,
						}, -- [1]
					},
				},
				["end_time"] = 14226.948,
				["combat_id"] = 31,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:59:52",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["파멸수호병 파멸자"] = 1,
				},
				["start_time"] = 14184.974,
				["TimeData"] = {
				},
				["contra"] = "파멸수호병 파멸자",
			}, -- [10]
			{
				{
					["combatId"] = 30,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003935,
							["damage_from"] = {
								["군단 사령부"] = true,
								["모아그 투사"] = true,
								["에레다르 소환사"] = true,
								["환경피해 (낙하 충격)"] = true,
								["파멸수호병 파멸자"] = true,
								["세비스 브라이트플레임"] = true,
							},
							["targets"] = {
							},
							["on_hold"] = false,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003935,
							["spec"] = 577,
							["dps_started"] = false,
							["total"] = 0.003935,
							["classe"] = "DEMONHUNTER",
							["serial"] = "Player-205-075EECC9",
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["end_time"] = 1560535083,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 59951.003935,
							["start_time"] = 1560535083,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008662,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 399,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 399.008662,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535083,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "모아그 투사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 399,
										["targets"] = {
											["받아줘요악사"] = 399,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 399,
										["n_min"] = 399,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 399,
										["c_max"] = 0,
										["DODGE"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200425] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200425,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 399.008662,
							["serial"] = "Creature-0-3057-1481-10216-96400-000003C592",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535049,
							["damage_taken"] = 0.008662,
							["start_time"] = 1560535072,
							["delay"] = 1560535049,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003746,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 388,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 388.003746,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535083,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "에레다르 소환사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 388,
										["targets"] = {
											["받아줘요악사"] = 388,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 388,
										["n_min"] = 388,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 388,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 388.003746,
							["serial"] = "Creature-0-3057-1481-10216-95046-000003C576",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535059,
							["damage_taken"] = 0.003746,
							["start_time"] = 1560535082,
							["delay"] = 1560535059,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.0033,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 371,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 371.0033,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560535083,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "군단 사령부",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[193507] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 371,
										["targets"] = {
											["받아줘요악사"] = 371,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 371,
										["n_min"] = 371,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 371,
										["c_max"] = 0,
										["id"] = 193507,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 371.0033,
							["serial"] = "Creature-0-3057-1481-10216-98191-00000346AE",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560535040,
							["damage_taken"] = 0.0033,
							["start_time"] = 1560535082,
							["delay"] = 1560535040,
							["tipo"] = 1,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 30,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 30,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.007182,
							["resource"] = 22.007182,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.007182,
							["total"] = 0.007182,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.007182,
							["last_event"] = 1560535191,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.007182,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 30,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime"] = 88,
							["nome"] = "받아줘요악사",
							["pets"] = {
							},
							["last_event"] = 1560535083,
							["classe"] = "DEMONHUNTER",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 44,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[200175] = {
										["activedamt"] = 1,
										["id"] = 200175,
										["targets"] = {
										},
										["uptime"] = 44,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "모아그 투사",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200425] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-96400-000003C561",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 30,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14172.288,
				["tempo_start"] = 1560535039,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 35,
				["playing_solo"] = true,
				["totals"] = {
					1157.964038, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["data_fim"] = "02:58:04",
				["cleu_timeline"] = {
				},
				["enemy"] = "모아그 투사",
				["TotalElapsedCombatTime"] = 14077.428,
				["CombatEndedAt"] = 14077.428,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 0.003935,
						}, -- [1]
					},
				},
				["end_time"] = 14077.428,
				["combat_id"] = 30,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
					["받아줘요악사"] = {
						{
							true, -- [1]
							204317, -- [2]
							58310, -- [3]
							1560535089.483, -- [4]
							1, -- [5]
							"세비스 브라이트플레임", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							45394, -- [10]
						}, -- [1]
						{
							true, -- [1]
							3, -- [2]
							76, -- [3]
							1560535179.84, -- [4]
							12393, -- [5]
							"환경피해 (낙하 충격)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							1, -- [2]
							407, -- [3]
							1560535180.283, -- [4]
							12393, -- [5]
							"파멸수호병 파멸자", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 4,
					},
				},
				["data_inicio"] = "02:57:20",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 14032.923,
				["TimeData"] = {
				},
				["contra"] = "모아그 투사",
			}, -- [11]
			{
				{
					["combatId"] = 29,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00623,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 711,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 711.00623,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534997,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "지옥수호병 보초",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 390,
										["targets"] = {
											["받아줘요악사"] = 711,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 711,
										["n_min"] = 321,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 711,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200570] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200570,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 711.00623,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003DF9C",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534962,
							["damage_taken"] = 0.00623,
							["start_time"] = 1560534996,
							["delay"] = 1560534962,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007222,
							["damage_from"] = {
								["지옥수호병 보초"] = true,
								["파멸수호병 파멸자"] = true,
								["더러운 지옥사냥개"] = true,
							},
							["targets"] = {
								["파멸수호병 파멸자"] = 8565,
								["더러운 지옥사냥개"] = 4017,
							},
							["total"] = 12582.007222,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 12582.007222,
							["colocacao"] = 1,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1560534997,
							["friendlyfire_total"] = 0,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1683,
										["g_amt"] = 0,
										["n_max"] = 254,
										["targets"] = {
											["파멸수호병 파멸자"] = 1740,
											["더러운 지옥사냥개"] = 740,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 797,
										["n_min"] = 135,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 2480,
										["c_max"] = 602,
										["MISS"] = 5,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 490,
									}, -- [1]
									[199547] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1893,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["파멸수호병 파멸자"] = 1893,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1893,
										["c_max"] = 947,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 946,
									},
									[162243] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1372,
										["g_amt"] = 0,
										["n_max"] = 286,
										["targets"] = {
											["파멸수호병 파멸자"] = 1658,
											["더러운 지옥사냥개"] = 571,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 857,
										["n_min"] = 285,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2229,
										["c_max"] = 686,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 686,
									},
									[192611] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 251,
										["targets"] = {
											["더러운 지옥사냥개"] = 251,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 251,
										["n_min"] = 251,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 251,
										["c_max"] = 0,
										["id"] = 192611,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[198030] = {
										["c_amt"] = 30,
										["b_amt"] = 0,
										["c_dmg"] = 5729,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["파멸수호병 파멸자"] = 3274,
											["더러운 지옥사냥개"] = 2455,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 30,
										["total"] = 5729,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 163,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 363.820583003204,
							["custom"] = 0,
							["last_event"] = 1560534996,
							["damage_taken"] = 7741.007222,
							["start_time"] = 1560534978,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004153,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1900,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1900.004153,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534997,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "더러운 지옥사냥개",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 422,
										["targets"] = {
											["받아줘요악사"] = 1900,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1900,
										["n_min"] = 330,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1900,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200417] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200417,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1900.004153,
							["serial"] = "Creature-0-3057-1481-10216-93115-000003DF98",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534986,
							["damage_taken"] = 4017.004153,
							["start_time"] = 1560534988,
							["delay"] = 1560534986,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002774,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 5130,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5130.002774,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534997,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "파멸수호병 파멸자",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 423,
										["targets"] = {
											["받아줘요악사"] = 4182,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4182,
										["n_min"] = 342,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 4182,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200608] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 187,
										["targets"] = {
											["받아줘요악사"] = 948,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 948,
										["n_min"] = 47,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 948,
										["c_max"] = 0,
										["id"] = 200608,
										["r_dmg"] = 0,
										["spellschool"] = 32,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 14,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 5130.002774,
							["serial"] = "Creature-0-3057-1481-10216-94654-000003C500",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534995,
							["damage_taken"] = 8565.002774,
							["start_time"] = 1560534977,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 29,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["받아줘요악사"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.005687,
							["total_without_pet"] = 3448.005687,
							["total"] = 3448.005687,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075EECC9",
							["totalabsorb"] = 0.005687,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 3448,
							},
							["totalover_without_pet"] = 0.005687,
							["healing_taken"] = 3448.005687,
							["fight_component"] = true,
							["end_time"] = 1560534997,
							["targets_overheal"] = {
							},
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[202644] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 3448,
										["targets"] = {
											["받아줘요악사"] = 3448,
										},
										["n_min"] = 3448,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 3448,
										["c_max"] = 0,
										["id"] = 202644,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 3448,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1560534990,
							["custom"] = 0,
							["last_event"] = 1560534990,
							["spec"] = 577,
							["totaldenied"] = 0.005687,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 29,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.006284,
							["resource"] = 159.006284,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.006284,
							["fight_component"] = true,
							["total"] = 0.006284,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.006284,
							["last_event"] = 1560534996,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.006284,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 29,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 44,
							["pets"] = {
							},
							["spell_cast"] = {
								[198013] = 1,
								[162243] = 5,
								[162794] = 2,
								[195072] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[200175] = {
										["activedamt"] = 1,
										["id"] = 200175,
										["targets"] = {
										},
										["actived_at"] = 1560534962,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 35,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["last_event"] = 1560534997,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "지옥수호병 보초",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200570] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003DF9C",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["nome"] = "더러운 지옥사냥개",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200417] = 3,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93115-000003DF98",
							["classe"] = "UNKNOW",
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 29,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 14025.941,
				["tempo_start"] = 1560534962,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 34,
				["playing_solo"] = true,
				["totals"] = {
					20323, -- [1]
					3448, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					12582, -- [1]
					3448, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:56:38",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥수호병 보초",
				["TotalElapsedCombatTime"] = 13991.077,
				["CombatEndedAt"] = 13991.077,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["받아줘요악사"] = 3448.005687,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 12582.007222,
						}, -- [1]
					},
				},
				["end_time"] = 13991.077,
				["combat_id"] = 29,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:56:03",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["영혼 거머리"] = 1,
					["더러운 지옥사냥개"] = 1,
					["파멸수호병 파멸자"] = 2,
				},
				["start_time"] = 13955.786,
				["TimeData"] = {
				},
				["contra"] = "지옥수호병 보초",
			}, -- [12]
			{
				{
					["combatId"] = 28,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007481,
							["spec"] = 577,
							["damage_from"] = {
								["고뇌의 간수"] = true,
							},
							["targets"] = {
								["고뇌의 간수"] = 5585,
							},
							["pets"] = {
							},
							["colocacao"] = 1,
							["end_time"] = 1560534941,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5585.007481,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 5585.007481,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1032,
										["g_amt"] = 0,
										["n_max"] = 250,
										["targets"] = {
											["고뇌의 간수"] = 1416,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 384,
										["n_min"] = 134,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1416,
										["c_max"] = 500,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 263,
									}, -- [1]
									[162243] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 571,
										["g_amt"] = 0,
										["n_max"] = 286,
										["targets"] = {
											["고뇌의 간수"] = 1143,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 572,
										["n_min"] = 286,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1143,
										["c_max"] = 571,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 571,
									},
									[199547] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 666,
										["g_amt"] = 0,
										["n_max"] = 394,
										["targets"] = {
											["고뇌의 간수"] = 1060,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 394,
										["n_min"] = 394,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1060,
										["c_max"] = 666,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 666,
									},
									[198030] = {
										["c_amt"] = 8,
										["b_amt"] = 0,
										["c_dmg"] = 1966,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["고뇌의 간수"] = 1966,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 1966,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 245,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 778.832447496833,
							["custom"] = 0,
							["last_event"] = 1560534941,
							["damage_taken"] = 1485.007481,
							["start_time"] = 1560534934,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007366,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1485,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1485.007366,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534941,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "고뇌의 간수",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 422,
										["targets"] = {
											["받아줘요악사"] = 1485,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1485,
										["n_min"] = 311,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1485,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200502] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200502,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1485.007366,
							["serial"] = "Creature-0-3057-1481-10216-95226-000003DD1E",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534940,
							["damage_taken"] = 5585.007366,
							["start_time"] = 1560534934,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 28,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 28,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.005372,
							["resource"] = 68.005372,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.005372,
							["total"] = 0.005372,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.005372,
							["last_event"] = 1560534938,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.005372,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 28,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["spell_cast"] = {
								[198013] = 1,
								[162243] = 3,
								[162794] = 1,
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 9,
							["tipo"] = 4,
							["last_event"] = 1560534941,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["classe"] = "DEMONHUNTER",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "고뇌의 간수",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200502] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-95226-000003DD1E",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 28,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 13955.385,
				["tempo_start"] = 1560534934,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 33,
				["playing_solo"] = true,
				["totals"] = {
					7070, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					5585, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:55:42",
				["cleu_timeline"] = {
				},
				["enemy"] = "고뇌의 간수",
				["TotalElapsedCombatTime"] = 13935.073,
				["CombatEndedAt"] = 13935.073,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 5585.007481,
						}, -- [1]
					},
				},
				["end_time"] = 13935.073,
				["combat_id"] = 28,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:55:35",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["고뇌의 간수"] = 1,
				},
				["start_time"] = 13927.902,
				["TimeData"] = {
				},
				["contra"] = "고뇌의 간수",
			}, -- [13]
			{
				{
					["combatId"] = 27,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007106,
							["total"] = 5524.007106,
							["damage_from"] = {
								["모아그 투사"] = true,
							},
							["targets"] = {
								["모아그 투사"] = 5524,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5524.007106,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560534930,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 1465,
										["g_amt"] = 0,
										["n_max"] = 292,
										["targets"] = {
											["모아그 투사"] = 1757,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 292,
										["n_min"] = 292,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1757,
										["c_max"] = 591,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 255,
									}, -- [1]
									[162243] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 686,
										["g_amt"] = 0,
										["n_max"] = 343,
										["targets"] = {
											["모아그 투사"] = 1372,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 686,
										["n_min"] = 343,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1372,
										["c_max"] = 686,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 686,
									},
									[199547] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 800,
										["g_amt"] = 0,
										["n_max"] = 473,
										["targets"] = {
											["모아그 투사"] = 2395,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1595,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2395,
										["c_max"] = 800,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 800,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 847.630367653851,
							["custom"] = 0,
							["last_event"] = 1560534929,
							["damage_taken"] = 767.007106,
							["start_time"] = 1560534923,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003251,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 767,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 767.003251,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534930,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "모아그 투사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 413,
										["targets"] = {
											["받아줘요악사"] = 767,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 767,
										["n_min"] = 354,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 767,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
								},
							},
							["total"] = 767.003251,
							["serial"] = "Creature-0-3057-1481-10216-96400-000003DD07",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534926,
							["damage_taken"] = 5524.003251,
							["start_time"] = 1560534924,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 27,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 27,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.005051,
							["resource"] = 92.005051,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.005051,
							["total"] = 0.005051,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.005051,
							["last_event"] = 1560534929,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.005051,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 27,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["spell_cast"] = {
								[162794] = 3,
								[162243] = 2,
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 12,
							["tipo"] = 4,
							["last_event"] = 1560534930,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 5,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["classe"] = "DEMONHUNTER",
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 27,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 13927.701,
				["tempo_start"] = 1560534923,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 32,
				["playing_solo"] = true,
				["totals"] = {
					6291, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					5524, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:55:31",
				["cleu_timeline"] = {
				},
				["enemy"] = "모아그 투사",
				["TotalElapsedCombatTime"] = 13923.694,
				["CombatEndedAt"] = 13923.694,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 5524.007106,
						}, -- [1]
					},
				},
				["end_time"] = 13923.694,
				["combat_id"] = 27,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:55:23",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["모아그 투사"] = 1,
				},
				["start_time"] = 13916.655,
				["TimeData"] = {
				},
				["contra"] = "모아그 투사",
			}, -- [14]
			{
				{
					["combatId"] = 26,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003758,
							["total"] = 19813.003758,
							["damage_from"] = {
								["더러운 지옥사냥개"] = true,
								["지옥수호병 보초"] = true,
							},
							["targets"] = {
								["지옥수호병 보초"] = 15635,
								["더러운 지옥사냥개"] = 4178,
							},
							["pets"] = {
								"갈퀴흉터 바다소환사 <받아줘요악사>", -- [1]
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 18364.003758,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560534912,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 811,
										["g_amt"] = 0,
										["n_max"] = 300,
										["targets"] = {
											["지옥수호병 보초"] = 1068,
											["더러운 지옥사냥개"] = 1535,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1792,
										["n_min"] = 127,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 2603,
										["c_max"] = 490,
										["MISS"] = 4,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 321,
									}, -- [1]
									[162243] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 686,
										["g_amt"] = 0,
										["n_max"] = 343,
										["targets"] = {
											["더러운 지옥사냥개"] = 856,
											["지옥수호병 보초"] = 2057,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2227,
										["n_min"] = 285,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 2913,
										["c_max"] = 686,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["r_amt"] = 0,
										["c_min"] = 686,
									},
									[199547] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1332,
										["g_amt"] = 0,
										["n_max"] = 474,
										["targets"] = {
											["더러운 지옥사냥개"] = 1787,
											["지옥수호병 보초"] = 2808,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3263,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 4595,
										["c_max"] = 666,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 666,
									},
									[198030] = {
										["c_amt"] = 37,
										["b_amt"] = 0,
										["c_dmg"] = 8253,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥수호병 보초"] = 8253,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 37,
										["total"] = 8253,
										["c_max"] = 295,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 196,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 945.547568865146,
							["custom"] = 0,
							["last_event"] = 1560534911,
							["damage_taken"] = 14174.003758,
							["start_time"] = 1560534890,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005064,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1405,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1405.005064,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534912,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "더러운 지옥사냥개",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 419,
										["targets"] = {
											["받아줘요악사"] = 1405,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1405,
										["n_min"] = 309,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1405,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200417] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200417,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1405.005064,
							["serial"] = "Creature-0-3057-1481-10216-93115-000003BC65",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534902,
							["damage_taken"] = 4178.005064,
							["start_time"] = 1560534901,
							["delay"] = 1560534902,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006362,
							["damage_from"] = {
								["받아줘요악사"] = true,
								["갈퀴흉터 바다소환사 <받아줘요악사>"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 12769,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 12769.006362,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534912,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "지옥수호병 보초",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 635,
										["g_amt"] = 0,
										["n_max"] = 422,
										["targets"] = {
											["받아줘요악사"] = 7819,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 7184,
										["n_min"] = 301,
										["g_dmg"] = 0,
										["counter"] = 25,
										["MISS"] = 1,
										["total"] = 7819,
										["c_max"] = 635,
										["DODGE"] = 3,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 20,
										["r_amt"] = 0,
										["c_min"] = 635,
									}, -- [1]
									[200573] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 390,
										["targets"] = {
											["받아줘요악사"] = 4950,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4950,
										["n_min"] = 372,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 4950,
										["c_max"] = 0,
										["id"] = 200573,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 13,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[200570] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200570,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 5,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 12769.006362,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003BD10",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534910,
							["damage_taken"] = 15635.006362,
							["start_time"] = 1560534892,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 8465,
							["totalabsorbed"] = 0.005443,
							["serial"] = "Creature-0-3057-1481-10216-96884-000003DF6C",
							["damage_from"] = {
							},
							["targets"] = {
								["지옥수호병 보초"] = 1449,
							},
							["pets"] = {
							},
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1449.005443,
							["dps_started"] = false,
							["total"] = 1449.005443,
							["classe"] = "PET",
							["ownerName"] = "받아줘요악사",
							["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 555,
										["g_amt"] = 0,
										["n_max"] = 311,
										["targets"] = {
											["지옥수호병 보초"] = 866,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 311,
										["n_min"] = 311,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 866,
										["c_max"] = 555,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 555,
									}, -- [1]
									[197745] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 199,
										["targets"] = {
											["지옥수호병 보초"] = 583,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 583,
										["n_min"] = 192,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 583,
										["c_max"] = 0,
										["id"] = 197745,
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1560534912,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.005443,
							["start_time"] = 1560534892,
							["delay"] = 0,
							["last_event"] = 1560534911,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 26,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["healing_from"] = {
								["받아줘요악사"] = true,
								["갈퀴흉터 바다소환사 <받아줘요악사>"] = true,
							},
							["pets"] = {
								"갈퀴흉터 바다소환사 <받아줘요악사>", -- [1]
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 255.00518,
							["total_without_pet"] = 13541.00518,
							["total"] = 14174.00518,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075EECC9",
							["totalabsorb"] = 0.00518,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 14429,
							},
							["totalover_without_pet"] = 0.00518,
							["healing_taken"] = 14174.00518,
							["fight_component"] = true,
							["end_time"] = 1560534912,
							["targets_overheal"] = {
								["받아줘요악사"] = 255,
							},
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[202644] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["받아줘요악사"] = 255,
										},
										["n_max"] = 3449,
										["targets"] = {
											["받아줘요악사"] = 13541,
										},
										["n_min"] = 3194,
										["counter"] = 4,
										["overheal"] = 255,
										["total"] = 13541,
										["c_max"] = 0,
										["id"] = 202644,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 13541,
										["n_amt"] = 4,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1560534903,
							["custom"] = 0,
							["last_event"] = 1560534911,
							["spec"] = 577,
							["totaldenied"] = 0.00518,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
						{
							["flag_original"] = 8465,
							["healing_from"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "PET",
							["totalover"] = 0.007235,
							["total_without_pet"] = 633.007235,
							["total"] = 633.007235,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-3057-1481-10216-96884-000003DF6C",
							["totalabsorb"] = 0.007235,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 633,
							},
							["totalover_without_pet"] = 0.007235,
							["healing_taken"] = 0.007235,
							["fight_component"] = true,
							["end_time"] = 1560534912,
							["ownerName"] = "받아줘요악사",
							["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[197744] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 633,
										["targets"] = {
											["받아줘요악사"] = 633,
										},
										["n_min"] = 633,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 633,
										["c_max"] = 0,
										["id"] = 197744,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 633,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["targets_overheal"] = {
							},
							["start_time"] = 1560534903,
							["heal_enemy_amt"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534903,
							["totaldenied"] = 0.007235,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [2]
					},
				}, -- [2]
				{
					["combatId"] = 26,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.007149,
							["resource"] = 264.007149,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.007149,
							["fight_component"] = true,
							["total"] = 0.007149,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.007149,
							["last_event"] = 1560534923,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.007149,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 26,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 37,
							["pets"] = {
								"갈퀴흉터 바다소환사 <받아줘요악사>", -- [1]
							},
							["spell_cast"] = {
								[198013] = 1,
								[162243] = 8,
								[162794] = 5,
							},
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 22,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 2,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 13,
										["appliedamt"] = 2,
										["refreshamt"] = 3,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["last_event"] = 1560534912,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "지옥수호병 보초",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200570] = 5,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003C1AB",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 8465,
							["ownerName"] = "받아줘요악사",
							["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
							["pets"] = {
							},
							["classe"] = "PET",
							["fight_component"] = true,
							["tipo"] = 4,
							["spell_cast"] = {
								[197745] = 3,
								[197744] = 1,
							},
							["serial"] = "Creature-0-3057-1481-10216-96884-000003DF6C",
							["last_event"] = 0,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["nome"] = "더러운 지옥사냥개",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200417] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93115-000003BC65",
							["classe"] = "UNKNOW",
						}, -- [4]
					},
				}, -- [4]
				{
					["combatId"] = 26,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 13916.401,
				["tempo_start"] = 1560534890,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 31,
				["playing_solo"] = true,
				["totals"] = {
					33987, -- [1]
					14174, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					18364, -- [1]
					13541, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:55:13",
				["cleu_timeline"] = {
				},
				["enemy"] = "더러운 지옥사냥개",
				["TotalElapsedCombatTime"] = 21.4079999999995,
				["CombatEndedAt"] = 13905.824,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["받아줘요악사"] = 14174.00518,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 19813.003758,
						}, -- [1]
					},
				},
				["end_time"] = 13905.824,
				["combat_id"] = 26,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:54:51",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["지옥수호병 보초"] = 4,
					["더러운 지옥사냥개"] = 1,
				},
				["start_time"] = 13884.416,
				["TimeData"] = {
				},
				["contra"] = "더러운 지옥사냥개",
			}, -- [15]
			{
				{
					["combatId"] = 25,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002731,
							["total"] = 7982.002731,
							["damage_from"] = {
								["지옥수호병 보초"] = true,
							},
							["targets"] = {
								["지옥수호병 보초"] = 7982,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7982.002731,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560534879,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1340,
										["g_amt"] = 0,
										["n_max"] = 287,
										["targets"] = {
											["지옥수호병 보초"] = 2277,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 937,
										["n_min"] = 157,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 2277,
										["c_max"] = 575,
										["MISS"] = 2,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 266,
									}, -- [1]
									[162243] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 571,
										["g_amt"] = 0,
										["n_max"] = 343,
										["targets"] = {
											["지옥수호병 보초"] = 1485,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 914,
										["n_min"] = 285,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1485,
										["c_max"] = 571,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 571,
									},
									[199547] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 474,
										["targets"] = {
											["지옥수호병 보초"] = 1602,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1602,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1602,
										["c_max"] = 0,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[198030] = {
										["c_amt"] = 11,
										["b_amt"] = 0,
										["c_dmg"] = 2618,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥수호병 보초"] = 2618,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2618,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 164,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 656.684716659775,
							["custom"] = 0,
							["last_event"] = 1560534878,
							["damage_taken"] = 4072.002731,
							["start_time"] = 1560534867,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001838,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 4072,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4072.001838,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534879,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "지옥수호병 보초",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 653,
										["g_amt"] = 0,
										["n_max"] = 413,
										["targets"] = {
											["받아줘요악사"] = 2172,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1519,
										["n_min"] = 340,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2172,
										["c_max"] = 653,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 653,
									}, -- [1]
									[200570] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200570,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									[200573] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 386,
										["targets"] = {
											["받아줘요악사"] = 1900,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1900,
										["n_min"] = 374,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1900,
										["c_max"] = 0,
										["id"] = 200573,
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 4072.001838,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003BBAE",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534878,
							["damage_taken"] = 7982.001838,
							["start_time"] = 1560534868,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 25,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 25,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.003639,
							["resource"] = 92.003639,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.003639,
							["total"] = 0.003639,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.003639,
							["last_event"] = 1560534875,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.003639,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 25,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["spell_cast"] = {
								[198013] = 1,
								[162243] = 3,
								[162794] = 2,
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 17,
							["tipo"] = 4,
							["last_event"] = 1560534879,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 1,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["classe"] = "DEMONHUNTER",
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "지옥수호병 보초",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200570] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003BBDE",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 25,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1560534867,
				["enemy"] = "지옥수호병 보초",
				["combat_counter"] = 30,
				["playing_solo"] = true,
				["totals"] = {
					12054, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 13873.405,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:54:28",
				["end_time"] = 13873.405,
				["totals_grupo"] = {
					7982, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 25,
				["TotalElapsedCombatTime"] = 13873.405,
				["frags_need_refresh"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 7982.002731,
						}, -- [1]
					},
				},
				["frags"] = {
					["지옥수호병 보초"] = 2,
				},
				["data_fim"] = "02:54:40",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 13861.25,
				["contra"] = "지옥수호병 보초",
				["TimeData"] = {
				},
			}, -- [16]
			{
				{
					["combatId"] = 24,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002836,
							["total"] = 5739.002836,
							["damage_from"] = {
								["고뇌의 간수"] = true,
							},
							["targets"] = {
								["고뇌의 간수"] = 5739,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5739.002836,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560534851,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1471,
										["g_amt"] = 0,
										["n_max"] = 247,
										["targets"] = {
											["고뇌의 간수"] = 1853,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 382,
										["n_min"] = 135,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1853,
										["c_max"] = 495,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 486,
									}, -- [1]
									[162243] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1144,
										["g_amt"] = 0,
										["n_max"] = 286,
										["targets"] = {
											["고뇌의 간수"] = 1430,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 286,
										["n_min"] = 286,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1430,
										["c_max"] = 572,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 572,
									},
									[198030] = {
										["c_amt"] = 10,
										["b_amt"] = 0,
										["c_dmg"] = 2456,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["고뇌의 간수"] = 2456,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 2456,
										["c_max"] = 246,
										["id"] = 198030,
										["r_dmg"] = 0,
										["spellschool"] = 124,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 245,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 786.703610143926,
							["custom"] = 0,
							["last_event"] = 1560534850,
							["damage_taken"] = 1139.002836,
							["start_time"] = 1560534843,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002973,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1139,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1139.002973,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534851,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "고뇌의 간수",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 418,
										["targets"] = {
											["받아줘요악사"] = 1139,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1139,
										["n_min"] = 305,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1139,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200502] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200502,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1139.002973,
							["serial"] = "Creature-0-3057-1481-10216-95226-000003DC47",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534849,
							["damage_taken"] = 5739.002973,
							["start_time"] = 1560534845,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 24,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 24,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.001642,
							["resource"] = 74.001642,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.001642,
							["total"] = 0.001642,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.001642,
							["last_event"] = 1560534867,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.001642,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 24,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["spell_cast"] = {
								[162243] = 2,
								[198013] = 1,
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 10,
							["tipo"] = 4,
							["last_event"] = 1560534851,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[198013] = {
										["activedamt"] = 1,
										["id"] = 198013,
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["classe"] = "DEMONHUNTER",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "고뇌의 간수",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200502] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-95226-000003DC47",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 24,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["CombatStartedAt"] = 13861.25,
				["tempo_start"] = 1560534843,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 29,
				["playing_solo"] = true,
				["totals"] = {
					6878, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					5739, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "02:54:11",
				["cleu_timeline"] = {
				},
				["enemy"] = "고뇌의 간수",
				["TotalElapsedCombatTime"] = 7.29500000000007,
				["CombatEndedAt"] = 13844.611,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 5739.002836,
						}, -- [1]
					},
				},
				["end_time"] = 13844.611,
				["combat_id"] = 24,
				["cleu_events"] = {
					["n"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["data_inicio"] = "02:54:04",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["고뇌의 간수"] = 1,
				},
				["start_time"] = 13837.316,
				["TimeData"] = {
				},
				["contra"] = "고뇌의 간수",
			}, -- [17]
			{
				{
					["combatId"] = 23,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00194,
							["damage_from"] = {
							},
							["targets"] = {
								["받아줘요악사"] = 403,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 403.00194,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534828,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "지옥수호병 보초",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 403,
										["targets"] = {
											["받아줘요악사"] = 403,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 403,
										["n_min"] = 403,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 403,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									}, -- [1]
									[200570] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200570,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 403.00194,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003DED5",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534799,
							["damage_taken"] = 0.00194,
							["start_time"] = 1560534827,
							["delay"] = 1560534799,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00786,
							["total"] = 5558.00786,
							["damage_from"] = {
								["고뇌의 간수"] = true,
								["지옥수호병 보초"] = true,
							},
							["targets"] = {
								["고뇌의 간수"] = 5558,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["colocacao"] = 1,
							["classe"] = "DEMONHUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5558.00786,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["end_time"] = 1560534828,
							["on_hold"] = false,
							["spec"] = 577,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 264,
										["g_amt"] = 0,
										["n_max"] = 252,
										["targets"] = {
											["고뇌의 간수"] = 1396,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1132,
										["n_min"] = 128,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 1396,
										["c_max"] = 264,
										["MISS"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["r_amt"] = 0,
										["c_min"] = 264,
									}, -- [1]
									[162243] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 571,
										["g_amt"] = 0,
										["n_max"] = 286,
										["targets"] = {
											["고뇌의 간수"] = 857,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 286,
										["n_min"] = 286,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 857,
										["c_max"] = 571,
										["id"] = 162243,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 571,
									},
									[199547] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1456,
										["g_amt"] = 0,
										["n_max"] = 395,
										["targets"] = {
											["고뇌의 간수"] = 3305,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1849,
										["n_min"] = 333,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 3305,
										["c_max"] = 789,
										["id"] = 199547,
										["r_dmg"] = 0,
										["spellschool"] = 127,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 667,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-205-075EECC9",
							["last_dps"] = 251.846837645572,
							["custom"] = 0,
							["last_event"] = 1560534821,
							["damage_taken"] = 1871.00786,
							["start_time"] = 1560534813,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008591,
							["damage_from"] = {
								["받아줘요악사"] = true,
							},
							["targets"] = {
								["받아줘요악사"] = 1468,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1468.008591,
							["monster"] = true,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1560534828,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "고뇌의 간수",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 804,
										["g_amt"] = 0,
										["n_max"] = 350,
										["targets"] = {
											["받아줘요악사"] = 1468,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 664,
										["n_min"] = 314,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1468,
										["c_max"] = 804,
										["DODGE"] = 1,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 804,
									}, -- [1]
									[200502] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 200502,
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 1468.008591,
							["serial"] = "Creature-0-3057-1481-10216-95226-000003DB7B",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1560534819,
							["damage_taken"] = 5558.008591,
							["start_time"] = 1560534813,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 23,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["받아줘요악사"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DEMONHUNTER",
							["totalover"] = 0.002201,
							["total_without_pet"] = 3448.002201,
							["total"] = 3448.002201,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-205-075EECC9",
							["totalabsorb"] = 0.002201,
							["last_hps"] = 0,
							["targets"] = {
								["받아줘요악사"] = 3448,
							},
							["totalover_without_pet"] = 0.002201,
							["healing_taken"] = 3448.002201,
							["fight_component"] = true,
							["end_time"] = 1560534828,
							["targets_overheal"] = {
							},
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									[202644] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 3448,
										["targets"] = {
											["받아줘요악사"] = 3448,
										},
										["n_min"] = 3448,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 3448,
										["c_max"] = 0,
										["id"] = 202644,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 3448,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1560534825,
							["custom"] = 0,
							["last_event"] = 1560534825,
							["spec"] = 577,
							["totaldenied"] = 0.002201,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 23,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 0.001464,
							["resource"] = 89.001464,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DEMONHUNTER",
							["passiveover"] = 0.001464,
							["fight_component"] = true,
							["total"] = 0.001464,
							["nome"] = "받아줘요악사",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["resource_type"] = 17,
							["flag_original"] = 1297,
							["alternatepower"] = 0.001464,
							["last_event"] = 1560534843,
							["spec"] = 577,
							["tipo"] = 3,
							["serial"] = "Player-205-075EECC9",
							["totalover"] = 0.001464,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 23,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["nome"] = "받아줘요악사",
							["spec"] = 577,
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 35,
							["pets"] = {
							},
							["spell_cast"] = {
								[162243] = 2,
								[162794] = 4,
								[195072] = 1,
							},
							["classe"] = "DEMONHUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[191466] = {
										["activedamt"] = 1,
										["id"] = 191466,
										["targets"] = {
										},
										["uptime"] = 29,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[163073] = {
										["activedamt"] = 2,
										["id"] = 163073,
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[200175] = {
										["activedamt"] = 1,
										["id"] = 200175,
										["targets"] = {
										},
										["actived_at"] = 1560534799,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-205-075EECC9",
							["last_event"] = 1560534828,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["nome"] = "지옥수호병 보초",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200570] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-93112-000003DED5",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["nome"] = "고뇌의 간수",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								[200502] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-3057-1481-10216-95226-000003DB7B",
							["classe"] = "UNKNOW",
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 23,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["받아줘요악사"] = true,
				},
				["last_events_tables"] = {
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1560534799,
				["enemy"] = "지옥수호병 보초",
				["combat_counter"] = 28,
				["playing_solo"] = true,
				["totals"] = {
					7428.993088, -- [1]
					3448, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatEndedAt"] = 13821.943,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "02:53:20",
				["end_time"] = 13821.943,
				["totals_grupo"] = {
					5558, -- [1]
					3448, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["combat_id"] = 23,
				["TotalElapsedCombatTime"] = 13821.943,
				["frags_need_refresh"] = true,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["받아줘요악사"] = 3448.002201,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["받아줘요악사"] = 5558.00786,
						}, -- [1]
					},
				},
				["frags"] = {
					["고뇌의 간수"] = 1,
				},
				["data_fim"] = "02:53:49",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 13793.304,
				["contra"] = "지옥수호병 보초",
				["TimeData"] = {
				},
			}, -- [18]
		},
	},
	["last_version"] = "v8.1.5.7129",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["nextreset"] = 1561829812,
		["last_version"] = 11,
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 0,
	["active_profile"] = "받아줘요악사-아즈샤라",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 1,
			["enabled"] = true,
			["animate"] = false,
			["useplayercolor"] = false,
			["author"] = "Details! Team",
			["useclasscolors"] = false,
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["showamount"] = false,
		},
		["DETAILS_PLUGIN_RAIDCHECK"] = {
			["enabled"] = true,
			["food_tier1"] = true,
			["mythic_1_4"] = true,
			["food_tier2"] = true,
			["author"] = "Details! Team",
			["use_report_panel"] = true,
			["pre_pot_healers"] = false,
			["pre_pot_tanks"] = false,
			["food_tier3"] = true,
		},
		["DETAILS_PLUGIN_VANGUARD"] = {
			["enabled"] = true,
			["tank_block_color"] = {
				0.24705882, -- [1]
				0.0039215, -- [2]
				0, -- [3]
				0.8, -- [4]
			},
			["tank_block_texture"] = "Details Serenity",
			["show_inc_bars"] = false,
			["author"] = "Details! Team",
			["first_run"] = false,
			["tank_block_size"] = 150,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["author"] = "Details! Team",
			["window_scale"] = 1,
			["encounter_timers_dbm"] = {
			},
			["show_icon"] = 5,
			["opened"] = 0,
			["hide_on_combat"] = false,
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 160,
				["radius"] = 160,
				["hide"] = false,
			},
			["arrow_anchor_x"] = 0,
			["row_texture"] = "Details Serenity",
			["font_size"] = 10,
			["main_frame_locked"] = false,
			["use_spark"] = true,
			["enabled"] = false,
			["arrow_size"] = 10,
			["arrow_anchor_y"] = 0,
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["author"] = "Details! Team",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["y"] = 4.577636718750e-05,
			["x"] = 0,
			["font_face"] = "Friz Quadrata TT",
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = 3.05175781250e-05,
				["x"] = 3.05175781250e-05,
				["attribute_type"] = 1,
				["update_speed"] = 0.05,
				["size"] = 32,
			},
			["point"] = "CENTER",
			["main_frame_strata"] = "LOW",
			["row_height"] = 20,
			["scale"] = 1,
		},
	},
	["last_day"] = "15",
	["cached_talents"] = {
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["character_data"] = {
		["logons"] = 2,
	},
	["combat_id"] = 40,
	["savedStyles"] = {
	},
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = true,
			["isLocked"] = false,
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 101.333251953125,
					["x"] = -1059.80908203125,
					["w"] = 310.000030517578,
					["h"] = 157.999862670898,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["force_font_outline"] = "",
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.012656,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 1252,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 1252.012656,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 1252.012656,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "지옥살이 임프",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 116,
								["targets"] = {
									["받아줘요악사"] = 1120,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1120,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 1120,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 11,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200371] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 44,
								["targets"] = {
									["받아줘요악사"] = 132,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 132,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 132,
								["c_max"] = 0,
								["id"] = 200371,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1560534078,
					["serial"] = "Creature-0-3057-1481-10216-98483-000083DB29",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560534060,
					["delay"] = 0,
					["damage_taken"] = 7624.012656,
				}, -- [1]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.233893,
					["damage_from"] = {
						["지옥살이 임프"] = true,
						["환경피해 (용암)"] = true,
						["광선을 뿜는 눈알"] = true,
						["더러운 지옥사냥개"] = true,
						["심연 바실리스크"] = true,
						["모아그 투사"] = true,
						["격노전사"] = true,
						["파멸의 학살자"] = true,
						["에레다르 소환사"] = true,
						["지옥 군주 카자"] = true,
						["에레다르 마술사"] = true,
						["파멸의 사령관 벨라이아쉬"] = true,
						["심문관 베일풀"] = true,
						["군단 사령부"] = true,
						["[*] 어둠의 칼날"] = true,
						["격노용사"] = true,
						["고뇌의 간수"] = true,
						["[*] 부정한 지옥"] = true,
						["[*] 비통의 첨탑"] = true,
						["지옥수호병 도살자"] = true,
						["파멸수호병 파멸자"] = true,
						["지옥수호병 보초"] = true,
					},
					["targets"] = {
						["지옥살이 임프"] = 7624,
						["더러운 지옥사냥개"] = 25302,
						["심연 바실리스크"] = 3976,
						["모아그 투사"] = 22476,
						["지옥수호병 보초"] = 32453,
						["파멸의 학살자"] = 3047,
						["가시발톱 새끼 거미"] = 27587,
						["파멸의 사령관 벨라이아쉬"] = 23441,
						["심문관 베일풀"] = 21645,
						["영혼 거머리"] = 235,
						["지옥 군주 카자"] = 26175,
						["에레다르 마술사"] = 5725,
						["고뇌의 간수"] = 42411,
						["격노전사"] = 39578,
						["격노용사"] = 10562,
						["지옥수호병 도살자"] = 46473,
						["파멸수호병 파멸자"] = 12472,
						["붉은 무리거미"] = 53796,
					},
					["on_hold"] = false,
					["pets"] = {
						"잿빛혓바닥 추적자 <받아줘요악사>", -- [1]
						"갈퀴흉터 바다소환사 <받아줘요악사>", -- [2]
					},
					["last_event"] = 0,
					["classe"] = "DEMONHUNTER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 390392.233893,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560534078,
					["friendlyfire"] = {
					},
					["total"] = 404978.233893,
					["nome"] = "받아줘요악사",
					["spec"] = 577,
					["grupo"] = true,
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 92,
								["b_amt"] = 0,
								["c_dmg"] = 41133,
								["g_amt"] = 0,
								["n_max"] = 321,
								["targets"] = {
									["지옥살이 임프"] = 3164,
									["지옥 군주 카자"] = 5214,
									["에레다르 마술사"] = 624,
									["파멸의 사령관 벨라이아쉬"] = 7230,
									["심문관 베일풀"] = 6227,
									["지옥수호병 도살자"] = 6367,
									["격노용사"] = 1008,
									["더러운 지옥사냥개"] = 7975,
									["심연 바실리스크"] = 1125,
									["모아그 투사"] = 7487,
									["고뇌의 간수"] = 12284,
									["지옥수호병 보초"] = 5322,
									["파멸수호병 파멸자"] = 2620,
									["격노전사"] = 12212,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 37726,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 323,
								["total"] = 78859,
								["c_max"] = 639,
								["IMMUNE"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 49,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 181,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[198030] = {
								["c_amt"] = 307,
								["b_amt"] = 0,
								["c_dmg"] = 64190,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["에레다르 마술사"] = 2454,
									["파멸의 사령관 벨라이아쉬"] = 3925,
									["지옥 군주 카자"] = 3681,
									["더러운 지옥사냥개"] = 2455,
									["고뇌의 간수"] = 4422,
									["지옥수호병 도살자"] = 19366,
									["파멸의 학살자"] = 2702,
									["지옥수호병 보초"] = 10871,
									["파멸수호병 파멸자"] = 5729,
									["격노용사"] = 8585,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 307,
								["total"] = 64190,
								["c_max"] = 295,
								["id"] = 198030,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[162243] = {
								["c_amt"] = 46,
								["b_amt"] = 0,
								["c_dmg"] = 29409,
								["g_amt"] = 0,
								["n_max"] = 365,
								["targets"] = {
									["지옥살이 임프"] = 3040,
									["지옥 군주 카자"] = 3450,
									["에레다르 마술사"] = 1222,
									["지옥수호병 도살자"] = 5058,
									["파멸의 사령관 벨라이아쉬"] = 4226,
									["심문관 베일풀"] = 4860,
									["파멸의 학살자"] = 345,
									["격노용사"] = 574,
									["더러운 지옥사냥개"] = 4687,
									["심연 바실리스크"] = 1608,
									["모아그 투사"] = 5771,
									["고뇌의 간수"] = 9718,
									["지옥수호병 보초"] = 4227,
									["파멸수호병 파멸자"] = 2230,
									["격노전사"] = 10288,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 31895,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 149,
								["total"] = 61304,
								["c_max"] = 730,
								["id"] = 162243,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 102,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[199547] = {
								["c_amt"] = 56,
								["b_amt"] = 0,
								["c_dmg"] = 46344,
								["g_amt"] = 0,
								["n_max"] = 474,
								["targets"] = {
									["지옥살이 임프"] = 1420,
									["지옥 군주 카자"] = 8071,
									["에레다르 마술사"] = 873,
									["파멸의 사령관 벨라이아쉬"] = 7673,
									["심문관 베일풀"] = 6945,
									["지옥수호병 도살자"] = 10219,
									["격노용사"] = 395,
									["더러운 지옥사냥개"] = 7044,
									["심연 바실리스크"] = 1243,
									["모아그 투사"] = 8616,
									["고뇌의 간수"] = 15248,
									["지옥수호병 보초"] = 7975,
									["파멸수호병 파멸자"] = 1893,
									["격노전사"] = 15573,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 46844,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 173,
								["total"] = 93188,
								["c_max"] = 947,
								["id"] = 199547,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 117,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[192611] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 56791,
								["g_amt"] = 0,
								["n_max"] = 13449,
								["targets"] = {
									["에레다르 마술사"] = 552,
									["가시발톱 새끼 거미"] = 27587,
									["심문관 베일풀"] = 501,
									["영혼 거머리"] = 235,
									["지옥 군주 카자"] = 251,
									["더러운 지옥사냥개"] = 552,
									["고뇌의 간수"] = 301,
									["모아그 투사"] = 602,
									["지옥수호병 도살자"] = 5463,
									["격노전사"] = 1505,
									["지옥수호병 보초"] = 1506,
									["붉은 무리거미"] = 53796,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 36060,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 40,
								["total"] = 92851,
								["c_max"] = 27587,
								["id"] = 192611,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 34,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["serial"] = "Player-205-075EECC9",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 130349.233893,
					["start_time"] = 1560533641,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [2]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.045238,
					["on_hold"] = false,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 19452,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 19452.045238,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560534091,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "격노전사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 2741,
								["g_amt"] = 0,
								["n_max"] = 429,
								["targets"] = {
									["받아줘요악사"] = 14859,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 12118,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 40,
								["total"] = 14859,
								["c_max"] = 753,
								["MISS"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 33,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200379] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 209,
								["targets"] = {
									["받아줘요악사"] = 4593,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4593,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 4593,
								["c_max"] = 0,
								["id"] = 200379,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 27,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 19452.045238,
					["serial"] = "Creature-0-3057-1481-10216-98486-000003D97C",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 39578.045238,
					["start_time"] = 1560534027,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [3]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.037288,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 9531,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 9531.037288,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 9531.037288,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "모아그 투사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 636,
								["targets"] = {
									["받아줘요악사"] = 5945,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 5945,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 5945,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 12,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200425] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1797,
								["targets"] = {
									["받아줘요악사"] = 3586,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3586,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 3586,
								["c_max"] = 0,
								["id"] = 200425,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 4,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1560534127,
					["serial"] = "Creature-0-3057-1481-10216-98484-000003D9D8",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560534083,
					["delay"] = 0,
					["damage_taken"] = 22476.037288,
				}, -- [4]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.053322,
					["damage_from"] = {
						["받아줘요악사"] = true,
						["잿빛혓바닥 추적자 <받아줘요악사>"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 10789,
						["잿빛혓바닥 추적자 <받아줘요악사>"] = 272,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 11061.053322,
					["fight_component"] = true,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1560534183,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["nome"] = "더러운 지옥사냥개",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1381,
								["g_amt"] = 0,
								["n_max"] = 422,
								["targets"] = {
									["잿빛혓바닥 추적자"] = 0,
									["잿빛혓바닥 추적자 <받아줘요악사>"] = 272,
									["받아줘요악사"] = 10789,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 9680,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 36,
								["MISS"] = 1,
								["total"] = 11061,
								["c_max"] = 793,
								["a_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 3,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 3,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 27,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200417] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 200417,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 12,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["total"] = 11061.053322,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["serial"] = "Creature-0-3057-1481-10216-98482-000003DA8A",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 25302.053322,
					["start_time"] = 1560534117,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [5]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.023009,
					["fight_component"] = true,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.023009,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1560534280,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "붉은 무리거미",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["total"] = 0.023009,
					["serial"] = "Creature-0-3057-1481-10216-99656-000003ABBB",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 53796.023009,
					["start_time"] = 1560534277,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [6]
				{
					["flag_original"] = 8465,
					["totalabsorbed"] = 0.03036,
					["damage_from"] = {
						["지옥수호병 보초"] = true,
						["더러운 지옥사냥개"] = true,
					},
					["targets"] = {
						["더러운 지옥사냥개"] = 2589,
						["고뇌의 간수"] = 438,
						["지옥수호병 보초"] = 1103,
						["심문관 베일풀"] = 3112,
						["지옥 군주 카자"] = 5508,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 12750.03036,
					["end_time"] = 1560534434,
					["on_hold"] = false,
					["dps_started"] = false,
					["total"] = 12750.03036,
					["friendlyfire_total"] = 0,
					["ownerName"] = "받아줘요악사",
					["nome"] = "잿빛혓바닥 추적자 <받아줘요악사>",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 1843,
								["g_amt"] = 0,
								["n_max"] = 331,
								["targets"] = {
									["더러운 지옥사냥개"] = 2589,
									["고뇌의 간수"] = 438,
									["지옥수호병 보초"] = 1103,
									["심문관 베일풀"] = 3112,
									["지옥 군주 카자"] = 5508,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 10907,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 63,
								["total"] = 12750,
								["c_max"] = 642,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 9,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 50,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["last_event"] = 0,
					["serial"] = "Creature-0-3057-1481-10216-96877-000003DD95",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1111.03036,
					["start_time"] = 1560534370,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [7]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.014355,
					["damage_from"] = {
					},
					["targets"] = {
						["받아줘요악사"] = 861,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 861.014355,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 861.014355,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "[*] 부정한 지옥",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							[200420] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 126,
								["targets"] = {
									["받아줘요악사"] = 861,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 861,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 861,
								["c_max"] = 0,
								["id"] = 200420,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 7,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1560534434,
					["serial"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560534418,
					["delay"] = 0,
					["damage_taken"] = 0.014355,
				}, -- [8]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.053762,
					["damage_from"] = {
						["받아줘요악사"] = true,
						["잿빛혓바닥 추적자 <받아줘요악사>"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 9636,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 9636.053762,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 9636.053762,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "고뇌의 간수",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 804,
								["g_amt"] = 0,
								["n_max"] = 427,
								["targets"] = {
									["받아줘요악사"] = 9636,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8832,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 31,
								["a_amt"] = 0,
								["total"] = 9636,
								["c_max"] = 804,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 24,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200502] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 200502,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 8,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1560534588,
					["serial"] = "Creature-0-3057-1481-10216-95226-000003DAED",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560534526,
					["delay"] = 0,
					["damage_taken"] = 42411.053762,
				}, -- [9]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.028057,
					["damage_from"] = {
						["받아줘요악사"] = true,
						["잿빛혓바닥 추적자 <받아줘요악사>"] = true,
						["갈퀴흉터 바다소환사 <받아줘요악사>"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 19809,
						["잿빛혓바닥 추적자 <받아줘요악사>"] = 839,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 20648.028057,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 20648.028057,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "지옥수호병 보초",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1288,
								["g_amt"] = 0,
								["n_max"] = 425,
								["targets"] = {
									["받아줘요악사"] = 12571,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 11283,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 38,
								["total"] = 12571,
								["c_max"] = 653,
								["MISS"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 4,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 31,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200570] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 200570,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 12,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[200573] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 424,
								["targets"] = {
									["잿빛혓바닥 추적자 <받아줘요악사>"] = 839,
									["받아줘요악사"] = 7238,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8077,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["total"] = 8077,
								["c_max"] = 0,
								["id"] = 200573,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 21,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1560534607,
					["serial"] = "Creature-0-3057-1481-10216-93112-000003DC82",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560534560,
					["delay"] = 0,
					["damage_taken"] = 32453.028057,
				}, -- [10]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.011068,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 644,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 644.011068,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1560534657,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "심연 바실리스크",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 323,
								["targets"] = {
									["받아줘요악사"] = 644,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 644,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 644,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire_total"] = 0,
					["total"] = 644.011068,
					["serial"] = "Creature-0-3057-1481-10216-101288-000003BB2D",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 3976.011068,
					["start_time"] = 1560534651,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [11]
				{
					["flag_original"] = -2147483648,
					["totalabsorbed"] = 0.01185,
					["damage_from"] = {
					},
					["targets"] = {
						["받아줘요악사"] = 2798,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 2798.01185,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1560534657,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "환경피해 (용암)",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							[7] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1403,
								["targets"] = {
									["받아줘요악사"] = 2798,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2798,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 2798,
								["c_max"] = 0,
								["id"] = 7,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire_total"] = 0,
					["total"] = 2798.01185,
					["serial"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.01185,
					["start_time"] = 1560534652,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [12]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.01413,
					["on_hold"] = false,
					["damage_from"] = {
						["받아줘요악사"] = true,
						["잿빛혓바닥 추적자 <받아줘요악사>"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 6194,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 6194.01413,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560534786,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "심문관 베일풀",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 502,
								["g_amt"] = 0,
								["n_max"] = 269,
								["targets"] = {
									["받아줘요악사"] = 1944,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1442,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["total"] = 1944,
								["c_max"] = 502,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 6,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[194529] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 126,
								["targets"] = {
									["받아줘요악사"] = 3941,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3941,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 32,
								["total"] = 3941,
								["c_max"] = 0,
								["id"] = 194529,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 32,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[194519] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 63,
								["targets"] = {
									["받아줘요악사"] = 309,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 309,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 309,
								["c_max"] = 0,
								["id"] = 194519,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[1604] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["받아줘요악사"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1604,
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 6194.01413,
					["serial"] = "Creature-0-3057-1481-10216-93105-000003DD94",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 21645.01413,
					["start_time"] = 1560534748,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [13]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.013406,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["받아줘요악사"] = 122,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 122.013406,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560534786,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "광선을 뿜는 눈알",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							[195051] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 195051,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 9,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[195054] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 122,
								["targets"] = {
									["받아줘요악사"] = 122,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 122,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 122,
								["c_max"] = 0,
								["id"] = 195054,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 122.013406,
					["serial"] = "Creature-0-3057-1481-10216-99160-000083DED4",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.013406,
					["start_time"] = 1560534782,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [14]
				{
					["flag_original"] = 8465,
					["totalabsorbed"] = 0.008906,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["파멸의 사령관 벨라이아쉬"] = 387,
						["지옥수호병 보초"] = 1449,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1836.008906,
					["end_time"] = 1560534913,
					["dps_started"] = false,
					["total"] = 1836.008906,
					["last_event"] = 0,
					["ownerName"] = "받아줘요악사",
					["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
					["friendlyfire"] = {
					},
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 555,
								["g_amt"] = 0,
								["n_max"] = 311,
								["targets"] = {
									["지옥수호병 보초"] = 866,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 311,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 866,
								["c_max"] = 555,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[197745] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 199,
								["targets"] = {
									["파멸의 사령관 벨라이아쉬"] = 387,
									["지옥수호병 보초"] = 583,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 970,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 970,
								["c_max"] = 0,
								["id"] = 197745,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["serial"] = "Creature-0-3057-1481-10216-96884-000003DF6C",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560534886,
					["delay"] = 0,
					["damage_taken"] = 0.008906,
				}, -- [15]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.008495,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 6679,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 6679.008495,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 6679.008495,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "파멸수호병 파멸자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 423,
								["targets"] = {
									["받아줘요악사"] = 5253,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 5253,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 5253,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 14,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200608] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 193,
								["targets"] = {
									["받아줘요악사"] = 1426,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1426,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["total"] = 1426,
								["c_max"] = 0,
								["id"] = 200608,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 21,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1560534998,
					["serial"] = "Creature-0-3057-1481-10216-94654-000003C500",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560534965,
					["delay"] = 0,
					["damage_taken"] = 12472.008495,
				}, -- [16]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.005857,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["받아줘요악사"] = 371,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 371.005857,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535084,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "군단 사령부",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							[193507] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 371,
								["targets"] = {
									["받아줘요악사"] = 371,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 371,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 371,
								["c_max"] = 0,
								["id"] = 193507,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 371.005857,
					["serial"] = "Creature-0-3057-1481-10216-98191-00000346AE",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.005857,
					["start_time"] = 1560535080,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [17]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.005525,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["받아줘요악사"] = 388,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 388.005525,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535084,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "에레다르 소환사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 388,
								["targets"] = {
									["받아줘요악사"] = 388,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 388,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 388,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["monster"] = true,
					["total"] = 388.005525,
					["serial"] = "Creature-0-3057-1481-10216-95046-000003C576",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.005525,
					["start_time"] = 1560535080,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [18]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.012973,
					["on_hold"] = false,
					["damage_from"] = {
						["받아줘요악사"] = true,
						["갈퀴흉터 바다소환사 <받아줘요악사>"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 7381,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 7381.012973,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535084,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "파멸의 사령관 벨라이아쉬",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1363,
								["g_amt"] = 0,
								["n_max"] = 425,
								["targets"] = {
									["받아줘요악사"] = 4353,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2990,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 12,
								["total"] = 4353,
								["c_max"] = 702,
								["a_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 8,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[196677] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 769,
								["targets"] = {
									["받아줘요악사"] = 1516,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1516,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 1516,
								["c_max"] = 0,
								["id"] = 196677,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[196625] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 196625,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[196403] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 766,
								["targets"] = {
									["받아줘요악사"] = 1512,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1512,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 1512,
								["c_max"] = 0,
								["id"] = 196403,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 7381.012973,
					["serial"] = "Creature-0-3057-1481-10216-93221-000003E009",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 23441.012973,
					["start_time"] = 1560535042,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [19]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.010123,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["받아줘요악사"] = 1863,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1863.010123,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535234,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "[*] 비통의 첨탑",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							[192603] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 373,
								["targets"] = {
									["받아줘요악사"] = 1863,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1863,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 1863,
								["c_max"] = 0,
								["id"] = 192603,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 6,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 1863.010123,
					["serial"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.010123,
					["start_time"] = 1560535214,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [20]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.019732,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 3747,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 3747.019732,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 3747.019732,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "파멸의 학살자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 420,
								["targets"] = {
									["받아줘요악사"] = 3134,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3134,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 3134,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 3,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 11,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200525] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 613,
								["targets"] = {
									["받아줘요악사"] = 613,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 613,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 613,
								["c_max"] = 0,
								["id"] = 200525,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1560535356,
					["serial"] = "Creature-0-3057-1481-10216-93716-000003C72F",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1560535328,
					["delay"] = 0,
					["damage_taken"] = 3047.019732,
				}, -- [21]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.008509,
					["on_hold"] = false,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 1391,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1391.008509,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535529,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "격노용사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 407,
								["targets"] = {
									["받아줘요악사"] = 1124,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1124,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1124,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 4,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200753] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 200753,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[200755] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 54,
								["targets"] = {
									["받아줘요악사"] = 267,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 267,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 267,
								["c_max"] = 0,
								["id"] = 200755,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 1391.008509,
					["serial"] = "Creature-0-3057-1481-10216-97034-000003D09E",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 10562.008509,
					["start_time"] = 1560535521,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [22]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.028801,
					["on_hold"] = false,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 22082,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 22082.028801,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535605,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "지옥수호병 도살자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 827,
								["g_amt"] = 0,
								["n_max"] = 443,
								["targets"] = {
									["받아줘요악사"] = 22082,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 21255,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 67,
								["DODGE"] = 3,
								["total"] = 22082,
								["c_max"] = 827,
								["a_amt"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 3,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 59,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200647] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 200647,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 5,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[200632] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 200632,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 7,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 22082.028801,
					["serial"] = "Creature-0-3057-1481-10216-96494-000003DFFE",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 46473.028801,
					["start_time"] = 1560535567,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [23]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.014282,
					["on_hold"] = false,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 1348,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1348.014282,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535605,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "에레다르 마술사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 359,
								["targets"] = {
									["받아줘요악사"] = 359,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 359,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 359,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[200582] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 989,
								["targets"] = {
									["받아줘요악사"] = 989,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 989,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 989,
								["c_max"] = 0,
								["id"] = 200582,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[200615] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 200615,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 1348.014282,
					["serial"] = "Creature-0-3057-1481-10216-96473-000003DF4F",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 5725.014282,
					["start_time"] = 1560535599,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [24]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.014774,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["받아줘요악사"] = 1227,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1227.014774,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535605,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "[*] 어둠의 칼날",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							[200662] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 89,
								["targets"] = {
									["받아줘요악사"] = 1227,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1227,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 1227,
								["c_max"] = 0,
								["id"] = 200662,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 14,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 1227.014774,
					["serial"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.014774,
					["start_time"] = 1560535577,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [25]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.006834,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006834,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1560535632,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "가시발톱 새끼 거미",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["받아줘요악사"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
						},
					},
					["friendlyfire_total"] = 0,
					["total"] = 0.006834,
					["serial"] = "Creature-0-3057-1481-10216-99650-000003AAFD",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 27587.006834,
					["start_time"] = 1560535629,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [26]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.011117,
					["on_hold"] = false,
					["damage_from"] = {
						["받아줘요악사"] = true,
						["잿빛혓바닥 추적자 <받아줘요악사>"] = true,
					},
					["targets"] = {
						["받아줘요악사"] = 2784,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 2784.011117,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1560535708,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "지옥 군주 카자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 210,
								["targets"] = {
									["받아줘요악사"] = 1078,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1078,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["a_amt"] = 0,
								["total"] = 1078,
								["c_max"] = 0,
								["DODGE"] = 1,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 8,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[197002] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 948,
								["targets"] = {
									["받아줘요악사"] = 948,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 948,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 948,
								["c_max"] = 0,
								["id"] = 197002,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[197184] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 19,
								["targets"] = {
									["받아줘요악사"] = 112,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 112,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 112,
								["c_max"] = 0,
								["id"] = 197184,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 6,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[197180] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 197180,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[196955] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 646,
								["targets"] = {
									["받아줘요악사"] = 646,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 646,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 646,
								["c_max"] = 0,
								["id"] = 196955,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 2784.011117,
					["serial"] = "Creature-0-3057-1481-10216-96441-000003DEB0",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 26175.011117,
					["start_time"] = 1560535674,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [27]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.004773,
					["damage_from"] = {
						["받아줘요악사"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004773,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1560535741,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "영혼 거머리",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["friendlyfire_total"] = 0,
					["total"] = 0.004773,
					["serial"] = "Creature-0-3057-1481-10216-94655-000003C8C7",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 235.004773,
					["start_time"] = 1560535738,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [28]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["targets_overheal"] = {
						["받아줘요악사"] = 30252,
					},
					["pets"] = {
						"갈퀴흉터 바다소환사 <받아줘요악사>", -- [1]
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 30252.059913,
					["total_without_pet"] = 58380.059913,
					["total"] = 59013.059913,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-205-075EECC9",
					["totalabsorb"] = 0.059913,
					["last_hps"] = 0,
					["targets"] = {
						["받아줘요악사"] = 71217,
					},
					["totalover_without_pet"] = 0.059913,
					["healing_taken"] = 59013.059913,
					["fight_component"] = true,
					["end_time"] = 1560534078,
					["healing_from"] = {
						["받아줘요악사"] = true,
						["갈퀴흉터 바다소환사 <받아줘요악사>"] = true,
					},
					["nome"] = "받아줘요악사",
					["spells"] = {
						["tipo"] = 3,
						["_ActorTable"] = {
							[202644] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["받아줘요악사"] = 30252,
								},
								["n_max"] = 3650,
								["targets"] = {
									["받아줘요악사"] = 58380,
								},
								["n_min"] = 0,
								["counter"] = 25,
								["overheal"] = 30252,
								["total"] = 58380,
								["c_max"] = 0,
								["id"] = 202644,
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 58380,
								["n_amt"] = 25,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
					},
					["grupo"] = true,
					["start_time"] = 1560534009,
					["classe"] = "DEMONHUNTER",
					["custom"] = 0,
					["tipo"] = 2,
					["spec"] = 577,
					["totaldenied"] = 0.059913,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [1]
				{
					["flag_original"] = 8465,
					["healing_from"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "PET",
					["totalover"] = 0.010217,
					["total_without_pet"] = 633.010217,
					["total"] = 633.010217,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-3057-1481-10216-96884-000003DF6C",
					["totalabsorb"] = 0.010217,
					["last_hps"] = 0,
					["targets"] = {
						["받아줘요악사"] = 633,
					},
					["totalover_without_pet"] = 0.010217,
					["healing_taken"] = 0.010217,
					["targets_overheal"] = {
					},
					["fight_component"] = true,
					["end_time"] = 1560534913,
					["ownerName"] = "받아줘요악사",
					["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
					["heal_enemy_amt"] = 0,
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 2,
					["start_time"] = 1560534901,
					["totaldenied"] = 0.010217,
					["delay"] = 0,
					["spells"] = {
						["tipo"] = 3,
						["_ActorTable"] = {
							[197744] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 633,
								["targets"] = {
									["받아줘요악사"] = 633,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 633,
								["c_max"] = 0,
								["id"] = 197744,
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 633,
								["n_amt"] = 1,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
					},
				}, -- [2]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["resource"] = 4247.164998,
					["targets"] = {
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "DEMONHUNTER",
					["totalover"] = 0.003045,
					["fight_component"] = true,
					["alternatepower"] = 0.164998,
					["nome"] = "받아줘요악사",
					["spec"] = 577,
					["grupo"] = true,
					["received"] = 0.164998,
					["passiveover"] = 0.003045,
					["resource_type"] = 17,
					["last_event"] = 0,
					["total"] = 0.164998,
					["tipo"] = 3,
					["serial"] = "Player-205-075EECC9",
					["spells"] = {
						["tipo"] = 7,
						["_ActorTable"] = {
						},
					},
				}, -- [1]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["fight_component"] = true,
					["buff_uptime_targets"] = {
					},
					["spec"] = 577,
					["grupo"] = true,
					["nome"] = "받아줘요악사",
					["spell_cast"] = {
						[162794] = 98,
						[195072] = 12,
						[162243] = 141,
						[131347] = 5,
						[202719] = 1,
						[198013] = 12,
					},
					["pets"] = {
						"갈퀴흉터 바다소환사 <받아줘요악사>", -- [1]
					},
					["classe"] = "DEMONHUNTER",
					["tipo"] = 4,
					["buff_uptime"] = 756,
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[191466] = {
								["refreshamt"] = 0,
								["activedamt"] = 27,
								["appliedamt"] = 27,
								["id"] = 191466,
								["uptime"] = 452,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[200175] = {
								["refreshamt"] = 0,
								["appliedamt"] = 6,
								["activedamt"] = 6,
								["uptime"] = 68,
								["id"] = 200175,
								["actived_at"] = 6242139512,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[198013] = {
								["actived_at"] = 1560535622,
								["refreshamt"] = 0,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = 198013,
								["uptime"] = 22,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[210093] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = 210093,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[131347] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = 131347,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[210105] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = 210105,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[163073] = {
								["refreshamt"] = 15,
								["activedamt"] = 32,
								["appliedamt"] = 32,
								["id"] = 163073,
								["uptime"] = 214,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[203925] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = 203925,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-205-075EECC9",
					["last_event"] = 0,
				}, -- [1]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "모아그 투사",
					["pets"] = {
					},
					["spell_cast"] = {
						[200425] = 4,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-98484-000003D9D8",
					["classe"] = "UNKNOW",
				}, -- [2]
				{
					["fight_component"] = true,
					["last_event"] = 0,
					["nome"] = "더러운 지옥사냥개",
					["spell_cast"] = {
						[200417] = 12,
					},
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 68168,
					["serial"] = "Creature-0-3057-1481-10216-98482-000003DA8A",
					["tipo"] = 4,
				}, -- [3]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "고뇌의 간수",
					["pets"] = {
					},
					["spell_cast"] = {
						[200502] = 8,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-95226-000003DAED",
					["classe"] = "UNKNOW",
				}, -- [4]
				{
					["fight_component"] = true,
					["nome"] = "지옥수호병 보초",
					["flag_original"] = 68168,
					["spell_cast"] = {
						[200570] = 12,
					},
					["monster"] = true,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["serial"] = "Creature-0-3057-1481-10216-93112-000003DC82",
					["last_event"] = 0,
				}, -- [5]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "광선을 뿜는 눈알",
					["pets"] = {
					},
					["spell_cast"] = {
						[195051] = 9,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-99160-000083DED4",
					["classe"] = "UNKNOW",
				}, -- [6]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "심문관 베일풀",
					["pets"] = {
					},
					["spell_cast"] = {
						[194529] = 2,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-93105-000003DD94",
					["classe"] = "UNKNOW",
				}, -- [7]
				{
					["fight_component"] = true,
					["ownerName"] = "받아줘요악사",
					["nome"] = "갈퀴흉터 바다소환사 <받아줘요악사>",
					["pets"] = {
					},
					["spell_cast"] = {
						[197745] = 5,
						[197744] = 1,
					},
					["flag_original"] = 8465,
					["last_event"] = 0,
					["classe"] = "PET",
					["serial"] = "Creature-0-3057-1481-10216-96884-000003DF6C",
					["tipo"] = 4,
				}, -- [8]
				{
					["flag_original"] = 2632,
					["nome"] = "파멸의 사령관 벨라이아쉬",
					["spell_cast"] = {
						[196677] = 3,
						[196625] = 2,
						[196403] = 2,
					},
					["monster"] = true,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["fight_component"] = true,
					["pets"] = {
					},
					["serial"] = "Creature-0-3057-1481-10216-93221-000003E009",
					["last_event"] = 0,
				}, -- [9]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "격노용사",
					["pets"] = {
					},
					["spell_cast"] = {
						[200753] = 1,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-97034-000003D106",
					["classe"] = "UNKNOW",
				}, -- [10]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "지옥수호병 도살자",
					["pets"] = {
					},
					["spell_cast"] = {
						[200632] = 7,
						[200647] = 5,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-96494-000003DFFE",
					["classe"] = "UNKNOW",
				}, -- [11]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "에레다르 마술사",
					["pets"] = {
					},
					["spell_cast"] = {
						[200615] = 1,
						[200582] = 1,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-102726-000003C801",
					["classe"] = "UNKNOW",
				}, -- [12]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "지옥 군주 카자",
					["pets"] = {
					},
					["spell_cast"] = {
						[197180] = 1,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3057-1481-10216-96441-000003DEB0",
					["classe"] = "UNKNOW",
				}, -- [13]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1560534071,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 5,
		["totals"] = {
			551024.604078, -- [1]
			59646.058326, -- [2]
			{
				0.161953, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["spells_cast_timeline"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "02:41:12",
		["end_time"] = 14733.697,
		["cleu_events"] = {
			["n"] = 1,
		},
		["segments_added"] = {
			{
				["elapsed"] = 1.33499999999913,
				["type"] = 0,
				["name"] = "영혼 거머리",
				["clock"] = "03:08:59",
			}, -- [1]
			{
				["elapsed"] = 30.5720000000001,
				["type"] = 0,
				["name"] = "지옥 군주 카자",
				["clock"] = "03:07:57",
			}, -- [2]
			{
				["elapsed"] = 24.3619999999992,
				["type"] = 0,
				["name"] = "지옥수호병 도살자",
				["clock"] = "03:07:14",
			}, -- [3]
			{
				["elapsed"] = 0.895000000000437,
				["type"] = 0,
				["name"] = "에레다르 마술사",
				["clock"] = "03:07:11",
			}, -- [4]
			{
				["elapsed"] = 4.44900000000052,
				["type"] = 0,
				["name"] = "지옥수호병 도살자",
				["clock"] = "03:07:00",
			}, -- [5]
			{
				["elapsed"] = 17.8430000000008,
				["type"] = 0,
				["name"] = "지옥수호병 도살자",
				["clock"] = "03:06:27",
			}, -- [6]
			{
				["elapsed"] = 7.53100000000086,
				["type"] = 0,
				["name"] = "격노용사",
				["clock"] = "03:05:21",
			}, -- [7]
			{
				["elapsed"] = 19.4709999999996,
				["type"] = 0,
				["name"] = "파멸의 학살자",
				["clock"] = "03:02:17",
			}, -- [8]
			{
				["elapsed"] = 24.7510000000002,
				["type"] = 0,
				["name"] = "파멸수호병 파멸자",
				["clock"] = "03:01:27",
			}, -- [9]
			{
				["elapsed"] = 41.9740000000002,
				["type"] = 0,
				["name"] = "파멸수호병 파멸자",
				["clock"] = "02:59:52",
			}, -- [10]
			{
				["elapsed"] = 44.5049999999992,
				["type"] = 0,
				["name"] = "모아그 투사",
				["clock"] = "02:57:20",
			}, -- [11]
			{
				["elapsed"] = 35.2910000000011,
				["type"] = 0,
				["name"] = "지옥수호병 보초",
				["clock"] = "02:56:03",
			}, -- [12]
			{
				["elapsed"] = 7.17100000000028,
				["type"] = 0,
				["name"] = "고뇌의 간수",
				["clock"] = "02:55:35",
			}, -- [13]
			{
				["elapsed"] = 7.03899999999885,
				["type"] = 0,
				["name"] = "모아그 투사",
				["clock"] = "02:55:23",
			}, -- [14]
			{
				["elapsed"] = 21.4079999999995,
				["type"] = 0,
				["name"] = "더러운 지옥사냥개",
				["clock"] = "02:54:51",
			}, -- [15]
			{
				["elapsed"] = 12.1550000000007,
				["type"] = 0,
				["name"] = "지옥수호병 보초",
				["clock"] = "02:54:28",
			}, -- [16]
			{
				["elapsed"] = 7.29500000000007,
				["type"] = 0,
				["name"] = "고뇌의 간수",
				["clock"] = "02:54:04",
			}, -- [17]
			{
				["elapsed"] = 28.639000000001,
				["type"] = 0,
				["name"] = "지옥수호병 보초",
				["clock"] = "02:53:20",
			}, -- [18]
			{
				["elapsed"] = 50.5389999999989,
				["type"] = 0,
				["name"] = "심문관 베일풀",
				["clock"] = "02:52:16",
			}, -- [19]
			{
				["elapsed"] = 9.06999999999971,
				["type"] = 0,
				["name"] = "고뇌의 간수",
				["clock"] = "02:51:05",
			}, -- [20]
			{
				["elapsed"] = 4.40800000000127,
				["type"] = 0,
				["name"] = "심연 바실리스크",
				["clock"] = "02:50:53",
			}, -- [21]
			{
				["elapsed"] = 9.6859999999997,
				["type"] = 0,
				["name"] = "고뇌의 간수",
				["clock"] = "02:50:32",
			}, -- [22]
			{
				["elapsed"] = 9.87099999999919,
				["type"] = 0,
				["name"] = "고뇌의 간수",
				["clock"] = "02:50:12",
			}, -- [23]
			{
				["elapsed"] = 4.60899999999856,
				["type"] = 0,
				["name"] = "지옥수호병 보초",
				["clock"] = "02:50:03",
			}, -- [24]
			{
				["elapsed"] = 7.05199999999968,
				["type"] = 0,
				["name"] = "고뇌의 간수",
				["clock"] = "02:49:51",
			}, -- [25]
			{
				["elapsed"] = 7.31899999999951,
				["type"] = 0,
				["name"] = "고뇌의 간수",
				["clock"] = "02:49:41",
			}, -- [26]
			{
				["elapsed"] = 14.1170000000002,
				["type"] = 0,
				["name"] = "더러운 지옥사냥개",
				["clock"] = "02:49:13",
			}, -- [27]
			{
				["elapsed"] = 17.9519999999993,
				["type"] = 0,
				["name"] = "더러운 지옥사냥개",
				["clock"] = "02:46:56",
			}, -- [28]
			{
				["elapsed"] = 4.76300000000083,
				["type"] = 0,
				["name"] = "격노전사",
				["clock"] = "02:44:46",
			}, -- [29]
			{
				["elapsed"] = 8.06999999999971,
				["type"] = 0,
				["name"] = "격노전사",
				["clock"] = "02:44:32",
			}, -- [30]
		},
		["totals_grupo"] = {
			404978.225838, -- [1]
			59013.051091, -- [2]
			{
				0.161953, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["frags"] = {
		},
		["data_fim"] = "03:09:01",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["cleu_timeline"] = {
		},
		["start_time"] = 14150.642,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
			["damage"] = {
			},
		},
	},
	["combat_counter"] = 45,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["last_realversion"] = 140,
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-205-075EECC9"] = 577,
	},
}
