
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["무시중한디"] = {
			["GUID"] = "Player-2116-06595DB7",
			["LastEventHealth"] = {
				5082504, -- [1]
				5082504, -- [2]
				5082504, -- [3]
				5082504, -- [4]
				5082504, -- [5]
				5082504, -- [6]
				5082504, -- [7]
				5040553, -- [8]
				5040553, -- [9]
				4991476, -- [10]
				4991476, -- [11]
				4983597, -- [12]
				5028509, -- [13]
				5155380, -- [14]
				5147501, -- [15]
				5155380, -- [16]
				5147501, -- [17]
				5155380, -- [18]
				5104461, -- [19]
				5104461, -- [20]
				5155380, -- [21]
				5155380, -- [22]
				5155380, -- [23]
				5155380, -- [24]
				5155380, -- [25]
				5155380, -- [26]
				5155380, -- [27]
				5155380, -- [28]
				5155380, -- [29]
				5116039, -- [30]
				5116039, -- [31]
				5155380, -- [32]
				5155380, -- [33]
				5155380, -- [34]
				5155380, -- [35]
				5103276, -- [36]
				5038193, -- [37]
				5038193, -- [38]
				5038193, -- [39]
				4964725, -- [40]
				4938199, -- [41]
				4938199, -- [42]
				4898653, -- [43]
				4832709, -- [44]
				4832709, -- [45]
				5155380, -- [46]
				5155380, -- [47]
				5155380, -- [48]
				5155380, -- [49]
				5082504, -- [50]
			},
			["LastAttackedBy"] = "되살아난 선봉대원",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"HEAL", -- [21]
				"HEAL", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"HEAL", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					33.56, -- [1]
				},
				["Healing"] = {
					9148704, -- [1]
				},
				["DamageTaken"] = {
					13023150, -- [1]
				},
				["HealingTaken"] = {
					9148704, -- [1]
				},
				["Overhealing"] = {
					23092299, -- [1]
				},
				["ActiveTime"] = {
					132.73, -- [1]
				},
				["TimeDamage"] = {
					99.17, -- [1]
				},
				["FuryGain"] = {
					1362, -- [1]
				},
				["Damage"] = {
					86287642, -- [1]
				},
			},
			["enClass"] = "DEMONHUNTER",
			["unit"] = "무시중한디",
			["level"] = 110,
			["LastDamageAbility"] = "일반 공격",
			["LastFightIn"] = 14,
			["LastHealTime"] = 1231782.677,
			["type"] = "Self",
			["FightsSaved"] = 5,
			["LastEventHealthMax"] = {
				5155380, -- [1]
				5155380, -- [2]
				5155380, -- [3]
				5155380, -- [4]
				5155380, -- [5]
				5155380, -- [6]
				5155380, -- [7]
				5155380, -- [8]
				5155380, -- [9]
				5155380, -- [10]
				5155380, -- [11]
				5155380, -- [12]
				5155380, -- [13]
				5155380, -- [14]
				5155380, -- [15]
				5155380, -- [16]
				5155380, -- [17]
				5155380, -- [18]
				5155380, -- [19]
				5155380, -- [20]
				5155380, -- [21]
				5155380, -- [22]
				5155380, -- [23]
				5155380, -- [24]
				5155380, -- [25]
				5155380, -- [26]
				5155380, -- [27]
				5155380, -- [28]
				5155380, -- [29]
				5155380, -- [30]
				5155380, -- [31]
				5155380, -- [32]
				5155380, -- [33]
				5155380, -- [34]
				5155380, -- [35]
				5155380, -- [36]
				5155380, -- [37]
				5155380, -- [38]
				5155380, -- [39]
				5155380, -- [40]
				5155380, -- [41]
				5155380, -- [42]
				5155380, -- [43]
				5155380, -- [44]
				5155380, -- [45]
				5155380, -- [46]
				5155380, -- [47]
				5155380, -- [48]
				5155380, -- [49]
				5155380, -- [50]
			},
			["LastDamageTaken"] = 39388,
			["Owner"] = false,
			["TimeLast"] = {
				["TimeHeal"] = 1231782.23,
				["OVERALL"] = 1231815.244,
				["DamageTaken"] = 1231815.244,
				["HealingTaken"] = 1231782.23,
				["Overhealing"] = 1231782.23,
				["TimeDamage"] = 1231786.245,
				["Healing"] = 1231782.23,
				["FuryGain"] = 1231805.248,
				["ActiveTime"] = 1231786.245,
				["Damage"] = 1231786.245,
			},
			["NextEventNum"] = 46,
			["LastDamageTime"] = 1231786.863,
			["LastEvents"] = {
				"무시중한디 일반 공격 되살아난 표범 Hit -36059 (Physical)", -- [1]
				"무시중한디 혼돈의 일격 되살아난 표범 Crit -816414", -- [2]
				"무시중한디 혼돈의 회전베기 되살아난 표범 Hit -52672", -- [3]
				"무시중한디 혼돈의 일격 되살아난 표범 Crit -581471", -- [4]
				"무시중한디 혼돈의 회전베기 되살아난 표범 Hit -37514", -- [5]
				"되살아난 표범 일반 공격 무시중한디 Hit -41951 (Physical)", -- [6]
				"무시중한디 일반 공격 되살아난 표범 Crit -37895 (Physical)", -- [7]
				"무시중한디 악마의 이빨 되살아난 표범 Hit -175244 (Physical)", -- [8]
				"되살아난 표범 일반 공격 무시중한디 Hit -49077 (Physical)", -- [9]
				"무시중한디 일반 공격 되살아난 표범 Hit -35465 (Physical)", -- [10]
				"무시중한디 혼돈의 일격 되살아난 표범 Hit -283694", -- [11]
				"되살아난 표범 유령 휘둘러치기 (지속 피해) 무시중한디 Tick -7879 (Shadow)", -- [12]
				"되살아난 표범 유령 휘둘러치기 (지속 피해) 무시중한디 Tick -7879 (Shadow)", -- [13]
				"무시중한디 영혼 삼키기 무시중한디 Hit +1288845 (1214224 오버힐)", -- [14]
				"되살아난 표범 유령 휘둘러치기 (지속 피해) 무시중한디 Tick -7879 (Shadow)", -- [15]
				"무시중한디 영혼 삼키기 무시중한디 Hit +1288845 (1288845 오버힐)", -- [16]
				"되살아난 표범 유령 휘둘러치기 (지속 피해) 무시중한디 Tick -7879 (Shadow)", -- [17]
				"되살아난 병사 일반 공격 무시중한디 Hit -50919 (Physical)", -- [18]
				"무시중한디 악마의 이빨 되살아난 병사 Hit -295710 (Physical)", -- [19]
				"무시중한디 어둠의 결합 되살아난 병사 Crit -1898199 (Shadow)", -- [20]
				"무시중한디 어둠의 결합 무시중한디 Hit +1315153 (1264234 오버힐)", -- [21]
				"무시중한디 영혼 삼키기 무시중한디 Hit +1288845 (1288845 오버힐)", -- [22]
				"무시중한디 혼돈의 일격 레이븐크레스트의 하인 Hit -403275", -- [23]
				"무시중한디 혼돈의 회전베기 레이븐크레스트의 하인 Hit -26018", -- [24]
				"무시중한디 연약함 레이븐크레스트의 하인 Hit -142657 (Frost)", -- [25]
				"레이븐크레스트의 하인 일반 공격 무시중한디 Hit -39341 (Physical)", -- [26]
				"무시중한디 혼돈의 일격 레이븐크레스트의 하인 Hit -344789", -- [27]
				"무시중한디 일반 공격 레이븐크레스트의 하인 Hit -51863 (Physical)", -- [28]
				"무시중한디 혼돈의 회전베기 레이븐크레스트의 하인 Hit -22244", -- [29]
				"무시중한디 일반 공격 레이븐크레스트의 하인 Crit -51816 (Physical)", -- [30]
				"무시중한디 악마의 이빨 레이븐크레스트의 하인 Hit -280181 (Physical)", -- [31]
				"무시중한디 영혼 삼키기 무시중한디 Hit +515538 (476197 오버힐)", -- [32]
				"무시중한디 영혼 삼키기 무시중한디 Hit +1288845 (1288845 오버힐)", -- [33]
				"유령 장교 일반 공격 무시중한디 Dodge (1)", -- [34]
				"되살아난 선봉대원 일반 공격 무시중한디 Hit -52104 (Physical)", -- [35]
				"유령 장교 일반 공격 무시중한디 Hit -65083 (Physical)", -- [36]
				"되살아난 선봉대원 일반 공격 무시중한디 Miss (1)", -- [37]
				"되살아난 선봉대원 일반 공격 무시중한디 Hit -46680 (Physical)", -- [38]
				"유령 장교 일반 공격 무시중한디 Dodge (1)", -- [39]
				"유령 장교 더럽혀진 자의 저주 (지속 피해) 무시중한디 Tick -26788 (Shadow)", -- [40]
				"유령 장교 더럽혀진 자의 저주 (지속 피해) 무시중한디 Tick -26526 (Shadow)", -- [41]
				"되살아난 선봉대원 일반 공격 무시중한디 Hit -39546 (Physical)", -- [42]
				"되살아난 선봉대원 일반 공격 무시중한디 Hit -40469 (Physical)", -- [43]
				"유령 장교 더럽혀진 자의 저주 (지속 피해) 무시중한디 Tick -25475 (Shadow)", -- [44]
				"되살아난 선봉대원 일반 공격 무시중한디 Hit -39388 (Physical)", -- [45]
				"무시중한디 영혼 삼키기 무시중한디 Hit +515538 (285990 오버힐)", -- [46]
				"무시중한디 악마의 이빨 되살아난 표범 Crit -355174 (Physical)", -- [47]
				"되살아난 표범 일반 공격 무시중한디 Hit -53472 (Physical)", -- [48]
				"무시중한디 일반 공격 되살아난 표범 Hit -19533 (Physical)", -- [49]
				"되살아난 표범 유령 휘둘러치기 무시중한디 Hit -19404 (Shadow)", -- [50]
			},
			["Name"] = "무시중한디",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				false, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				false, -- [19]
				false, -- [20]
				true, -- [21]
				true, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				true, -- [43]
				true, -- [44]
				true, -- [45]
				true, -- [46]
				false, -- [47]
				true, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				1231739.789, -- [1]
				1231739.955, -- [2]
				1231739.955, -- [3]
				1231740.244, -- [4]
				1231740.244, -- [5]
				1231740.519, -- [6]
				1231740.86, -- [7]
				1231741.78, -- [8]
				1231741.78, -- [9]
				1231742.146, -- [10]
				1231742.463, -- [11]
				1231742.693, -- [12]
				1231745.796, -- [13]
				1231746.213, -- [14]
				1231748.672, -- [15]
				1231750.554, -- [16]
				1231751.955, -- [17]
				1231779.711, -- [18]
				1231782.677, -- [19]
				1231782.677, -- [20]
				1231782.677, -- [21]
				1231784.865, -- [22]
				1231785.611, -- [23]
				1231785.611, -- [24]
				1231785.611, -- [25]
				1231785.826, -- [26]
				1231785.936, -- [27]
				1231785.936, -- [28]
				1231785.936, -- [29]
				1231786.517, -- [30]
				1231786.863, -- [31]
				1231788.763, -- [32]
				1231793.197, -- [33]
				1231800.298, -- [34]
				1231802.131, -- [35]
				1231802.131, -- [36]
				1231805.108, -- [37]
				1231805.684, -- [38]
				1231805.684, -- [39]
				1231808.863, -- [40]
				1231811.85, -- [41]
				1231813.289, -- [42]
				1231813.703, -- [43]
				1231814.852, -- [44]
				1231815.285, -- [45]
				1231737.883, -- [46]
				1231738.109, -- [47]
				1231738.508, -- [48]
				1231738.674, -- [49]
				1231739.694, -- [50]
			},
			["Fights"] = {
				["Fight5"] = {
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 식탐"] = {
									["count"] = 35,
								},
							},
							["amount"] = 35,
						},
					},
					["FuryGain"] = 35,
					["DOTs"] = {
					},
					["FuryGained"] = {
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 35,
								},
							},
							["amount"] = 35,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 1802281,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 1551164,
						["Fire"] = 0,
						["Melee"] = 174167,
						["Shadow"] = 76950,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["지옥 화염구"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["되살아난 병사"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 98110,
								},
							},
							["amount"] = 98110,
						},
						["유령 장교"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 76057,
								},
								["더럽혀진 자의 저주 (지속 피해)"] = {
									["count"] = 76950,
								},
							},
							["amount"] = 153007,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 1551164,
								},
							},
							["amount"] = 1551164,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["지옥 화염구"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["Falling"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["지옥 화염구"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 2,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 식탐"] = {
									["count"] = 0,
								},
								["기만자의 격노"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
					},
					["FuryGain"] = 2,
					["DOTs"] = {
					},
					["FuryGained"] = {
						["악마의 이빨"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["기만자의 격노"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 50919,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 0,
						["Melee"] = 50919,
						["Shadow"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 2193909,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Physical"] = 295710,
						["Melee"] = 0,
						["Shadow"] = 1898199,
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["유령 휘둘러치기 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["정수 삼키기 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["되살아난 병사"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 295710,
								},
								["어둠의 결합"] = {
									["count"] = 1898199,
								},
							},
							["amount"] = 2193909,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["빛벼림 기갑전투복"] = {
							["Details"] = {
								["탈태"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["고뇌"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["파멸"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["탈태"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["되살아난 병사"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 50919,
								},
							},
							["amount"] = 50919,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["되살아난 표범"] = {
							["Details"] = {
								["유령 휘둘러치기 (지속 피해)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["정수 삼키기 (지속 피해)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["유령 휘둘러치기 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["정수 삼키기 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 0,
					},
					["TimeHealing"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1264234,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1264234,
								},
							},
							["count"] = 1,
							["amount"] = 1264234,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 50919,
								},
							},
							["amount"] = 50919,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 1264234,
					["TimeSpent"] = {
						["되살아난 병사"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["시요키"] = {
							["Details"] = {
								["슬픔"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["탈태"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["파멸"] = {
									["count"] = 0,
								},
								["고뇌"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 50919,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 50919,
								},
							},
							["count"] = 1,
							["amount"] = 50919,
						},
					},
					["WhoHealed"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 50919,
								},
							},
							["amount"] = 50919,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 3,
					["Healing"] = 50919,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["연약함"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["악마의 이빨"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 295710,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 295710,
								},
							},
							["count"] = 1,
							["amount"] = 295710,
						},
						["고뇌"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1898199,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1898199,
								},
							},
							["count"] = 1,
							["amount"] = 1898199,
						},
						["혼돈의 회전베기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["파멸"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["슬픔"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit (방어)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["안광"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["내면의 악마"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["탈태"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 50919,
					["RageGain"] = 0,
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["되살아난 병사"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["시요키"] = {
							["Details"] = {
								["슬픔"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["탈태"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["파멸"] = {
									["count"] = 0,
								},
								["고뇌"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 식탐"] = {
									["count"] = 0,
								},
								["기만자의 격노"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FuryGain"] = 0,
					["DOTs"] = {
					},
					["FuryGained"] = {
						["악마의 이빨"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["기만자의 격노"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Frost"] = 0,
						["Physical"] = 0,
						["Melee"] = 0,
						["Fire"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Shadow"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥 화염구"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["뼈아픈 이빨"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혹독한 베기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["되살아난 선봉대원"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["연약함"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["지옥 돌진"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["혹독한 지옥야수"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혹독한 베기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["지옥 화염구"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["혹독한 지옥야수"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["뼈아픈 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥 화염구"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["뼈아픈 이빨"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혹독한 베기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 0,
					},
					["TimeHealing"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0,
								},
								["어둠의 결합"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["연약함"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥 돌진"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 회전베기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["슬픔"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["악마의 이빨"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["안광"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["내면의 악마"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["Hit (방어)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["ElementDoneBlock"] = {
						["Physical"] = 0,
					},
					["FuryGain"] = 88,
					["OverHeals"] = {
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 285990,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 285990,
								},
							},
							["count"] = 1,
							["amount"] = 285990,
						},
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["되살아난 표범"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 5.83,
								},
								["혼돈의 일격"] = {
									["count"] = 1.2,
								},
								["악마의 이빨"] = {
									["count"] = 1.47,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 8.6,
						},
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 1.5,
								},
								["생기흡수"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.5,
						},
						["아스트릭스"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["카드래우스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["글레이브 투척"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 401331,
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["유령 휘둘러치기 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 6,
						},
						["십자 베기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["유령 휘둘러치기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["유령 휘둘러치기 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["십자 베기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["유령 휘둘러치기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 10.1,
					["ElementDone"] = {
						["Physical"] = 895593,
						["Melee"] = 310772,
						["Shadow"] = 0,
					},
					["ElementTaken"] = {
						["Shadow"] = 27283,
						["Physical"] = 0,
						["Melee"] = 374048,
						["Arcane"] = 0,
					},
					["WhoHealed"] = {
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 229548,
								},
								["생기흡수"] = {
									["count"] = 0,
								},
							},
							["amount"] = 229548,
						},
					},
					["Damage"] = 3586475,
					["HealedWho"] = {
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 229548,
								},
								["생기흡수"] = {
									["count"] = 0,
								},
							},
							["amount"] = 229548,
						},
					},
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 29,
								},
								["혼돈의 일격"] = {
									["count"] = 20,
								},
								["기만자의 격노"] = {
									["count"] = 0,
								},
								["악마의 식탐"] = {
									["count"] = 39,
								},
							},
							["amount"] = 88,
						},
					},
					["Heals"] = {
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 229548,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 229548,
								},
							},
							["count"] = 1,
							["amount"] = 229548,
						},
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeHeal"] = 1.5,
					["TimeHealing"] = {
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 1.5,
								},
								["생기흡수"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Healing"] = 229548,
					["Overhealing"] = 285990,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 7,
						},
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["어둠의 결합"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 회전베기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 52672,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 177152,
								},
							},
							["count"] = 7,
							["amount"] = 177152,
						},
						["안광"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 816414,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1397885,
								},
								["Hit"] = {
									["max"] = 305224,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 805073,
								},
							},
							["count"] = 5,
							["amount"] = 2202958,
						},
						["일반 공격"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 36059,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 91057,
								},
								["Crit"] = {
									["max"] = 73383,
									["min"] = 37638,
									["count"] = 4,
									["amount"] = 219715,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 310772,
						},
						["글레이브 투척"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["내면의 악마"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["악마의 이빨"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 175244,
									["min"] = 175244,
									["count"] = 1,
									["amount"] = 175244,
								},
								["Crit"] = {
									["max"] = 365175,
									["min"] = 355174,
									["count"] = 2,
									["amount"] = 720349,
								},
								["Hit (방어)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 895593,
						},
					},
					["HealingTaken"] = 229548,
					["DamagedWho"] = {
						["새끼 황혼거미"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 19692,
								},
							},
							["amount"] = 19692,
						},
						["되살아난 표범"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 895593,
								},
								["혼돈의 일격"] = {
									["count"] = 2202958,
								},
								["혼돈의 회전베기"] = {
									["count"] = 157460,
								},
								["일반 공격"] = {
									["count"] = 310772,
								},
							},
							["amount"] = 3566783,
						},
						["아스트릭스"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 0,
								},
								["글레이브 투척"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["카드래우스"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["내면의 악마"] = {
									["count"] = 0,
								},
								["글레이브 투척"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 8.6,
					["WhoDamaged"] = {
						["아스트릭스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["십자 베기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["되살아난 표범"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 374048,
								},
								["유령 휘둘러치기 (지속 피해)"] = {
									["count"] = 7879,
								},
								["유령 휘둘러치기"] = {
									["count"] = 19404,
								},
							},
							["amount"] = 401331,
						},
						["카드래우스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FuryGained"] = {
						["악마의 이빨"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 29,
								},
							},
							["amount"] = 29,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["기만자의 격노"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 39,
								},
							},
							["amount"] = 39,
						},
					},
					["TimeDamaging"] = {
						["되살아난 표범"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 5.83,
								},
								["혼돈의 일격"] = {
									["count"] = 1.2,
								},
								["악마의 이빨"] = {
									["count"] = 1.47,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 8.6,
						},
						["아스트릭스"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["카드래우스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["글레이브 투척"] = {
									["count"] = 0,
								},
								["안광"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 6,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["Fight4"] = {
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 22,
								},
								["혼돈의 일격"] = {
									["count"] = 40,
								},
								["악마의 식탐"] = {
									["count"] = 20,
								},
								["기만자의 격노"] = {
									["count"] = 13,
								},
							},
							["amount"] = 95,
						},
					},
					["FuryGain"] = 95,
					["DOTs"] = {
					},
					["FuryGained"] = {
						["악마의 이빨"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 40,
								},
							},
							["amount"] = 40,
						},
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["기만자의 격노"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 13,
								},
							},
							["amount"] = 13,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 226707,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Fire"] = 0,
						["Melee"] = 226707,
						["Arcane"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 9294173,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 3.59,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Shadow"] = 707460,
						["Melee"] = 106836,
						["Physical"] = 232185,
					},
					["PartialAbsorb"] = {
						["유령 휘둘러치기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["오염된 함정"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["미래 흡수"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["비전 찢기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥칼날 베기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥 열기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["바퀴벌레"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 297204,
								},
							},
							["amount"] = 297204,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["어둠그늘"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 150389,
								},
								["파멸"] = {
									["count"] = 1267200,
								},
								["슬픔"] = {
									["count"] = 707460,
								},
								["일반 공격"] = {
									["count"] = 106836,
								},
								["혼돈의 일격"] = {
									["count"] = 2331063,
								},
								["안광"] = {
									["count"] = 2877957,
								},
								["악마의 이빨"] = {
									["count"] = 232185,
								},
							},
							["amount"] = 7673090,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 1173489,
								},
								["혼돈의 회전베기"] = {
									["count"] = 150390,
								},
							},
							["amount"] = 1323879,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["연약함"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["슬픔"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["비전 찢기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["어둠그늘"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 86125,
								},
							},
							["amount"] = 86125,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 140582,
								},
							},
							["amount"] = 140582,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["오염된 함정"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["미래 흡수"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["지옥칼날 베기"] = {
									["count"] = 0,
								},
								["지옥 열기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["유령 휘둘러치기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["오염된 함정"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["미래 흡수"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
						["비전 찢기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥칼날 베기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥 열기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 0,
					},
					["TimeHealing"] = {
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0.85,
								},
								["생기흡수"] = {
									["count"] = 2.74,
								},
							},
							["amount"] = 3.59,
						},
					},
					["OverHeals"] = {
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 515538,
								},
								["생기흡수"] = {
									["count"] = 847741,
								},
							},
							["amount"] = 1363279,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["어둠그늘"] = {
							["Details"] = {
								["파멸"] = {
									["count"] = 0.44,
								},
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
								["혼돈의 일격"] = {
									["count"] = 2.21,
								},
								["안광"] = {
									["count"] = 1.02,
								},
								["일반 공격"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 5.56,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["바퀴벌레"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 1.3,
								},
							},
							["amount"] = 1.3,
						},
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 0.85,
								},
								["생기흡수"] = {
									["count"] = 2.74,
								},
							},
							["amount"] = 3.59,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 515538,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 515538,
								},
							},
							["count"] = 1,
							["amount"] = 515538,
						},
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 547371,
									["min"] = 300370,
									["count"] = 2,
									["amount"] = 847741,
								},
							},
							["count"] = 2,
							["amount"] = 847741,
						},
					},
					["WhoHealed"] = {
						["무시중한디"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 0,
								},
								["영혼 삼키기"] = {
									["count"] = 515538,
								},
								["생기흡수"] = {
									["count"] = 847741,
								},
							},
							["amount"] = 1363279,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 11.95,
					["Healing"] = 1363279,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["연약함"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["지옥 돌진"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 297204,
									["min"] = 297204,
									["count"] = 1,
									["amount"] = 297204,
								},
							},
							["count"] = 1,
							["amount"] = 297204,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 933992,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1718358,
								},
								["Hit"] = {
									["max"] = 351868,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 612705,
								},
							},
							["count"] = 4,
							["amount"] = 2331063,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 회전베기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 60257,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 300779,
								},
							},
							["count"] = 8,
							["amount"] = 300779,
						},
						["슬픔"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 707460,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 707460,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 707460,
						},
						["악마의 이빨"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 232185,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 232185,
								},
							},
							["count"] = 1,
							["amount"] = 232185,
						},
						["파멸"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1267200,
									["min"] = 1267200,
									["count"] = 1,
									["amount"] = 1267200,
								},
							},
							["count"] = 1,
							["amount"] = 1267200,
						},
						["안광"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 201738,
									["min"] = 183936,
									["count"] = 21,
									["amount"] = 4051446,
								},
							},
							["count"] = 21,
							["amount"] = 4051446,
						},
						["일반 공격"] = {
							["Details"] = {
								["Hit (방어)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 21140,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 21140,
								},
								["Crit"] = {
									["max"] = 85696,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 85696,
								},
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 106836,
						},
					},
					["HealingTaken"] = 1363279,
					["RageGain"] = 0,
					["TimeDamage"] = 8.36,
					["TimeDamaging"] = {
						["바퀴벌레"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["어둠그늘"] = {
							["Details"] = {
								["파멸"] = {
									["count"] = 0.44,
								},
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
								["혼돈의 일격"] = {
									["count"] = 2.21,
								},
								["안광"] = {
									["count"] = 1.02,
								},
								["일반 공격"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 5.56,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 1.3,
								},
							},
							["amount"] = 1.3,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["기만자의 격노"] = {
									["count"] = 6,
								},
								["악마의 식탐"] = {
									["count"] = 18,
								},
							},
							["amount"] = 24,
						},
					},
					["FuryGain"] = 24,
					["DOTs"] = {
					},
					["FuryGained"] = {
						["악마의 이빨"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["기만자의 격노"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 362059,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Shadow"] = 78789,
						["Physical"] = 0,
						["Melee"] = 283270,
						["Arcane"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["PartialAbsorb"] = {
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["비전 찢기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["연약함"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 218187,
								},
							},
							["amount"] = 218187,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["유령 장교"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 65083,
								},
								["더럽혀진 자의 저주 (지속 피해)"] = {
									["count"] = 78789,
								},
							},
							["amount"] = 143872,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["비전 찢기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 9,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["Falling"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["비전 찢기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["혼돈의 회전베기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["악마의 이빨"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["연약함"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["기만자의 격노"] = {
									["count"] = 6,
								},
								["악마의 식탐"] = {
									["count"] = 18,
								},
							},
							["amount"] = 24,
						},
					},
					["FuryGain"] = 24,
					["DOTs"] = {
					},
					["FuryGained"] = {
						["악마의 이빨"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["기만자의 격노"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 362059,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Shadow"] = 78789,
						["Physical"] = 0,
						["Melee"] = 283270,
						["Arcane"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["PartialAbsorb"] = {
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["비전 찢기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 0,
								},
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
								["연약함"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 218187,
								},
							},
							["amount"] = 218187,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["유령 장교"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 65083,
								},
								["더럽혀진 자의 저주 (지속 피해)"] = {
									["count"] = 78789,
								},
							},
							["amount"] = 143872,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["비전 찢기"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 9,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["Falling"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["비전 찢기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["혼돈의 회전베기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["악마의 이빨"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["연약함"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0,
								},
								["혼돈의 일격"] = {
									["count"] = 0,
								},
								["악마의 이빨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 35383,
						["Physical"] = 71420,
					},
					["FuryGain"] = 1362,
					["OverHeals"] = {
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 410370,
									["min"] = 26505,
									["count"] = 14,
									["amount"] = 2125947,
								},
							},
							["count"] = 14,
							["amount"] = 2125947,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1412113,
									["min"] = 31739,
									["count"] = 15,
									["amount"] = 12492798,
								},
							},
							["count"] = 15,
							["amount"] = 12492798,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1898199,
									["min"] = 581021,
									["count"] = 7,
									["amount"] = 8473554,
								},
							},
							["count"] = 7,
							["amount"] = 8473554,
						},
					},
					["TimeSpent"] = {
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 8.52,
								},
								["혼돈의 일격"] = {
									["count"] = 0.83,
								},
								["내면의 악마"] = {
									["count"] = 1.32,
								},
								["악마의 이빨"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 10.97,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 1.5,
								},
								["일반 공격"] = {
									["count"] = 4.01,
								},
								["혼돈의 일격"] = {
									["count"] = 0.39,
								},
								["내면의 악마"] = {
									["count"] = 0.09,
								},
								["안광"] = {
									["count"] = 3.27,
								},
							},
							["amount"] = 9.26,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0.63,
								},
								["혼돈의 일격"] = {
									["count"] = 2.82,
								},
								["악마의 이빨"] = {
									["count"] = 0.36,
								},
							},
							["amount"] = 3.81,
						},
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 11.43,
								},
								["영혼 삼키기"] = {
									["count"] = 11.63,
								},
								["어둠의 결합"] = {
									["count"] = 10.5,
								},
							},
							["amount"] = 33.56,
						},
						["바퀴벌레"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["되살아난 병사"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["아스트릭스"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 0.97,
								},
							},
							["amount"] = 0.97,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 3.48,
								},
								["혼돈의 일격"] = {
									["count"] = 0.73,
								},
							},
							["amount"] = 4.21,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0.93,
								},
								["혼돈의 일격"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 2.73,
						},
						["카드래우스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 3.74,
								},
								["글레이브 투척"] = {
									["count"] = 1.5,
								},
								["안광"] = {
									["count"] = 0.83,
								},
								["혼돈의 일격"] = {
									["count"] = 3.28,
								},
							},
							["amount"] = 9.35,
						},
						["시요키"] = {
							["Details"] = {
								["슬픔"] = {
									["count"] = 1.5,
								},
								["내면의 악마"] = {
									["count"] = 0.38,
								},
								["탈태"] = {
									["count"] = 0.33,
								},
							},
							["amount"] = 2.21,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["어둠그늘"] = {
							["Details"] = {
								["파멸"] = {
									["count"] = 0.44,
								},
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
								["혼돈의 일격"] = {
									["count"] = 2.21,
								},
								["안광"] = {
									["count"] = 1.02,
								},
								["일반 공격"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 5.56,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 4.09,
								},
								["혼돈의 일격"] = {
									["count"] = 0.59,
								},
								["악마의 이빨"] = {
									["count"] = 4.13,
								},
							},
							["amount"] = 8.81,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0.58,
								},
								["혼돈의 일격"] = {
									["count"] = 1.82,
								},
								["안광"] = {
									["count"] = 1.3,
								},
								["악마의 이빨"] = {
									["count"] = 0.35,
								},
							},
							["amount"] = 4.05,
						},
						["되살아난 표범"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 5.83,
								},
								["혼돈의 일격"] = {
									["count"] = 1.2,
								},
								["악마의 이빨"] = {
									["count"] = 1.47,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 8.6,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 2.57,
								},
								["혼돈의 일격"] = {
									["count"] = 0.34,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 3.01,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 0.54,
								},
								["혼돈의 일격"] = {
									["count"] = 0.38,
								},
								["파멸"] = {
									["count"] = 3.67,
								},
								["고뇌"] = {
									["count"] = 0.41,
								},
								["슬픔"] = {
									["count"] = 0.56,
								},
								["악마의 이빨"] = {
									["count"] = 1.38,
								},
								["안광"] = {
									["count"] = 2.49,
								},
								["내면의 악마"] = {
									["count"] = 0.36,
								},
								["일반 공격"] = {
									["count"] = 11.34,
								},
							},
							["amount"] = 21.13,
						},
					},
					["DamageTaken"] = 13023150,
					["PartialResist"] = {
						["유령 휘둘러치기 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
						["지옥 화염구"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 11,
						},
						["미래 흡수"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["유령 휘둘러치기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 6,
						},
						["뼈아픈 이빨"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["비전 찢기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["Falling"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 6,
						},
						["혹독한 베기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["정수 삼키기 (지속 피해)"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["십자 베기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["일반 공격"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 135,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 135,
						},
						["오염된 함정"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["지옥칼날 베기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["지옥 열기"] = {
							["Details"] = {
								["저항 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["PartialAbsorb"] = {
						["유령 휘둘러치기 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["지옥 화염구"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["미래 흡수"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["유령 휘둘러치기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["더럽혀진 자의 저주 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["뼈아픈 이빨"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["비전 찢기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["혹독한 베기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["정수 삼키기 (지속 피해)"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["십자 베기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["일반 공격"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 135,
									["amount"] = 0,
								},
							},
							["count"] = 135,
							["amount"] = 0,
						},
						["오염된 함정"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["지옥칼날 베기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["지옥 열기"] = {
							["Details"] = {
								["흡수 없음"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 132.73,
					["ElementDone"] = {
						["Frost"] = 3104135,
						["Physical"] = 6395734,
						["Melee"] = 2741208,
						["Shadow"] = 17161874,
					},
					["ElementTaken"] = {
						["Physical"] = 2753507,
						["Melee"] = 6411327,
						["Arcane"] = 347646,
						["Fire"] = 2911367,
						["Frost"] = 92707,
						["Shadow"] = 506596,
					},
					["Overhealing"] = 23092299,
					["Damage"] = 86287642,
					["WhoHealed"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 2715329,
								},
								["영혼 삼키기"] = {
									["count"] = 3600915,
								},
								["어둠의 결합"] = {
									["count"] = 2832460,
								},
							},
							["amount"] = 9148704,
						},
					},
					["FuryGainedFrom"] = {
						["무시중한디"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 398,
								},
								["혼돈의 일격"] = {
									["count"] = 200,
								},
								["악마의 식탐"] = {
									["count"] = 486,
								},
								["기만자의 격노"] = {
									["count"] = 278,
								},
							},
							["amount"] = 1362,
						},
					},
					["HealedWho"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 2715329,
								},
								["영혼 삼키기"] = {
									["count"] = 3600915,
								},
								["어둠의 결합"] = {
									["count"] = 2832460,
								},
							},
							["amount"] = 9148704,
						},
					},
					["Heals"] = {
						["생기흡수"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 622210,
									["min"] = 15387,
									["count"] = 9,
									["amount"] = 2715329,
								},
							},
							["count"] = 9,
							["amount"] = 2715329,
						},
						["영혼 삼키기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1257106,
									["min"] = 74621,
									["count"] = 9,
									["amount"] = 3600915,
								},
							},
							["count"] = 9,
							["amount"] = 3600915,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 890326,
									["min"] = 50919,
									["count"] = 7,
									["amount"] = 2832460,
								},
							},
							["count"] = 7,
							["amount"] = 2832460,
						},
					},
					["TimeHealing"] = {
						["무시중한디"] = {
							["Details"] = {
								["생기흡수"] = {
									["count"] = 11.43,
								},
								["영혼 삼키기"] = {
									["count"] = 11.63,
								},
								["어둠의 결합"] = {
									["count"] = 10.5,
								},
							},
							["amount"] = 33.56,
						},
					},
					["Healing"] = 9148704,
					["TimeHeal"] = 33.56,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 16,
						},
						["Physical"] = {
							["Details"] = {
								["Block"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 18,
								},
							},
							["amount"] = 24,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 28,
								},
								["Block"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 25,
								},
								["Miss"] = {
									["count"] = 16,
								},
							},
							["amount"] = 72,
						},
						["Shadow"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 8,
								},
							},
							["amount"] = 19,
						},
					},
					["Attacks"] = {
						["연약함"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 328104,
									["min"] = 262078,
									["count"] = 6,
									["amount"] = 1699524,
								},
								["Hit"] = {
									["max"] = 158056,
									["min"] = 132822,
									["count"] = 10,
									["amount"] = 1404611,
								},
							},
							["count"] = 16,
							["amount"] = 3104135,
						},
						["지옥 돌진"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 594407,
									["min"] = 594407,
									["count"] = 1,
									["amount"] = 594407,
								},
								["Hit"] = {
									["max"] = 297204,
									["min"] = 297204,
									["count"] = 1,
									["amount"] = 297204,
								},
							},
							["count"] = 2,
							["amount"] = 891611,
						},
						["악마의 이빨"] = {
							["Details"] = {
								["Hit (방어)"] = {
									["max"] = 166648,
									["min"] = 166648,
									["count"] = 1,
									["amount"] = 166648,
								},
								["Crit"] = {
									["max"] = 576291,
									["min"] = 355174,
									["count"] = 5,
									["amount"] = 2297048,
								},
								["Hit"] = {
									["max"] = 295710,
									["min"] = 175244,
									["count"] = 15,
									["amount"] = 3394111,
								},
							},
							["count"] = 21,
							["amount"] = 5857807,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1206090,
									["min"] = 581471,
									["count"] = 14,
									["amount"] = 12868666,
								},
								["Hit"] = {
									["max"] = 438160,
									["min"] = 216155,
									["count"] = 24,
									["amount"] = 8186659,
								},
							},
							["count"] = 38,
							["amount"] = 21055325,
						},
						["고뇌"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 758566,
									["min"] = 758566,
									["count"] = 1,
									["amount"] = 758566,
								},
							},
							["count"] = 1,
							["amount"] = 758566,
						},
						["파멸"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1285379,
									["min"] = 1026882,
									["count"] = 3,
									["amount"] = 3579461,
								},
								["Hit"] = {
									["max"] = 565210,
									["min"] = 360004,
									["count"] = 10,
									["amount"] = 4386882,
								},
							},
							["count"] = 13,
							["amount"] = 7966343,
						},
						["어둠의 결합"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1898201,
									["min"] = 1518559,
									["count"] = 6,
									["amount"] = 10629917,
								},
								["Hit"] = {
									["max"] = 949100,
									["min"] = 759279,
									["count"] = 2,
									["amount"] = 1708379,
								},
							},
							["count"] = 8,
							["amount"] = 12338296,
						},
						["혼돈의 회전베기"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 82928,
									["min"] = 13945,
									["count"] = 93,
									["amount"] = 3162654,
								},
							},
							["count"] = 93,
							["amount"] = 3162654,
						},
						["안광"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 253090,
									["min"] = 183601,
									["count"] = 67,
									["amount"] = 14320367,
								},
							},
							["count"] = 67,
							["amount"] = 14320367,
						},
						["슬픔"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 707460,
									["min"] = 506477,
									["count"] = 4,
									["amount"] = 2628853,
								},
								["Hit"] = {
									["max"] = 442160,
									["min"] = 337651,
									["count"] = 6,
									["amount"] = 2194725,
								},
							},
							["count"] = 11,
							["amount"] = 4823578,
						},
						["일반 공격"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 16,
									["amount"] = 0,
								},
								["Hit (방어)"] = {
									["max"] = 31818,
									["min"] = 19988,
									["count"] = 2,
									["amount"] = 51806,
								},
								["Crit (방어)"] = {
									["max"] = 30755,
									["min"] = 30755,
									["count"] = 1,
									["amount"] = 30755,
								},
								["Crit"] = {
									["max"] = 111040,
									["min"] = 37638,
									["count"] = 24,
									["amount"] = 1730618,
								},
								["Hit"] = {
									["max"] = 56271,
									["min"] = 18361,
									["count"] = 26,
									["amount"] = 928029,
								},
							},
							["count"] = 69,
							["amount"] = 2741208,
						},
						["글레이브 투척"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 315487,
									["min"] = 222440,
									["count"] = 2,
									["amount"] = 537927,
								},
							},
							["count"] = 2,
							["amount"] = 537927,
						},
						["내면의 악마"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1642711,
									["min"] = 736421,
									["count"] = 5,
									["amount"] = 6950367,
								},
								["Hit"] = {
									["max"] = 642907,
									["min"] = 514325,
									["count"] = 2,
									["amount"] = 1157232,
								},
							},
							["count"] = 8,
							["amount"] = 8107599,
						},
						["탈태"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 395635,
									["min"] = 226591,
									["count"] = 2,
									["amount"] = 622226,
								},
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 622226,
						},
					},
					["HealingTaken"] = 9148704,
					["DamagedWho"] = {
						["되살아난 선봉대원"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 949100,
								},
								["연약함"] = {
									["count"] = 550906,
								},
								["혼돈의 회전베기"] = {
									["count"] = 77051,
								},
								["슬픔"] = {
									["count"] = 353728,
								},
								["일반 공격"] = {
									["count"] = 420433,
								},
								["혼돈의 일격"] = {
									["count"] = 1194333,
								},
								["내면의 악마"] = {
									["count"] = 1642711,
								},
								["악마의 이빨"] = {
									["count"] = 639798,
								},
							},
							["amount"] = 5828060,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 1518559,
								},
								["혼돈의 회전베기"] = {
									["count"] = 130667,
								},
								["지옥 돌진"] = {
									["count"] = 594407,
								},
								["안광"] = {
									["count"] = 3368050,
								},
								["일반 공격"] = {
									["count"] = 219144,
								},
								["혼돈의 일격"] = {
									["count"] = 2025358,
								},
								["내면의 악마"] = {
									["count"] = 1642711,
								},
								["악마의 이빨"] = {
									["count"] = 275492,
								},
							},
							["amount"] = 9774388,
						},
						["혹독한 지옥야수"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 2304768,
								},
							},
							["amount"] = 2304768,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 233569,
								},
								["슬픔"] = {
									["count"] = 707458,
								},
								["일반 공격"] = {
									["count"] = 138811,
								},
								["혼돈의 일격"] = {
									["count"] = 1066005,
								},
								["악마의 이빨"] = {
									["count"] = 576291,
								},
							},
							["amount"] = 2722134,
						},
						["빛벼림 기갑전투복"] = {
							["Details"] = {
								["탈태"] = {
									["count"] = 226591,
								},
								["혼돈의 회전베기"] = {
									["count"] = 367766,
								},
								["내면의 악마"] = {
									["count"] = 736421,
								},
								["슬픔"] = {
									["count"] = 844128,
								},
							},
							["amount"] = 2174906,
						},
						["바퀴벌레"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 297204,
								},
							},
							["amount"] = 297204,
						},
						["되살아난 병사"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 295710,
								},
								["어둠의 결합"] = {
									["count"] = 1898199,
								},
							},
							["amount"] = 2193909,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 433118,
								},
								["슬픔"] = {
									["count"] = 1414916,
								},
								["일반 공격"] = {
									["count"] = 302966,
								},
								["혼돈의 일격"] = {
									["count"] = 2594463,
								},
								["악마의 이빨"] = {
									["count"] = 824740,
								},
							},
							["amount"] = 5570203,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 486160,
								},
								["악마의 이빨"] = {
									["count"] = 288896,
								},
								["혼돈의 일격"] = {
									["count"] = 3312329,
								},
								["혼돈의 회전베기"] = {
									["count"] = 151470,
								},
								["일반 공격"] = {
									["count"] = 110925,
								},
							},
							["amount"] = 4349780,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 347919,
								},
								["슬픔"] = {
									["count"] = 353728,
								},
								["일반 공격"] = {
									["count"] = 91501,
								},
								["혼돈의 일격"] = {
									["count"] = 654758,
								},
								["연약함"] = {
									["count"] = 284913,
								},
							},
							["amount"] = 1732819,
						},
						["카드래우스"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 3796400,
								},
								["혼돈의 회전베기"] = {
									["count"] = 200578,
								},
								["안광"] = {
									["count"] = 189775,
								},
								["일반 공격"] = {
									["count"] = 116197,
								},
								["악마의 이빨"] = {
									["count"] = 166648,
								},
								["혼돈의 일격"] = {
									["count"] = 3109032,
								},
								["내면의 악마"] = {
									["count"] = 642907,
								},
								["글레이브 투척"] = {
									["count"] = 315487,
								},
							},
							["amount"] = 8537024,
						},
						["새끼 황혼거미"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 19692,
								},
							},
							["amount"] = 19692,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 177796,
								},
								["어둠의 결합"] = {
									["count"] = 1518560,
								},
							},
							["amount"] = 1696356,
						},
						["어둠그늘"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 150389,
								},
								["파멸"] = {
									["count"] = 1267200,
								},
								["슬픔"] = {
									["count"] = 707460,
								},
								["일반 공격"] = {
									["count"] = 106836,
								},
								["혼돈의 일격"] = {
									["count"] = 2331063,
								},
								["안광"] = {
									["count"] = 2877957,
								},
								["악마의 이빨"] = {
									["count"] = 232185,
								},
							},
							["amount"] = 7673090,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["어둠의 결합"] = {
									["count"] = 759279,
								},
								["혼돈의 일격"] = {
									["count"] = 1077583,
								},
								["일반 공격"] = {
									["count"] = 53347,
								},
								["혼돈의 회전베기"] = {
									["count"] = 41815,
								},
							},
							["amount"] = 1932024,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["혼돈의 회전베기"] = {
									["count"] = 198652,
								},
								["악마의 이빨"] = {
									["count"] = 280181,
								},
								["일반 공격"] = {
									["count"] = 103679,
								},
								["혼돈의 일격"] = {
									["count"] = 748064,
								},
								["안광"] = {
									["count"] = 1173489,
								},
								["연약함"] = {
									["count"] = 142657,
								},
							},
							["amount"] = 2646722,
						},
						["되살아난 표범"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 895593,
								},
								["혼돈의 일격"] = {
									["count"] = 2202958,
								},
								["혼돈의 회전베기"] = {
									["count"] = 157460,
								},
								["일반 공격"] = {
									["count"] = 310772,
								},
							},
							["amount"] = 3566783,
						},
						["아스트릭스"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 785929,
								},
								["글레이브 투척"] = {
									["count"] = 222440,
								},
								["내면의 악마"] = {
									["count"] = 514325,
								},
								["혼돈의 회전베기"] = {
									["count"] = 200581,
								},
							},
							["amount"] = 1723275,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 1639499,
								},
								["혼돈의 일격"] = {
									["count"] = 739379,
								},
								["일반 공격"] = {
									["count"] = 766597,
								},
								["고뇌"] = {
									["count"] = 758566,
								},
								["어둠의 결합"] = {
									["count"] = 1898199,
								},
								["혼돈의 회전베기"] = {
									["count"] = 451927,
								},
								["파멸"] = {
									["count"] = 6699143,
								},
								["슬픔"] = {
									["count"] = 442160,
								},
								["악마의 이빨"] = {
									["count"] = 1204477,
								},
								["안광"] = {
									["count"] = 3620399,
								},
								["내면의 악마"] = {
									["count"] = 2928524,
								},
								["탈태"] = {
									["count"] = 395635,
								},
							},
							["amount"] = 21544505,
						},
					},
					["TimeDamage"] = 99.17,
					["WhoDamaged"] = {
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 542988,
								},
								["혹독한 베기"] = {
									["count"] = 92707,
								},
							},
							["amount"] = 635695,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 239180,
								},
							},
							["amount"] = 239180,
						},
						["혹독한 지옥야수"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 222994,
								},
								["뼈아픈 이빨"] = {
									["count"] = 81662,
								},
							},
							["amount"] = 304656,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 484131,
								},
								["지옥칼날 베기"] = {
									["count"] = 135240,
								},
								["지옥 열기"] = {
									["count"] = 74594,
								},
							},
							["amount"] = 693965,
						},
						["유령 장교"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 213564,
								},
								["더럽혀진 자의 저주 (지속 피해)"] = {
									["count"] = 155739,
								},
							},
							["amount"] = 369303,
						},
						["되살아난 병사"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 149029,
								},
							},
							["amount"] = 149029,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 327715,
								},
								["오염된 함정"] = {
									["count"] = 176404,
								},
							},
							["amount"] = 504119,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 135790,
								},
								["지옥 화염구"] = {
									["count"] = 2443467,
								},
							},
							["amount"] = 2579257,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 351249,
								},
								["미래 흡수"] = {
									["count"] = 77872,
								},
							},
							["amount"] = 429121,
						},
						["카드래우스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 112678,
								},
							},
							["amount"] = 112678,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 542616,
								},
							},
							["amount"] = 542616,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 1365401,
								},
								["비전 찢기"] = {
									["count"] = 196972,
								},
							},
							["amount"] = 1562373,
						},
						["어둠그늘"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 86125,
								},
							},
							["amount"] = 86125,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 2753507,
								},
							},
							["amount"] = 2753507,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 179923,
								},
							},
							["amount"] = 179923,
						},
						["되살아난 표범"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 374048,
								},
								["유령 휘둘러치기 (지속 피해)"] = {
									["count"] = 31516,
								},
								["유령 휘둘러치기"] = {
									["count"] = 19404,
								},
							},
							["amount"] = 424968,
						},
						["아스트릭스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 107601,
								},
								["십자 베기"] = {
									["count"] = 72802,
								},
							},
							["amount"] = 180403,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 976295,
								},
								["정수 삼키기 (지속 피해)"] = {
									["count"] = 299937,
								},
							},
							["amount"] = 1276232,
						},
					},
					["FuryGained"] = {
						["악마의 이빨"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 398,
								},
							},
							["amount"] = 398,
						},
						["혼돈의 일격"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 200,
								},
							},
							["amount"] = 200,
						},
						["악마의 식탐"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 486,
								},
							},
							["amount"] = 486,
						},
						["기만자의 격노"] = {
							["Details"] = {
								["무시중한디"] = {
									["count"] = 278,
								},
							},
							["amount"] = 278,
						},
					},
					["TimeDamaging"] = {
						["되살아난 선봉대원"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 8.52,
								},
								["혼돈의 일격"] = {
									["count"] = 0.83,
								},
								["내면의 악마"] = {
									["count"] = 1.32,
								},
								["악마의 이빨"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 10.97,
						},
						["발티스 아마란"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 1.5,
								},
								["일반 공격"] = {
									["count"] = 4.01,
								},
								["혼돈의 일격"] = {
									["count"] = 0.39,
								},
								["내면의 악마"] = {
									["count"] = 0.09,
								},
								["안광"] = {
									["count"] = 3.27,
								},
							},
							["amount"] = 9.26,
						},
						["지옥살이 습격자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0.63,
								},
								["혼돈의 일격"] = {
									["count"] = 2.82,
								},
								["악마의 이빨"] = {
									["count"] = 0.36,
								},
							},
							["amount"] = 3.81,
						},
						["바퀴벌레"] = {
							["Details"] = {
								["지옥 돌진"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["되살아난 병사"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["아스트릭스"] = {
							["Details"] = {
								["안광"] = {
									["count"] = 0.97,
								},
							},
							["amount"] = 0.97,
						},
						["달빛깃털 배회자"] = {
							["Details"] = {
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["나이트본 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0.93,
								},
								["혼돈의 일격"] = {
									["count"] = 1.8,
								},
							},
							["amount"] = 2.73,
						},
						["시요키"] = {
							["Details"] = {
								["슬픔"] = {
									["count"] = 1.5,
								},
								["내면의 악마"] = {
									["count"] = 0.38,
								},
								["탈태"] = {
									["count"] = 0.33,
								},
							},
							["amount"] = 2.21,
						},
						["지옥살이 학자"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 3.48,
								},
								["혼돈의 일격"] = {
									["count"] = 0.73,
								},
							},
							["amount"] = 4.21,
						},
						["카드래우스"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 3.74,
								},
								["글레이브 투척"] = {
									["count"] = 1.5,
								},
								["안광"] = {
									["count"] = 0.83,
								},
								["혼돈의 일격"] = {
									["count"] = 3.28,
								},
							},
							["amount"] = 9.35,
						},
						["수풀 사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 4.09,
								},
								["혼돈의 일격"] = {
									["count"] = 0.59,
								},
								["악마의 이빨"] = {
									["count"] = 4.13,
								},
							},
							["amount"] = 8.81,
						},
						["어둠그늘"] = {
							["Details"] = {
								["파멸"] = {
									["count"] = 0.44,
								},
								["악마의 이빨"] = {
									["count"] = 1.5,
								},
								["혼돈의 일격"] = {
									["count"] = 2.21,
								},
								["안광"] = {
									["count"] = 1.02,
								},
								["일반 공격"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 5.56,
						},
						["레이븐크레스트의 하인"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 0.58,
								},
								["혼돈의 일격"] = {
									["count"] = 1.82,
								},
								["안광"] = {
									["count"] = 1.3,
								},
								["악마의 이빨"] = {
									["count"] = 0.35,
								},
							},
							["amount"] = 4.05,
						},
						["되살아난 표범"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 5.83,
								},
								["혼돈의 일격"] = {
									["count"] = 1.2,
								},
								["악마의 이빨"] = {
									["count"] = 1.47,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 8.6,
						},
						["지옥살이 덫사냥꾼"] = {
							["Details"] = {
								["일반 공격"] = {
									["count"] = 2.57,
								},
								["혼돈의 일격"] = {
									["count"] = 0.34,
								},
								["혼돈의 회전베기"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 3.01,
						},
						["영혼이 뒤틀린 흉물"] = {
							["Details"] = {
								["연약함"] = {
									["count"] = 0.54,
								},
								["혼돈의 일격"] = {
									["count"] = 0.38,
								},
								["파멸"] = {
									["count"] = 3.67,
								},
								["고뇌"] = {
									["count"] = 0.41,
								},
								["슬픔"] = {
									["count"] = 0.56,
								},
								["악마의 이빨"] = {
									["count"] = 1.38,
								},
								["안광"] = {
									["count"] = 2.49,
								},
								["내면의 악마"] = {
									["count"] = 0.36,
								},
								["일반 공격"] = {
									["count"] = 11.34,
								},
							},
							["amount"] = 21.13,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 98,
								},
								["Dodge"] = {
									["count"] = 19,
								},
								["Miss"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 11,
								},
								["Parry"] = {
									["count"] = 3,
								},
							},
							["amount"] = 135,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 19,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 15,
								},
							},
							["amount"] = 17,
						},
					},
				},
			},
			["UnitLockout"] = 1230044.634,
			["LastActive"] = 1231815.244,
		},
	},
	["FightNum"] = 15,
	["CombatTimes"] = {
		{
			1230147.639, -- [1]
			1230161.639, -- [2]
			"00:42:59", -- [3]
			"00:43:13", -- [4]
			"달빛깃털 배회자", -- [5]
		}, -- [1]
		{
			1230163.649, -- [1]
			1230199.665, -- [2]
			"00:43:16", -- [3]
			"00:43:51", -- [4]
			"달빛깃털 배회자", -- [5]
		}, -- [2]
		{
			1230211.638, -- [1]
			1230223.646, -- [2]
			"00:44:04", -- [3]
			"00:44:15", -- [4]
			"수풀 사냥꾼", -- [5]
		}, -- [3]
		{
			1230291.651, -- [1]
			1230322.648, -- [2]
			"00:45:24", -- [3]
			"00:45:54", -- [4]
			"혹독한 지옥야수", -- [5]
		}, -- [4]
		{
			1230335.648, -- [1]
			1230359.637, -- [2]
			"00:46:08", -- [3]
			"00:46:31", -- [4]
			"지옥살이 학자", -- [5]
		}, -- [5]
		{
			1230408.638, -- [1]
			1230443.645, -- [2]
			"00:47:21", -- [3]
			"00:47:55", -- [4]
			"지옥살이 습격자", -- [5]
		}, -- [6]
		{
			1230477.648, -- [1]
			1230489.665, -- [2]
			"00:48:30", -- [3]
			"00:48:41", -- [4]
			"카드래우스", -- [5]
		}, -- [7]
		{
			1230812.848, -- [1]
			1230855.864, -- [2]
			"00:54:05", -- [3]
			"00:54:47", -- [4]
			"영혼이 뒤틀린 흉물", -- [5]
		}, -- [8]
		{
			1231596.247, -- [1]
			1231627.247, -- [2]
			"01:07:08", -- [3]
			"01:07:39", -- [4]
			"유령 장교", -- [5]
		}, -- [9]
		{
			1231642.23, -- [1]
			1231657.247, -- [2]
			"01:07:54", -- [3]
			"01:08:09", -- [4]
			"되살아난 선봉대원", -- [5]
		}, -- [10]
		{
			1231681.23, -- [1]
			1231714.28, -- [2]
			"01:08:34", -- [3]
			"01:09:06", -- [4]
			"유령 장교", -- [5]
		}, -- [11]
		{
			1231715.237, -- [1]
			1231724.232, -- [2]
			"01:09:07", -- [3]
			"01:09:16", -- [4]
			"바퀴벌레", -- [5]
		}, -- [12]
		{
			1231734.23, -- [1]
			1231743.23, -- [2]
			"01:09:27", -- [3]
			"01:09:35", -- [4]
			"되살아난 표범", -- [5]
		}, -- [13]
		{
			1231779.235, -- [1]
			1231784.235, -- [2]
			"01:10:11", -- [3]
			"01:10:16", -- [4]
			"되살아난 병사", -- [5]
		}, -- [14]
		{
			1231800.242, -- [1]
			1231828.246, -- [2]
			"01:10:32", -- [3]
			"01:11:00", -- [4]
			"유령 장교", -- [5]
		}, -- [15]
	},
	["FoughtWho"] = {
		"유령 장교 01:10:32-01:11:00", -- [1]
		"되살아난 병사 01:10:11-01:10:16", -- [2]
		"되살아난 표범 01:09:27-01:09:35", -- [3]
		"바퀴벌레 01:09:07-01:09:16", -- [4]
		"유령 장교 01:08:34-01:09:06", -- [5]
	},
}
