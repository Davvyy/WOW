
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 11,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002492,
							["monster"] = true,
							["damage_from"] = {
							},
							["targets"] = {
								["완소야드"] = 112,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 112.002492,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 112.002492,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-3058-530-125-18952-00003B90C7",
							["nome"] = "해골이빨 청소부",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									[13398] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 112,
										["targets"] = {
											["완소야드"] = 112,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 112,
										["n_min"] = 112,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 112,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = 13398,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1555799590,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002492,
							["start_time"] = 1555799590,
							["delay"] = 0,
							["last_event"] = 1555799590,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002046,
							["damage_from"] = {
								["해골이빨 청소부"] = true,
							},
							["targets"] = {
							},
							["on_hold"] = false,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002046,
							["spec"] = 103,
							["dps_started"] = false,
							["total"] = 0.002046,
							["classe"] = "DRUID",
							["serial"] = "Player-2116-0507E01E",
							["nome"] = "완소야드",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["end_time"] = 1555799590,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 112.002046,
							["start_time"] = 1555799590,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 11,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 11,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 11,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["buff_uptime"] = 0,
							["nome"] = "완소야드",
							["pets"] = {
							},
							["last_event"] = 1555799590,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[39911] = {
										["activedamt"] = 1,
										["id"] = 39911,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[289982] = {
										["activedamt"] = 1,
										["id"] = 289982,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[32071] = {
										["activedamt"] = 1,
										["id"] = 32071,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									[288740] = {
										["activedamt"] = 1,
										["id"] = 288740,
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-2116-0507E01E",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["combatId"] = 11,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["tempo_start"] = 1555799590,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["TotalElapsedCombatTime"] = 131013.675,
				["enemy"] = "해골이빨 청소부",
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					112, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["last_events_tables"] = {
				},
				["frags_need_refresh"] = false,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["완소야드"] = 0.002046,
						}, -- [1]
					},
				},
				["end_time"] = 131013.675,
				["instance_type"] = "none",
				["combat_id"] = 11,
				["combat_counter"] = 36,
				["player_last_events"] = {
				},
				["CombatEndedAt"] = 131013.675,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "07:33:10",
				["data_inicio"] = "07:33:10",
				["CombatSkillCache"] = {
				},
				["frags"] = {
				},
				["start_time"] = 131013.381,
				["TimeData"] = {
				},
				["contra"] = "해골이빨 청소부",
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007182,
							["damage_from"] = {
								["지옥불정령 전쟁인도자"] = true,
							},
							["targets"] = {
								["지옥불정령 전쟁인도자"] = 2573,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2573.007182,
							["custom"] = 0,
							["tipo"] = 1,
							["dps_started"] = false,
							["total"] = 2573.007182,
							["classe"] = "DRUID",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 615,
										["g_amt"] = 0,
										["n_max"] = 63,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 1360,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 745,
										["n_min"] = 61,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 1360,
										["c_max"] = 127,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 120,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 12,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[106830] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 79,
										["g_amt"] = 0,
										["n_max"] = 23,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 148,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 69,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 148,
										["c_max"] = 49,
										["id"] = 106830,
										["r_dmg"] = 0,
										["c_min"] = 30,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 340,
										["g_amt"] = 0,
										["n_max"] = 170,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 794,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 454,
										["n_min"] = 142,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 794,
										["c_max"] = 340,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 340,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[1079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 55,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 165,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 165,
										["n_min"] = 55,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 165,
										["c_max"] = 0,
										["id"] = 1079,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106785] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 106,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 106,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 106,
										["n_min"] = 106,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 106,
										["c_max"] = 0,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["end_time"] = 1555799040,
							["damage_taken"] = 2545.007182,
							["last_dps"] = 107.257792404911,
							["colocacao"] = 1,
							["last_event"] = 1555799039,
							["friendlyfire"] = {
							},
							["start_time"] = 1555799023,
							["serial"] = "Player-2116-0507E01E",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003282,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 2545,
							},
							["pets"] = {
							},
							["last_event"] = 1555799038,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2545.003282,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 2545.003282,
							["classe"] = "UNKNOW",
							["damage_taken"] = 2573.003282,
							["nome"] = "지옥불정령 전쟁인도자",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 324,
										["g_amt"] = 0,
										["n_max"] = 181,
										["targets"] = {
											["완소야드"] = 1875,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1551,
										["n_min"] = 131,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 1875,
										["c_max"] = 324,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 324,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[12744] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 87,
										["targets"] = {
											["완소야드"] = 670,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 670,
										["n_min"] = 79,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 670,
										["c_max"] = 0,
										["id"] = 12744,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1555799040,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1555799016,
							["serial"] = "Creature-0-3058-530-125-19261-00003B9B6E",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.00559,
							["total_without_pet"] = 243.00559,
							["total"] = 243.00559,
							["spec"] = 103,
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.00559,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 243,
							},
							["totalover_without_pet"] = 0.00559,
							["healing_taken"] = 243.00559,
							["fight_component"] = true,
							["end_time"] = 1555799040,
							["targets_overheal"] = {
							},
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[8936] = {
										["c_amt"] = 1,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 33,
										["targets"] = {
											["완소야드"] = 152,
										},
										["n_min"] = 22,
										["counter"] = 4,
										["overheal"] = 0,
										["total"] = 152,
										["c_max"] = 65,
										["id"] = 8936,
										["targets_absorbs"] = {
										},
										["c_curado"] = 65,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 65,
										["totaldenied"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 87,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 91,
										},
										["n_min"] = 91,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 91,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 91,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1555799039,
							["heal_enemy_amt"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.00559,
							["start_time"] = 1555799034,
							["delay"] = 1555799022,
							["targets_absorbs"] = {
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["received"] = 124.004483,
							["resource"] = 0.004483,
							["targets"] = {
								["완소야드"] = 124,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 124.004483,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555799500,
							["alternatepower"] = 0.004483,
							["spells"] = {
								["_ActorTable"] = {
									[5221] = {
										["id"] = 5221,
										["total"] = 3,
										["targets"] = {
											["완소야드"] = 3,
										},
										["counter"] = 4,
									},
									[16953] = {
										["id"] = 16953,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 2,
									},
									[17057] = {
										["id"] = 17057,
										["total"] = 120,
										["targets"] = {
											["완소야드"] = 120,
										},
										["counter"] = 6,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[106830] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = 106830,
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[1079] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 1079,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 76,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 24,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 24,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[8936] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 8936,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 19,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[106830] = 3,
								[106785] = 1,
								[5221] = 4,
								[768] = 2,
								[16953] = 2,
								[1079] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1555799040,
							["nome"] = "완소야드",
							["pets"] = {
							},
							["serial"] = "Player-2116-0507E01E",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 131012.474,
				["tempo_start"] = 1555799016,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 34,
				["playing_solo"] = true,
				["totals"] = {
					5117.961713, -- [1]
					243, -- [2]
					{
						0, -- [1]
						[0] = 123.998159,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2573, -- [1]
					243, -- [2]
					{
						0, -- [1]
						[0] = 124,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:24:01",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥불정령 전쟁인도자",
				["TotalElapsedCombatTime"] = 130464.434,
				["CombatEndedAt"] = 130464.434,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2573.007182,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 243.00559,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130464.434,
				["combat_id"] = 10,
				["player_last_events"] = {
				},
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "07:23:37",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["contra"] = "지옥불정령 전쟁인도자",
				["start_time"] = 130440.445,
				["TimeData"] = {
				},
				["frags"] = {
					["지옥불정령 전쟁인도자"] = 1,
				},
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003161,
							["damage_from"] = {
								["갈퀴발 지옥 마귀"] = true,
								["임프 화염술사"] = true,
							},
							["targets"] = {
								["임프 화염술사"] = 832,
								["갈퀴발 지옥 마귀"] = 2040,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2872.003161,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 2872.003161,
							["damage_taken"] = 912.003161,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 674,
										["g_amt"] = 0,
										["n_max"] = 80,
										["targets"] = {
											["임프 화염술사"] = 378,
											["갈퀴발 지옥 마귀"] = 801,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 505,
										["n_min"] = 61,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 1179,
										["c_max"] = 146,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 121,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[106785] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 508,
										["g_amt"] = 0,
										["n_max"] = 131,
										["targets"] = {
											["임프 화염술사"] = 392,
											["갈퀴발 지옥 마귀"] = 370,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 254,
										["n_min"] = 123,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 762,
										["c_max"] = 261,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 247,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106830] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 35,
										["g_amt"] = 0,
										["n_max"] = 28,
										["targets"] = {
											["임프 화염술사"] = 62,
											["갈퀴발 지옥 마귀"] = 232,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 259,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 294,
										["c_max"] = 35,
										["id"] = 106830,
										["r_dmg"] = 0,
										["c_min"] = 35,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 12,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[22568] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 293,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 293,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 293,
										["n_min"] = 293,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 293,
										["c_max"] = 0,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 172,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 344,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 344,
										["n_min"] = 172,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 344,
										["c_max"] = 0,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 227.828269157548,
							["end_time"] = 1555798994,
							["colocacao"] = 1,
							["last_event"] = 1555798994,
							["on_hold"] = false,
							["start_time"] = 1555798981,
							["serial"] = "Player-2116-0507E01E",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007762,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 233,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 233.007762,
							["delay"] = 1555798984,
							["monster"] = true,
							["end_time"] = 1555798994,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 832.007762,
							["nome"] = "임프 화염술사",
							["spells"] = {
								["_ActorTable"] = {
									[9053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 233,
										["targets"] = {
											["완소야드"] = 233,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 233,
										["n_min"] = 233,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 233,
										["c_max"] = 0,
										["id"] = 9053,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 233.007762,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798984,
							["on_hold"] = false,
							["start_time"] = 1555798993,
							["serial"] = "Creature-0-3058-530-125-19136-00003B3D50",
							["fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004303,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 679,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 679.004303,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798994,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 2040.004303,
							["nome"] = "갈퀴발 지옥 마귀",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 102,
										["g_amt"] = 0,
										["n_max"] = 68,
										["targets"] = {
											["완소야드"] = 514,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 412,
										["n_min"] = 49,
										["g_dmg"] = 0,
										["counter"] = 10,
										["c_min"] = 102,
										["total"] = 514,
										["c_max"] = 102,
										["r_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 7,
										["DODGE"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[11968] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 28,
										["targets"] = {
											["완소야드"] = 165,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 165,
										["n_min"] = 27,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 165,
										["c_max"] = 0,
										["id"] = 11968,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 679.004303,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798993,
							["on_hold"] = false,
							["start_time"] = 1555798982,
							["serial"] = "Creature-0-3058-530-125-18978-0000BB3D50",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.001827,
							["total_without_pet"] = 273.001827,
							["total"] = 273.001827,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.001827,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 273,
							},
							["totalover_without_pet"] = 0.001827,
							["healing_taken"] = 273.001827,
							["fight_component"] = true,
							["end_time"] = 1555798994,
							["heal_enemy_amt"] = 0,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 273,
										},
										["n_min"] = 91,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 273,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 273,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1555798994,
							["totaldenied"] = 0.001827,
							["start_time"] = 1555798985,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["received"] = 4.003146,
							["resource"] = 0.003146,
							["targets"] = {
								["완소야드"] = 4,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 4.003146,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798994,
							["alternatepower"] = 0.003146,
							["spells"] = {
								["_ActorTable"] = {
									[16953] = {
										["id"] = 16953,
										["total"] = 2,
										["targets"] = {
											["완소야드"] = 2,
										},
										["counter"] = 2,
									},
									[5221] = {
										["id"] = 5221,
										["total"] = 2,
										["targets"] = {
											["완소야드"] = 2,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[106830] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 3,
										["id"] = 106830,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									[1079] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 1079,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[50259] = {
										["activedamt"] = -1,
										["id"] = 50259,
										["targets"] = {
										},
										["actived_at"] = 1555798983,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									[61391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 61391,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 52,
							["cc_done_spells"] = {
								["_ActorTable"] = {
									[61391] = {
										["id"] = 61391,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 2,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[5217] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 5217,
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[106951] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 106951,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 20,
							["cc_done"] = 2.006185,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[106830] = 2,
								[106785] = 2,
								[5221] = 2,
								[1079] = 1,
								[106951] = 1,
								[61391] = 1,
								[16953] = 2,
								[22568] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1555798994,
							["pets"] = {
							},
							["nome"] = "완소야드",
							["serial"] = "Player-2116-0507E01E",
							["cc_done_targets"] = {
								["갈퀴발 지옥 마귀"] = 2,
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "임프 화염술사",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[9053] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-3058-530-125-19136-00003B3D50",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 9,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130437.735,
				["tempo_start"] = 1555798981,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					3784, -- [1]
					273, -- [2]
					{
						0, -- [1]
						[0] = 4,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2872, -- [1]
					273, -- [2]
					{
						0, -- [1]
						[0] = 4,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:23:15",
				["cleu_timeline"] = {
				},
				["enemy"] = "임프 화염술사",
				["TotalElapsedCombatTime"] = 130418.746,
				["CombatEndedAt"] = 130418.746,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2872.003161,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 273.001827,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130418.746,
				["combat_id"] = 9,
				["combat_counter"] = 33,
				["frags"] = {
					["임프 화염술사"] = 1,
					["갈퀴발 지옥 마귀"] = 2,
				},
				["player_last_events"] = {
				},
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "07:23:02",
				["start_time"] = 130405.579,
				["contra"] = "임프 화염술사",
				["spells_cast_timeline"] = {
				},
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005826,
							["damage_from"] = {
								["갈퀴발 지옥 마귀"] = true,
								["임프 화염술사"] = true,
							},
							["targets"] = {
								["임프 화염술사"] = 811,
								["갈퀴발 지옥 마귀"] = 2144,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2955.005826,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 2955.005826,
							["damage_taken"] = 1560.005826,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 640,
										["g_amt"] = 0,
										["n_max"] = 70,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 747,
											["임프 화염술사"] = 539,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 646,
										["n_min"] = 59,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 1286,
										["c_max"] = 136,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 123,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1079] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 55,
										["targets"] = {
											["임프 화염술사"] = 110,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 110,
										["n_min"] = 55,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 110,
										["c_max"] = 0,
										["id"] = 1079,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106785] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 108,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 215,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 215,
										["n_min"] = 107,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 215,
										["c_max"] = 0,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 171,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 171,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 171,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 171,
										["c_max"] = 0,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[22568] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 456,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 693,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 693,
										["n_min"] = 237,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 693,
										["c_max"] = 0,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106830] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 172,
										["g_amt"] = 0,
										["n_max"] = 25,
										["targets"] = {
											["임프 화염술사"] = 162,
											["갈퀴발 지옥 마귀"] = 318,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 308,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 21,
										["total"] = 480,
										["c_max"] = 48,
										["id"] = 106830,
										["r_dmg"] = 0,
										["c_min"] = 31,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 16,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 163.512938579016,
							["end_time"] = 1555798970,
							["colocacao"] = 1,
							["last_event"] = 1555798969,
							["on_hold"] = false,
							["start_time"] = 1555798951,
							["serial"] = "Player-2116-0507E01E",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006772,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 685,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 685.006772,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798981,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 811.006772,
							["nome"] = "임프 화염술사",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 65,
										["targets"] = {
											["완소야드"] = 91,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 91,
										["n_min"] = 26,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 91,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[9053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 247,
										["targets"] = {
											["완소야드"] = 594,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 594,
										["n_min"] = 120,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 594,
										["c_max"] = 0,
										["id"] = 9053,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 685.006772,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798981,
							["on_hold"] = false,
							["start_time"] = 1555798954,
							["serial"] = "Creature-0-3058-530-125-19136-00003B5CD2",
							["fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002724,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 875,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 875.002724,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798970,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 2144.002724,
							["nome"] = "갈퀴발 지옥 마귀",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 73,
										["targets"] = {
											["완소야드"] = 682,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 682,
										["n_min"] = 30,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 682,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[11968] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 28,
										["targets"] = {
											["완소야드"] = 193,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 193,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 193,
										["c_max"] = 0,
										["id"] = 11968,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 875.002724,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798969,
							["on_hold"] = false,
							["start_time"] = 1555798952,
							["serial"] = "Creature-0-3058-530-125-18978-00003B5CD2",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.00894,
							["total_without_pet"] = 273.00894,
							["total"] = 273.00894,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.00894,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 273,
							},
							["totalover_without_pet"] = 0.00894,
							["healing_taken"] = 273.00894,
							["fight_component"] = true,
							["end_time"] = 1555798970,
							["heal_enemy_amt"] = 0,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 273,
										},
										["n_min"] = 91,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 273,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 273,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1555798969,
							["totaldenied"] = 0.00894,
							["start_time"] = 1555798959,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["received"] = 2.008857,
							["resource"] = 0.008857,
							["targets"] = {
								["완소야드"] = 2,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 2.008857,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798968,
							["alternatepower"] = 0.008857,
							["spells"] = {
								["_ActorTable"] = {
									[16953] = {
										["id"] = 16953,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
									[5221] = {
										["id"] = 5221,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[106830] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 5,
										["id"] = 106830,
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									[50259] = {
										["activedamt"] = -1,
										["id"] = 50259,
										["targets"] = {
										},
										["actived_at"] = 1555798953,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									[1079] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 1079,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["cooldowns_defensive"] = 2.007935,
							["buff_uptime"] = 74,
							["last_cooldown"] = {
								1555798962.223, -- [1]
								61336, -- [2]
							},
							["classe"] = "DRUID",
							["cooldowns_defensive_targets"] = {
								["완소야드"] = 1,
								["[*] 공격대 단위 생존기"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61336] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61336,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[77764] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 77764,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 22,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[106830] = 4,
								[106785] = 1,
								[5221] = 1,
								[77764] = 1,
								[22568] = 2,
								[61336] = 1,
								[16953] = 1,
								[1079] = 1,
							},
							["tipo"] = 4,
							["serial"] = "Player-2116-0507E01E",
							["last_event"] = 1555798970,
							["pets"] = {
							},
							["nome"] = "완소야드",
							["cooldowns_defensive_spells"] = {
								["_ActorTable"] = {
									[61336] = {
										["id"] = 61336,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
									[77764] = {
										["id"] = 77764,
										["targets"] = {
											["[*] 공격대 단위 생존기"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "임프 화염술사",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[9053] = 3,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-3058-530-125-19136-00003B5CD2",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 8,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130405.325,
				["tempo_start"] = 1555798951,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					4515, -- [1]
					273, -- [2]
					{
						0, -- [1]
						[0] = 2,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 2,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2955, -- [1]
					273, -- [2]
					{
						0, -- [1]
						[0] = 2,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 2,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:22:51",
				["cleu_timeline"] = {
				},
				["enemy"] = "임프 화염술사",
				["TotalElapsedCombatTime"] = 130394.469,
				["CombatEndedAt"] = 130394.469,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2955.005826,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 273.00894,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130394.469,
				["combat_id"] = 8,
				["combat_counter"] = 32,
				["frags"] = {
					["갈퀴발 지옥 마귀"] = 2,
					["임프 화염술사"] = 1,
				},
				["player_last_events"] = {
					["완소야드"] = {
						{
							true, -- [1]
							1, -- [2]
							65, -- [3]
							1555798981.736, -- [4]
							2567, -- [5]
							"임프 화염술사", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "07:22:32",
				["start_time"] = 130375.369,
				["contra"] = "임프 화염술사",
				["spells_cast_timeline"] = {
				},
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002909,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 1355,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["end_time"] = 1555798934,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1355.002909,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 1355.002909,
							["dps_started"] = false,
							["damage_taken"] = 2514.002909,
							["nome"] = "지옥불정령 전쟁인도자",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 174,
										["targets"] = {
											["완소야드"] = 1033,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1033,
										["n_min"] = 128,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 1033,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[12744] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 87,
										["targets"] = {
											["완소야드"] = 322,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 322,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 322,
										["c_max"] = 0,
										["id"] = 12744,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798933,
							["on_hold"] = false,
							["start_time"] = 1555798921,
							["serial"] = "Creature-0-3058-530-125-19261-00003B3B71",
							["fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002719,
							["damage_from"] = {
								["지옥불정령 전쟁인도자"] = true,
							},
							["targets"] = {
								["지옥불정령 전쟁인도자"] = 2514,
								["살무사"] = 25,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2539.002719,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1555798934,
							["damage_taken"] = 1355.002719,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 379,
										["g_amt"] = 0,
										["n_max"] = 64,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 999,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 620,
										["n_min"] = 59,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 999,
										["c_max"] = 129,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 125,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[22568] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 284,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 368,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 368,
										["n_min"] = 84,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 368,
										["c_max"] = 0,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106785] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 212,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 212,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 212,
										["c_max"] = 212,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 212,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[1822] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 80,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 80,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 80,
										["n_min"] = 80,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 80,
										["c_max"] = 0,
										["id"] = 1822,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[155722] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 69,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 275,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 275,
										["n_min"] = 68,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 275,
										["c_max"] = 0,
										["id"] = 155722,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 340,
										["g_amt"] = 0,
										["n_max"] = 170,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 510,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 170,
										["n_min"] = 170,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 510,
										["c_max"] = 340,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 340,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106830] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 31,
										["g_amt"] = 0,
										["n_max"] = 25,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 70,
											["살무사"] = 25,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 64,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 95,
										["c_max"] = 31,
										["id"] = 106830,
										["r_dmg"] = 0,
										["c_min"] = 31,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 198.483639696666,
							["friendlyfire_total"] = 0,
							["colocacao"] = 1,
							["last_event"] = 1555798933,
							["friendlyfire"] = {
							},
							["start_time"] = 1555798922,
							["serial"] = "Player-2116-0507E01E",
							["total"] = 2539.002719,
						}, -- [2]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.008765,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["total"] = 0.008765,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008765,
							["last_event"] = 0,
							["fight_component"] = true,
							["end_time"] = 1555798934,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "살무사",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 25.008765,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1555798934,
							["serial"] = "Creature-0-3058-530-125-3300-0011B79829",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.007827,
							["total_without_pet"] = 91.007827,
							["total"] = 91.007827,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.007827,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 91,
							},
							["totalover_without_pet"] = 0.007827,
							["healing_taken"] = 91.007827,
							["fight_component"] = true,
							["end_time"] = 1555798934,
							["heal_enemy_amt"] = 0,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 91,
										},
										["n_min"] = 91,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 91,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 91,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1555798933,
							["totaldenied"] = 0.007827,
							["start_time"] = 1555798933,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 5.008411,
							["resource"] = 0.008411,
							["targets"] = {
								["완소야드"] = 5,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 5.008411,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798932,
							["alternatepower"] = 0.008411,
							["spells"] = {
								["_ActorTable"] = {
									[5221] = {
										["id"] = 5221,
										["total"] = 2,
										["targets"] = {
											["완소야드"] = 2,
										},
										["counter"] = 2,
									},
									[1822] = {
										["id"] = 1822,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
									[16953] = {
										["id"] = 16953,
										["total"] = 2,
										["targets"] = {
											["완소야드"] = 2,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[155722] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 155722,
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[58180] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 58180,
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[106830] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 106830,
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 40,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 30,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[22568] = 2,
								[106785] = 1,
								[1822] = 1,
								[106830] = 1,
								[16953] = 2,
								[5221] = 2,
							},
							["tipo"] = 4,
							["last_event"] = 1555798934,
							["nome"] = "완소야드",
							["pets"] = {
							},
							["serial"] = "Player-2116-0507E01E",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 7,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130375.035,
				["tempo_start"] = 1555798921,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					3894, -- [1]
					91, -- [2]
					{
						0, -- [1]
						[0] = 5,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2539, -- [1]
					91, -- [2]
					{
						0, -- [1]
						[0] = 5,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:22:15",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥불정령 전쟁인도자",
				["TotalElapsedCombatTime"] = 130358.013,
				["CombatEndedAt"] = 130358.013,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2539.002719,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 91.007827,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130358.013,
				["combat_id"] = 7,
				["combat_counter"] = 31,
				["frags"] = {
					["살무사"] = 1,
					["지옥불정령 전쟁인도자"] = 1,
				},
				["player_last_events"] = {
				},
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "07:22:02",
				["start_time"] = 130345.007,
				["contra"] = "지옥불정령 전쟁인도자",
				["spells_cast_timeline"] = {
				},
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008462,
							["damage_from"] = {
								["지옥불정령 전쟁인도자"] = true,
							},
							["targets"] = {
								["지옥불정령 전쟁인도자"] = 2530,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2530.008462,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 2530.008462,
							["damage_taken"] = 714.008462,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 148,
										["g_amt"] = 0,
										["n_max"] = 74,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 653,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 505,
										["n_min"] = 70,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 653,
										["c_max"] = 148,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 148,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[106785] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 204,
										["g_amt"] = 0,
										["n_max"] = 102,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 407,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 203,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 407,
										["c_max"] = 204,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 204,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 163,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 326,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 326,
										["n_min"] = 163,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 326,
										["c_max"] = 0,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[22568] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1144,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 1144,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1144,
										["c_max"] = 1144,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 1144,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 370.100711234085,
							["end_time"] = 1555798878,
							["colocacao"] = 1,
							["last_event"] = 1555798877,
							["on_hold"] = false,
							["start_time"] = 1555798871,
							["serial"] = "Player-2116-0507E01E",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008448,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 714,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 714.008448,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798878,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 2530.008448,
							["nome"] = "지옥불정령 전쟁인도자",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 168,
										["targets"] = {
											["완소야드"] = 486,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 486,
										["n_min"] = 156,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 486,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[12744] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 78,
										["targets"] = {
											["완소야드"] = 228,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 228,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 228,
										["c_max"] = 0,
										["id"] = 12744,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 714.008448,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798877,
							["on_hold"] = false,
							["start_time"] = 1555798871,
							["serial"] = "Creature-0-3058-530-125-19261-00003B3E97",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.003909,
							["total_without_pet"] = 235.003909,
							["total"] = 235.003909,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.003909,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 235,
							},
							["totalover_without_pet"] = 0.003909,
							["healing_taken"] = 235.003909,
							["fight_component"] = true,
							["end_time"] = 1555798878,
							["heal_enemy_amt"] = 0,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[8936] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 33,
										["targets"] = {
											["완소야드"] = 144,
										},
										["n_min"] = 15,
										["counter"] = 5,
										["overheal"] = 0,
										["total"] = 144,
										["c_max"] = 0,
										["id"] = 8936,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 144,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 91,
										},
										["n_min"] = 91,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 91,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 91,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1555798878,
							["totaldenied"] = 0.003909,
							["start_time"] = 1555798871,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["received"] = 2.008313,
							["resource"] = 0.008313,
							["targets"] = {
								["완소야드"] = 2,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 2.008313,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798874,
							["alternatepower"] = 0.008313,
							["spells"] = {
								["_ActorTable"] = {
									[16953] = {
										["id"] = 16953,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
									[5221] = {
										["id"] = 5221,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[50259] = {
										["activedamt"] = -1,
										["id"] = 50259,
										["targets"] = {
										},
										["actived_at"] = 1555798873,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 36,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[8936] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 8936,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[5217] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 5217,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 0,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[106785] = 3,
								[16953] = 1,
								[5221] = 1,
								[22568] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1555798878,
							["nome"] = "완소야드",
							["pets"] = {
							},
							["serial"] = "Player-2116-0507E01E",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 6,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130341.069,
				["tempo_start"] = 1555798871,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					3244, -- [1]
					235, -- [2]
					{
						0, -- [1]
						[0] = 2,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2530, -- [1]
					235, -- [2]
					{
						0, -- [1]
						[0] = 2,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:21:19",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥불정령 전쟁인도자",
				["TotalElapsedCombatTime"] = 7.25100000000384,
				["CombatEndedAt"] = 130302.22,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2530.008462,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 235.003909,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130302.22,
				["combat_id"] = 6,
				["combat_counter"] = 30,
				["frags"] = {
					["지옥불정령 전쟁인도자"] = 1,
				},
				["player_last_events"] = {
				},
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "07:21:11",
				["start_time"] = 130294.863,
				["contra"] = "지옥불정령 전쟁인도자",
				["spells_cast_timeline"] = {
				},
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008832,
							["damage_from"] = {
								["임프 화염술사"] = true,
								["갈퀴발 지옥 마귀"] = true,
								["지옥불정령 전쟁인도자"] = true,
								["공포의 소환사"] = true,
							},
							["targets"] = {
								["임프 화염술사"] = 875,
								["갈퀴발 지옥 마귀"] = 1946,
								["지옥불정령 전쟁인도자"] = 2482,
								["공포의 소환사"] = 4888,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 10191.008832,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 10191.008832,
							["damage_taken"] = 6119.008832,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 9,
										["b_amt"] = 0,
										["c_dmg"] = 1238,
										["g_amt"] = 0,
										["n_max"] = 161,
										["targets"] = {
											["임프 화염술사"] = 643,
											["갈퀴발 지옥 마귀"] = 784,
											["지옥불정령 전쟁인도자"] = 867,
											["공포의 소환사"] = 1727,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2783,
										["n_min"] = 60,
										["g_dmg"] = 0,
										["counter"] = 49,
										["total"] = 4021,
										["c_max"] = 159,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 122,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 40,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[22568] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 731,
										["targets"] = {
											["공포의 소환사"] = 1326,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1326,
										["n_min"] = 204,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1326,
										["c_max"] = 0,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106785] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 429,
										["g_amt"] = 0,
										["n_max"] = 107,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 322,
											["지옥불정령 전쟁인도자"] = 213,
											["공포의 소환사"] = 321,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 427,
										["n_min"] = 106,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 856,
										["c_max"] = 215,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 214,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 328,
										["g_amt"] = 0,
										["n_max"] = 196,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 170,
											["공포의 소환사"] = 1171,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1013,
										["n_min"] = 142,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 1341,
										["c_max"] = 328,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 328,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106830] = {
										["c_amt"] = 14,
										["b_amt"] = 0,
										["c_dmg"] = 566,
										["g_amt"] = 0,
										["n_max"] = 28,
										["targets"] = {
											["임프 화염술사"] = 122,
											["갈퀴발 지옥 마귀"] = 454,
											["지옥불정령 전쟁인도자"] = 297,
											["공포의 소환사"] = 343,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 650,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 48,
										["total"] = 1216,
										["c_max"] = 56,
										["id"] = 106830,
										["r_dmg"] = 0,
										["c_min"] = 13,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 34,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[1079] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 586,
										["g_amt"] = 0,
										["n_max"] = 64,
										["targets"] = {
											["임프 화염술사"] = 110,
											["갈퀴발 지옥 마귀"] = 277,
											["지옥불정령 전쟁인도자"] = 935,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 736,
										["n_min"] = 55,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 1322,
										["c_max"] = 127,
										["id"] = 1079,
										["r_dmg"] = 0,
										["c_min"] = 110,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 12,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[164812] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 61,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 109,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 48,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 109,
										["c_max"] = 31,
										["id"] = 164812,
										["r_dmg"] = 0,
										["c_min"] = 30,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 64,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 147.946646226206,
							["end_time"] = 1555798857,
							["colocacao"] = 1,
							["last_event"] = 1555798857,
							["on_hold"] = false,
							["start_time"] = 1555798788,
							["serial"] = "Player-2116-0507E01E",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001997,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 1942,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1942.001997,
							["delay"] = 1555798816,
							["monster"] = true,
							["end_time"] = 1555798857,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 4888.001997,
							["nome"] = "공포의 소환사",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 173,
										["targets"] = {
											["완소야드"] = 1570,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1570,
										["n_min"] = 137,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 1570,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["spellschool"] = 1,
										["DODGE"] = 2,
									}, -- [1]
									[11443] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 11443,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									[32666] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 186,
										["targets"] = {
											["완소야드"] = 372,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 372,
										["n_min"] = 186,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 372,
										["c_max"] = 0,
										["id"] = 32666,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 1942.001997,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798816,
							["on_hold"] = false,
							["start_time"] = 1555798828,
							["serial"] = "Creature-0-3058-530-125-19434-00003B5CC5",
							["fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002581,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 1324,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1324.002581,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798857,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 1946.002581,
							["nome"] = "갈퀴발 지옥 마귀",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 119,
										["g_amt"] = 0,
										["n_max"] = 69,
										["targets"] = {
											["완소야드"] = 1002,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 883,
										["n_min"] = 24,
										["g_dmg"] = 0,
										["counter"] = 23,
										["c_min"] = 119,
										["total"] = 1002,
										["c_max"] = 119,
										["r_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 18,
										["DODGE"] = 2,
										["MISS"] = 2,
									}, -- [1]
									[11968] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 27,
										["targets"] = {
											["완소야드"] = 322,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 322,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 322,
										["c_max"] = 0,
										["id"] = 11968,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 13,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 1324.002581,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798848,
							["on_hold"] = false,
							["start_time"] = 1555798813,
							["serial"] = "Creature-0-3058-530-125-18978-0000BB5C84",
							["fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006941,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 992,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 992.006941,
							["delay"] = 1555798828,
							["monster"] = true,
							["end_time"] = 1555798857,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 875.006941,
							["nome"] = "임프 화염술사",
							["spells"] = {
								["_ActorTable"] = {
									[9053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 265,
										["targets"] = {
											["완소야드"] = 992,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 992,
										["n_min"] = 233,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 992,
										["c_max"] = 0,
										["id"] = 9053,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 992.006941,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798828,
							["on_hold"] = false,
							["start_time"] = 1555798845,
							["serial"] = "Creature-0-3058-530-125-19136-00003B5C84",
							["fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005754,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 1861,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1861.005754,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798857,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 2482.005754,
							["nome"] = "지옥불정령 전쟁인도자",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 183,
										["targets"] = {
											["완소야드"] = 1331,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1331,
										["n_min"] = 49,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 1331,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 11,
										["spellschool"] = 1,
										["DODGE"] = 3,
									}, -- [1]
									[12744] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 82,
										["targets"] = {
											["완소야드"] = 530,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 530,
										["n_min"] = 34,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 530,
										["c_max"] = 0,
										["id"] = 12744,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 1861.005754,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798856,
							["on_hold"] = false,
							["start_time"] = 1555798833,
							["serial"] = "Creature-0-3058-530-125-19261-00003B5C8B",
							["fight_component"] = true,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.005191,
							["total_without_pet"] = 4001.005191,
							["total"] = 4001.005191,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.005191,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 4001,
							},
							["totalover_without_pet"] = 0.005191,
							["healing_taken"] = 4001.005191,
							["fight_component"] = true,
							["end_time"] = 1555798857,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 453,
										},
										["n_min"] = 90,
										["counter"] = 5,
										["overheal"] = 0,
										["total"] = 453,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 453,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									[8936] = {
										["c_amt"] = 5,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 774,
										["targets"] = {
											["완소야드"] = 3548,
										},
										["n_min"] = 32,
										["counter"] = 13,
										["overheal"] = 0,
										["total"] = 3548,
										["c_max"] = 1548,
										["id"] = 8936,
										["targets_absorbs"] = {
										},
										["c_curado"] = 1805,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 64,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 1743,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1555798857,
							["classe"] = "DRUID",
							["custom"] = 0,
							["tipo"] = 2,
							["totaldenied"] = 0.005191,
							["start_time"] = 1555798817,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["received"] = 91.005282,
							["resource"] = 0.005282,
							["targets"] = {
								["완소야드"] = 91,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 91.005282,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798871,
							["alternatepower"] = 0.005282,
							["spells"] = {
								["_ActorTable"] = {
									[5217] = {
										["id"] = 5217,
										["total"] = 50,
										["targets"] = {
											["완소야드"] = 50,
										},
										["counter"] = 1,
									},
									[5221] = {
										["id"] = 5221,
										["total"] = 7,
										["targets"] = {
											["완소야드"] = 7,
										},
										["counter"] = 7,
									},
									[17057] = {
										["id"] = 17057,
										["total"] = 20,
										["targets"] = {
											["완소야드"] = 20,
										},
										["counter"] = 1,
									},
									[16953] = {
										["id"] = 16953,
										["total"] = 8,
										["targets"] = {
											["완소야드"] = 8,
										},
										["counter"] = 9,
									},
									[195707] = {
										["id"] = 195707,
										["total"] = 6,
										["targets"] = {
											["완소야드"] = 6,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[50259] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -1,
										["refreshamt"] = 0,
										["id"] = 50259,
										["uptime"] = 67,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[61391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 61391,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[164812] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = 164812,
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[1079] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = 1079,
										["uptime"] = 33,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									[106830] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 10,
										["id"] = 106830,
										["uptime"] = 62,
										["targets"] = {
										},
										["appliedamt"] = 6,
									},
								},
								["tipo"] = 9,
							},
							["cooldowns_defensive"] = 1.003791,
							["buff_uptime"] = 262,
							["last_cooldown"] = {
								1555798837.686, -- [1]
								61336, -- [2]
							},
							["cc_done_spells"] = {
								["_ActorTable"] = {
									[61391] = {
										["id"] = 61391,
										["targets"] = {
											["공포의 소환사"] = 1,
										},
										["counter"] = 1,
									},
									[50259] = {
										["id"] = 50259,
										["targets"] = {
											["임프 화염술사"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "DRUID",
							["cooldowns_defensive_targets"] = {
								["완소야드"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[61336] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 61336,
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 69,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 69,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 5,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 5,
									},
									[106898] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 106898,
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[5487] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 5487,
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[8936] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 2,
										["id"] = 8936,
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 54,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									[5217] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = 5217,
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 175,
							["tipo"] = 4,
							["cc_done"] = 2.003685,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[5221] = 6,
								[22568] = 3,
								[61336] = 1,
								[768] = 1,
								[106785] = 5,
								[61391] = 1,
								[1079] = 4,
								[49376] = 1,
								[16953] = 9,
								[106898] = 1,
								[106830] = 9,
								[8921] = 2,
								[5217] = 1,
								[8936] = 3,
							},
							["serial"] = "Player-2116-0507E01E",
							["pets"] = {
							},
							["last_event"] = 1555798857,
							["nome"] = "완소야드",
							["debuff_uptime_targets"] = {
							},
							["cooldowns_defensive_spells"] = {
								["_ActorTable"] = {
									[61336] = {
										["id"] = 61336,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["cc_done_targets"] = {
								["임프 화염술사"] = 1,
								["공포의 소환사"] = 1,
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "공포의 소환사",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[11443] = 1,
								[32666] = 2,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-3058-530-125-19434-00003B5CC5",
							["fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "임프 화염술사",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[9053] = 4,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-3058-530-125-19136-00003B5C84",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 5,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130212.128,
				["tempo_start"] = 1555798788,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					16310, -- [1]
					4001, -- [2]
					{
						0, -- [1]
						[0] = 91,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 1,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					10191, -- [1]
					4001, -- [2]
					{
						0, -- [1]
						[0] = 91,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 1,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:20:58",
				["cleu_timeline"] = {
				},
				["enemy"] = "공포의 소환사",
				["TotalElapsedCombatTime"] = 69.0600000000122,
				["CombatEndedAt"] = 130281.188,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 10191.008832,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 4001.005191,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130281.188,
				["combat_id"] = 5,
				["combat_counter"] = 29,
				["frags"] = {
					["임프 화염술사"] = 1,
					["갈퀴발 지옥 마귀"] = 2,
					["지옥불정령 전쟁인도자"] = 1,
					["공포의 소환사"] = 1,
				},
				["player_last_events"] = {
				},
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "07:19:49",
				["start_time"] = 130212.024,
				["contra"] = "공포의 소환사",
				["spells_cast_timeline"] = {
				},
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004237,
							["damage_from"] = {
								["지옥불정령 전쟁인도자"] = true,
							},
							["targets"] = {
								["지옥불정령 전쟁인도자"] = 2525,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2525.004237,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 2525.004237,
							["damage_taken"] = 892.004237,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 499,
										["g_amt"] = 0,
										["n_max"] = 63,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 866,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 367,
										["n_min"] = 60,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 866,
										["c_max"] = 129,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 120,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[22568] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 785,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 785,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 785,
										["c_max"] = 785,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 785,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 567,
										["g_amt"] = 0,
										["n_max"] = 142,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 850,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 283,
										["n_min"] = 141,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 850,
										["c_max"] = 284,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 283,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106830] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 24,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 24,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 24,
										["n_min"] = 24,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 24,
										["c_max"] = 0,
										["id"] = 106830,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 264.509138592022,
							["end_time"] = 1555798669,
							["colocacao"] = 1,
							["last_event"] = 1555798668,
							["on_hold"] = false,
							["start_time"] = 1555798660,
							["serial"] = "Player-2116-0507E01E",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007736,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 892,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 892.007736,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798669,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 2525.007736,
							["nome"] = "지옥불정령 전쟁인도자",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 177,
										["targets"] = {
											["완소야드"] = 658,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 658,
										["n_min"] = 131,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 658,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[12744] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 83,
										["targets"] = {
											["완소야드"] = 234,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 234,
										["n_min"] = 75,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 234,
										["c_max"] = 0,
										["id"] = 12744,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 892.007736,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798668,
							["on_hold"] = false,
							["start_time"] = 1555798660,
							["serial"] = "Creature-0-3058-530-125-19261-00003B5C32",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.008909,
							["total_without_pet"] = 91.008909,
							["total"] = 91.008909,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.008909,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 91,
							},
							["totalover_without_pet"] = 0.008909,
							["healing_taken"] = 91.008909,
							["fight_component"] = true,
							["end_time"] = 1555798669,
							["heal_enemy_amt"] = 0,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 91,
										},
										["n_min"] = 91,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 91,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 91,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1555798668,
							["totaldenied"] = 0.008909,
							["start_time"] = 1555798668,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["received"] = 4.005936,
							["resource"] = 0.005936,
							["targets"] = {
								["완소야드"] = 4,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 4.005936,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798788,
							["alternatepower"] = 0.005936,
							["spells"] = {
								["_ActorTable"] = {
									[5221] = {
										["id"] = 5221,
										["total"] = 4,
										["targets"] = {
											["완소야드"] = 4,
										},
										["counter"] = 4,
									},
									[16953] = {
										["id"] = 16953,
										["total"] = 0,
										["targets"] = {
											["완소야드"] = 0,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[50259] = {
										["activedamt"] = -1,
										["id"] = 50259,
										["targets"] = {
										},
										["actived_at"] = 1555798662,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									[106830] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 106830,
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 28,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 0,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[5221] = 3,
								[16953] = 1,
								[22568] = 1,
								[106830] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1555798669,
							["nome"] = "완소야드",
							["pets"] = {
							},
							["serial"] = "Player-2116-0507E01E",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 4,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130084.102,
				["tempo_start"] = 1555798660,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					3416.995508, -- [1]
					91, -- [2]
					{
						0, -- [1]
						[0] = 3.994028,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2525, -- [1]
					91, -- [2]
					{
						0, -- [1]
						[0] = 4,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:17:50",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥불정령 전쟁인도자",
				["TotalElapsedCombatTime"] = 9.5460000000021,
				["CombatEndedAt"] = 130093.648,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2525.004237,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 91.008909,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130093.648,
				["combat_id"] = 4,
				["combat_counter"] = 28,
				["frags"] = {
					["지옥불정령 전쟁인도자"] = 1,
				},
				["player_last_events"] = {
				},
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "07:17:41",
				["start_time"] = 130084.102,
				["contra"] = "지옥불정령 전쟁인도자",
				["spells_cast_timeline"] = {
				},
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005603,
							["damage_from"] = {
								["지옥불정령 전쟁인도자"] = true,
							},
							["targets"] = {
								["지옥불정령 전쟁인도자"] = 2487,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2487.005603,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 2487.005603,
							["damage_taken"] = 1944.005603,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 252,
										["g_amt"] = 0,
										["n_max"] = 65,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 691,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 439,
										["n_min"] = 60,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 691,
										["c_max"] = 130,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 122,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[22568] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 995,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 995,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 995,
										["c_max"] = 995,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 995,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 285,
										["g_amt"] = 0,
										["n_max"] = 143,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 712,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 427,
										["n_min"] = 142,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 712,
										["c_max"] = 285,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 285,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106785] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 89,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 89,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 89,
										["n_min"] = 89,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 89,
										["c_max"] = 0,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 136.746335459354,
							["end_time"] = 1555798645,
							["colocacao"] = 1,
							["last_event"] = 1555798644,
							["on_hold"] = false,
							["start_time"] = 1555798627,
							["serial"] = "Player-2116-0507E01E",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008733,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
								["완소야드"] = 1944,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1944.008733,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798645,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 2487.008733,
							["nome"] = "지옥불정령 전쟁인도자",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 366,
										["g_amt"] = 0,
										["n_max"] = 178,
										["targets"] = {
											["완소야드"] = 1480,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1114,
										["n_min"] = 134,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 1480,
										["c_max"] = 366,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 366,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[12744] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 83,
										["targets"] = {
											["완소야드"] = 464,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 464,
										["n_min"] = 70,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 464,
										["c_max"] = 0,
										["id"] = 12744,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 1944.008733,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798643,
							["on_hold"] = false,
							["start_time"] = 1555798628,
							["serial"] = "Creature-0-3058-530-125-19261-00003B5BFC",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 0.006497,
							["total_without_pet"] = 91.006497,
							["total"] = 91.006497,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.006497,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 91,
							},
							["totalover_without_pet"] = 0.006497,
							["healing_taken"] = 91.006497,
							["fight_component"] = true,
							["end_time"] = 1555798645,
							["heal_enemy_amt"] = 0,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 91,
										},
										["n_min"] = 91,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 91,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 91,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1555798644,
							["totaldenied"] = 0.006497,
							["start_time"] = 1555798644,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["received"] = 2.001653,
							["resource"] = 0.001653,
							["targets"] = {
								["완소야드"] = 2,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 2.001653,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798660,
							["alternatepower"] = 0.001653,
							["spells"] = {
								["_ActorTable"] = {
									[5221] = {
										["id"] = 5221,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 4,
									},
									[16953] = {
										["id"] = 16953,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[50259] = {
										["activedamt"] = -1,
										["id"] = 50259,
										["targets"] = {
										},
										["actived_at"] = 1555798629,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									[61391] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 61391,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 55,
							["cc_done_spells"] = {
								["_ActorTable"] = {
									[61391] = {
										["id"] = 61391,
										["targets"] = {
											["지옥불정령 전쟁인도자"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 1,
							["cc_done"] = 1.002755,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[22568] = 1,
								[106785] = 1,
								[5221] = 3,
								[16953] = 1,
								[61391] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1555798645,
							["pets"] = {
							},
							["nome"] = "완소야드",
							["serial"] = "Player-2116-0507E01E",
							["cc_done_targets"] = {
								["지옥불정령 전쟁인도자"] = 1,
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["tempo_start"] = 1555798627,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 27,
				["playing_solo"] = true,
				["totals"] = {
					4431, -- [1]
					91, -- [2]
					{
						0, -- [1]
						[0] = 2,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2487, -- [1]
					91, -- [2]
					{
						0, -- [1]
						[0] = 2,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:17:26",
				["cleu_timeline"] = {
				},
				["enemy"] = "지옥불정령 전쟁인도자",
				["TotalElapsedCombatTime"] = 130069.02,
				["CombatEndedAt"] = 130069.02,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2487.005603,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 91.006497,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130069.02,
				["combat_id"] = 3,
				["player_last_events"] = {
				},
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "07:17:07",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["contra"] = "지옥불정령 전쟁인도자",
				["start_time"] = 130050.833,
				["TimeData"] = {
				},
				["frags"] = {
					["지옥불정령 전쟁인도자"] = 1,
				},
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002235,
							["damage_from"] = {
								["갈퀴발 지옥 마귀"] = true,
								["임프 화염술사"] = true,
							},
							["targets"] = {
								["갈퀴발 지옥 마귀"] = 2041,
								["임프 화염술사"] = 785,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["custom"] = 0,
							["tipo"] = 1,
							["classe"] = "DRUID",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2826.002235,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 2826.002235,
							["damage_taken"] = 625.002235,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 384,
										["g_amt"] = 0,
										["n_max"] = 68,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 628,
											["임프 화염술사"] = 331,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 575,
										["n_min"] = 60,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 959,
										["c_max"] = 131,
										["id"] = 1,
										["r_dmg"] = 0,
										["c_min"] = 124,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[22568] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 293,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 540,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 540,
										["n_min"] = 247,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 540,
										["c_max"] = 0,
										["id"] = 22568,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106785] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 205,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 205,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 205,
										["c_max"] = 205,
										["id"] = 106785,
										["r_dmg"] = 0,
										["c_min"] = 205,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[1822] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 161,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 161,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 161,
										["n_min"] = 161,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 161,
										["c_max"] = 0,
										["id"] = 1822,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[155722] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 138,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 138,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 138,
										["n_min"] = 138,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 138,
										["c_max"] = 0,
										["id"] = 155722,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[5221] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 303,
										["g_amt"] = 0,
										["n_max"] = 170,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 313,
											["임프 화염술사"] = 454,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 464,
										["n_min"] = 143,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 767,
										["c_max"] = 303,
										["id"] = 5221,
										["r_dmg"] = 0,
										["c_min"] = 303,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[106830] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 56,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["갈퀴발 지옥 마귀"] = 56,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 56,
										["c_max"] = 56,
										["id"] = 106830,
										["r_dmg"] = 0,
										["c_min"] = 56,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["last_dps"] = 178.894868329527,
							["end_time"] = 1555798616,
							["colocacao"] = 1,
							["last_event"] = 1555798615,
							["friendlyfire"] = {
							},
							["start_time"] = 1555798600,
							["serial"] = "Player-2116-0507E01E",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008059,
							["damage_from"] = {
								["완소야드"] = true,
								["Aclouds-하이잘"] = true,
							},
							["targets"] = {
								["완소야드"] = 254,
								["Aclouds-하이잘"] = 507,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 761.008059,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798616,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 1066.008059,
							["nome"] = "임프 화염술사",
							["spells"] = {
								["_ActorTable"] = {
									[9053] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 255,
										["targets"] = {
											["완소야드"] = 254,
											["Aclouds-하이잘"] = 507,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 761,
										["n_min"] = 252,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 761,
										["c_max"] = 0,
										["id"] = 9053,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 761.008059,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798610,
							["on_hold"] = false,
							["start_time"] = 1555798603,
							["serial"] = "Creature-0-3058-530-125-19136-00003B5C14",
							["fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005386,
							["damage_from"] = {
								["완소야드"] = true,
								["Aclouds-하이잘"] = true,
							},
							["targets"] = {
								["완소야드"] = 371,
								["Aclouds-하이잘"] = 237,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 608.005386,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1555798616,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 3642.005386,
							["nome"] = "갈퀴발 지옥 마귀",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 69,
										["targets"] = {
											["완소야드"] = 235,
											["Aclouds-하이잘"] = 157,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 392,
										["n_min"] = 45,
										["g_dmg"] = 0,
										["counter"] = 10,
										["c_min"] = 0,
										["total"] = 392,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 7,
										["DODGE"] = 1,
										["MISS"] = 2,
									}, -- [1]
									[11968] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 28,
										["targets"] = {
											["완소야드"] = 136,
											["Aclouds-하이잘"] = 80,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 216,
										["n_min"] = 26,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 216,
										["c_max"] = 0,
										["id"] = 11968,
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 608.005386,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1555798613,
							["on_hold"] = false,
							["start_time"] = 1555798601,
							["serial"] = "Creature-0-3058-530-125-18978-00003B5C14",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["완소야드"] = 7,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "DRUID",
							["totalover"] = 7.006507,
							["total_without_pet"] = 266.006507,
							["total"] = 266.006507,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-2116-0507E01E",
							["totalabsorb"] = 0.006507,
							["last_hps"] = 0,
							["targets"] = {
								["완소야드"] = 273,
							},
							["totalover_without_pet"] = 0.006507,
							["healing_taken"] = 266.006507,
							["fight_component"] = true,
							["end_time"] = 1555798616,
							["heal_enemy_amt"] = 0,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[59913] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["완소야드"] = 7,
										},
										["n_max"] = 91,
										["targets"] = {
											["완소야드"] = 266,
										},
										["n_min"] = 84,
										["counter"] = 3,
										["overheal"] = 7,
										["total"] = 266,
										["c_max"] = 0,
										["id"] = 59913,
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 266,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["완소야드"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1555798615,
							["totaldenied"] = 0.006507,
							["start_time"] = 1555798603,
							["delay"] = 0,
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["received"] = 57.002534,
							["resource"] = 0.002534,
							["targets"] = {
								["완소야드"] = 57,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "DRUID",
							["fight_component"] = true,
							["total"] = 57.002534,
							["nome"] = "완소야드",
							["spec"] = 103,
							["grupo"] = true,
							["tipo"] = 3,
							["last_event"] = 1555798627,
							["alternatepower"] = 0.002534,
							["spells"] = {
								["_ActorTable"] = {
									[5221] = {
										["id"] = 5221,
										["total"] = 4,
										["targets"] = {
											["완소야드"] = 4,
										},
										["counter"] = 5,
									},
									[16953] = {
										["id"] = 16953,
										["total"] = 3,
										["targets"] = {
											["완소야드"] = 3,
										},
										["counter"] = 3,
									},
									[5217] = {
										["id"] = 5217,
										["total"] = 50,
										["targets"] = {
											["완소야드"] = 50,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["serial"] = "Player-2116-0507E01E",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									[155722] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 155722,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[58180] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = 58180,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[163505] = {
										["activedamt"] = -1,
										["id"] = 163505,
										["targets"] = {
										},
										["actived_at"] = 1555798603,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 52,
							["classe"] = "DRUID",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[768] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 768,
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[135700] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 135700,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[32071] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 32071,
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[39911] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 39911,
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									[5217] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 5217,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 6,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["spell_cast"] = {
								[22568] = 2,
								[106785] = 1,
								[1822] = 1,
								[5221] = 4,
								[5217] = 1,
								[16953] = 3,
								[106830] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1555798616,
							["nome"] = "완소야드",
							["pets"] = {
							},
							["serial"] = "Player-2116-0507E01E",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "임프 화염술사",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								[9053] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-3058-530-125-19136-00003B5C14",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130050.833,
				["tempo_start"] = 1555798600,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					4194.986928, -- [1]
					265.996106, -- [2]
					{
						0, -- [1]
						[0] = 56.994173,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2826, -- [1]
					266, -- [2]
					{
						0, -- [1]
						[0] = 57,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "07:16:57",
				["cleu_timeline"] = {
				},
				["enemy"] = "갈퀴발 지옥 마귀",
				["TotalElapsedCombatTime"] = 130039.947,
				["CombatEndedAt"] = 130039.947,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["완소야드"] = 2826.002235,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["완소야드"] = 266.006507,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 130039.947,
				["combat_id"] = 2,
				["combat_counter"] = 26,
				["frags"] = {
					["갈퀴발 지옥 마귀"] = 4,
					["임프 화염술사"] = 1,
				},
				["player_last_events"] = {
				},
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "07:16:41",
				["start_time"] = 130024.15,
				["contra"] = "갈퀴발 지옥 마귀",
				["spells_cast_timeline"] = {
				},
			}, -- [10]
			{
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008854,
							["damage_from"] = {
								["갈퀴발 지옥 마귀"] = true,
							},
							["targets"] = {
								["긴꼬리쥐"] = 122,
							},
							["serial"] = "Player-2116-0507E01E",
							["pets"] = {
							},
							["colocacao"] = 1,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 122.008854,
							["spec"] = 103,
							["dps_started"] = false,
							["total"] = 122.008854,
							["friendlyfire"] = {
							},
							["last_event"] = 1555795908,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[106785] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 122,
										["targets"] = {
											["긴꼬리쥐"] = 122,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 122,
										["n_min"] = 122,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 122,
										["c_max"] = 0,
										["id"] = 106785,
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["last_dps"] = 101.504870215903,
							["end_time"] = 1555795909,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 56.008854,
							["start_time"] = 1555795908,
							["delay"] = 0,
							["classe"] = "DRUID",
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.003901,
							["damage_from"] = {
								["완소야드"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003901,
							["dps_started"] = false,
							["fight_component"] = true,
							["total"] = 0.003901,
							["serial"] = "Creature-0-3058-0-9-48972-00003B5874",
							["damage_taken"] = 122.003901,
							["nome"] = "긴꼬리쥐",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1555795909,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1555795909,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["resource"] = 0.00796,
							["targets"] = {
								["완소야드"] = 21,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "DRUID",
							["alternatepower"] = 0.00796,
							["nome"] = "완소야드",
							["spells"] = {
								["_ActorTable"] = {
									[17057] = {
										["id"] = 17057,
										["total"] = 20,
										["targets"] = {
											["완소야드"] = 20,
										},
										["counter"] = 1,
									},
									[1822] = {
										["id"] = 1822,
										["total"] = 1,
										["targets"] = {
											["완소야드"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["received"] = 21.00796,
							["last_event"] = 1555798600,
							["total"] = 21.00796,
							["tipo"] = 3,
							["serial"] = "Player-2116-0507E01E",
							["spec"] = 103,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 103,
							["grupo"] = true,
							["buff_uptime"] = 1,
							["nome"] = "완소야드",
							["pets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1555795909,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[768] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = 768,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-2116-0507E01E",
							["classe"] = "DRUID",
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["완소야드"] = true,
				},
				["CombatStartedAt"] = 130024.15,
				["tempo_start"] = 1555795908,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					121.993464, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 21,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["완소야드"] = {
						{
							true, -- [1]
							1, -- [2]
							56, -- [3]
							1555798600.561, -- [4]
							4466, -- [5]
							"갈퀴발 지옥 마귀", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "06:31:49",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "긴꼬리쥐",
				["TotalElapsedCombatTime"] = 127332.797,
				["CombatEndedAt"] = 127332.797,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["완소야드"] = 122.008854,
						}, -- [1]
					},
				},
				["end_time"] = 127332.797,
				["combat_id"] = 1,
				["spells_cast_timeline"] = {
				},
				["frags"] = {
					["긴꼬리쥐"] = 1,
				},
				["combat_counter"] = 24,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					122, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 21,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 127331.595,
				["TimeData"] = {
				},
				["data_inicio"] = "06:31:48",
			}, -- [11]
		},
	},
	["last_version"] = "v8.1.5.7099",
	["character_data"] = {
		["logons"] = 11,
	},
	["tabela_instancias"] = {
	},
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = true,
			["isLocked"] = false,
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = 166.523681640625,
					["x"] = -994.904479980469,
					["w"] = 320.000091552734,
					["h"] = 129.999969482422,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["cached_talents"] = {
		["Player-2116-0507E01E"] = {
			22364, -- [1]
			18577, -- [2]
			18571, -- [3]
			22163, -- [4]
		},
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 0,
	["active_profile"] = "완소야드-굴단",
	["last_realversion"] = 139,
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 1,
			["showamount"] = false,
			["animate"] = false,
			["useplayercolor"] = false,
			["useclasscolors"] = false,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["enabled"] = true,
		},
		["DETAILS_PLUGIN_TIME_ATTACK"] = {
			["enabled"] = true,
			["realm_last_shown"] = 40,
			["saved_as_anonymous"] = true,
			["recently_as_anonymous"] = true,
			["dps"] = 0,
			["disable_sharing"] = false,
			["history"] = {
			},
			["time"] = 40,
			["history_lastindex"] = 0,
			["realm_lastamt"] = 0,
			["realm_history"] = {
			},
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_DAMAGE_RANK"] = {
			["lasttry"] = {
			},
			["annouce"] = true,
			["dpshistory"] = {
			},
			["author"] = "Details! Team",
			["dps"] = 0,
			["level"] = 1,
			["enabled"] = true,
		},
		["DETAILS_PLUGIN_VANGUARD"] = {
			["enabled"] = true,
			["tank_block_texture"] = "Details Serenity",
			["tank_block_color"] = {
				0.24705882, -- [1]
				0.0039215, -- [2]
				0, -- [3]
				0.8, -- [4]
			},
			["show_inc_bars"] = false,
			["author"] = "Details! Team",
			["first_run"] = false,
			["tank_block_size"] = 150,
		},
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["author"] = "Details! Team",
			["window_scale"] = 1,
			["hide_on_combat"] = false,
			["show_icon"] = 5,
			["opened"] = 0,
			["encounter_timers_dbm"] = {
			},
		},
		["DETAILS_PLUGIN_DPS_TUNING"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
			["SpellBarsShowType"] = 1,
		},
		["DETAILS_PLUGIN_RAIDCHECK"] = {
			["enabled"] = true,
			["food_tier1"] = true,
			["mythic_1_4"] = true,
			["food_tier2"] = true,
			["author"] = "Details! Team",
			["use_report_panel"] = true,
			["pre_pot_healers"] = false,
			["pre_pot_tanks"] = false,
			["food_tier3"] = true,
		},
		["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["main_frame_size"] = {
				300, -- [1]
				500.000030517578, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 160,
				["radius"] = 160,
				["hide"] = false,
			},
			["arrow_anchor_x"] = 0,
			["row_texture"] = "Details Serenity",
			["scale"] = 1,
			["row_height"] = 20,
			["point"] = "CENTER",
			["enabled"] = false,
			["arrow_size"] = 10,
			["author"] = "Details! Team",
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.2, -- [4]
			},
			["row_color"] = {
				0.1, -- [1]
				0.1, -- [2]
				0.1, -- [3]
				0.4, -- [4]
			},
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["per_second"] = {
				["enabled"] = false,
				["point"] = "CENTER",
				["scale"] = 1,
				["font_shadow"] = true,
				["y"] = 3.05175781250e-05,
				["x"] = 3.05175781250e-05,
				["size"] = 32,
				["update_speed"] = 0.05,
				["attribute_type"] = 1,
			},
			["font_size"] = 10,
			["x"] = 0,
			["font_face"] = "Friz Quadrata TT",
			["y"] = 4.577636718750e-05,
			["use_spark"] = true,
			["main_frame_strata"] = "LOW",
			["main_frame_locked"] = false,
			["arrow_anchor_y"] = 0,
		},
	},
	["nick_tag_cache"] = {
		["nextreset"] = 1557088442,
		["last_version"] = 11,
	},
	["on_death_menu"] = true,
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["last_day"] = "21",
	["combat_counter"] = 36,
	["combat_id"] = 11,
	["savedStyles"] = {
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.002405,
					["damage_from"] = {
					},
					["targets"] = {
						["임프 화염술사"] = 0,
						["살무사"] = 0,
						["공포의 소환사"] = 0,
						["갈퀴발 지옥 마귀"] = 0,
						["긴꼬리쥐"] = 0,
						["지옥불정령 전쟁인도자"] = 0,
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["tipo"] = 1,
					["classe"] = "DRUID",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002405,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1555796345,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["임프 화염술사"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
									["지옥불정령 전쟁인도자"] = 0,
									["공포의 소환사"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[1079] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["임프 화염술사"] = 0,
									["지옥불정령 전쟁인도자"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1079,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[106785] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["임프 화염술사"] = 0,
									["공포의 소환사"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
									["긴꼬리쥐"] = 0,
									["지옥불정령 전쟁인도자"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 106785,
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							[5221] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["임프 화염술사"] = 0,
									["지옥불정령 전쟁인도자"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
									["공포의 소환사"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 5221,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[164812] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["갈퀴발 지옥 마귀"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 164812,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[1822] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["지옥불정령 전쟁인도자"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1822,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[155722] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["지옥불정령 전쟁인도자"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 155722,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[22568] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["갈퀴발 지옥 마귀"] = 0,
									["지옥불정령 전쟁인도자"] = 0,
									["공포의 소환사"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 22568,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[106830] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["임프 화염술사"] = 0,
									["살무사"] = 0,
									["공포의 소환사"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
									["지옥불정령 전쟁인도자"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 106830,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.002405,
					["nome"] = "완소야드",
					["spec"] = 103,
					["grupo"] = true,
					["total"] = 0.002405,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1555796342,
					["serial"] = "Player-2116-0507E01E",
					["friendlyfire"] = {
					},
				}, -- [1]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.001464,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001464,
					["last_dps"] = 0,
					["fight_component"] = true,
					["end_time"] = 1555796345,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "긴꼬리쥐",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.001464,
					["total"] = 0.001464,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1555796342,
					["serial"] = "Creature-0-3058-0-9-48972-00003B5874",
					["dps_started"] = false,
				}, -- [2]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.002215,
					["damage_from"] = {
					},
					["targets"] = {
						["완소야드"] = 0,
					},
					["fight_component"] = true,
					["pets"] = {
					},
					["end_time"] = 1555799253,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002215,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.002215,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "지옥불정령 전쟁인도자",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[12744] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 12744,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["on_hold"] = false,
					["serial"] = "Creature-0-3058-530-125-19261-00003B9B6E",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.002215,
					["start_time"] = 1555799250,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [3]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.002744,
					["damage_from"] = {
					},
					["targets"] = {
						["Aclouds-하이잘"] = 0,
						["완소야드"] = 0,
					},
					["fight_component"] = true,
					["pets"] = {
					},
					["end_time"] = 1555799253,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002744,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.002744,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "임프 화염술사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[9053] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Aclouds-하이잘"] = 0,
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 9053,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["on_hold"] = false,
					["serial"] = "Creature-0-3058-530-125-19136-00003B3D50",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.002744,
					["start_time"] = 1555799250,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [4]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.006824,
					["damage_from"] = {
					},
					["targets"] = {
						["Aclouds-하이잘"] = 0,
						["완소야드"] = 0,
					},
					["fight_component"] = true,
					["pets"] = {
					},
					["end_time"] = 1555799253,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006824,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.006824,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "갈퀴발 지옥 마귀",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Aclouds-하이잘"] = 0,
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[11968] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Aclouds-하이잘"] = 0,
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 11968,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["on_hold"] = false,
					["serial"] = "Creature-0-3058-530-125-18978-0000BB3D50",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.006824,
					["start_time"] = 1555799250,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [5]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.006955,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006955,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1555799253,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["nome"] = "살무사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["friendlyfire_total"] = 0,
					["total"] = 0.006955,
					["serial"] = "Creature-0-3058-530-125-3300-0011B79829",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.006955,
					["start_time"] = 1555799250,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [6]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.008793,
					["damage_from"] = {
					},
					["targets"] = {
						["완소야드"] = 0,
					},
					["fight_component"] = true,
					["pets"] = {
					},
					["end_time"] = 1555799253,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008793,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.008793,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "공포의 소환사",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							}, -- [1]
							[11443] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 11443,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							[32666] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 32666,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["on_hold"] = false,
					["serial"] = "Creature-0-3058-530-125-19434-00003B5CC5",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.008793,
					["start_time"] = 1555799250,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [7]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorb"] = 0.008017,
					["last_hps"] = 0,
					["healing_from"] = {
					},
					["targets_overheal"] = {
						["완소야드"] = 0,
					},
					["targets"] = {
						["완소야드"] = 0,
					},
					["spells"] = {
						["tipo"] = 3,
						["_ActorTable"] = {
							[8936] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 8936,
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							[59913] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["완소야드"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 59913,
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["totalover_without_pet"] = 0.008017,
					["healing_taken"] = 0.008017,
					["totalover"] = 0.008017,
					["total_without_pet"] = 0.008017,
					["spec"] = 103,
					["classe"] = "DRUID",
					["fight_component"] = true,
					["end_time"] = 1555799253,
					["heal_enemy_amt"] = 0,
					["total"] = 0.008017,
					["nome"] = "완소야드",
					["targets_absorbs"] = {
					},
					["grupo"] = true,
					["start_time"] = 1555799250,
					["heal_enemy"] = {
					},
					["serial"] = "Player-2116-0507E01E",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["totaldenied"] = 0.008017,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [1]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 0.003128,
					["resource"] = 0.059703,
					["targets"] = {
						["완소야드"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "DRUID",
					["fight_component"] = true,
					["total"] = 0.003128,
					["nome"] = "완소야드",
					["spec"] = 103,
					["grupo"] = true,
					["spells"] = {
						["tipo"] = 7,
						["_ActorTable"] = {
							[5217] = {
								["id"] = 5217,
								["total"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["counter"] = 0,
							},
							[1822] = {
								["id"] = 1822,
								["total"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["counter"] = 0,
							},
							[195707] = {
								["id"] = 195707,
								["total"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["counter"] = 0,
							},
							[17057] = {
								["id"] = 17057,
								["total"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["counter"] = 0,
							},
							[16953] = {
								["id"] = 16953,
								["total"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["counter"] = 0,
							},
							[5221] = {
								["id"] = 5221,
								["total"] = 0,
								["targets"] = {
									["완소야드"] = 0,
								},
								["counter"] = 0,
							},
						},
					},
					["tipo"] = 3,
					["flag_original"] = 1297,
					["last_event"] = 0,
					["alternatepower"] = 0.003128,
					["serial"] = "Player-2116-0507E01E",
				}, -- [1]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[50259] = {
								["id"] = 50259,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[61391] = {
								["id"] = 61391,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[58180] = {
								["id"] = 58180,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[164812] = {
								["id"] = 164812,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[163505] = {
								["id"] = 163505,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[155722] = {
								["id"] = 155722,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[106830] = {
								["id"] = 106830,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[1079] = {
								["id"] = 1079,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["cooldowns_defensive"] = 0,
					["pets"] = {
					},
					["cc_done_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[61391] = {
								["id"] = 61391,
								["targets"] = {
									["지옥불정령 전쟁인도자"] = 0,
									["갈퀴발 지옥 마귀"] = 0,
									["공포의 소환사"] = 0,
								},
								["counter"] = 0,
							},
							[50259] = {
								["id"] = 50259,
								["targets"] = {
									["임프 화염술사"] = 0,
								},
								["counter"] = 0,
							},
						},
					},
					["classe"] = "DRUID",
					["cooldowns_defensive_targets"] = {
						["[*] 공격대 단위 생존기"] = 0,
						["완소야드"] = 0,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[61336] = {
								["id"] = 61336,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[32071] = {
								["id"] = 32071,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[77764] = {
								["id"] = 77764,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[5487] = {
								["id"] = 5487,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[39911] = {
								["id"] = 39911,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[106898] = {
								["id"] = 106898,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[5217] = {
								["id"] = 5217,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[768] = {
								["id"] = 768,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[8936] = {
								["id"] = 8936,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[106951] = {
								["id"] = 106951,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[135700] = {
								["id"] = 135700,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 0,
					["cooldowns_defensive_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[61336] = {
								["id"] = 61336,
								["targets"] = {
									["완소야드"] = 0,
								},
								["counter"] = 0,
							},
							[77764] = {
								["id"] = 77764,
								["targets"] = {
									["[*] 공격대 단위 생존기"] = 0,
								},
								["counter"] = 0,
							},
						},
					},
					["cc_done"] = 0,
					["nome"] = "완소야드",
					["spec"] = 103,
					["grupo"] = true,
					["spell_cast"] = {
						[106951] = 0,
						[61336] = 0,
						[1822] = 0,
						[1079] = 0,
						[16953] = 0,
						[49376] = 0,
						[106785] = 0,
						[22568] = 0,
						[8921] = 0,
						[106830] = 0,
						[106898] = 0,
						[5217] = 0,
						[5221] = 0,
						[77764] = 0,
						[61391] = 0,
						[8936] = 0,
						[768] = 0,
					},
					["cc_done_targets"] = {
						["임프 화염술사"] = 0,
						["지옥불정령 전쟁인도자"] = 0,
						["갈퀴발 지옥 마귀"] = 0,
						["공포의 소환사"] = 0,
					},
					["debuff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 0,
					["serial"] = "Player-2116-0507E01E",
					["last_event"] = 0,
				}, -- [1]
				{
					["monster"] = true,
					["nome"] = "임프 화염술사",
					["tipo"] = 4,
					["pets"] = {
					},
					["spell_cast"] = {
						[9053] = 0,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3058-530-125-19136-00003B3D50",
					["classe"] = "UNKNOW",
				}, -- [2]
				{
					["monster"] = true,
					["nome"] = "공포의 소환사",
					["tipo"] = 4,
					["pets"] = {
					},
					["spell_cast"] = {
						[11443] = 0,
						[32666] = 0,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-3058-530-125-19434-00003B5CC5",
					["classe"] = "UNKNOW",
				}, -- [3]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1555795908,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 23,
		["totals"] = {
			0, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = 0,
		["spells_cast_timeline"] = {
		},
		["totals_grupo"] = {
			0, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["hasSaved"] = true,
		["frags"] = {
		},
		["data_fim"] = 0,
		["cleu_timeline"] = {
		},
		["CombatSkillCache"] = {
		},
		["cleu_events"] = {
			["n"] = 1,
		},
		["start_time"] = 0,
		["TimeData"] = {
			["Raid Damage Done"] = {
			},
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
	},
	["force_font_outline"] = "",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-2107-0663FC07"] = 64,
		["Player-2116-0507E01E"] = 103,
		["Player-2107-0630F28F"] = 72,
	},
}
