
PawnOptions = {
	["LastVersion"] = 2.024,
	["LastPlayerFullName"] = "국제금융로-굴단",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "WARRIOR",
	["LastAdded"] = 1,
}
