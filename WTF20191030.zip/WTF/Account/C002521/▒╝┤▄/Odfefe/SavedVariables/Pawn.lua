
PawnOptions = {
	["LastVersion"] = 2.0231,
	["LastPlayerFullName"] = "Odfefe-굴단",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "MAGE",
	["LastAdded"] = 1,
}
