
MADB = {
	["noBags"] = false,
	["characters"] = {
	},
	["alwaysShowNudger"] = false,
	["tooltips"] = true,
	["profiles"] = {
		["default"] = {
			["name"] = "default",
			["frames"] = {
				["ObjectiveTrackerFrameMover"] = {
					["orgPos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						-10, -- [4]
						0, -- [5]
					},
					["name"] = "ObjectiveTrackerFrameMover",
					["pos"] = {
						"TOPRIGHT", -- [1]
						"MinimapCluster", -- [2]
						"BOTTOMRIGHT", -- [3]
						-8.9757080078125, -- [4]
						0.00042724609375, -- [5]
					},
				},
			},
		},
	},
	["closeGUIOnEscape"] = false,
	["noMMMW"] = false,
	["playSound"] = false,
	["frameListRows"] = 18,
}
