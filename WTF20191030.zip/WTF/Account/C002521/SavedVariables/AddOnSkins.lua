
AddOnSkinsDB = {
	["profileKeys"] = {
		["완소야드 - 굴단"] = "Skullflower",
		["무시중한디 - 굴단"] = "Skullflower",
		["뉘시빨라마 - 굴단"] = "뉘시빨라마 - 굴단",
		["쌩뚱마죠 - 렉사르"] = "쌩뚱마죠 - 렉사르",
		["국제금융로 - 굴단"] = "BenikUI",
	},
	["profiles"] = {
		["쌩뚱마죠 - 렉사르"] = {
		},
		["Default"] = {
			["Azeroth Auto Pilot"] = false,
		},
		["완소야드 - 굴단"] = {
		},
		["BenikUI"] = {
			["Skada"] = false,
			["WeakAuraAuraBar"] = true,
			["DBMFontSize"] = 10,
			["DBMFont"] = "Bui Prototype",
			["DBMSkinHalf"] = true,
			["DBMRadarTrans"] = true,
			["EmbedSystemDual"] = true,
			["DetailsBackdrop"] = false,
			["TransparentEmbed"] = true,
			["LoginMsg"] = true,
			["Parchment"] = true,
			["SkinDebug"] = true,
			["Azeroth Auto Pilot"] = false,
		},
		["무시중한디 - 굴단"] = {
		},
		["Skullflower"] = {
			["LoginMsg"] = true,
			["Azeroth Auto Pilot"] = false,
		},
		["뉘시빨라마 - 굴단"] = {
			["SkinDebug"] = true,
			["Parchment"] = true,
			["LoginMsg"] = true,
			["Azeroth Auto Pilot"] = false,
		},
	},
}
AddOnSkinsDS = {
	[4.31] = {
	},
}
