
SkadaDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["잘생겨따 - 굴단"] = "Default",
		["무시중한디 - 굴단"] = "Wide",
		["뉘시빨라마 - 굴단"] = "Default",
		["국제금융로 - 굴단"] = "Default",
	},
	["profiles"] = {
		["굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["point"] = "TOPRIGHT",
					["spark"] = false,
				}, -- [1]
			},
		},
		["WARRIOR"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["point"] = "TOPRIGHT",
					["spark"] = false,
				}, -- [1]
			},
		},
		["Default"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 2,
				["적이 받은 치유"] = 1,
				["약화 효과"] = 1,
				["DPS"] = 2,
			},
			["windows"] = {
				{
					["point"] = "TOPRIGHT",
					["barwidth"] = 195.9999847412109,
					["y"] = 0,
					["x"] = 0,
					["barslocked"] = true,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["mode"] = "DPS",
					["spark"] = false,
					["name"] = "S",
				}, -- [1]
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
			["icon"] = {
				["minimapPos"] = 192.7243435647033,
			},
			["reset"] = {
				["leave"] = 2,
				["instance"] = 2,
				["join"] = 2,
			},
		},
		["Wide"] = {
			["windows"] = {
				{
					["y"] = 4.580974578857422,
					["point"] = "BOTTOMLEFT",
					["mode"] = "DPS",
					["barwidth"] = 287.238525390625,
					["background"] = {
						["height"] = 346.28564453125,
					},
					["x"] = 456.3641662597656,
				}, -- [1]
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
			["modeclicks"] = {
				["GTFO 경고"] = 1,
				["DPS"] = 1,
			},
		},
		["국제금융로 - 굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["point"] = "TOPRIGHT",
					["spark"] = false,
				}, -- [1]
			},
		},
	},
}
