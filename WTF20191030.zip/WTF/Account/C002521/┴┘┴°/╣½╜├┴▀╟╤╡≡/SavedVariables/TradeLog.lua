
TradeLog_TradesHistory = {
	{
		["targetMoney"] = 0,
		["playerMoney"] = 0,
		["id"] = 1,
		["playerItems"] = {
		},
		["reason"] = "self",
		["targetItems"] = {
		},
		["player"] = "아라스틴",
		["where"] = "폭풍우 봉우리",
		["who"] = "팜비냥",
		["when"] = "2017-06-11 15:47:00",
		["result"] = "cancelled",
	}, -- [1]
	{
		["targetMoney"] = 0,
		["playerMoney"] = 600000000,
		["id"] = 2,
		["playerItems"] = {
		},
		["targetItems"] = {
			{
				["name"] = "대족장의 부서진 엄니",
				["numItems"] = 1,
				["itemLink"] = "|cffa335ee|Hitem:140823::::::::110:258::5:3:3517:1492:3528:::|h[대족장의 부서진 엄니]|h|r",
				["isUsable"] = true,
				["texture"] = 1519262,
			}, -- [1]
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_SHOW", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
		},
		["who"] = "식빵대왕",
		["when"] = "2017-06-18 17:46:15",
		["result"] = "complete",
		["where"] = "밤의 요새",
	}, -- [2]
	{
		["targetMoney"] = 0,
		["playerMoney"] = 300000000,
		["id"] = 3,
		["playerItems"] = {
		},
		["targetItems"] = {
			{
				["name"] = "예견된 정복자 망토",
				["numItems"] = 1,
				["itemLink"] = "|cffa335ee|Hitem:143577::::::::110:258::5:1:570:::|h[예견된 정복자 망토]|h|r",
				["isUsable"] = true,
				["texture"] = 133772,
			}, -- [1]
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_SHOW", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
		},
		["who"] = "식빵대왕",
		["when"] = "2017-06-18 18:06:44",
		["result"] = "complete",
		["where"] = "밤의 요새",
	}, -- [3]
	{
		["targetMoney"] = 566660000,
		["playerMoney"] = 0,
		["id"] = 4,
		["playerItems"] = {
		},
		["targetItems"] = {
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_SHOW", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
		},
		["who"] = "식빵대왕",
		["when"] = "2017-06-18 18:56:06",
		["result"] = "complete",
		["where"] = "밤의 요새",
	}, -- [4]
	{
		["targetMoney"] = 0,
		["playerMoney"] = 200000000,
		["id"] = 5,
		["playerItems"] = {
		},
		["targetItems"] = {
			{
				["name"] = "가혹한 고통의 낙인",
				["numItems"] = 1,
				["isUsable"] = true,
				["itemLink"] = "|cffa335ee|Hitem:147108::::::::110:258::3:3:3561:1482:3528:::|h[가혹한 고통의 낙인]|h|r",
				["texture"] = 615100,
			}, -- [1]
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_CLOSED", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
			"TRADE_CLOSED", -- [4]
			"TRADE_CLOSED", -- [5]
			"TRADE_SHOW", -- [6]
			"TRADE_CLOSED", -- [7]
			"TRADE_CLOSED", -- [8]
		},
		["who"] = "달빛의달콤함",
		["when"] = "2017-07-02 11:17:05",
		["result"] = "complete",
		["where"] = "살게라스의 무덤",
	}, -- [5]
	{
		["targetMoney"] = 1300000000,
		["playerMoney"] = 0,
		["id"] = 6,
		["playerItems"] = {
		},
		["targetItems"] = {
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_SHOW", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
		},
		["who"] = "야인랑",
		["when"] = "2017-07-02 13:27:48",
		["result"] = "complete",
		["where"] = "아즈스나",
	}, -- [6]
	{
		["targetMoney"] = 0,
		["playerMoney"] = 0,
		["id"] = 7,
		["playerItems"] = {
			[6] = {
				["texture"] = 1408445,
				["itemLink"] = "|cffa335ee|Hitem:133637::::::::110:258::16:3:3411:1522:3528:::|h[우트가드 왕실 인장]|h|r",
				["name"] = "우트가드 왕실 인장",
				["numItems"] = 1,
			},
		},
		["targetItems"] = {
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_SHOW", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
		},
		["who"] = "팜비아",
		["when"] = "2017-07-02 20:59:42",
		["result"] = "complete",
		["where"] = "스톰하임",
	}, -- [7]
	{
		["targetMoney"] = 0,
		["playerMoney"] = 0,
		["id"] = 8,
		["playerItems"] = {
			[6] = {
				["texture"] = 1125584,
				["itemLink"] = "|cffa335ee|Hitem:137372::::::::110:258::16:3:3535:1572:3337:::|h[소용돌이치는 심연의 손목띠]|h|r",
				["name"] = "소용돌이치는 심연의 손목띠",
				["numItems"] = 1,
			},
		},
		["targetItems"] = {
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_SHOW", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
		},
		["who"] = "검은고냥",
		["when"] = "2017-07-16 14:02:53",
		["result"] = "complete",
		["where"] = "아즈샤라의 눈",
	}, -- [8]
	{
		["targetMoney"] = 0,
		["playerMoney"] = 700000000,
		["id"] = 9,
		["playerItems"] = {
		},
		["targetItems"] = {
			{
				["name"] = "앞서간 정복자 다리보호구",
				["numItems"] = 1,
				["itemLink"] = "|cffa335ee|Hitem:147326::::::::110:258::3::::|h[앞서간 정복자 다리보호구]|h|r",
				["isUsable"] = true,
				["texture"] = 133834,
			}, -- [1]
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_SHOW", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
		},
		["who"] = "올공찾",
		["when"] = "2017-07-23 16:50:37",
		["result"] = "complete",
		["where"] = "아즈스나",
	}, -- [9]
	{
		["targetMoney"] = 580000000,
		["playerMoney"] = 0,
		["id"] = 10,
		["playerItems"] = {
		},
		["targetItems"] = {
		},
		["player"] = "아라스틴",
		["events"] = {
			"TRADE_CLOSED", -- [1]
			"TRADE_CLOSED", -- [2]
			"TRADE_CLOSED", -- [3]
			"TRADE_CLOSED", -- [4]
			"TRADE_SHOW", -- [5]
			"TRADE_CLOSED", -- [6]
			"TRADE_CLOSED", -- [7]
		},
		["who"] = "역곡역",
		["when"] = "2017-07-23 17:18:14",
		["result"] = "complete",
		["where"] = "아즈스나",
	}, -- [10]
	["minimapPos"] = 293.334185044223,
}
TradeLog_Announce_Checked = nil
TradeLog_AnnounceChannel = "WHISPER"
