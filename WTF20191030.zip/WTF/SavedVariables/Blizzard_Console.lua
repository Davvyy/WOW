
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["height"] = 300.0002136230469,
	["messageHistory"] = {
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [35]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [36]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Time set to 10/1/2019 (Tue) 20:34", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Total: 33d 20h 40m 12s", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Level: 23d 15h 36m 32s", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Time set to 10/1/2019 (Tue) 20:45", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Total: 17d 14h 36m 35s", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"Level: 11d 10h 42m 28s", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Weather changed to 1, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Weather changed to 1, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Weather changed to 1, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Weather changed to 1, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Weather changed to 1, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Weather changed to 1, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Weather changed to 1, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Weather changed to 2, intensity 0.147637\n", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Weather changed to 2, intensity 0.147637\n", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Weather changed to 2, intensity 0.147637\n", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Weather changed to 2, intensity 0.147637\n", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Weather changed to 2, intensity 0.147637\n", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Time set to 10/1/2019 (Tue) 21:39", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Total: 26d 7h 58m 56s", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Level: 1d 5h 49m 37s", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Skill 2437 increased from 57 to 58", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Skill 2437 increased from 58 to 59", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Skill 2437 increased from 59 to 60", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Skill 2437 increased from 60 to 61", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Weather changed to 3, intensity 0.384981\n", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Weather changed to 3, intensity 0.384981\n", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Weather changed to 3, intensity 0.320737\n", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Weather changed to 3, intensity 0.320737\n", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Weather changed to 3, intensity 0.320737\n", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Weather changed to 3, intensity 0.175098\n", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Weather changed to 2, intensity 0.093248\n", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Weather changed to 2, intensity 0.088908\n", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Skill 2437 increased from 61 to 62", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Skill 2437 increased from 62 to 63", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Skill 2437 increased from 63 to 64", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Skill 2437 increased from 64 to 65", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Weather changed to 2, intensity 0.088908\n", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"Weather changed to 2, intensity 0.088908\n", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Weather changed to 2, intensity 0.088908\n", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Weather changed to 2, intensity 0.088908\n", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 2, intensity 0.088908\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Weather changed to 2, intensity 0.088908\n", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"Weather changed to 3, intensity 0.378917\n", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Weather changed to 3, intensity 0.378917\n", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Weather changed to 3, intensity 0.378917\n", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Time set to 10/1/2019 (Tue) 23:23", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Total: 26d 9h 41m 56s", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Level: 1d 7h 32m 37s", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [380]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [381]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Time set to 10/1/2019 (Tue) 23:33", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Total: 26d 9h 51m 39s", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"Level: 1d 7h 42m 20s", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Skill 2437 increased from 65 to 66", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Skill 2437 increased from 66 to 67", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Skill 2437 increased from 67 to 68", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Total: 26d 10h 3m 27s", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Level: 1d 7h 54m 8s", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [502]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [503]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Time set to 10/2/2019 (Wed) 21:06", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Total: 17d 15h 30m 1s", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Level: 11d 11h 35m 54s", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Time set to 10/2/2019 (Wed) 21:21", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Total: 26d 10h 6m 30s", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"Level: 1d 7h 57m 11s", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"Time set to 10/2/2019 (Wed) 21:42", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Total: 33d 20h 50m 54s", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Level: 23d 15h 47m 14s", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Time set to 10/2/2019 (Wed) 21:57", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Total: 26d 10h 27m 20s", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Level: 1d 8h 18m 1s", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Weather changed to 2, intensity 0.242131\n", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Weather changed to 2, intensity 0.081971\n", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"Weather changed to 2, intensity 0.195879\n", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Weather changed to 3, intensity 0.394458\n", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Weather changed to 2, intensity 0.195879\n", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Weather changed to 3, intensity 0.371727\n", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Weather changed to 3, intensity 0.156125\n", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Weather changed to 3, intensity 0.156125\n", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Weather changed to 3, intensity 0.379203\n", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"Skill 2437 increased from 68 to 69", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Skill 2437 increased from 69 to 70", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Skill 2437 increased from 70 to 71", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Skill 2437 increased from 71 to 72", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Skill 2437 increased from 72 to 73", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"Skill 2437 increased from 73 to 74", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Skill 2437 increased from 74 to 75", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Skill 2437 increased from 75 to 76", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Skill 2437 increased from 76 to 77", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"Skill 2437 increased from 77 to 78", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"Skill 2437 increased from 78 to 79", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"Skill 2437 increased from 79 to 80", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Skill 2437 increased from 80 to 81", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Skill 2437 increased from 81 to 82", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Skill 2437 increased from 82 to 83", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Skill 2437 increased from 83 to 84", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Skill 2437 increased from 84 to 85", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Skill 2437 increased from 85 to 86", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"GameTimeSync: delta=0, differential=1, HoursAndMinutes=24", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"Weather changed to 2, intensity 0.195850\n", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Dissolve Effect ID 790 has invalid fade in time. This will result in the record beign ignore and a regular fade in being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Weather changed to 2, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Dissolve Effect ID 790 has invalid fade in time. This will result in the record beign ignore and a regular fade in being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Dissolve Effect ID 790 has invalid fade in time. This will result in the record beign ignore and a regular fade in being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Weather changed to 2, intensity 0.231568\n", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Weather changed to 2, intensity 0.148797\n", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Skill 2437 increased from 86 to 87", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Skill 2437 increased from 87 to 88", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Skill 2437 increased from 88 to 89", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Skill 2437 increased from 89 to 90", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Skill 2437 increased from 90 to 91", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Skill 2437 increased from 91 to 92", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Skill 2437 increased from 92 to 93", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Skill 2437 increased from 93 to 94", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Skill 2437 increased from 94 to 95", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Skill 2437 increased from 95 to 96", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Skill 2437 increased from 96 to 97", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Skill 2437 increased from 97 to 98", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Skill 2437 increased from 98 to 99", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Skill 2437 increased from 99 to 100", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"Skill 2437 increased from 100 to 101", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Skill 2437 increased from 101 to 102", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Skill 2437 increased from 102 to 103", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Skill 2437 increased from 103 to 104", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Skill 2437 increased from 104 to 105", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Skill 2437 increased from 105 to 106", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"5\"", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [919]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [920]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"Time set to 10/3/2019 (Thu) 9:36", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"Total: 26d 14h 13m 56s", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"Level: 1d 12h 4m 37s", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Time set to 10/3/2019 (Thu) 9:37", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"Total: 17d 15h 44m 43s", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Level: 11d 11h 50m 36s", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Time set to 10/3/2019 (Thu) 9:38", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Total: 33d 21h 5m 57s", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Level: 23d 16h 2m 17s", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["isShown"] = false,
	["fontHeight"] = 14,
	["commandHistory"] = {
	},
}
