
Postal3DB = {
	["profileKeys"] = {
		["무시중한디 - 굴단"] = "Wide",
	},
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"무시중한디|굴단|Alliance|110|DEMONHUNTER", -- [1]
			},
		},
	},
	["profiles"] = {
		["Wide"] = {
		},
		["무시중한디 - 굴단"] = {
		},
	},
}
