
SSItemLevelDurability = true
SSItemLevelMore = true
SSItemLevelOpt = {
	["enable"] = true,
	["count"] = 2,
	["CacheSize"] = 25,
}
