
SavedInstancesDB = {
	["DBVersion"] = 12,
	["Toons"] = {
		["쌩뚱마삼 - 렉사르"] = {
			["lastbossyell"] = "나르고 스크류보어",
			["isResting"] = true,
			["Emissary"] = {
			},
			["Race"] = "트롤",
			["LClass"] = "사제",
			["RBGrating"] = 0,
			["lastbosstime"] = 1560529473,
			["Show"] = "saved",
			["Faction"] = "Horde",
			["ILe"] = 75.875,
			["Quests"] = {
			},
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["LastSeen"] = 1560529722,
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "PRIEST",
			["currency"] = {
			},
			["Warmode"] = false,
			["Level"] = 65,
			["XP"] = 115452,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 3531824,
			["lastbossyelltime"] = 1560529675,
			["Money"] = 9280735,
			["Zone"] = "북풍의 땅",
			["IL"] = 77.625,
			["lastboss"] = "파괴자 켈리단: 일반",
			["DailyResetTime"] = 1579301999,
			["PlayedLevel"] = 8388,
			["MaxXP"] = 219090,
			["oRace"] = "Troll",
			["Skills"] = {
			},
			["Order"] = 50,
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
		},
		["쌩뚱악사 - 렉사르"] = {
			["Paragon"] = {
			},
			["oRace"] = "BloodElf",
			["isResting"] = false,
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "DEMONHUNTER",
			["Order"] = 50,
			["LastSeen"] = 1560530867,
			["Race"] = "블러드 엘프",
			["DailyResetTime"] = 1579301999,
			["Warmode"] = false,
			["Emissary"] = {
			},
			["Level"] = 98,
			["XP"] = 1480,
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 47,
			["LClass"] = "악마사냥꾼",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["Money"] = 0,
			["IL"] = 138,
			["currency"] = {
			},
			["Zone"] = "마르둠 - 산산조각난 심연",
			["Show"] = "saved",
			["MaxXP"] = 477610,
			["PlayedLevel"] = 47,
			["Faction"] = "Horde",
			["ILe"] = 138,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["WeeklyResetTime"] = 1579733999,
		},
		["쌩뚱마꾼 - 렉사르"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["LastSeen"] = 1559916331,
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "HUNTER",
			["Race"] = "오크",
			["IL"] = 56.6875,
			["Warmode"] = false,
			["lastbossyell"] = "바라딘 그런트",
			["Level"] = 60,
			["LClass"] = "사냥꾼",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 1058752,
			["DailyResetTime"] = 1579301999,
			["lastbossyelltime"] = 1559916273,
			["Money"] = 3981153,
			["Order"] = 50,
			["Emissary"] = {
			},
			["currency"] = {
			},
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 288424,
			["Faction"] = "Horde",
			["ILe"] = 55.4375,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["Zone"] = "오그리마",
		},
		["잘생겨따 - 굴단"] = {
			["IL"] = 1.8125,
			["Zone"] = "암멘 골짜기",
			["Order"] = 50,
			["Class"] = "SHAMAN",
			["currency"] = {
			},
			["Level"] = 4,
			["LClass"] = "주술사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 3418,
			["WeeklyResetTime"] = 1579733999,
			["Money"] = 380,
			["DailyWorldQuest"] = {
			},
			["DailyResetTime"] = 1579301999,
			["LastSeen"] = 1521817526,
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 1685,
			["Faction"] = "Alliance",
			["ILe"] = 1.8125,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["Race"] = "드레나이",
		},
		["오지져스 - 렉사르"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "텔드랏실",
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "DRUID",
			["Race"] = "나이트 엘프",
			["Warmode"] = false,
			["Level"] = 12,
			["LClass"] = "드루이드",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 69213,
			["IL"] = 4.5,
			["LastSeen"] = 1559916493,
			["Money"] = 3323,
			["Skills"] = {
			},
			["Order"] = 50,
			["Emissary"] = {
			},
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 2812,
			["Faction"] = "Alliance",
			["ILe"] = 4.375,
			["DailyResetTime"] = 1579301999,
			["Quests"] = {
			},
			["currency"] = {
			},
		},
		["무시중한디 - 굴단"] = {
			["lastbossyell"] = "스랄: 느조스의 환영",
			["isResting"] = true,
			["Emissary"] = {
				[6] = {
					["unlocked"] = true,
					["days"] = {
						{
							["questReward"] = {
								["itemName"] = "감시관의 현장 도구",
								["itemLvl"] = 110,
								["quality"] = 3,
							},
							["questDone"] = 0,
							["isFinish"] = false,
							["isComplete"] = false,
						}, -- [1]
						{
							["isComplete"] = false,
							["questDone"] = 0,
							["isFinish"] = false,
							["questReward"] = {
								["itemName"] = "키린 토 상자",
								["itemLvl"] = 110,
								["quality"] = 3,
							},
						}, -- [2]
						{
							["isComplete"] = false,
							["questDone"] = 0,
							["isFinish"] = false,
							["questReward"] = {
								["itemName"] = "금빛 트렁크",
								["itemLvl"] = 110,
								["quality"] = 3,
							},
						}, -- [3]
					},
				},
				[7] = {
					["unlocked"] = true,
					["days"] = {
						{
							["questReward"] = {
								["quantity"] = 3000,
								["currencyID"] = 1553,
							},
							["questDone"] = 0,
							["isFinish"] = false,
							["isComplete"] = false,
						}, -- [1]
						{
							["isComplete"] = false,
							["questDone"] = 0,
							["isFinish"] = false,
							["questReward"] = {
								["money"] = 20000000,
							},
						}, -- [2]
						{
							["isComplete"] = false,
							["questDone"] = 0,
							["isFinish"] = false,
							["questReward"] = {
								["itemName"] = "깨어난 폭풍 장비 보관함",
								["itemLvl"] = 415,
								["quality"] = 4,
							},
						}, -- [3]
					},
				},
			},
			["Race"] = "나이트 엘프",
			["LClass"] = "악마사냥꾼",
			["RBGrating"] = 0,
			["Artifact"] = "71 (21%)",
			["lastbosstime"] = 1579288616,
			["Show"] = "saved",
			["Faction"] = "Alliance",
			["ILe"] = 447.1875,
			["Quests"] = {
				[58463] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1530,
						["name"] = "영원꽃 골짜기",
						["parentMapID"] = 424,
					},
					["Title"] = "광기의 피조물",
					["Link"] = "|cffffff00|Hquest:58463:90|h[광기의 피조물]|h|r",
				},
				[53334] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1161,
						["name"] = "보랄러스",
						["parentMapID"] = 895,
					},
					["Title"] = "아라시 기부: 전쟁 자원",
					["Link"] = "|cffffff00|Hquest:53334:90|h[아라시 기부: 전쟁 자원]|h|r",
				},
				[58467] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1530,
						["name"] = "영원꽃 골짜기",
						["parentMapID"] = 424,
					},
					["Title"] = "정신과 육체의 포로",
					["Link"] = "|cffffff00|Hquest:58467:90|h[정신과 육체의 포로]|h|r",
				},
				[58471] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1530,
						["name"] = "영원꽃 골짜기",
						["parentMapID"] = 424,
					},
					["Title"] = "적극적인 탐구",
					["Link"] = "|cffffff00|Hquest:58471:90|h[적극적인 탐구]|h|r",
				},
				[58464] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1530,
						["name"] = "영원꽃 골짜기",
						["parentMapID"] = 424,
					},
					["Title"] = "심연둥지 학살",
					["Link"] = "|cffffff00|Hquest:58464:90|h[심연둥지 학살]|h|r",
				},
				[54380] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1161,
						["name"] = "보랄러스",
						["parentMapID"] = 895,
					},
					["Title"] = "어둠해안 기부: 금화",
					["Link"] = "|cffffff00|Hquest:54380:90|h[어둠해안 기부: 금화]|h|r",
				},
				[58167] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1530,
						["name"] = "영원꽃 골짜기",
						["parentMapID"] = 424,
					},
					["Title"] = "예방 조치",
					["Link"] = "|cffffff00|Hquest:58167:90|h[예방 조치]|h|r",
				},
				[58282] = {
					["isDaily"] = true,
					["Zone"] = {
						["mapType"] = 3,
						["mapID"] = 1527,
						["name"] = "울둠",
						["parentMapID"] = 12,
					},
					["Title"] = "화살비가 내려와",
					["Link"] = "|cffffff00|Hquest:58282:90|h[화살비가 내려와]|h|r",
				},
			},
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["LastSeen"] = 1579290560,
			["Progress"] = {
				{
					["rewardWaiting"] = false,
					["rewardAchieved"] = false,
					["isComplete"] = false,
					["numRequired"] = 500,
					["numFulfilled"] = 173,
					["unlocked"] = true,
					["isFinish"] = false,
				}, -- [1]
				{
					["numRequired"] = 36000,
					["isComplete"] = false,
					["numFulfilled"] = 0,
					["unlocked"] = true,
					["isFinish"] = false,
				}, -- [2]
			},
			["Class"] = "DEMONHUNTER",
			["currency"] = {
				[1755] = {
					["totalMax"] = 25000,
					["amount"] = 18254,
				},
				[1719] = {
					["amount"] = 122,
				},
				[1580] = {
					["weeklyMax"] = 2,
					["totalMax"] = 5,
					["amount"] = 5,
				},
				[1149] = {
					["totalMax"] = 5000,
					["amount"] = 75,
				},
				[1275] = {
					["amount"] = 48,
				},
				[1710] = {
					["amount"] = 1656,
				},
				[1273] = {
					["weeklyMax"] = 3,
					["totalMax"] = 6,
					["amount"] = 6,
				},
				[1155] = {
					["totalMax"] = 300,
					["amount"] = 270,
				},
				[1342] = {
					["totalMax"] = 1000,
					["amount"] = 0,
				},
				[1560] = {
					["amount"] = 21275,
				},
				[1220] = {
					["amount"] = 29484,
				},
				[1717] = {
					["amount"] = 764,
				},
				[1718] = {
					["amount"] = 0,
				},
				[1533] = {
					["amount"] = 3906,
				},
				[1721] = {
					["amount"] = 261,
				},
				[1226] = {
					["amount"] = 10118,
				},
				[738] = {
					["amount"] = 3,
				},
				[1166] = {
					["amount"] = 3180,
				},
				[1508] = {
					["totalMax"] = 2000,
					["amount"] = 951,
				},
				[1314] = {
					["weeklyMax"] = 20,
					["totalMax"] = 40,
					["amount"] = 0,
				},
			},
			["Warmode"] = false,
			["IL"] = 451.25,
			["Level"] = 120,
			["Warfront"] = {
				{
					["scenario"] = {
						false, -- [1]
						false, -- [2]
					},
					["boss"] = false,
				}, -- [1]
				{
					["scenario"] = {
						false, -- [1]
					},
					["boss"] = true,
				}, -- [2]
			},
			["MythicKey"] = {
				["mapID"] = 251,
				["name"] = "썩은굴",
				["link"] = "|cffa335ee|Hkeystone:158923:251:12:9:5:3:119|h[쐐기돌: 썩은굴 (12)]|h|r",
				["color"] = "ffa335ee",
				["level"] = 12,
				["ResetTime"] = 1579733999,
			},
			["PlayedTotal"] = 3303154,
			["lastbossyelltime"] = 1579288616,
			["Money"] = 2309105895,
			["DailyResetTime"] = 1579301999,
			["Order"] = 50,
			["lastboss"] = "타락한 스랄: 느조스의 환영",
			["BonusRoll"] = {
				{
					["item"] = "|cffa335ee|Hitem:168345::::::::120:577::6:4:4824:1517:4786:6270:::|h[거침없는 파도의 투구]|h|r",
					["time"] = 1578317553,
					["name"] = "심연 사령관 사이바라: 신화",
					["costCurrencyID"] = 1580,
				}, -- [1]
				{
					["money"] = 20000000,
					["time"] = 1577623046,
					["name"] = "심연 사령관 사이바라: 신화",
					["costCurrencyID"] = 1580,
				}, -- [2]
				{
					["money"] = 20000000,
					["name"] = "검은바다 거수: 신화",
					["time"] = 1576923459,
					["costCurrencyID"] = 1580,
				}, -- [3]
				{
					["item"] = "|cffa335ee|Hitem:168276::::::::120:577::6:3:4800:1517:4786:::|h[미르미돈의 발톱]|h|r",
					["time"] = 1576921084,
					["name"] = "심연 사령관 사이바라: 신화",
					["costCurrencyID"] = 1580,
				}, -- [4]
				{
					["money"] = 20000000,
					["name"] = "심연 사령관 사이바라: 신화",
					["time"] = 1575035792,
					["costCurrencyID"] = 1580,
				}, -- [5]
				{
					["money"] = 20000000,
					["time"] = 1574431136,
					["name"] = "썩은굴: 신화 쐐기돌",
					["costCurrencyID"] = 1580,
				}, -- [6]
				{
					["name"] = "올고조아: 영웅",
					["item"] = "|cffa335ee|Hitem:168893::::::::120:577::5:3:4799:1502:4786:::|h[부화장 날긁개]|h|r",
					["time"] = 1574257684,
					["costCurrencyID"] = 1580,
				}, -- [7]
				{
					["money"] = 20000000,
					["name"] = "올고조아: 영웅",
					["time"] = 1571923271,
					["costCurrencyID"] = 1580,
				}, -- [8]
				{
					["name"] = "올고조아: 영웅",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1570544154,
					["currencyID"] = 1553,
				}, -- [9]
				{
					["name"] = "검은바다 거수: 신화",
					["item"] = "|cffa335ee|Hitem:168900::::::::120:577::6:3:4800:1517:4786:::|h[잠수자의 거대 장식]|h|r",
					["time"] = 1570457343,
					["costCurrencyID"] = 1580,
				}, -- [10]
				{
					["name"] = "아즈샤라의 광채: 신화",
					["item"] = "|cffa335ee|Hitem:168348::::::::120:577::6:4:4824:1517:4786:6271:::|h[부글거리는 분노의 어깨덧대]|h|r",
					["time"] = 1570456110,
					["costCurrencyID"] = 1580,
				}, -- [11]
				{
					["name"] = "심연 사령관 사이바라: 신화",
					["item"] = "|cffa335ee|Hitem:168345::::::::120:577::6:4:4824:1517:4786:6270:::|h[거침없는 파도의 투구]|h|r",
					["time"] = 1570454673,
					["costCurrencyID"] = 1580,
				}, -- [12]
				{
					["time"] = 1569080467,
					["name"] = "여왕 아즈샤라: 영웅",
					["item"] = "|cffa335ee|Hitem:168871::::::::120:577::5:3:4799:1502:4786:::|h[친애하는 군주의 허리띠]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [13]
				{
					["name"] = "자쿨: 영웅",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1569079904,
					["costCurrencyID"] = 1580,
				}, -- [14]
				{
					["name"] = "웨이크레스트 저택: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:158362::::::::120:577::16:3:5010:1602:4786:::|h[웨이크레스트 군주의 인장]|h|r",
					["time"] = 1567779186,
					["costCurrencyID"] = 1580,
				}, -- [15]
				{
					["name"] = "웨이크레스트 저택: 신화 쐐기돌",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1567257003,
					["costCurrencyID"] = 1580,
				}, -- [16]
				{
					["name"] = "자유지대: 신화 쐐기돌",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1565966965,
					["costCurrencyID"] = 1580,
				}, -- [17]
				{
					["name"] = "웨이크레스트 저택: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159659::::::::120:577::16:3:5010:1602:4786:::|h[사악한 버들 갈퀴]|h|r",
					["time"] = 1565790384,
					["costCurrencyID"] = 1580,
				}, -- [18]
				{
					["name"] = "웨이크레스트 저택: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1563985688,
					["currencyID"] = 1553,
				}, -- [19]
				{
					["item"] = "|cffa335ee|Hitem:168891::::::::120:577::3:3:4798:1487:4786:::|h[저주받은 연인의 반지]|h|r",
					["time"] = 1563462459,
					["name"] = "여왕 아즈샤라: 일반",
					["costCurrencyID"] = 1580,
				}, -- [20]
				{
					["name"] = "나이알로사의 전령 자쿨: 일반",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1563460974,
					["costCurrencyID"] = 1580,
				}, -- [21]
				{
					["name"] = "심연 사령관 사이바라: 일반",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1563454675,
					["costCurrencyID"] = 1580,
				}, -- [22]
				{
					["name"] = "고라크 툴: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1562427424,
					["currencyID"] = 1553,
				}, -- [23]
				{
					["time"] = 1562272887,
					["name"] = "무법의 링: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:155862::::::::120:577::16:4:5010:42:1572:4786:::|h[크라그의 삭구 등반신발]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [24]
				{
					["name"] = "아탈다자르: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159458::::::::120:577::16:4:5010:4802:1572:4786:::|h[위풍당당한 로아의 인장 반지]|h|r",
					["time"] = 1560260180,
					["costCurrencyID"] = 1580,
				}, -- [25]
			},
			["PlayedLevel"] = 2420934,
			["MaxXP"] = 893550,
			["MythicKeyBest"] = {
				["LastWeekLevel"] = 13,
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["Skills"] = {
			},
			["oRace"] = "NightElf",
			["Zone"] = "심장의 방",
		},
		["아놀드클래식 - 렉사르"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "시험의 골짜기",
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "SHAMAN",
			["currency"] = {
			},
			["Warmode"] = false,
			["Level"] = 1,
			["LClass"] = "주술사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 939,
			["LastSeen"] = 1559916067,
			["Emissary"] = {
			},
			["Money"] = 0,
			["DailyResetTime"] = 1579301999,
			["Order"] = 50,
			["Race"] = "오크",
			["Show"] = "saved",
			["IL"] = 0.125,
			["PlayedLevel"] = 939,
			["Faction"] = "Horde",
			["ILe"] = 0.125,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
		},
		["닌자창고 - 렉사르"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "오그리마",
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "MAGE",
			["Race"] = "트롤",
			["Warmode"] = false,
			["Level"] = 1,
			["LClass"] = "마법사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 23440,
			["currency"] = {
			},
			["LastSeen"] = 1559916094,
			["Money"] = 65181,
			["DailyResetTime"] = 1579301999,
			["Order"] = 50,
			["Emissary"] = {
			},
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 23440,
			["Faction"] = "Horde",
			["ILe"] = 0.0625,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["IL"] = 0.0625,
		},
		["오우지져스 - 렉사르"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "그늘 협곡",
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "WARRIOR",
			["currency"] = {
			},
			["Warmode"] = false,
			["Level"] = 6,
			["LClass"] = "전사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 9346,
			["LastSeen"] = 1559916393,
			["Order"] = 50,
			["Money"] = 692,
			["Skills"] = {
			},
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["Race"] = "나이트 엘프",
			["Show"] = "saved",
			["Emissary"] = {
			},
			["PlayedLevel"] = 2177,
			["Faction"] = "Alliance",
			["ILe"] = 2.25,
			["DailyResetTime"] = 1579301999,
			["Quests"] = {
			},
			["IL"] = 2.25,
		},
		["Udiess - 굴단"] = {
			["lastbossyell"] = "안두인 린",
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "스톰윈드",
			["Order"] = 50,
			["Class"] = "MAGE",
			["currency"] = {
				[1166] = {
					["amount"] = 225,
				},
				[241] = {
					["amount"] = 35,
				},
			},
			["Level"] = 80,
			["LClass"] = "마법사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 6144889,
			["lastbossyelltime"] = 1542896104,
			["Money"] = 6201538,
			["LastSeen"] = 1542896176,
			["Quests"] = {
			},
			["Show"] = "saved",
			["Skills"] = {
			},
			["PlayedLevel"] = 1762816,
			["Faction"] = "Alliance",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["DailyResetTime"] = 1579301999,
			["DailyWorldQuest"] = {
			},
			["Race"] = "인간",
		},
		["Odfefe - 굴단"] = {
			["IL"] = 100,
			["Zone"] = "스톰윈드",
			["Order"] = 50,
			["Class"] = "MAGE",
			["currency"] = {
				[1166] = {
					["amount"] = 225,
				},
				[241] = {
					["amount"] = 35,
				},
			},
			["Level"] = 80,
			["LClass"] = "마법사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 6148998,
			["Race"] = "인간",
			["Money"] = 5620180,
			["Quests"] = {
			},
			["Skills"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 1766925,
			["Faction"] = "Alliance",
			["ILe"] = 100,
			["DailyResetTime"] = 1579301999,
			["DailyWorldQuest"] = {
			},
			["LastSeen"] = 1542895786,
		},
		["악사다구 - 아즈샤라"] = {
			["lastbossyell"] = "비전 투영체",
			["isResting"] = true,
			["Emissary"] = {
				[7] = {
					["unlocked"] = true,
					["days"] = {
						{
							["questDone"] = 0,
							["isFinish"] = false,
							["isComplete"] = false,
						}, -- [1]
						{
							["questDone"] = 0,
							["isComplete"] = false,
							["isFinish"] = false,
						}, -- [2]
						{
							["questDone"] = 0,
							["isComplete"] = false,
							["isFinish"] = false,
						}, -- [3]
					},
				},
			},
			["Race"] = "블러드 엘프",
			["LClass"] = "악마사냥꾼",
			["RBGrating"] = 0,
			["Artifact"] = "36 (84%)",
			["lastbosstime"] = 1563041791,
			["Show"] = "saved",
			["Faction"] = "Horde",
			["ILe"] = 315.8125,
			["Quests"] = {
			},
			["Paragon"] = {
			},
			["oRace"] = "BloodElf",
			["Zone"] = "나즈자타",
			["Order"] = 50,
			["Class"] = "DEMONHUNTER",
			["currency"] = {
				[1716] = {
					["amount"] = 5,
				},
				[1220] = {
					["amount"] = 3868,
				},
				[1560] = {
					["amount"] = 131,
				},
				[1533] = {
					["amount"] = 83,
				},
				[1721] = {
					["amount"] = 13,
				},
				[1226] = {
					["amount"] = 496,
				},
			},
			["Warmode"] = false,
			["Level"] = 120,
			["Warfront"] = {
				{
					["scenario"] = {
						false, -- [1]
					},
					["boss"] = false,
				}, -- [1]
				{
					["scenario"] = {
						false, -- [1]
					},
					["boss"] = false,
				}, -- [2]
			},
			["MythicKey"] = {
			},
			["PlayedTotal"] = 71803,
			["lastbossyelltime"] = 1563040952,
			["MaxXP"] = 893550,
			["IL"] = 316.8125,
			["LastSeen"] = 1563043125,
			["lastboss"] = "영혼술사 울매스",
			["Skills"] = {
			},
			["PlayedLevel"] = 6820,
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["Money"] = 30298502,
			["DailyResetTime"] = 1579301999,
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = true,
					["numFulfilled"] = 0,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = true,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["WeeklyResetTime"] = 1579733999,
		},
		["국제금융로 - 굴단"] = {
			["lastbossyell"] = "고라크 툴: 신화 쐐기돌",
			["isResting"] = true,
			["Emissary"] = {
				[7] = {
					["unlocked"] = true,
					["days"] = {
						{
							["isFinish"] = false,
							["questDone"] = 0,
							["isComplete"] = false,
							["questReward"] = {
								["currencyID"] = 1553,
								["quantity"] = 3000,
							},
						}, -- [1]
						{
							["isComplete"] = false,
							["questDone"] = 0,
							["isFinish"] = false,
							["questReward"] = {
								["money"] = 20000000,
							},
						}, -- [2]
						{
							["questDone"] = 0,
							["isComplete"] = false,
							["isFinish"] = false,
						}, -- [3]
					},
				},
			},
			["Race"] = "드레나이",
			["LClass"] = "전사",
			["RBGrating"] = 0,
			["Artifact"] = "70 (65%)",
			["lastbosstime"] = 1579098188,
			["Show"] = "saved",
			["Faction"] = "Alliance",
			["ILe"] = 443,
			["Quests"] = {
			},
			["Paragon"] = {
			},
			["oRace"] = "Draenei",
			["Zone"] = "보랄러스 항구",
			["Progress"] = {
				{
					["isFinish"] = false,
					["isComplete"] = false,
					["rewardWaiting"] = false,
					["numFulfilled"] = 285,
					["numRequired"] = 500,
					["unlocked"] = true,
					["rewardAchieved"] = false,
				}, -- [1]
				{
					["numRequired"] = 36000,
					["isFinish"] = false,
					["isComplete"] = false,
					["unlocked"] = true,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "WARRIOR",
			["currency"] = {
				[777] = {
					["amount"] = 3,
				},
				[824] = {
					["totalMax"] = 10000,
					["amount"] = 506,
				},
				[1220] = {
					["amount"] = 6452,
				},
				[1580] = {
					["weeklyMax"] = 2,
					["totalMax"] = 5,
					["amount"] = 5,
				},
				[1721] = {
					["amount"] = 151,
				},
				[402] = {
					["amount"] = 1,
				},
				[1560] = {
					["amount"] = 3055,
				},
				[1533] = {
					["amount"] = 56,
				},
				[1717] = {
					["amount"] = 337,
				},
				[1166] = {
					["amount"] = 1530,
				},
				[1710] = {
					["amount"] = 202,
				},
				[241] = {
					["amount"] = 2,
				},
				[1718] = {
					["amount"] = 0,
				},
				[81] = {
					["amount"] = 1,
				},
			},
			["Warmode"] = false,
			["Level"] = 120,
			["Warfront"] = {
				{
					["scenario"] = {
						false, -- [1]
						false, -- [2]
					},
					["boss"] = false,
				}, -- [1]
				{
					["scenario"] = {
						false, -- [1]
					},
					["boss"] = false,
				}, -- [2]
			},
			["MythicKey"] = {
				["mapID"] = 244,
				["name"] = "아탈다자르",
				["link"] = "|cffa335ee|Hkeystone:158923:244:11:9:5:3:119|h[쐐기돌: 아탈다자르 (11)]|h|r",
				["color"] = "ffa335ee",
				["level"] = 11,
				["ResetTime"] = 1579733999,
			},
			["PlayedTotal"] = 2653669,
			["lastbossyelltime"] = 1579098188,
			["MaxXP"] = 893550,
			["LastSeen"] = 1579193513,
			["IL"] = 444.875,
			["Skills"] = {
			},
			["lastboss"] = "고라크 툴: 신화 쐐기돌",
			["BonusRoll"] = {
				{
					["money"] = 20000000,
					["time"] = 1577460560,
					["name"] = "올고조아: 영웅",
					["costCurrencyID"] = 1580,
				}, -- [1]
				{
					["name"] = "여군주 애쉬베인: 영웅",
					["item"] = "|cffa335ee|Hitem:169311::::::::120:72::5:4:4799:1502:5850:4783:::|h[애쉬베인의 칼날 산호]|h|r",
					["time"] = 1577460151,
					["costCurrencyID"] = 1580,
				}, -- [2]
				{
					["time"] = 1577020780,
					["name"] = "올고조아: 영웅",
					["item"] = "|cffa335ee|Hitem:168604::::::::120:72::5:4:4799:1502:5850:4783:::|h[부화사의 외투]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [3]
				{
					["money"] = 20000000,
					["name"] = "여군주 애쉬베인: 영웅",
					["time"] = 1577020370,
					["costCurrencyID"] = 1580,
				}, -- [4]
				{
					["money"] = 20000000,
					["time"] = 1575090775,
					["name"] = "올고조아: 영웅",
					["costCurrencyID"] = 1580,
				}, -- [5]
				{
					["item"] = "|cffa335ee|Hitem:168877::::::::120:72::5:4:4799:1808:1502:4786:::|h[산호껍질 전쟁장화]|h|r",
					["time"] = 1575090310,
					["name"] = "여군주 애쉬베인: 영웅",
					["costCurrencyID"] = 1580,
				}, -- [6]
				{
					["time"] = 1573993731,
					["name"] = "풀려난 흉물: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159433::::::::120:72::16:3:5010:1602:4786:::|h[빛을 발하는 판금소매]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [7]
				{
					["name"] = "풀려난 흉물: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1572528577,
					["currencyID"] = 1553,
				}, -- [8]
				{
					["name"] = "자유지대: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159634::::::::120:72::16:3:5010:1602:4786:::|h[보석 박힌 상어분쇄자]|h|r",
					["time"] = 1571318527,
					["costCurrencyID"] = 1580,
				}, -- [9]
				{
					["name"] = "야즈마: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1570369196,
					["currencyID"] = 1553,
				}, -- [10]
				{
					["name"] = "자유지대: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1569767363,
					["currencyID"] = 1553,
				}, -- [11]
				{
					["time"] = 1569330624,
					["name"] = "웨이크레스트 저택: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159616::::::::120:73::16:3:5007:1592:4786:::|h[선혈껍질 도살자의 돌판]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [12]
				{
					["name"] = "영혼술사 울매스",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1569084027,
					["currencyID"] = 1553,
				}, -- [13]
			},
			["PlayedLevel"] = 485910,
			["WeeklyResetTime"] = 1579733999,
			["MythicKeyBest"] = {
				["ResetTime"] = 1579733999,
				["level"] = 0,
				["WeeklyReward"] = false,
				["LastWeekLevel"] = 12,
			},
			["DailyResetTime"] = 1579301999,
			["Money"] = 209034365,
			["Order"] = 50,
		},
		["완소야드 - 굴단"] = {
			["lastbossyell"] = "경비대 사령관 렐손 레오누스",
			["IL"] = 52.3125,
			["Zone"] = "지옥불 반도",
			["Order"] = 50,
			["Class"] = "DRUID",
			["currency"] = {
				[1166] = {
					["amount"] = 225,
				},
			},
			["Warmode"] = false,
			["LastSeen"] = 1555799644,
			["Level"] = 61,
			["LClass"] = "드루이드",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 77651,
			["WeeklyResetTime"] = 1579733999,
			["lastbossyelltime"] = 1555793602,
			["Money"] = 12786440,
			["DailyResetTime"] = 1579301999,
			["Paragon"] = {
			},
			["Race"] = "나이트 엘프",
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 10618,
			["Faction"] = "Alliance",
			["ILe"] = 52.3125,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["Emissary"] = {
			},
		},
		["뉘시빨라마 - 굴단"] = {
			["lastbossyell"] = "야즈마: 신화 쐐기돌",
			["isResting"] = true,
			["Emissary"] = {
				[6] = {
					["unlocked"] = true,
					["days"] = {
						{
							["questReward"] = {
								["itemName"] = "감시관의 현장 도구",
								["itemLvl"] = 110,
								["quality"] = 3,
							},
							["questDone"] = 0,
							["isFinish"] = false,
							["isComplete"] = false,
						}, -- [1]
						{
							["questReward"] = {
								["itemName"] = "키린 토 상자",
								["itemLvl"] = 110,
								["quality"] = 3,
							},
							["questDone"] = 0,
							["isComplete"] = false,
							["isFinish"] = false,
						}, -- [2]
						{
							["questDone"] = 0,
							["isComplete"] = false,
							["isFinish"] = false,
						}, -- [3]
					},
				},
				[7] = {
					["unlocked"] = true,
					["days"] = {
						{
							["questReward"] = {
								["quantity"] = 3000,
								["currencyID"] = 1553,
							},
							["questDone"] = 0,
							["isFinish"] = false,
							["isComplete"] = false,
						}, -- [1]
						{
							["questReward"] = {
								["money"] = 20000000,
							},
							["questDone"] = 0,
							["isComplete"] = false,
							["isFinish"] = false,
						}, -- [2]
						{
							["questDone"] = 0,
							["isComplete"] = false,
							["isFinish"] = false,
						}, -- [3]
					},
				},
			},
			["Race"] = "판다렌 (얼라이언스)",
			["LClass"] = "주술사",
			["RBGrating"] = 0,
			["Artifact"] = "70 (5%)",
			["lastbosstime"] = 1578667747,
			["Show"] = "saved",
			["Faction"] = "Alliance",
			["ILe"] = 442.6875,
			["Quests"] = {
			},
			["Paragon"] = {
				2164, -- [1]
			},
			["WeeklyResetTime"] = 1579733999,
			["LastSeen"] = 1579193627,
			["Progress"] = {
				{
					["rewardAchieved"] = false,
					["rewardWaiting"] = false,
					["isComplete"] = false,
					["numRequired"] = 500,
					["numFulfilled"] = 0,
					["unlocked"] = true,
					["isFinish"] = false,
				}, -- [1]
				{
					["numRequired"] = 36000,
					["numFulfilled"] = 0,
					["isComplete"] = false,
					["unlocked"] = true,
					["isFinish"] = false,
				}, -- [2]
			},
			["Class"] = "SHAMAN",
			["currency"] = {
				[1580] = {
					["weeklyMax"] = 2,
					["totalMax"] = 5,
					["amount"] = 5,
				},
				[1220] = {
					["amount"] = 29405,
				},
				[1718] = {
					["amount"] = 0,
				},
				[1273] = {
					["weeklyMax"] = 3,
					["totalMax"] = 6,
					["amount"] = 5,
				},
				[1710] = {
					["amount"] = 1590,
				},
				[1560] = {
					["amount"] = 7970,
				},
				[1721] = {
					["amount"] = 404,
				},
				[1717] = {
					["amount"] = 928,
				},
				[1533] = {
					["amount"] = 3465,
				},
				[1342] = {
					["totalMax"] = 1000,
					["amount"] = 0,
				},
				[1226] = {
					["amount"] = 12816,
				},
				[1155] = {
					["totalMax"] = 300,
					["amount"] = 265,
				},
				[1166] = {
					["amount"] = 1745,
				},
				[1508] = {
					["totalMax"] = 2000,
					["amount"] = 250,
				},
				[1275] = {
					["amount"] = 27,
				},
			},
			["Warmode"] = false,
			["Level"] = 120,
			["Warfront"] = {
				{
					["scenario"] = {
						false, -- [1]
						false, -- [2]
					},
					["boss"] = false,
				}, -- [1]
				{
					["scenario"] = {
						false, -- [1]
					},
					["boss"] = false,
				}, -- [2]
			},
			["MythicKey"] = {
				["mapID"] = 249,
				["name"] = "왕들의 안식처",
				["link"] = "|cffa335ee|Hkeystone:158923:249:10:9:5:3:119|h[쐐기돌: 왕들의 안식처 (10)]|h|r",
				["color"] = "ffa335ee",
				["level"] = 10,
				["ResetTime"] = 1579733999,
			},
			["PlayedTotal"] = 1712073,
			["lastbossyelltime"] = 1578667747,
			["MaxXP"] = 893550,
			["oRace"] = "Pandaren",
			["Zone"] = "보랄러스 항구",
			["Skills"] = {
			},
			["lastboss"] = "야즈마: 신화 쐐기돌",
			["BonusRoll"] = {
				{
					["money"] = 20000000,
					["name"] = "아즈샤라의 광채: 신화",
					["time"] = 1577452675,
					["costCurrencyID"] = 1580,
				}, -- [1]
				{
					["item"] = "|cffa335ee|Hitem:168353::::::::120:264::6:4:4824:1517:4786:6270:::|h[빛 없는 심연의 두건]|h|r",
					["time"] = 1577451629,
					["name"] = "검은바다 거수: 신화",
					["costCurrencyID"] = 1580,
				}, -- [2]
				{
					["item"] = "|cffa335ee|Hitem:168384::::::::120:264::6:3:4800:1517:4786:::|h[파도척추 허리띠]|h|r",
					["time"] = 1577450596,
					["name"] = "심연 사령관 사이바라: 신화",
					["costCurrencyID"] = 1580,
				}, -- [3]
				{
					["money"] = 20000000,
					["time"] = 1575122308,
					["name"] = "검은바다 거수: 신화",
					["costCurrencyID"] = 1580,
				}, -- [4]
				{
					["money"] = 20000000,
					["time"] = 1575119789,
					["name"] = "심연 사령관 사이바라: 신화",
					["costCurrencyID"] = 1580,
				}, -- [5]
				{
					["name"] = "톨 다고르: 신화 쐐기돌",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1573352857,
					["costCurrencyID"] = 1580,
				}, -- [6]
				{
					["name"] = "웨이크레스트 저택: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1571315737,
					["currencyID"] = 1553,
				}, -- [7]
				{
					["name"] = "야즈마: 신화 쐐기돌",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1569681871,
					["costCurrencyID"] = 1580,
				}, -- [8]
				{
					["name"] = "폭풍의 사원: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1567516783,
					["currencyID"] = 1553,
				}, -- [9]
				{
					["name"] = "고라크 툴: 신화 쐐기돌",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1567003007,
					["costCurrencyID"] = 1580,
				}, -- [10]
				{
					["name"] = "왕노다지 광산!!: 신화 쐐기돌",
					["money"] = 750,
					["currencyID"] = 1553,
					["time"] = 1566398026,
					["costCurrencyID"] = 1580,
				}, -- [11]
				{
					["time"] = 1565794391,
					["name"] = "왕노다지 광산!!: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159663::::::::120:262::16:3:5009:1597:4786:::|h[OF-77-IZI3 군중 퇴치기]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [12]
				{
					["name"] = "웨케마라",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1564802751,
					["currencyID"] = 1553,
				}, -- [13]
				{
					["name"] = "모굴 라즈덩크: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1563804791,
					["currencyID"] = 1553,
				}, -- [14]
				{
					["money"] = 20000000,
					["name"] = "모굴 라즈덩크: 신화 쐐기돌",
					["time"] = 1560866689,
					["costCurrencyID"] = 1580,
				}, -- [15]
				{
					["item"] = "|cffa335ee|Hitem:158317::::::::120:262::16:3:5010:1572:4786:::|h[영원한 섬김의 건틀릿]|h|r",
					["time"] = 1559832541,
					["name"] = "아탈다자르: 신화 쐐기돌",
					["costCurrencyID"] = 1580,
				}, -- [16]
				{
					["money"] = 20000000,
					["time"] = 1559478965,
					["name"] = "아탈다자르: 신화 쐐기돌",
					["costCurrencyID"] = 1580,
				}, -- [17]
				{
					["time"] = 1559051282,
					["name"] = "썩은굴: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159396::::::::120:262::16:3:5010:1572:4786:::|h[감염된 자의 방수장화]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [18]
				{
					["name"] = "풀려난 흉물: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159463::::::::120:262::16:4:5010:4802:1572:4786:::|h[맥동하는 핏줄의 반지]|h|r",
					["time"] = 1558194959,
					["costCurrencyID"] = 1580,
				}, -- [19]
				{
					["time"] = 1557848329,
					["name"] = "썩은굴: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159402::::::::120:262::16:4:5010:4802:1572:4786:::|h[핏빛 열정의 허리보호대]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [20]
				{
					["name"] = "부패한 이부스",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1556369876,
					["currencyID"] = 1553,
				}, -- [21]
				{
					["time"] = 1555937465,
					["name"] = "자유지대: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:158356::::::::120:262::16:4:5010:43:1572:4786:::|h[껍질차기 장화]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [22]
				{
					["time"] = 1554560229,
					["name"] = "야즈마: 신화 쐐기돌",
					["item"] = "|cffa335ee|Hitem:159610::::::::120:262::16:4:5010:41:1572:4786:::|h[기어다니는 암흑의 유리병]|h|r",
					["costCurrencyID"] = 1580,
				}, -- [23]
				{
					["name"] = "속삭임의 볼지스: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1554035875,
					["currencyID"] = 1553,
				}, -- [24]
				{
					["name"] = "자유지대: 신화 쐐기돌",
					["money"] = 750,
					["costCurrencyID"] = 1580,
					["time"] = 1553175721,
					["currencyID"] = 1553,
				}, -- [25]
			},
			["PlayedLevel"] = 1179626,
			["Money"] = 2548197109,
			["MythicKeyBest"] = {
				["ResetTime"] = 1579733999,
				["level"] = 0,
				["WeeklyReward"] = false,
				["LastWeekLevel"] = 11,
			},
			["DailyResetTime"] = 1579301999,
			["IL"] = 445.5,
			["Order"] = 50,
		},
		["쌩뚱마적 - 렉사르"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "티리스팔 숲",
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "ROGUE",
			["Race"] = "언데드",
			["Warmode"] = false,
			["Level"] = 7,
			["LClass"] = "도적",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 7660,
			["currency"] = {
			},
			["LastSeen"] = 1559916149,
			["Money"] = 563,
			["DailyResetTime"] = 1579301999,
			["Order"] = 50,
			["Emissary"] = {
			},
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 1774,
			["Faction"] = "Horde",
			["ILe"] = 2.3125,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["IL"] = 2.3125,
		},
		["쌩뚱마장 - 렉사르"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "티리스팔 숲",
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "WARLOCK",
			["Race"] = "언데드",
			["Warmode"] = false,
			["Level"] = 11,
			["LClass"] = "흑마법사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 53697,
			["IL"] = 7.3125,
			["LastSeen"] = 1559916452,
			["Money"] = 15998,
			["Skills"] = {
			},
			["Order"] = 50,
			["Emissary"] = {
			},
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 7693,
			["Faction"] = "Horde",
			["ILe"] = 6.4375,
			["DailyResetTime"] = 1579301999,
			["Quests"] = {
			},
			["currency"] = {
			},
		},
		["받아줘요악사 - 아즈샤라"] = {
			["lastbossyell"] = "지옥 군주 카자",
			["Paragon"] = {
			},
			["IL"] = 138.125,
			["isResting"] = false,
			["Emissary"] = {
			},
			["Class"] = "DEMONHUNTER",
			["LastSeen"] = 1560536083,
			["Skills"] = {
			},
			["Order"] = 50,
			["Race"] = "블러드 엘프",
			["WeeklyResetTime"] = 1579733999,
			["Warmode"] = false,
			["MythicKey"] = {
			},
			["Level"] = 98,
			["LClass"] = "악마사냥꾼",
			["RBGrating"] = 0,
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedTotal"] = 2267,
			["currency"] = {
			},
			["lastbossyelltime"] = 1560535696,
			["Money"] = 2490000,
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["XP"] = 148768,
			["oRace"] = "BloodElf",
			["Show"] = "saved",
			["MaxXP"] = 486550,
			["PlayedLevel"] = 2267,
			["Faction"] = "Horde",
			["ILe"] = 138.125,
			["DailyResetTime"] = 1579301999,
			["Quests"] = {
			},
			["Zone"] = "마르둠 - 산산조각난 심연",
		},
		["아호와의증인 - 아즈샤라"] = {
			["Paragon"] = {
			},
			["WeeklyResetTime"] = 1579733999,
			["Zone"] = "실버문",
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Class"] = "MONK",
			["Race"] = "블러드 엘프",
			["Warmode"] = false,
			["Level"] = 9,
			["LClass"] = "수도사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 7750,
			["Emissary"] = {
			},
			["LastSeen"] = 1559927566,
			["Money"] = 3187,
			["DailyResetTime"] = 1579301999,
			["Order"] = 50,
			["IL"] = 7.8125,
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 1882,
			["Faction"] = "Horde",
			["ILe"] = 7.4375,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["currency"] = {
			},
		},
		["쌩뚱마죠 - 렉사르"] = {
			["Paragon"] = {
			},
			["IL"] = 56.3125,
			["Zone"] = "오그리마",
			["Order"] = 50,
			["Class"] = "WARRIOR",
			["Race"] = "타우렌",
			["Warmode"] = false,
			["Level"] = 60,
			["LClass"] = "전사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 2934777,
			["Emissary"] = {
			},
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Money"] = 71493,
			["DailyResetTime"] = 1579301999,
			["LastSeen"] = 1559916355,
			["WeeklyResetTime"] = 1579733999,
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 1254584,
			["Faction"] = "Horde",
			["ILe"] = 54.5,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["currency"] = {
			},
		},
		["공허엘프닷 - 굴단"] = {
			["Paragon"] = {
			},
			["IL"] = 20,
			["Zone"] = "스톰윈드",
			["Order"] = 50,
			["Class"] = "MONK",
			["currency"] = {
			},
			["LastSeen"] = 1556543409,
			["Warmode"] = false,
			["lastbossyell"] = "바라딘 경비병",
			["Level"] = 20,
			["LClass"] = "수도사",
			["RBGrating"] = 0,
			["MythicKey"] = {
			},
			["PlayedTotal"] = 2191,
			["DailyResetTime"] = 1579301999,
			["lastbossyelltime"] = 1556541916,
			["Money"] = 81650,
			["WeeklyResetTime"] = 1579733999,
			["Emissary"] = {
			},
			["Progress"] = {
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 500,
					["unlocked"] = false,
					["numFulfilled"] = 500,
				}, -- [1]
				{
					["isComplete"] = false,
					["isFinish"] = false,
					["numRequired"] = 36000,
					["unlocked"] = false,
					["numFulfilled"] = 0,
				}, -- [2]
			},
			["Show"] = "saved",
			["MythicKeyBest"] = {
				["level"] = 0,
				["ResetTime"] = 1579733999,
				["WeeklyReward"] = false,
			},
			["PlayedLevel"] = 2191,
			["Faction"] = "Alliance",
			["ILe"] = 19.875,
			["Skills"] = {
			},
			["Quests"] = {
			},
			["Race"] = "공허 엘프",
		},
	},
	["spelltip"] = {
		[71041] = {
		},
	},
	["Emissary"] = {
		["Expansion"] = {
			[6] = {
				{
					["questID"] = {
						["Horde"] = 42422,
						["Alliance"] = 42422,
					},
					["questNeed"] = 4,
					["expiredTime"] = 1579302140,
				}, -- [1]
				{
					["questID"] = {
						["Horde"] = 43179,
						["Alliance"] = 43179,
					},
					["questNeed"] = 3,
					["expiredTime"] = 1579388540,
				}, -- [2]
				{
					["questID"] = {
						["Horde"] = 48639,
						["Alliance"] = 48639,
					},
					["questNeed"] = 4,
					["expiredTime"] = 1579474940,
				}, -- [3]
				{
					["questID"] = {
						["Horde"] = 42170,
						["Alliance"] = 42170,
					},
					["questNeed"] = 4,
					["expiredTime"] = 1568502085,
				}, -- [4]
			},
			[7] = {
				{
					["questID"] = {
						["Horde"] = 50606,
						["Alliance"] = 50605,
					},
					["questNeed"] = 4,
					["expiredTime"] = 1579302140,
				}, -- [1]
				{
					["questID"] = {
						["Horde"] = 56120,
						["Alliance"] = 56119,
					},
					["questNeed"] = 4,
					["expiredTime"] = 1579388540,
				}, -- [2]
				{
					["questID"] = {
						["Horde"] = 50602,
						["Alliance"] = 50601,
					},
					["questNeed"] = 4,
					["expiredTime"] = 1579474940,
				}, -- [3]
				{
					["questID"] = {
						["Horde"] = 56120,
						["Alliance"] = 56119,
					},
					["questNeed"] = 4,
					["expiredTime"] = 1568502085,
				}, -- [4]
			},
		},
		["Cache"] = {
			[43179] = "달라란의 키린 토",
			[48639] = "빛의 군대",
			[50562] = "아제로스의 용사들",
			[48641] = "군단척결군",
			[48642] = "아르거스 세력단",
			[42420] = "파론디스의 궁정",
			[50604] = "토르톨란 탐구단",
			[50605] = "얼라이언스 전쟁 지원단",
			[50599] = "프라우드무어 해군",
			[50600] = "잿불단",
			[50601] = "깨어난 폭풍",
			[42170] = "몽술사",
			[50603] = "볼두나이",
			[42234] = "발라리아르",
			[42421] = "나이트폴른",
			[50606] = "호드 전쟁 지원단",
			[42422] = "감시관",
			[42233] = "높은산 부족들",
			[56119] = "파도칼날 안코안",
		},
	},
	["Tooltip"] = {
		["TrackBonus"] = false,
		["Currency1226"] = false,
		["CombineWorldBosses"] = false,
		["HistoryText"] = false,
		["ShowCategories"] = false,
		["Currency738"] = false,
		["ShowRandom"] = true,
		["Progress1"] = true,
		["Currency1718"] = true,
		["ServerOnly"] = false,
		["Currency1716"] = true,
		["TrackDailyQuests"] = true,
		["Currency823"] = false,
		["Currency1191"] = true,
		["ConnectedRealms"] = "group",
		["ServerSort"] = true,
		["ReverseInstances"] = false,
		["CurrencyMax"] = false,
		["ReportResets"] = true,
		["Currency1166"] = true,
		["Currency1560"] = true,
		["SelfFirst"] = true,
		["CategorySort"] = "EXPANSION",
		["ShowSoloCategory"] = false,
		["ShowServer"] = false,
		["NumberFormat"] = true,
		["Warfront1"] = true,
		["ShowExpired"] = false,
		["RaidsFirst"] = true,
		["Currency1149"] = true,
		["CurrencyEarned"] = true,
		["Currency1220"] = true,
		["CurrencyValueColor"] = true,
		["CombineLFR"] = true,
		["Currency994"] = false,
		["EmissaryFullName"] = true,
		["Progress2"] = true,
		["ShowHints"] = true,
		["LimitWarn"] = true,
		["AugmentBonus"] = true,
		["RowHighlight"] = 0.1,
		["DailyWorldQuest"] = true,
		["Currency824"] = false,
		["AbbreviateKeystone"] = true,
		["MythicKey"] = true,
		["Currency1717"] = true,
		["Currency1273"] = true,
		["TrackLFG"] = true,
		["Warfront2"] = true,
		["SelfAlways"] = false,
		["Currency1580"] = true,
		["Currency1587"] = true,
		["NewFirst"] = true,
		["TrackFarm"] = true,
		["Emissary7"] = true,
		["TrackWeeklyQuests"] = true,
		["CategorySpaces"] = false,
		["Currency1129"] = false,
		["ShowHoliday"] = true,
		["FitToScreen"] = true,
		["TrackDeserter"] = true,
		["Currency1155"] = true,
		["Scale"] = 1,
		["Currency1721"] = true,
		["TrackPlayed"] = true,
		["Currency1710"] = true,
		["TrackSkills"] = true,
		["MythicKeyBest"] = true,
		["Currency776"] = false,
		["Currency1101"] = false,
		["TrackParagon"] = true,
		["EmissaryShowCompleted"] = true,
	},
	["MinimapIcon"] = {
		["minimapPos"] = 19.55459132672599,
		["hide"] = false,
	},
	["Instances"] = {
		["화산 심장부"] = {
			["LFDID"] = 48,
			["Expansion"] = 0,
			["RecLevel"] = 60,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["무작위 대격변 (영웅)"] = {
			["LFDID"] = 301,
			["Expansion"] = 3,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["감시관의 금고"] = {
			["LFDID"] = 1044,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["영혼의 아귀"] = {
			["LFDID"] = 1192,
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 110,
			["Show"] = "saved",
		},
		["공찾: 영원한 슬픔의 골짜기"] = {
			["LFDID"] = 839,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["아포크론"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1956,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["공찾: 지옥의 관문"] = {
			["LFDID"] = 1920,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["지옥의 군주 바일머스"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 2015,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["공찾: 블랙핸드의 도가니"] = {
			["LFDID"] = 1359,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["무작위 군단 영웅"] = {
			["LFDID"] = 1046,
			["Expansion"] = 6,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 110,
		},
		["황혼의 시간"] = {
			["LFDID"] = 439,
			["Expansion"] = 3,
			["RecLevel"] = 85,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["조룬달"] = {
			["LFDID"] = 2041,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["과거의 하이잘"] = {
			["LFDID"] = 195,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["별의 궁정"] = {
			["LFDID"] = 1319,
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 110,
			["Show"] = "saved",
		},
		["공찾: 배반자의 탑"] = {
			["LFDID"] = 1922,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["영원한 궁전"] = {
			["Expansion"] = 7,
			["국제금융로 - 굴단"] = {
				[16] = {
					["Expires"] = 0,
					["Extended"] = false,
					["Link"] = "|cffff8000|Hinstancelock:Player-2116-0507AF5A:2164:16:69|h[영원한 궁전]|h|r",
					["ID"] = 350158802,
					["Locked"] = false,
				},
				[15] = {
					["Expires"] = 0,
					["Extended"] = false,
					["Link"] = "|cffff8000|Hinstancelock:Player-2116-0507AF5A:2164:15:255|h[영원한 궁전]|h|r",
					["ID"] = 887448376,
					["Locked"] = false,
				},
			},
			["Show"] = "saved",
			["무시중한디 - 굴단"] = {
				[16] = {
					["Expires"] = 0,
					["Extended"] = false,
					["Link"] = "|cffff8000|Hinstancelock:Player-2116-06595DB7:2164:16:69|h[영원한 궁전]|h|r",
					["ID"] = 888190685,
					["Locked"] = false,
				},
			},
			["RecLevel"] = 120,
			["LFDID"] = 2016,
			["뉘시빨라마 - 굴단"] = {
				[16] = {
					["Expires"] = 0,
					["Extended"] = false,
					["Link"] = "|cffff8000|Hinstancelock:Player-2116-0710D46B:2164:16:69|h[영원한 궁전]|h|r",
					["ID"] = 350112741,
					["Locked"] = false,
				},
				[15] = {
					["Expires"] = 0,
					["Extended"] = false,
					["Link"] = "|cffff8000|Hinstancelock:Player-2116-0710D46B:2164:15:255|h[영원한 궁전]|h|r",
					["ID"] = 887484217,
					["Locked"] = false,
				},
			},
			["Raid"] = true,
		},
		["용의 영혼"] = {
			["LFDID"] = 448,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["공찾: 지하요새"] = {
			["LFDID"] = 841,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 통곡의 전당"] = {
			["LFDID"] = 1919,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["용맹의 시험"] = {
			["LFDID"] = 1439,
			["Expansion"] = 6,
			["RecLevel"] = 109,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["강철 선착장"] = {
			["LFDID"] = 1974,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["어둠의 문 열기"] = {
			["LFDID"] = 1012,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["줄아만"] = {
			["LFDID"] = 340,
			["Expansion"] = 3,
			["RecLevel"] = 85,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["스톰윈드 지하감옥"] = {
			["LFDID"] = 12,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["피의 용광로"] = {
			["LFDID"] = 187,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["시초의 전당"] = {
			["LFDID"] = 321,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["마력의 눈"] = {
			["LFDID"] = 211,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["우트가드 성채"] = {
			["LFDID"] = 242,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["작전명: 메카곤 - 작업장"] = {
			["LFDID"] = 2028,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = false,
		},
		["살게라스의 무덤"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["LFDID"] = 1527,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["소용돌이 누각"] = {
			["LFDID"] = 1147,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["바위심장부"] = {
			["LFDID"] = 1148,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["무작위 드레노어의 전쟁군주 던전"] = {
			["LFDID"] = 788,
			["Expansion"] = 5,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["혈투의 전장 - 수도 정원"] = {
			["LFDID"] = 36,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["죽음의 폐광"] = {
			["LFDID"] = 326,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["검은 사원"] = {
			["LFDID"] = 196,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["웨케마라"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2363,
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["지옥불 성채"] = {
			["LFDID"] = 989,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["검은바위 첨탑 하층"] = {
			["LFDID"] = 32,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 다자알로 공성전"] = {
			["LFDID"] = 1945,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["검은바위 동굴"] = {
			["LFDID"] = 323,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["음영파 수도원"] = {
			["LFDID"] = 1468,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["시간의 끝"] = {
			["LFDID"] = 1152,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["스톰스타우트 양조장"] = {
			["LFDID"] = 1466,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["아나무즈"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1790,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["안퀴라즈 폐허"] = {
			["LFDID"] = 160,
			["Expansion"] = 0,
			["RecLevel"] = 60,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["어둠달 지하묘지"] = {
			["LFDID"] = 1976,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["시간의 동굴 - 기념 행사"] = {
			["LFDID"] = 1911,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["공찾: 고통받는 수호자들"] = {
			["LFDID"] = 1927,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["공찾: 아제로스의 기억: 리치 왕의 분노"] = {
			["LFDID"] = 2017,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["흑요석 성소"] = {
			["LFDID"] = 238,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["니소그"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1749,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["레반투스"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1769,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["공찾: 판테온의 권좌"] = {
			["LFDID"] = 1913,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["스칼로맨스"] = {
			["LFDID"] = 472,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["무작위 영웅 (격전의 아제로스)"] = {
			["LFDID"] = 1671,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 120,
		},
		["드락타론 성채"] = {
			["LFDID"] = 215,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["깨어난 도시 나이알로사"] = {
			["LFDID"] = 2035,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["검은바위 나락 - 감금 구역"] = {
			["LFDID"] = 30,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["세스랄리스 사원"] = {
			["LFDID"] = 1775,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = false,
			["RecLevel"] = 110,
		},
		["안식의 숲"] = {
			["LFDID"] = 2025,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["검은 떼까마귀 요새"] = {
			["LFDID"] = 1205,
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 110,
			["Show"] = "saved",
		},
		["메마른 짐"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1796,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["공찾: 잊혀진 심연"] = {
			["LFDID"] = 836,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["에메랄드의 악몽"] = {
			["LFDID"] = 1350,
			["Expansion"] = 6,
			["Raid"] = true,
			["RecLevel"] = 110,
			["Show"] = "saved",
		},
		["무작위 시간여행 던전 (드레노어의 전쟁군주)"] = {
			["Show"] = "saved",
			["Expansion"] = 5,
			["LFDID"] = 1971,
			["Holiday"] = true,
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["낙스라마스"] = {
			["LFDID"] = 227,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["운다스타"] = {
			["Show"] = "saved",
			["Expansion"] = 4,
			["WorldBoss"] = 826,
			["RecLevel"] = 90,
			["Raid"] = true,
		},
		["공찾: 높은 벽의 도시"] = {
			["LFDID"] = 1363,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["공찾: 모구샨의 수호자"] = {
			["LFDID"] = 830,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["무작위 군단 던전"] = {
			["LFDID"] = 1045,
			["Expansion"] = 6,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["무작위 판다리아의 안개 던전 (영웅)"] = {
			["LFDID"] = 462,
			["Expansion"] = 4,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["공찾: 검은 제련소"] = {
			["LFDID"] = 1360,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["천둥의 왕좌"] = {
			["LFDID"] = 634,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["혈투의 전장 - 고르독 광장"] = {
			["LFDID"] = 38,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 높은군주의 탑"] = {
			["LFDID"] = 1365,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["공찾: 피의 전당"] = {
			["LFDID"] = 1367,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["공찾: 지옥돌파"] = {
			["LFDID"] = 1366,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["마나 무덤"] = {
			["LFDID"] = 1013,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["울매스"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2362,
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["태양샘"] = {
			["LFDID"] = 199,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["왕자 사르사룬"] = {
			["Show"] = "saved",
			["Expansion"] = 0,
			["RecLevel"] = 80,
			["Raid"] = false,
			["Holiday"] = true,
			["LFDID"] = 310,
		},
		["보랏빛 요새 침공"] = {
			["LFDID"] = 1209,
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 105,
			["Show"] = "saved",
		},
		["십자군 사령관의 시험장"] = {
			["LFDID"] = 250,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["삼두정의 권좌"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["LFDID"] = 1535,
			["Raid"] = false,
			["RecLevel"] = 110,
		},
		["공찾: 육체의 축복"] = {
			["LFDID"] = 2038,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["증기 저장고"] = {
			["LFDID"] = 185,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["무작위 리치 왕 (영웅)"] = {
			["LFDID"] = 262,
			["Expansion"] = 2,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 80,
		},
		["어둠의 미궁"] = {
			["LFDID"] = 181,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["모래먹보 크롤로크"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2210,
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["가라앉은 사원"] = {
			["LFDID"] = 28,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 영원한 봄의 정원"] = {
			["LFDID"] = 834,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["루크마르"] = {
			["Show"] = "saved",
			["Expansion"] = 5,
			["WorldBoss"] = 1262,
			["RecLevel"] = 100,
			["Raid"] = true,
		},
		["옥룡사"] = {
			["LFDID"] = 1469,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["무작위 황혼의 시간 (영웅)"] = {
			["LFDID"] = 434,
			["Expansion"] = 3,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["세데크 전당"] = {
			["LFDID"] = 180,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["통곡의 동굴"] = {
			["LFDID"] = 1,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["자유지대"] = {
			["LFDID"] = 1773,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = false,
			["RecLevel"] = 110,
		},
		["분노의 샤"] = {
			["Show"] = "saved",
			["Expansion"] = 4,
			["WorldBoss"] = 691,
			["RecLevel"] = 90,
			["Raid"] = true,
		},
		["안퀴라즈 사원"] = {
			["LFDID"] = 161,
			["Expansion"] = 0,
			["RecLevel"] = 60,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["공찾: 진홍빛 내리막"] = {
			["LFDID"] = 1732,
			["Expansion"] = 7,
			["Raid"] = true,
			["RecLevel"] = 120,
			["Show"] = "saved",
		},
		["우트가드 첨탑"] = {
			["LFDID"] = 1020,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["티제인"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2139,
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["공찾: 아제로스의 기억: 불타는 성전"] = {
			["LFDID"] = 2004,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["모구샨 궁전"] = {
			["LFDID"] = 1467,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["스트라솔름 - 공무용 입구"] = {
			["LFDID"] = 274,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["시간여행 공격대: 불의 땅"] = {
			["Show"] = "saved",
			["Expansion"] = 3,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Holiday"] = true,
			["LFDID"] = 2026,
		},
		["그림 바톨"] = {
			["LFDID"] = 1149,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["무작위 시간여행 던전 (판다리아의 안개)"] = {
			["LFDID"] = 1453,
			["Expansion"] = 4,
			["Show"] = "saved",
			["Random"] = true,
			["Raid"] = false,
			["Holiday"] = true,
			["RecLevel"] = 0,
		},
		["무작위 리치 왕 던전"] = {
			["LFDID"] = 261,
			["Expansion"] = 2,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 80,
		},
		["단체 군도 탐험"] = {
			["LFDID"] = 2054,
			["Expansion"] = 7,
			["Scenario"] = true,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Random"] = true,
			["Raid"] = true,
		},
		["카라잔"] = {
			["LFDID"] = 175,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["공찾: 알른의 균열"] = {
			["LFDID"] = 1926,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["파괴의 / 영생의"] = {
			["Show"] = "saved",
			["Expansion"] = 5,
			["WorldBoss"] = 1211,
			["RecLevel"] = 100,
			["Raid"] = true,
		},
		["번개의 전당"] = {
			["LFDID"] = 1018,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["폭풍우 요새"] = {
			["LFDID"] = 193,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["석양문"] = {
			["LFDID"] = 1464,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["줄파락"] = {
			["LFDID"] = 24,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["다시 찾은 카라잔 하층"] = {
			["LFDID"] = 1475,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["신화 난이도 무작위 군도 탐험"] = {
			["LFDID"] = 1891,
			["Expansion"] = 7,
			["Scenario"] = true,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Random"] = true,
			["Raid"] = false,
		},
		["대공주 테라드라스"] = {
			["Show"] = "saved",
			["Expansion"] = 0,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Holiday"] = true,
			["LFDID"] = 309,
		},
		["시간여행 공격대: 울두아르"] = {
			["Show"] = "saved",
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 110,
			["Holiday"] = true,
			["LFDID"] = 1677,
		},
		["알카트라즈"] = {
			["LFDID"] = 1011,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["지하수렁"] = {
			["LFDID"] = 186,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["심문관 메토"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 2012,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["휴몽그리스"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1770,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["검은심연 나락"] = {
			["LFDID"] = 10,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 희망의 끝"] = {
			["LFDID"] = 1914,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["위대한 여제 셰크자라"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2378,
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["모구샨 금고"] = {
			["LFDID"] = 532,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["시바쉬"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1885,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["공찾: 밤의 첨탑"] = {
			["LFDID"] = 1923,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["파멸철로 정비소"] = {
			["LFDID"] = 1006,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["시간여행 공격대: 검은 사원"] = {
			["Show"] = "saved",
			["Expansion"] = 1,
			["Raid"] = true,
			["RecLevel"] = 110,
			["Holiday"] = true,
			["LFDID"] = 1533,
		},
		["전쟁인도자 예나즈"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2198,
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["넬타리온의 둥지"] = {
			["LFDID"] = 1207,
			["Expansion"] = 6,
			["RecLevel"] = 100,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["오닉시아의 둥지"] = {
			["LFDID"] = 257,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["공찾: 죽음의 계약"] = {
			["LFDID"] = 1949,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["아킨둔"] = {
			["LFDID"] = 1975,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["나락크"] = {
			["Show"] = "saved",
			["Expansion"] = 4,
			["WorldBoss"] = 814,
			["RecLevel"] = 90,
			["Raid"] = true,
		},
		["무작위 판다리아의 안개 던전"] = {
			["LFDID"] = 463,
			["Expansion"] = 4,
			["Show"] = "saved",
			["RecLevel"] = 0,
			["Random"] = true,
			["Raid"] = false,
		},
		["공찾: 헌신의 전당"] = {
			["LFDID"] = 2037,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["십자군의 시험장"] = {
			["LFDID"] = 248,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["용사의 시험장"] = {
			["LFDID"] = 249,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["검은바위 나락 - 상부 도시"] = {
			["LFDID"] = 276,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["영원한 봄의 정원"] = {
			["LFDID"] = 536,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 제국의 몰락"] = {
			["LFDID"] = 1946,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["바다떠돌이"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1795,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["메카나르"] = {
			["LFDID"] = 192,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["대사자 화염채찍"] = {
			["LFDID"] = 308,
			["Expansion"] = 0,
			["Show"] = "saved",
			["RecLevel"] = 80,
			["Holiday"] = true,
			["Raid"] = false,
		},
		["강제 노역소"] = {
			["LFDID"] = 1015,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["공찾: 헌신한 자의 심연"] = {
			["LFDID"] = 2010,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["공찾: 데스윙의 추락"] = {
			["LFDID"] = 844,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["그림자송곳니 성채"] = {
			["LFDID"] = 327,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["공찾: 다가오는 공포"] = {
			["LFDID"] = 832,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["네 천신"] = {
			["Show"] = "saved",
			["Expansion"] = 4,
			["WorldBoss"] = 857,
			["RecLevel"] = 90,
			["Raid"] = true,
		},
		["공찾: 살점구체자의 전당"] = {
			["LFDID"] = 837,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["소타나토르"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 2014,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["지옥불 성루"] = {
			["LFDID"] = 188,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["공찾: 운명의 환영"] = {
			["LFDID"] = 2036,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["코렌 다이어브루"] = {
			["LFDID"] = 287,
			["Expansion"] = 0,
			["RecLevel"] = 110,
			["Raid"] = false,
			["Holiday"] = true,
			["Show"] = "saved",
		},
		["마라우돈 - 악의 동굴"] = {
			["LFDID"] = 272,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["검은바위 첨탑 상층"] = {
			["LFDID"] = 1004,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 잿가루작업장"] = {
			["LFDID"] = 1361,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["루비 성소"] = {
			["LFDID"] = 294,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["무작위 불타는 성전 (영웅)"] = {
			["LFDID"] = 260,
			["Expansion"] = 1,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 70,
		},
		["으스러진 손의 전당"] = {
			["LFDID"] = 1014,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["무작위 판다리아의 안개 시나리오"] = {
			["LFDID"] = 493,
			["Expansion"] = 4,
			["Scenario"] = true,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["무작위 드레노어의 전쟁군주 던전 (영웅)"] = {
			["LFDID"] = 789,
			["Expansion"] = 5,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["공찾: 고룡쉼터 사원 탈환"] = {
			["LFDID"] = 843,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["아카본 석실"] = {
			["LFDID"] = 240,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["혈투의 전장 - 굽이나무 지구"] = {
			["LFDID"] = 34,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["마력의 탑"] = {
			["LFDID"] = 1019,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["아탈다자르"] = {
			["LFDID"] = 1772,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = false,
			["RecLevel"] = 110,
		},
		["갈레온"] = {
			["Show"] = "saved",
			["Expansion"] = 4,
			["WorldBoss"] = 725,
			["RecLevel"] = 90,
			["Raid"] = true,
		},
		["아쉬란"] = {
			["LFDID"] = 1127,
			["Expansion"] = 0,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["톨비르의 잃어버린 도시"] = {
			["LFDID"] = 1151,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["신록의 정원"] = {
			["LFDID"] = 191,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["마그테리돈의 둥지"] = {
			["LFDID"] = 176,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["황혼의 요새"] = {
			["LFDID"] = 316,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["폭풍의 사원"] = {
			["LFDID"] = 1774,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 110,
			["Raid"] = false,
		},
		["영원의 샘"] = {
			["LFDID"] = 437,
			["Expansion"] = 3,
			["RecLevel"] = 85,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["높은망치"] = {
			["LFDID"] = 897,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["군드락"] = {
			["LFDID"] = 1017,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["작전명: 메카곤"] = {
			["LFDID"] = 2006,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = false,
			["RecLevel"] = 120,
		},
		["줄구룹"] = {
			["LFDID"] = 334,
			["Expansion"] = 3,
			["RecLevel"] = 85,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 타락의 심장"] = {
			["LFDID"] = 1733,
			["Expansion"] = 7,
			["RecLevel"] = 120,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["왕관화학회사"] = {
			["Show"] = "saved",
			["Expansion"] = 0,
			["Raid"] = false,
			["RecLevel"] = 0,
			["Holiday"] = true,
			["LFDID"] = 288,
		},
		["보랄러스 공성전"] = {
			["LFDID"] = 1700,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = false,
		},
		["마라우돈 - 썩은포자 동굴"] = {
			["LFDID"] = 26,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["용맹의 전당"] = {
			["LFDID"] = 1194,
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["공찾: 성대한 환영"] = {
			["LFDID"] = 2009,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["밤의 요새"] = {
			["LFDID"] = 1353,
			["Expansion"] = 6,
			["Raid"] = true,
			["RecLevel"] = 110,
			["Show"] = "saved",
		},
		["아주레토스"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2199,
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["파도의 왕좌"] = {
			["LFDID"] = 1150,
			["Expansion"] = 3,
			["Raid"] = false,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["공찾: 강철 설비 시설"] = {
			["LFDID"] = 1362,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["샤르토스"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1763,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["스트라솔름 - 정문"] = {
			["LFDID"] = 40,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["톨 다고르"] = {
			["LFDID"] = 1778,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 115,
			["Raid"] = false,
		},
		["공찾: 아제로스의 기억: 대격변"] = {
			["LFDID"] = 2018,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["공찾: 승리가 아니면 죽음을"] = {
			["LFDID"] = 1950,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["하늘탑"] = {
			["LFDID"] = 1977,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 비전의 수로"] = {
			["LFDID"] = 1925,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["작전명: 메카곤 - 고철장"] = {
			["LFDID"] = 2027,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = false,
		},
		["오큘라러스"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 2013,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["무작위 오리지널 던전"] = {
			["LFDID"] = 258,
			["Expansion"] = 0,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 55,
		},
		["영원한 밤의 대성당"] = {
			["LFDID"] = 1488,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["우박 피조물"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2197,
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["공찾: 빛의 틈"] = {
			["LFDID"] = 1916,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["공찾: 용맹의 시험"] = {
			["LFDID"] = 1921,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["불의 땅"] = {
			["LFDID"] = 362,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["여군주 알루라델"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 2011,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["다자알로 전투"] = {
			["LFDID"] = 1944,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["아즈샤라의 눈"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 100,
			["LFDID"] = 1175,
		},
		["불뱀 제단"] = {
			["LFDID"] = 194,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["얼음왕관 성채"] = {
			["LFDID"] = 280,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["검은날개 둥지"] = {
			["LFDID"] = 50,
			["Expansion"] = 0,
			["RecLevel"] = 60,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["가시덩굴 구릉"] = {
			["LFDID"] = 20,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["무작위 불타는 성전 던전"] = {
			["Show"] = "saved",
			["Expansion"] = 1,
			["쌩뚱마삼 - 렉사르"] = {
			},
			["LFDID"] = 259,
			["RecLevel"] = 65,
			["Random"] = true,
			["Raid"] = false,
		},
		["영혼의 제련소"] = {
			["LFDID"] = 252,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["어둠심장 숲"] = {
			["LFDID"] = 1202,
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["공찾: 금지된 내리막"] = {
			["LFDID"] = 1915,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["공찾: 격리의 전당"] = {
			["LFDID"] = 1731,
			["Expansion"] = 7,
			["RecLevel"] = 120,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["고위 군주 카자크"] = {
			["Show"] = "saved",
			["Expansion"] = 5,
			["WorldBoss"] = 1452,
			["RecLevel"] = 100,
			["Raid"] = true,
		},
		["서리 군주 아훈"] = {
			["Show"] = "saved",
			["Expansion"] = 0,
			["Raid"] = false,
			["RecLevel"] = 110,
			["Holiday"] = true,
			["LFDID"] = 286,
		},
		["공찾: 깨어나는 꿈"] = {
			["LFDID"] = 2039,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["다시 찾은 카라잔"] = {
			["LFDID"] = 1347,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 얼라이언스의 힘"] = {
			["LFDID"] = 1947,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["붉은십자군 수도원"] = {
			["LFDID"] = 474,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 화신의 방"] = {
			["LFDID"] = 1918,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["울디르"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["RecLevel"] = 120,
			["Raid"] = true,
			["LFDID"] = 1889,
		},
		["무작위 시간여행 던전 (불타는 성전)"] = {
			["Show"] = "saved",
			["Expansion"] = 1,
			["LFDID"] = 744,
			["Random"] = true,
			["Raid"] = false,
			["Holiday"] = true,
			["RecLevel"] = 0,
		},
		["오르도스"] = {
			["Show"] = "saved",
			["Expansion"] = 4,
			["WorldBoss"] = 861,
			["RecLevel"] = 90,
			["Raid"] = true,
		},
		["공찾: 파괴자의 탑"] = {
			["LFDID"] = 1369,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["상록숲"] = {
			["LFDID"] = 1972,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["검은날개 강림지"] = {
			["LFDID"] = 314,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["성난불길 협곡"] = {
			["LFDID"] = 4,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 검은가지"] = {
			["LFDID"] = 1912,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["지아라크"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2141,
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["공찾: 응보의 성문"] = {
			["LFDID"] = 840,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["옛 스트라솔름"] = {
			["LFDID"] = 210,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["군도 탐험"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["Scenario"] = true,
			["LFDID"] = 1762,
			["RecLevel"] = 120,
			["Random"] = true,
			["Raid"] = false,
		},
		["무작위 시간여행 던전 (리치 왕의 분노)"] = {
			["Show"] = "saved",
			["Expansion"] = 2,
			["LFDID"] = 995,
			["Random"] = true,
			["Raid"] = false,
			["Holiday"] = true,
			["RecLevel"] = 0,
		},
		["아키나이 납골당"] = {
			["LFDID"] = 178,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["다시 찾은 카라잔 상층"] = {
			["LFDID"] = 1474,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 기만자의 몰락"] = {
			["LFDID"] = 1917,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["그룰의 둥지"] = {
			["LFDID"] = 177,
			["Expansion"] = 1,
			["RecLevel"] = 70,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["저주받은 기사"] = {
			["Show"] = "saved",
			["Expansion"] = 0,
			["Raid"] = false,
			["RecLevel"] = 110,
			["Holiday"] = true,
			["LFDID"] = 285,
		},
		["카이주 가즈릴라"] = {
			["LFDID"] = 306,
			["Expansion"] = 0,
			["RecLevel"] = 80,
			["Raid"] = false,
			["Holiday"] = true,
			["Show"] = "saved",
		},
		["보랏빛 요새"] = {
			["LFDID"] = 221,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["마법학자의 정원"] = {
			["LFDID"] = 1154,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["영원의 눈"] = {
			["LFDID"] = 237,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["돌의 전당"] = {
			["LFDID"] = 213,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["투영의 전당"] = {
			["LFDID"] = 256,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["안카헤트: 고대 왕국"] = {
			["LFDID"] = 1016,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["폭풍의 용광로"] = {
			["LFDID"] = 1954,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["피망치 잿가루 광산"] = {
			["LFDID"] = 1973,
			["Expansion"] = 5,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["주둔지 우두머리"] = {
			["Show"] = "saved",
			["Expansion"] = 5,
			["WorldBoss"] = 9001,
			["RecLevel"] = 100,
			["Raid"] = true,
		},
		["사론의 구덩이"] = {
			["LFDID"] = 1153,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["공찾: 별들의 원"] = {
			["LFDID"] = 2011,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["공찾: 왕립 도서관"] = {
			["LFDID"] = 1924,
			["Expansion"] = 6,
			["RecLevel"] = 110,
			["Raid"] = true,
			["Show"] = "saved",
		},
		["공찾: 다자알로 방어전"] = {
			["LFDID"] = 1948,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["공찾: 어둠의 보루"] = {
			["LFDID"] = 1368,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["칼라미르"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1774,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["썩은굴"] = {
			["LFDID"] = 1777,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 110,
			["Raid"] = false,
		},
		["공찾: 폭풍의 용광로"] = {
			["LFDID"] = 1951,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = true,
			["RecLevel"] = 120,
		},
		["무작위 던전 (격전의 아제로스)"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["LFDID"] = 1670,
			["RecLevel"] = 0,
			["Random"] = true,
			["Raid"] = false,
		},
		["냉혈의 드루곤"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1789,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["왕들의 안식처"] = {
			["LFDID"] = 1785,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = false,
			["RecLevel"] = 120,
		},
		["오그리마 공성전"] = {
			["LFDID"] = 766,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["말리피쿠스"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1884,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["브루탈루스"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1883,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["바라딘 요새"] = {
			["LFDID"] = 329,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["대지파괴자 부클라즈"] = {
			["Show"] = "saved",
			["Expansion"] = 7,
			["WorldBoss"] = 2381,
			["RecLevel"] = 120,
			["Raid"] = true,
		},
		["울다만"] = {
			["LFDID"] = 22,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["왕노다지 광산!!"] = {
			["LFDID"] = 1776,
			["Expansion"] = 7,
			["Show"] = "saved",
			["Raid"] = false,
			["RecLevel"] = 115,
		},
		["공찾: 셰크지르의 악몽"] = {
			["LFDID"] = 833,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 잔달라 부족 최후의 저항"] = {
			["LFDID"] = 835,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["던홀드 탈출"] = {
			["LFDID"] = 183,
			["Expansion"] = 1,
			["Raid"] = false,
			["RecLevel"] = 70,
			["Show"] = "saved",
		},
		["비전로"] = {
			["LFDID"] = 1190,
			["Expansion"] = 6,
			["Raid"] = false,
			["RecLevel"] = 110,
			["Show"] = "saved",
		},
		["붉은십자군 전당"] = {
			["LFDID"] = 473,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["놈리건"] = {
			["LFDID"] = 14,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["안토러스 - 불타는 왕좌"] = {
			["LFDID"] = 1642,
			["Expansion"] = 6,
			["Show"] = "saved",
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["무작위 대격변 던전"] = {
			["LFDID"] = 300,
			["Expansion"] = 3,
			["Show"] = "saved",
			["RecLevel"] = 0,
			["Random"] = true,
			["Raid"] = false,
		},
		["네 바람의 왕좌"] = {
			["LFDID"] = 318,
			["Expansion"] = 3,
			["Raid"] = true,
			["RecLevel"] = 85,
			["Show"] = "saved",
		},
		["대모 폴누나"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 2010,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["무작위 시간여행 던전 (대격변)"] = {
			["Show"] = "saved",
			["Expansion"] = 3,
			["LFDID"] = 1146,
			["Random"] = true,
			["Raid"] = false,
			["Holiday"] = true,
			["RecLevel"] = 0,
		},
		["마라우돈 - 대지노래 폭포"] = {
			["LFDID"] = 273,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 폭풍의 첨탑"] = {
			["LFDID"] = 838,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 비전 성소"] = {
			["LFDID"] = 1364,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["니우짜오 사원 공성전투"] = {
			["LFDID"] = 1465,
			["Expansion"] = 4,
			["Raid"] = false,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["마귀 나자크"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1783,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["울두아르"] = {
			["LFDID"] = 244,
			["Expansion"] = 2,
			["Raid"] = true,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["공찾: 폭군의 몰락"] = {
			["LFDID"] = 842,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["무작위 판다리아의 안개 영웅 시나리오"] = {
			["LFDID"] = 641,
			["Expansion"] = 4,
			["Scenario"] = true,
			["Show"] = "saved",
			["Raid"] = false,
			["Random"] = true,
			["RecLevel"] = 0,
		},
		["웨이크레스트 저택"] = {
			["LFDID"] = 1779,
			["Expansion"] = 7,
			["Show"] = "saved",
			["RecLevel"] = 110,
			["Raid"] = false,
		},
		["아졸네룹"] = {
			["LFDID"] = 241,
			["Expansion"] = 2,
			["Raid"] = false,
			["RecLevel"] = 80,
			["Show"] = "saved",
		},
		["검은바위 용광로"] = {
			["LFDID"] = 900,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
		["공포의 심장"] = {
			["LFDID"] = 534,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["영혼약탈자"] = {
			["Show"] = "saved",
			["Expansion"] = 6,
			["WorldBoss"] = 1756,
			["RecLevel"] = 110,
			["Raid"] = true,
		},
		["가시덩굴 우리"] = {
			["LFDID"] = 16,
			["Expansion"] = 0,
			["RecLevel"] = 0,
			["Raid"] = false,
			["Show"] = "saved",
		},
		["공찾: 신비의 금고"] = {
			["LFDID"] = 831,
			["Expansion"] = 4,
			["Raid"] = true,
			["RecLevel"] = 90,
			["Show"] = "saved",
		},
		["공찾: 검은 문"] = {
			["LFDID"] = 1370,
			["Expansion"] = 5,
			["Raid"] = true,
			["RecLevel"] = 100,
			["Show"] = "saved",
		},
	},
	["histGeneration"] = 1624,
	["History"] = {
		["무시중한디 - 굴단:심장의 방 - 시나리오:scenario:12:1618"] = {
			["last"] = 1579288937,
			["create"] = 1579288763,
			["desc"] = "무시중한디: 심장의 방 - 시나리오 - 일반 시나리오",
		},
		["무시중한디 - 굴단:시초의 전당:scenario:12:1617"] = {
			["last"] = 1579286161,
			["create"] = 1579284593,
			["desc"] = "무시중한디: 시초의 전당 - 일반 시나리오",
		},
	},
	["Indicators"] = {
		["R2ClassColor"] = true,
		["D2Indicator"] = "BLANK",
		["R7Color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
		},
		["R5Color"] = {
			0, -- [1]
			0, -- [2]
			1, -- [3]
		},
		["R1Text"] = "KILLED/TOTAL",
		["R4Indicator"] = "BLANK",
		["R1Color"] = {
			0.6, -- [1]
			0.6, -- [2]
			0, -- [3]
		},
		["R0Indicator"] = "BLANK",
		["R8ClassColor"] = true,
		["D2ClassColor"] = true,
		["R4ClassColor"] = true,
		["R6ClassColor"] = true,
		["D2Color"] = {
			0, -- [1]
			1, -- [2]
			0, -- [3]
		},
		["D1Text"] = "KILLED/TOTAL",
		["R5Text"] = "KILLED/TOTAL",
		["R7Text"] = "KILLED/TOTALH",
		["D1Indicator"] = "BLANK",
		["R8Color"] = {
			1, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["D3Indicator"] = "BLANK",
		["D3ClassColor"] = true,
		["R6Indicator"] = "BLANK",
		["R6Color"] = {
			0, -- [1]
			1, -- [2]
			0, -- [3]
		},
		["D1Color"] = {
			0, -- [1]
			0.6, -- [2]
			0, -- [3]
		},
		["R4Color"] = {
			1, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["R7Indicator"] = "BLANK",
		["R2Text"] = "KILLED/TOTAL",
		["R8Indicator"] = "BLANK",
		["R0Text"] = "KILLED/TOTAL",
		["R0Color"] = {
			0.6, -- [1]
			0.6, -- [2]
			0, -- [3]
		},
		["R1Indicator"] = "BLANK",
		["R2Color"] = {
			0.6, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["R3Indicator"] = "BLANK",
		["R7ClassColor"] = true,
		["R5Indicator"] = "BLANK",
		["D1ClassColor"] = true,
		["R4Text"] = "KILLED/TOTALH",
		["R3Color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
		},
		["R3ClassColor"] = true,
		["R3Text"] = "KILLED/TOTALH",
		["R5ClassColor"] = true,
		["R6Text"] = "KILLED/TOTAL",
		["D3Color"] = {
			1, -- [1]
			0, -- [2]
			0, -- [3]
		},
		["R8Text"] = "KILLED/TOTALM",
		["D3Text"] = "KILLED/TOTALM",
		["D2Text"] = "KILLED/TOTALH",
		["R2Indicator"] = "BLANK",
		["R1ClassColor"] = true,
		["R0ClassColor"] = true,
	},
	["QuestDB"] = {
		["Daily"] = {
			[53159] = 1161,
			[55725] = 1355,
			[56753] = 1462,
			[55765] = 1462,
			[55773] = 1355,
			[55789] = 1355,
			[55032] = 1355,
			[55813] = 1462,
			[55821] = 1355,
			[55829] = 1355,
			[55837] = 1355,
			[55845] = 1355,
			[55885] = 1462,
			[54363] = 1161,
			[54387] = 1161,
			[55463] = 1462,
			[55726] = 1355,
			[55750] = 1355,
			[56523] = 1462,
			[53216] = 1161,
			[55790] = 1355,
			[56053] = 1462,
			[56324] = 1462,
			[55822] = 1355,
			[55830] = 1355,
			[56380] = 1462,
			[56149] = 1355,
			[31840] = 379,
			[54380] = 1161,
			[56173] = 1462,
			[55695] = 1462,
			[55719] = 1355,
			[55727] = 1355,
			[56755] = 1462,
			[56508] = 1462,
			[56532] = 1462,
			[55775] = 1355,
			[55528] = 1462,
			[56301] = 1462,
			[56572] = 1462,
			[53265] = 1161,
			[55823] = 1355,
			[55831] = 1355,
			[56373] = 1462,
			[56142] = 1462,
			[54365] = 1161,
			[53361] = 1161,
			[54389] = 1161,
			[55672] = 1462,
			[55688] = 1462,
			[54394] = 1161,
			[56469] = 1462,
			[55720] = 1355,
			[55728] = 1355,
			[56501] = 1462,
			[53226] = 1161,
			[55792] = 1355,
			[26183] = 84,
			[56326] = 1462,
			[56334] = 1462,
			[55832] = 1355,
			[56621] = 1462,
			[58167] = 1530,
			[55880] = 1462,
			[55633] = 1355,
			[54382] = 1161,
			[55681] = 1355,
			[56223] = 1355,
			[55721] = 1355,
			[56000] = 1355,
			[53219] = 1161,
			[55777] = 1355,
			[55785] = 1355,
			[55793] = 1355,
			[55801] = 1355,
			[56760] = 1462,
			[56327] = 1462,
			[55825] = 1355,
			[55833] = 1355,
			[55658] = 1462,
			[54367] = 1161,
			[56160] = 1355,
			[58463] = 1530,
			[58471] = 1530,
			[56184] = 1462,
			[55791] = 1355,
			[56471] = 1462,
			[54949] = 1355,
			[55575] = 1462,
			[54965] = 1462,
			[58288] = 1527,
			[56001] = 1355,
			[55786] = 1355,
			[56150] = 1355,
			[56335] = 1462,
			[43323] = 84,
			[55834] = 1355,
			[55380] = 1462,
			[56153] = 1355,
			[58464] = 1530,
			[55723] = 1355,
			[56751] = 1462,
			[55994] = 1462,
			[53205] = 1161,
			[55771] = 1355,
			[55787] = 1355,
			[55819] = 1355,
			[41037] = 720,
			[56361] = 1462,
			[54082] = 1462,
			[54090] = 1462,
			[56146] = 1355,
			[56154] = 1355,
			[56405] = 1462,
			[55743] = 1462,
			[55818] = 1355,
			[56355] = 1462,
			[55776] = 1355,
			[55724] = 1355,
			[58282] = 1527,
			[58290] = 1527,
			[55659] = 1355,
			[56573] = 1462,
			[56152] = 1355,
			[56493] = 1462,
			[55827] = 1355,
			[56306] = 1462,
			[56082] = 1462,
			[55820] = 1355,
			[55828] = 1355,
			[55836] = 1355,
			[41062] = 721,
			[56370] = 1355,
			[55905] = 1462,
			[56558] = 1462,
			[53334] = 1161,
			[55637] = 1355,
			[56410] = 1462,
			[56328] = 1462,
			[55816] = 1462,
			[56434] = 1462,
			[55824] = 1355,
			[53371] = 942,
			[55701] = 1355,
			[58467] = 1530,
		},
		["Darkmoon"] = {
			["expires"] = 1578841140,
		},
		["AccountDaily"] = {
			[31752] = -1,
			[37644] = -1,
			[56042] = 1161,
			[37645] = -1,
			[34774] = 1161,
			[38300] = -1,
			[40753] = 1161,
			[38299] = -1,
		},
		["Weekly"] = {
			[48910] = 1135,
			[56092] = 942,
			[52944] = -1,
			[40787] = -1,
			[52948] = -1,
			[52950] = -1,
			[52952] = -1,
			[52954] = -1,
			[52956] = -1,
			[52958] = -1,
			[40173] = -1,
			[55213] = 1462,
			[53033] = -1,
			[50956] = 942,
			[53037] = 1161,
			[53039] = -1,
			[55498] = -1,
			[48912] = 831,
			[53035] = -1,
			[44164] = -1,
			[44166] = -1,
			[56475] = 942,
			[33334] = -1,
			[44172] = -1,
			[56144] = 942,
			[56650] = -1,
			[56148] = -1,
			[56969] = -1,
			[56648] = -1,
			[56091] = 942,
			[48911] = -1,
			[40786] = -1,
			[49293] = 1171,
			[52949] = -1,
			[52951] = -1,
			[52953] = -1,
			[32640] = -1,
			[40168] = -1,
			[56473] = 942,
			[44174] = -1,
			[56050] = -1,
			[52957] = -1,
			[53030] = 1161,
			[53032] = -1,
			[53034] = 1161,
			[53036] = -1,
			[33338] = -1,
			[54995] = -1,
			[45799] = -1,
			["expires"] = 1579733999,
			[52782] = -1,
			[44167] = -1,
			[32641] = -1,
			[44171] = 1014,
			[44173] = -1,
			[44175] = -1,
			[45563] = 554,
			[55121] = 1355,
			[56649] = -1,
			[55499] = -1,
		},
		["AccountWeekly"] = {
			[53038] = -1,
			[46292] = -1,
			["expires"] = 1579733999,
			[54186] = -1,
			[56492] = -1,
			[45539] = -1,
			[40329] = -1,
		},
	},
	["RealmMap"] = {
		{
			"가로나", -- [1]
			"굴단", -- [2]
			"줄진", -- [3]
		}, -- [1]
		{
			"렉사르", -- [1]
			"와일드해머", -- [2]
			"윈드러너", -- [3]
		}, -- [2]
		["굴단"] = 1,
		["줄진"] = 1,
		["와일드해머"] = 2,
		["가로나"] = 1,
		["윈드러너"] = 2,
		["렉사르"] = 2,
	},
	["DailyResetTime"] = 1579301999,
	["Quests"] = {
	},
	["Warfront"] = {
		{
			["contributing"] = true,
			["captureSide"] = "Horde",
		}, -- [1]
		{
			["contributing"] = true,
			["captureSide"] = "Horde",
		}, -- [2]
	},
}
