
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "받아줘요악사-아즈샤라",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "DEMONHUNTER",
	["LastAdded"] = 1,
}
