
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["alertDamage"] = 0,
		["ccbreaks"] = 0,
		["overhealing"] = 0,
		["interrupts"] = 0,
		["ffdamagedone"] = 0,
		["shielding"] = 0,
		["damage"] = 0,
		["players"] = {
		},
		["deaths"] = 0,
		["damagetaken"] = 0,
		["power"] = {
		},
		["dispells"] = 0,
		["healing"] = 0,
		["starttime"] = 1579289148,
		["time"] = 0,
		["mobs"] = {
		},
		["auras"] = {
		},
		["name"] = "전체",
		["alertCount"] = 0,
		["mobtaken"] = 0,
		["mobhdone"] = 0,
		["last_action"] = 1579289148,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
