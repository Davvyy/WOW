
PawnOptions = {
	["LastVersion"] = 2.024,
	["LastPlayerFullName"] = "완소야드-굴단",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "DRUID",
	["LastAdded"] = 1,
}
