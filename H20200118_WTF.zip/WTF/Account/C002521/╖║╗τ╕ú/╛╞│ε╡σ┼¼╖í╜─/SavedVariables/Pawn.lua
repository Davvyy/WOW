
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "아놀드클래식-렉사르",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "SHAMAN",
	["LastAdded"] = 1,
}
