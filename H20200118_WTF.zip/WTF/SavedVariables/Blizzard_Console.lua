
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Total: 37d 21h 27m 28s", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"Level: 27d 16h 23m 48s", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [114]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [115]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Time set to 1/15/2020 (Wed) 22:30", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Total: 37d 23h 8m 27s", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"Level: 27d 18h 4m 47s", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"Time set to 1/15/2020 (Wed) 22:34", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Total: 30d 16h 16m 13s", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"Level: 5d 14h 6m 54s", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Skill 2437 increased from 151 to 152", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Completed challenge mode mapID 1862, level 12, time 2278746", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Time set to 1/15/2020 (Wed) 23:23", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Total: 37d 23h 12m 13s", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Level: 27d 18h 8m 33s", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Completed challenge mode mapID 1754, level 13, time 1393863", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"GxApi set pending client restart", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [379]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [380]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Time set to 1/16/2020 (Thu) 23:58", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Total: 38d 0h 10m 50s", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Level: 27d 19h 7m 10s", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [481]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [482]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"Time set to 1/17/2020 (Fri) 0:07", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Total: 38d 0h 19m 21s", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Level: 27d 19h 15m 41s", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"Weather changed to 4, intensity 0.300000\n", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Weather changed to 4, intensity 0.300000\n", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Weather changed to 4, intensity 0.300000\n", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Weather changed to 4, intensity 0.300000\n", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"Weather changed to 4, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"Time set to 1/17/2020 (Fri) 1:46", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"Total: 30d 17h 4m 17s", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Level: 5d 14h 54m 58s", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Time set to 1/17/2020 (Fri) 1:50", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Total: 19d 19h 32m 49s", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Level: 13d 15h 38m 42s", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"SSAO mode set to 3", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [709]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [710]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Weather changed to 2, intensity 0.057100\n", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"Time set to 1/18/2020 (Sat) 1:12", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"Total: 38d 1h 58m 13s", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Level: 27d 20h 54m 33s", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"GameTimeSync: skipping forwards 2 game minutes, (current = 1/18/2020 (Sat) 2:07, newtime = 1/18/2020 (Sat) 2:09)", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"GameTimeSync: delta=0, differential=1, HoursAndMinutes=183", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Dissolve Effect ID 904 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"Weather changed to 5, intensity 0.275022\n", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Weather changed to 5, intensity 0.262365\n", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Weather changed to 5, intensity 0.258078\n", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Weather changed to 5, intensity 0.250606\n", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"Dissolve Effect ID 1135 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Weather changed to 5, intensity 0.236089\n", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Weather changed to 5, intensity 0.250489\n", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"Weather changed to 5, intensity 0.299547\n", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Weather changed to 5, intensity 0.280392\n", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Time set to 1/18/2020 (Sat) 4:28", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Total: 38d 5h 13m 27s", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Level: 28d 0h 9m 47s", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Weather changed to 5, intensity 0.250121\n", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Weather changed to 5, intensity 0.258815\n", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Weather changed to 5, intensity 0.206826\n", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Weather changed to 5, intensity 0.207633\n", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 300.0002136230469,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
