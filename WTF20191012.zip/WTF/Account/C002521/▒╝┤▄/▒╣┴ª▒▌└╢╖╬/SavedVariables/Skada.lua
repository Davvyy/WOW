
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["dispells"] = 0,
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["ffdamagedone"] = 0,
		["mobs"] = {
		},
		["damage"] = 0,
		["players"] = {
		},
		["deaths"] = 0,
		["damagetaken"] = 0,
		["shielding"] = 0,
		["alertDamage"] = 0,
		["healing"] = 0,
		["overhealing"] = 0,
		["auras"] = {
		},
		["starttime"] = 1570805826,
		["power"] = {
		},
		["name"] = "전체",
		["alertCount"] = 0,
		["mobtaken"] = 0,
		["mobhdone"] = 0,
		["last_action"] = 1570805826,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
