
BlueItemLinkDB = {
	["scale"] = 1,
	["showIcon"] = true,
	["escHide"] = true,
}
