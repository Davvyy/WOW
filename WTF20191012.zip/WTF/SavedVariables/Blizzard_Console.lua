
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [1]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [2]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [3]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [4]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [5]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [6]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [7]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [8]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [9]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [10]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [11]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [12]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [13]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [14]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [15]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [16]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [17]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [18]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [19]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [20]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [21]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [22]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [23]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [24]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [25]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [26]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [27]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [28]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [29]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [30]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [31]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [32]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [33]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [34]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [35]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [36]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [37]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [38]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [39]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [40]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [41]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [42]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [43]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [44]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [45]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [46]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [47]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [48]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [49]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [50]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [51]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [52]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [53]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [54]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [55]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [56]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [57]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [58]
		{
			"Weather changed to 2, intensity 0.171553\n", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Weather changed to 2, intensity 0.171553\n", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Weather changed to 2, intensity 0.171553\n", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Completed challenge mode mapID 1754, level 9, time 2886882", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Skill 2437 increased from 119 to 120", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Trainer service 253157 unavailable", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"Weather changed to 2, intensity 0.121763\n", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [96]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [97]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [98]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [99]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [100]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [101]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [102]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [103]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [104]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [105]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [106]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [107]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [108]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [109]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [110]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [111]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [112]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [113]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [114]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [115]
		{
			"Weather changed to 2, intensity 0.253466\n", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Weather changed to 2, intensity 0.253466\n", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [127]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [128]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [129]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [130]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [131]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [132]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [133]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [134]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [135]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [136]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [137]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [138]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [139]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [140]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [141]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [142]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [143]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [144]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [145]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [146]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [147]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [148]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [149]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [150]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [151]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [152]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [153]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [154]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [155]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [156]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [157]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [158]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [159]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [160]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [161]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [162]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [163]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [164]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [165]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [166]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [167]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [168]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [169]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [170]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [171]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [172]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [173]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [174]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [175]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [176]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [177]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [178]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [179]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [180]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [181]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [182]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [183]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [184]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [185]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [186]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Time set to 10/10/2019 (Thu) 22:29", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Total: 34d 15h 17m 29s", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Level: 24d 10h 13m 49s", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Skill 202 increased from 137 to 138", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Skill 2499 increased from 137 to 138", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Skill 202 increased from 138 to 139", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Skill 2499 increased from 138 to 139", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Skill 202 increased from 139 to 140", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Skill 2499 increased from 139 to 140", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Skill 202 increased from 140 to 141", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Skill 2499 increased from 140 to 141", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Weather changed to 2, intensity 0.210522\n", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Time set to 10/10/2019 (Thu) 22:39", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Total: 27d 4h 54m 50s", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Level: 2d 2h 45m 31s", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Time set to 10/10/2019 (Thu) 22:41", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Total: 34d 15h 27m 43s", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Level: 24d 10h 24m 3s", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Skill 202 increased from 141 to 142", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"Skill 2499 increased from 141 to 142", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Weather changed to 2, intensity 0.102251\n", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Weather changed to 2, intensity 0.102251\n", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [308]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [309]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [310]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [311]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [312]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [313]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [314]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [315]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [316]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [317]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [318]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [319]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [320]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [321]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [322]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [323]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [324]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [325]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [326]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [327]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [328]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [329]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [330]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [331]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [332]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [333]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [334]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [335]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [336]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [337]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [338]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [339]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [340]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [341]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [342]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [343]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [344]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [345]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [346]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [347]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [348]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [349]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [350]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [351]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [352]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [353]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [354]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [355]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [356]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [357]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [358]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [359]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"Weather changed to 2, intensity 0.109230\n", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Time set to 10/11/2019 (Fri) 0:09", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"Total: 27d 4h 55m 36s", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Level: 2d 2h 46m 17s", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Time set to 10/11/2019 (Fri) 0:12", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Total: 17d 17h 32m 52s", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Level: 11d 13h 38m 45s", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"Time set to 10/11/2019 (Fri) 0:13", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"Total: 34d 16h 56m 9s", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"Level: 24d 11h 52m 29s", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"Time set to 10/11/2019 (Fri) 0:14", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"Total: 27d 4h 58m 12s", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"Level: 2d 2h 48m 53s", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Time set to 10/11/2019 (Fri) 0:14", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"Total: 34d 16h 56m 44s", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"Level: 24d 11h 53m 4s", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Skill 202 increased from 142 to 143", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Skill 2499 increased from 142 to 143", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"Skill 202 increased from 143 to 144", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Skill 2499 increased from 143 to 144", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Skill 202 increased from 144 to 145", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Skill 2499 increased from 144 to 145", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Weather changed to 2, intensity 0.109230\n", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Weather changed to 2, intensity 0.109230\n", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [613]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [614]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Time set to 10/11/2019 (Fri) 22:41", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Total: 27d 4h 58m 44s", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Level: 2d 2h 49m 25s", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Weather changed to 3, intensity 0.125148\n", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Weather changed to 3, intensity 0.125148\n", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Weather changed to 3, intensity 0.365766\n", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Weather changed to 2, intensity 0.151692\n", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Completed challenge mode mapID 1754, level 9, time 1453983", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Weather changed to 2, intensity 0.167880\n", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Time set to 10/11/2019 (Fri) 23:59", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"Total: 34d 17h 9m 45s", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"Level: 24d 12h 6m 5s", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"true\"", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [788]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [789]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Time set to 10/12/2019 (Sat) 1:29", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Total: 34d 18h 4m 52s", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Level: 24d 13h 1m 12s", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Weather changed to 2, intensity 0.262453\n", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Weather changed to 2, intensity 0.262453\n", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Skill 202 increased from 145 to 146", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Skill 2499 increased from 145 to 146", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Skill 202 increased from 146 to 147", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Skill 2499 increased from 146 to 147", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Skill 202 increased from 147 to 148", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Skill 2499 increased from 147 to 148", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Skill 202 increased from 148 to 149", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Skill 2499 increased from 148 to 149", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"Skill 202 increased from 149 to 150", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Skill 2499 increased from 149 to 150", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"Skill 202 increased from 150 to 151", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"Skill 2499 increased from 150 to 151", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"Skill 202 increased from 151 to 152", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"Skill 2499 increased from 151 to 152", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Time set to 10/12/2019 (Sat) 2:40", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Total: 17d 17h 34m 7s", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"Level: 11d 13h 40m 0s", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Weather changed to 3, intensity 0.359533\n", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"Time set to 10/12/2019 (Sat) 3:05", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Total: 27d 6h 16m 26s", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Level: 2d 4h 7m 7s", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Time set to 10/12/2019 (Sat) 3:05", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Total: 34d 19h 15m 47s", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Level: 24d 14h 12m 7s", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 300.0002136230469,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
