# Deadly Boss Mods Core

## [8.2.15](https://github.com/DeadlyBossMods/DeadlyBossMods/tree/8.2.15) (2019-08-21)
[Full Changelog](https://github.com/DeadlyBossMods/DeadlyBossMods/compare/8.2.14...8.2.15)

- Fix eternal palace and DMF using italian in all languages do to bugs in merged pull request  
- refactor Boss Unit scanner some more to get rid of crappy 10 year ago me code, as well as add support for allowing tank when allow tank arg is passed  
- Update recent zhCN (#55)  
    更新3条翻译  