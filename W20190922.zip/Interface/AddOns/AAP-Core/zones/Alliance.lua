if (AAP.Faction == "Alliance") then
AAP.QuestStepList = {


}
end