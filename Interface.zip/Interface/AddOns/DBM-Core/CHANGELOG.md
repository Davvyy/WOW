# Deadly Boss Mods Core

## [8.3.12](https://github.com/DeadlyBossMods/DeadlyBossMods/tree/8.3.12) (2020-02-07)
[Full Changelog](https://github.com/DeadlyBossMods/DeadlyBossMods/compare/8.3.11...8.3.12)

- Quick fix a regression that caused several timers not to show at start of Phase 2 non mythic Nzoth. Sorry about that. A ton of mod was rewritten/cleaned up for mythic and tested on mythic but not heroic.  
    Also changed evoke anquish warning to generic "you" warning since people have different strats for it on non mythic and mythic raiders know what to do with it already without dbm needing to be specific.  
- Fixed a case where lua error might be thrown on mythic stage 3 nzoth  during heart chamber phase.  
