# Deadly Boss Mods Core

## [8.3.2](https://github.com/DeadlyBossMods/DeadlyBossMods/tree/8.3.2) (2020-01-21)
[Full Changelog](https://github.com/DeadlyBossMods/DeadlyBossMods/compare/8.3.1...8.3.2)

- Revert bad pull request that broke stuff. Don't contribute broken code to project. When a pull request is created I assume this code was ACTUALLY tested  
