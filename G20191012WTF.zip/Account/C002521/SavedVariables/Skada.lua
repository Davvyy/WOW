
SkadaDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["잘생겨따 - 굴단"] = "Default",
		["무시중한디 - 굴단"] = "Wide",
		["뉘시빨라마 - 굴단"] = "Default",
		["국제금융로 - 굴단"] = "Default",
	},
	["profiles"] = {
		["굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
		["WARRIOR"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
		["Default"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 2,
				["적이 받은 치유"] = 1,
				["약화 효과"] = 1,
				["DPS"] = 2,
			},
			["windows"] = {
				{
					["y"] = 100.5162963867188,
					["name"] = "S",
					["point"] = "LEFT",
					["mode"] = "DPS",
					["spark"] = false,
					["barwidth"] = 256.9525146484375,
					["background"] = {
						["strata"] = "LOW",
						["height"] = 266.0478210449219,
						["bordertexture"] = "None",
					},
					["x"] = 0,
				}, -- [1]
			},
			["icon"] = {
				["minimapPos"] = 189.8308812393392,
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
			["reset"] = {
				["leave"] = 2,
				["instance"] = 2,
				["join"] = 2,
			},
		},
		["Wide"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 1,
				["치유"] = 1,
				["DPS"] = 4,
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
			["icon"] = {
				["minimapPos"] = 189.9405717527841,
			},
			["windows"] = {
				{
					["y"] = 131.5016326904297,
					["x"] = 10.6499719619751,
					["point"] = "LEFT",
					["barwidth"] = 287.238525390625,
					["mode"] = "DPS",
					["background"] = {
						["height"] = 346.28564453125,
					},
				}, -- [1]
			},
		},
		["국제금융로 - 굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
	},
}
