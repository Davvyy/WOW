
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["dispells"] = 0,
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["ffdamagedone"] = 0,
		["damagetaken"] = 0,
		["damage"] = 0,
		["players"] = {
		},
		["deaths"] = 0,
		["mobs"] = {
		},
		["shielding"] = 0,
		["alertDamage"] = 0,
		["healing"] = 0,
		["mobtaken"] = 0,
		["auras"] = {
		},
		["starttime"] = 1570860273,
		["power"] = {
		},
		["name"] = "전체",
		["alertCount"] = 0,
		["overhealing"] = 0,
		["mobhdone"] = 0,
		["last_action"] = 1570860273,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
