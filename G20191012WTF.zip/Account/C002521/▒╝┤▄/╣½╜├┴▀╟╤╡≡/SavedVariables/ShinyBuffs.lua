
ShinyBuffsPCDB = {
	["charSpec"] = false,
}
