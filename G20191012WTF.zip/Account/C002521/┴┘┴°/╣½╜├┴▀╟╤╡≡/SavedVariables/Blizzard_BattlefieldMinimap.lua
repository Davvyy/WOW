
BattlefieldMinimapOptions = {
	["locked"] = true,
	["opacity"] = 0.699999988079071,
	["showPlayers"] = true,
}
