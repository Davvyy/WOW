
PawnOptions = {
	["LastVersion"] = 2.024,
	["LastPlayerFullName"] = "공허엘프닷-굴단",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "MONK",
	["LastAdded"] = 1,
}
