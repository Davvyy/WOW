
Broker_MoneyConfig = {
	["ShowCoinIcons"] = true,
	["ShowColoredText"] = true,
	["ShowVariation"] = true,
	["Sorting"] = "Name",
	["IconSize"] = 16,
	["CompressDisplay"] = false,
	["SortReverse"] = false,
	["ShortenGoldValue"] = false,
}
