
SkadaDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["잘생겨따 - 굴단"] = "Default",
		["무시중한디 - 굴단"] = "Wide",
		["뉘시빨라마 - 굴단"] = "Default",
		["국제금융로 - 굴단"] = "Default",
	},
	["profiles"] = {
		["굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
		["WARRIOR"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
		["Default"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 2,
				["적이 받은 치유"] = 1,
				["약화 효과"] = 1,
				["DPS"] = 4,
			},
			["windows"] = {
				{
					["y"] = 6.095123291015625,
					["x"] = 452.3816528320313,
					["name"] = "S",
					["mode"] = "DPS",
					["barwidth"] = 256.9525146484375,
					["background"] = {
						["height"] = 266.0478210449219,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "BOTTOMLEFT",
				}, -- [1]
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
			["icon"] = {
				["minimapPos"] = 206.6650563676227,
			},
			["reset"] = {
				["leave"] = 2,
				["instance"] = 2,
				["join"] = 2,
			},
		},
		["Wide"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 1,
				["치유"] = 1,
				["DPS"] = 4,
			},
			["windows"] = {
				{
					["y"] = 6.866730213165283,
					["point"] = "BOTTOMLEFT",
					["mode"] = "DPS",
					["barwidth"] = 287.238525390625,
					["background"] = {
						["height"] = 346.28564453125,
					},
					["x"] = 457.1260681152344,
				}, -- [1]
			},
			["icon"] = {
				["minimapPos"] = 213.6161596799995,
			},
			["report"] = {
				["chantype"] = "channel",
				["set"] = "total",
				["mode"] = "DPS",
				["channel"] = "ok",
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
		},
		["국제금융로 - 굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
	},
}
