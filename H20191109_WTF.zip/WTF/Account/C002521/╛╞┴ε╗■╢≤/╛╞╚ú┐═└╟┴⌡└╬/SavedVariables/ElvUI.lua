
ElvCharacterDB = {
	["ChatEditHistory"] = {
		"/누구 암효주", -- [1]
	},
	["ChatHistoryLog"] = {
	},
}
