
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "아호와의증인-아즈샤라",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "MONK",
	["LastAdded"] = 1,
}
