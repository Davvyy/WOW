
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "쌩뚱마삼-렉사르",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["Artifacts"] = {
		[127829] = {
			["Relics"] = {
				{
					["ItemLevel"] = 30,
					["Type"] = "Fel",
				}, -- [1]
				{
					["ItemLevel"] = 33,
					["Type"] = "Shadow",
				}, -- [2]
				{
					["ItemLevel"] = 28,
					["Type"] = "Fel",
				}, -- [3]
			},
			["Name"] = "기만자의 쌍날검",
		},
	},
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "PRIEST",
	["LastAdded"] = 1,
}
