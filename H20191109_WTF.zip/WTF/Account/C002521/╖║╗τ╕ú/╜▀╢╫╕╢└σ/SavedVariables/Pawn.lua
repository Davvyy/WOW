
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "쌩뚱마장-렉사르",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "WARLOCK",
	["LastAdded"] = 1,
}
