
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "오우지져스-렉사르",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "WARRIOR",
	["LastAdded"] = 1,
}
