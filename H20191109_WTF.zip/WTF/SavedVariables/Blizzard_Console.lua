
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Time set to 11/3/2019 (Sun) 18:25", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"Total: 28d 11h 31m 6s", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"Level: 3d 9h 21m 47s", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"Skill 2437 increased from 142 to 143", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Time set to 11/3/2019 (Sun) 18:40", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Total: 36d 2h 5m 20s", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Level: 25d 21h 1m 40s", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"Time set to 11/3/2019 (Sun) 18:43", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Total: 18d 4h 15m 50s", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"Level: 12d 0h 21m 43s", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"GameTimeSync: skipping forwards 2 game minutes, (current = 11/3/2019 (Sun) 18:43, newtime = 11/3/2019 (Sun) 18:45)", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"Completed challenge mode mapID 1841, level 11, time 2174291", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Time set to 11/3/2019 (Sun) 19:24", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Total: 36d 2h 8m 28s", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Level: 25d 21h 4m 48s", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Completed challenge mode mapID 1763, level 14, time 1717595", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [208]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [209]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Time set to 11/5/2019 (Tue) 5:04", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Total: 28d 11h 45m 26s", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Level: 3d 9h 36m 7s", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Weather changed to 3, intensity 0.120016\n", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [334]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [335]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"Time set to 11/6/2019 (Wed) 4:17", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"Total: 28d 12h 3m 52s", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"Level: 3d 9h 54m 33s", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Time set to 11/6/2019 (Wed) 4:20", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Total: 18d 4h 55m 50s", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Level: 12d 1h 1m 43s", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"Time set to 11/6/2019 (Wed) 4:21", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Total: 36d 2h 46m 43s", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"Level: 25d 21h 43m 3s", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [492]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [493]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"Time set to 11/7/2019 (Thu) 20:33", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Total: 36d 2h 48m 1s", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Level: 25d 21h 44m 21s", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"Time set to 11/7/2019 (Thu) 20:37", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Total: 18d 4h 56m 52s", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Level: 12d 1h 2m 45s", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Time set to 11/7/2019 (Thu) 20:40", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Total: 36d 2h 51m 57s", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Level: 25d 21h 48m 17s", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Time set to 11/7/2019 (Thu) 20:41", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Total: 28d 12h 6m 19s", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Level: 3d 9h 57m 0s", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [680]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [681]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Time set to 11/8/2019 (Fri) 19:47", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Total: 36d 2h 52m 20s", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"Level: 25d 21h 48m 40s", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"true\"", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"set pending client restart", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"set pending client restart", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [807]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [808]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Time set to 11/9/2019 (Sat) 1:37", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Total: 36d 4h 23m 25s", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Level: 25d 23h 19m 45s", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Water detail changed to 3", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Ripple detail changed to 2", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Reflection mode changed to 3", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Shadow mode changed to 3 - 4 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Resample quality changed to 1", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"MSAA set to 4 color samples, 4 coverage samples", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"[WowEntitlements] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [903]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [904]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Time set to 11/9/2019 (Sat) 9:56", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"Total: 36d 4h 27m 2s", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Level: 25d 23h 23m 22s", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [922]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [923]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [924]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [925]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [926]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [927]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [928]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [929]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [930]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [931]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [932]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [933]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [934]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [935]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [936]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [937]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [938]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [939]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [940]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [941]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [942]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [943]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [944]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [945]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [946]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [947]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [948]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [949]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [950]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [951]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [952]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [953]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [954]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [955]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [956]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [957]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [958]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [959]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [960]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [961]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [962]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [963]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [964]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [965]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [966]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [967]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [968]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [969]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [970]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [971]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [972]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [973]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [974]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [975]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 2, intensity 0.180350\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 300.0002136230469,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
