
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "오지져스-렉사르",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "DRUID",
	["LastAdded"] = 1,
}
