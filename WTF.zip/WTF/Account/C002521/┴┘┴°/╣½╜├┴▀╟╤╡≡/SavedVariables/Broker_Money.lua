
Broker_MoneyConfig = {
	["ShowCoinIcons"] = true,
	["ShowColoredText"] = true,
	["ShowVariation"] = true,
	["ShortenGoldValue"] = false,
	["IconSize"] = 16,
	["CompressDisplay"] = false,
	["SortReverse"] = false,
	["Sorting"] = "Name",
}
