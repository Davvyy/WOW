
uClockDB = {
	["profileKeys"] = {
		["무시중한디 - 굴단"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
