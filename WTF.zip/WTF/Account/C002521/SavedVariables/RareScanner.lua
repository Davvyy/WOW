
RareScannerDB = {
	["char"] = {
		["뉘시빨라마 - 굴단"] = {
			["scannerXPos"] = 1718.980834960938,
			["containers_opened"] = {
				[284410] = -1,
				[293964] = -1,
				[293962] = -1,
			},
			["scannerYPos"] = 458.6667175292969,
			["quests_completed"] = {
				[55117] = true,
				[47057] = true,
				[51215] = true,
				[49232] = true,
				[51343] = true,
				[51407] = true,
				[45394] = true,
				[55757] = true,
				[49744] = true,
				[56013] = true,
				[47889] = true,
				[50064] = true,
				[48081] = true,
				[42068] = true,
				[31309] = true,
				[56525] = true,
				[52495] = true,
				[40341] = true,
				[40405] = true,
				[50704] = true,
				[38486] = true,
				[46802] = true,
				[55118] = true,
				[51088] = true,
				[47058] = true,
				[51280] = true,
				[51408] = true,
				[45395] = true,
				[53711] = true,
				[51728] = true,
				[49745] = true,
				[47890] = true,
				[50001] = true,
				[50065] = true,
				[52240] = true,
				[42197] = true,
				[50449] = true,
				[50705] = true,
				[50897] = true,
				[55119] = true,
				[55183] = true,
				[47059] = true,
				[51217] = true,
				[51281] = true,
				[45396] = true,
				[53712] = true,
				[55823] = true,
				[49746] = true,
				[47891] = true,
				[50002] = true,
				[45972] = true,
				[52241] = true,
				[42198] = true,
				[50450] = true,
				[56719] = true,
				[50706] = true,
				[50898] = true,
				[44821] = true,
				[53073] = true,
				[51218] = true,
				[51282] = true,
				[47252] = true,
				[49427] = true,
				[51538] = true,
				[47508] = true,
				[49619] = true,
				[55888] = true,
				[49939] = true,
				[50003] = true,
				[52242] = true,
				[54417] = true,
				[56528] = true,
				[50451] = true,
				[56078] = true,
				[57039] = true,
				[46805] = true,
				[58636] = true,
				[53074] = true,
				[55185] = true,
				[53202] = true,
				[55121] = true,
				[51283] = true,
				[49300] = true,
				[55886] = true,
				[49428] = true,
				[56527] = true,
				[53714] = true,
				[55761] = true,
				[56652] = true,
				[51795] = true,
				[52494] = true,
				[52496] = true,
				[38037] = true,
				[50260] = true,
				[56209] = true,
				[54610] = true,
				[46033] = true,
				[56401] = true,
				[48277] = true,
				[42200] = true,
				[50452] = true,
				[50516] = true,
				[51028] = true,
				[48597] = true,
				[58896] = true,
				[49999] = true,
				[47888] = true,
				[48853] = true,
				[55759] = true,
				[57169] = true,
				[49807] = true,
				[51796] = true,
				[51220] = true,
				[51284] = true,
				[53773] = true,
				[51412] = true,
				[55756] = true,
				[51540] = true,
				[40084] = true,
				[49621] = true,
				[57873] = true,
				[55890] = true,
				[51534] = true,
				[57167] = true,
				[54035] = true,
				[56530] = true,
				[50069] = true,
				[50133] = true,
				[55887] = true,
				[44120] = true,
				[50325] = true,
				[58577] = true,
				[50453] = true,
				[54611] = true,
				[51278] = true,
				[50645] = true,
				[53715] = true,
				[50773] = true,
				[34774] = true,
				[44760] = true,
				[50965] = true,
				[51029] = true,
				[57362] = true,
				[55116] = true,
				[51221] = true,
				[53332] = true,
				[49302] = true,
				[56593] = true,
				[40276] = true,
				[41306] = true,
				[53652] = true,
				[41747] = true,
				[56529] = true,
				[47892] = true,
				[56779] = true,
				[56019] = true,
				[50446] = true,
				[39771] = true,
				[50070] = true,
				[50134] = true,
				[52245] = true,
				[57040] = true,
				[48399] = true,
				[54485] = true,
				[50454] = true,
				[54412] = true,
				[47960] = true,
				[56787] = true,
				[52118] = true,
				[50774] = true,
				[31568] = true,
				[43418] = true,
				[56276] = true,
				[48280] = true,
				[47000] = true,
				[58579] = true,
				[51222] = true,
				[49239] = true,
				[51350] = true,
				[49367] = true,
				[49431] = true,
				[55374] = true,
				[55700] = true,
				[53717] = true,
				[55828] = true,
				[51159] = true,
				[53909] = true,
				[56533] = true,
				[56084] = true,
				[52054] = true,
				[56212] = true,
				[50135] = true,
				[52246] = true,
				[50263] = true,
				[50327] = true,
				[48344] = true,
				[56596] = true,
				[53206] = true,
				[50583] = true,
				[48600] = true,
				[51415] = true,
				[57290] = true,
				[48792] = true,
				[50903] = true,
				[52439] = true,
				[51031] = true,
				[54870] = true,
				[57300] = true,
				[48793] = true,
				[53334] = true,
				[51351] = true,
				[49368] = true,
				[51032] = true,
				[49230] = true,
				[53976] = true,
				[47055] = true,
				[47641] = true,
				[55179] = true,
				[43675] = true,
				[53974] = true,
				[48974] = true,
				[56149] = true,
				[48025] = true,
				[50136] = true,
				[46106] = true,
				[50264] = true,
				[48281] = true,
				[48345] = true,
				[50009] = true,
				[58708] = true,
				[50584] = true,
				[48601] = true,
				[57034] = true,
				[50776] = true,
				[56981] = true,
				[50329] = true,
				[50457] = true,
				[46938] = true,
				[56982] = true,
				[47066] = true,
				[38355] = true,
				[47194] = true,
				[49305] = true,
				[49369] = true,
				[49433] = true,
				[51544] = true,
				[51608] = true,
				[51033] = true,
				[44184] = true,
				[53847] = true,
				[45723] = true,
				[53975] = true,
				[52492] = true,
				[45915] = true,
				[48026] = true,
				[50137] = true,
				[46107] = true,
				[50265] = true,
				[42141] = true,
				[56534] = true,
				[56598] = true,
				[48474] = true,
				[48538] = true,
				[50649] = true,
				[49818] = true,
				[54871] = true,
				[52888] = true,
				[54163] = true,
				[50253] = true,
				[48986] = true,
				[47003] = true,
				[56087] = true,
				[49178] = true,
				[49242] = true,
				[51353] = true,
				[53464] = true,
				[42142] = true,
				[51545] = true,
				[51609] = true,
				[44253] = true,
				[53784] = true,
				[55895] = true,
				[47771] = true,
				[56023] = true,
				[45852] = true,
				[45916] = true,
				[52121] = true,
				[47950] = true,
				[50586] = true,
				[50266] = true,
				[48283] = true,
				[54488] = true,
				[53583] = true,
				[48475] = true,
				[48539] = true,
				[51852] = true,
				[51021] = true,
				[50778] = true,
				[55818] = true,
				[55754] = true,
				[42782] = true,
				[51034] = true,
				[47004] = true,
				[50644] = true,
				[51541] = true,
				[47196] = true,
				[51354] = true,
				[51418] = true,
				[49435] = true,
				[54169] = true,
				[48348] = true,
				[50459] = true,
				[55832] = true,
				[49755] = true,
				[45725] = true,
				[53977] = true,
				[43806] = true,
				[52058] = true,
				[50075] = true,
				[50139] = true,
				[56728] = true,
				[56211] = true,
				[56472] = true,
				[56536] = true,
				[40224] = true,
				[48476] = true,
				[48540] = true,
				[53910] = true,
				[48668] = true,
				[50779] = true,
				[46941] = true,
				[42640] = true,
				[46734] = true,
				[51035] = true,
				[47005] = true,
				[51163] = true,
				[52875] = true,
				[56969] = true,
				[54418] = true,
				[43423] = true,
				[54421] = true,
				[51547] = true,
				[51611] = true,
				[48089] = true,
				[51994] = true,
				[55897] = true,
				[42208] = true,
				[53978] = true,
				[56089] = true,
				[56537] = true,
				[41888] = true,
				[50460] = true,
				[50588] = true,
				[31571] = true,
				[52171] = true,
				[52443] = true,
				[40225] = true,
				[48477] = true,
				[58776] = true,
				[48605] = true,
				[53275] = true,
				[50780] = true,
				[54938] = true,
				[50908] = true,
				[55066] = true,
				[47949] = true,
				[47006] = true,
				[50585] = true,
				[49181] = true,
				[54041] = true,
				[51356] = true,
				[55945] = true,
				[45724] = true,
				[54363] = true,
				[51612] = true,
				[53723] = true,
				[51740] = true,
				[55898] = true,
				[45727] = true,
				[58777] = true,
				[56090] = true,
				[52060] = true,
				[54171] = true,
				[46815] = true,
				[54299] = true,
				[50269] = true,
				[52308] = true,
				[56538] = true,
				[50461] = true,
				[50525] = true,
				[48542] = true,
				[48606] = true,
				[48670] = true,
				[50781] = true,
				[54939] = true,
				[50909] = true,
				[50973] = true,
				[8237] = true,
				[55497] = true,
				[42977] = true,
				[51229] = true,
				[51339] = true,
				[38367] = true,
				[53268] = true,
				[55707] = true,
				[51279] = true,
				[51613] = true,
				[53724] = true,
				[52125] = true,
				[47962] = true,
				[53916] = true,
				[49886] = true,
				[45856] = true,
				[47967] = true,
				[54172] = true,
				[52874] = true,
				[46733] = true,
				[52116] = true,
				[31572] = true,
				[56539] = true,
				[13807] = true,
				[54665] = true,
				[58778] = true,
				[48460] = true,
				[48671] = true,
				[54876] = true,
				[54940] = true,
				[46816] = true,
				[52490] = true,
				[50910] = true,
				[51102] = true,
				[49311] = true,
				[51230] = true,
				[52234] = true,
				[53405] = true,
				[56328] = true,
				[49439] = true,
				[47968] = true,
				[55708] = true,
				[56136] = true,
				[55836] = true,
				[55900] = true,
				[47948] = true,
				[49887] = true,
				[49951] = true,
				[56156] = true,
				[56220] = true,
				[47884] = true,
				[48352] = true,
				[37989] = true,
				[48088] = true,
				[56540] = true,
				[56604] = true,
				[52247] = true,
				[48544] = true,
				[53461] = true,
				[48672] = true,
				[50783] = true,
				[53465] = true,
				[47189] = true,
				[50975] = true,
				[53406] = true,
				[57244] = true,
				[51167] = true,
				[47137] = true,
				[52946] = true,
				[51359] = true,
				[53470] = true,
				[51487] = true,
				[55645] = true,
				[51615] = true,
				[53726] = true,
				[45652] = true,
				[51807] = true,
				[48087] = true,
				[56541] = true,
				[51999] = true,
				[47969] = true,
				[56221] = true,
				[56285] = true,
				[54302] = true,
				[56413] = true,
				[45079] = true,
				[48353] = true,
				[44771] = true,
				[50528] = true,
				[56542] = true,
				[47202] = true,
				[58013] = true,
				[50784] = true,
				[31573] = true,
				[46818] = true,
				[48929] = true,
				[50447] = true,
				[46732] = true,
				[51168] = true,
				[57373] = true,
				[55390] = true,
				[54303] = true,
				[51424] = true,
				[51488] = true,
				[52256] = true,
				[54559] = true,
				[52041] = true,
				[50593] = true,
				[51617] = true,
				[51872] = true,
				[53896] = true,
				[58502] = true,
				[47843] = true,
				[52128] = true,
				[49890] = true,
				[56350] = true,
				[56263] = true,
				[50530] = true,
				[54495] = true,
				[56606] = true,
				[47947] = true,
				[46499] = true,
				[41742] = true,
				[48674] = true,
				[52832] = true,
				[56007] = true,
				[51849] = true,
				[56966] = true,
				[47627] = true,
				[51170] = true,
				[51169] = true,
				[57374] = true,
				[47203] = true,
				[55392] = true,
				[55519] = true,
				[51489] = true,
				[51618] = true,
				[45476] = true,
				[51465] = true,
				[41510] = true,
				[51809] = true,
				[51873] = true,
				[56031] = true,
				[56095] = true,
				[52065] = true,
				[52872] = true,
				[56287] = true,
				[52257] = true,
				[52321] = true,
				[46244] = true,
				[48355] = true,
				[48419] = true,
				[48483] = true,
				[50594] = true,
				[53384] = true,
				[48675] = true,
				[52194] = true,
				[31574] = true,
				[48356] = true,
				[54945] = true,
				[55175] = true,
				[48805] = true,
				[55264] = true,
				[53000] = true,
				[51298] = true,
				[55393] = true,
				[55520] = true,
				[51490] = true,
				[51554] = true,
				[55712] = true,
				[50825] = true,
				[47652] = true,
				[53857] = true,
				[52296] = true,
				[55777] = true,
				[52002] = true,
				[56965] = true,
				[48806] = true,
				[44006] = true,
				[44070] = true,
				[58463] = true,
				[46245] = true,
				[52450] = true,
				[50467] = true,
				[50531] = true,
				[50595] = true,
				[48612] = true,
				[48676] = true,
				[52834] = true,
				[48804] = true,
				[47882] = true,
				[51492] = true,
				[43495] = true,
				[49060] = true,
				[42983] = true,
				[41897] = true,
				[49252] = true,
				[51363] = true,
				[55521] = true,
				[44108] = true,
				[53602] = true,
				[55713] = true,
				[47589] = true,
				[47653] = true,
				[52042] = true,
				[51875] = true,
				[53986] = true,
				[52003] = true,
				[52067] = true,
				[54627] = true,
				[50148] = true,
				[48165] = true,
				[46182] = true,
				[50340] = true,
				[52451] = true,
				[48421] = true,
				[54626] = true,
				[48678] = true,
				[54087] = true,
				[48677] = true,
				[49929] = true,
				[56993] = true,
				[50916] = true,
				[56006] = true,
				[55942] = true,
				[53155] = true,
				[42984] = true,
				[8860] = true,
				[55394] = true,
				[56994] = true,
				[51428] = true,
				[49445] = true,
				[52871] = true,
				[47526] = true,
				[41770] = true,
				[47654] = true,
				[43945] = true,
				[51876] = true,
				[49417] = true,
				[52197] = true,
				[56162] = true,
				[52132] = true,
				[52196] = true,
				[52260] = true,
				[54628] = true,
				[46247] = true,
				[53221] = true,
				[56610] = true,
				[50533] = true,
				[49161] = true,
				[51144] = true,
				[50725] = true,
				[42892] = true,
				[54947] = true,
				[43947] = true,
				[53028] = true,
				[42857] = true,
				[39596] = true,
				[57029] = true,
				[57378] = true,
				[55395] = true,
				[51365] = true,
				[53476] = true,
				[50824] = true,
				[50151] = true,
				[43433] = true,
				[44555] = true,
				[51749] = true,
				[51813] = true,
				[51877] = true,
				[53988] = true,
				[45864] = true,
				[50343] = true,
				[41898] = true,
				[44009] = true,
				[52261] = true,
				[50568] = true,
				[54436] = true,
				[51367] = true,
				[56611] = true,
				[50534] = true,
				[56037] = true,
				[50662] = true,
				[48679] = true,
				[52837] = true,
				[31576] = true,
				[46282] = true,
				[53990] = true,
				[50088] = true,
				[56039] = true,
				[42986] = true,
				[50280] = true,
				[55396] = true,
				[51366] = true,
				[49383] = true,
				[33071] = true,
				[50056] = true,
				[52039] = true,
				[50026] = true,
				[49703] = true,
				[57955] = true,
				[49831] = true,
				[53989] = true,
				[41771] = true,
				[52070] = true,
				[43946] = true,
				[54245] = true,
				[51432] = true,
				[42988] = true,
				[56484] = true,
				[58595] = true,
				[51752] = true,
				[54629] = true,
				[50599] = true,
				[48616] = true,
				[48680] = true,
				[47978] = true,
				[43948] = true,
				[57060] = true,
				[53030] = true,
				[50281] = true,
				[55205] = true,
				[53222] = true,
				[54183] = true,
				[55397] = true,
				[53414] = true,
				[51431] = true,
				[51177] = true,
				[51399] = true,
				[51623] = true,
				[51335] = true,
				[49704] = true,
				[39087] = true,
				[51879] = true,
				[49896] = true,
				[41772] = true,
				[47663] = true,
				[54182] = true,
				[50152] = true,
				[54310] = true,
				[58468] = true,
				[53800] = true,
				[51782] = true,
				[50604] = true,
				[54630] = true,
				[50600] = true,
				[53992] = true,
				[52457] = true,
				[46729] = true,
				[31577] = true,
				[57061] = true,
				[49259] = true,
				[49451] = true,
				[51626] = true,
				[38894] = true,
				[50567] = true,
				[55398] = true,
				[51368] = true,
				[49385] = true,
				[57063] = true,
				[52074] = true,
				[48903] = true,
				[56963] = true,
				[49705] = true,
				[55910] = true,
				[51880] = true,
				[56038] = true,
				[52008] = true,
				[52072] = true,
				[41901] = true,
				[48110] = true,
				[48170] = true,
				[56422] = true,
				[46251] = true,
				[55465] = true,
				[40238] = true,
				[44396] = true,
				[50601] = true,
				[55529] = true,
				[48682] = true,
				[50793] = true,
				[56998] = true,
				[50731] = true,
				[49452] = true,
				[51627] = true,
				[53160] = true,
				[42989] = true,
				[53957] = true,
				[55399] = true,
				[51369] = true,
				[47855] = true,
				[49735] = true,
				[48557] = true,
				[53672] = true,
				[55783] = true,
				[49706] = true,
				[46832] = true,
				[51881] = true,
				[49898] = true,
				[51570] = true,
				[56167] = true,
				[50090] = true,
				[48107] = true,
				[54312] = true,
				[52329] = true,
				[44205] = true,
				[40175] = true,
				[42286] = true,
				[54632] = true,
				[53573] = true,
				[38384] = true,
				[48683] = true,
				[56935] = true,
				[53675] = true,
				[52969] = true,
				[48939] = true,
				[51398] = true,
				[56042] = true,
				[42990] = true,
				[51242] = true,
				[55400] = true,
				[55464] = true,
				[50157] = true,
				[51498] = true,
				[47112] = true,
				[55720] = true,
				[55784] = true,
				[39986] = true,
				[48558] = true,
				[48622] = true,
				[55044] = true,
				[41775] = true,
				[47980] = true,
				[31592] = true,
				[48108] = true,
				[46728] = true,
				[44720] = true,
				[54441] = true,
				[51077] = true,
				[41330] = true,
				[44398] = true,
				[51757] = true,
				[56808] = true,
				[52778] = true,
				[44654] = true,
				[46765] = true,
				[44782] = true,
				[56643] = true,
				[53098] = true,
				[49710] = true,
				[51179] = true,
				[51949] = true,
				[49260] = true,
				[51371] = true,
				[49388] = true,
				[55593] = true,
				[55657] = true,
				[53674] = true,
				[58498] = true,
				[51504] = true,
				[50158] = true,
				[48370] = true,
				[47853] = true,
				[41776] = true,
				[47981] = true,
				[50092] = true,
				[52203] = true,
				[39985] = true,
				[48559] = true,
				[44785] = true,
				[48365] = true,
				[39691] = true,
				[44399] = true,
				[44463] = true,
				[48621] = true,
				[48943] = true,
				[52656] = true,
				[31579] = true,
				[38642] = true,
				[48941] = true,
				[55404] = true,
				[55210] = true,
				[49133] = true,
				[52462] = true,
				[51308] = true,
				[53677] = true,
				[50802] = true,
				[49453] = true,
				[55619] = true,
				[51628] = true,
				[47217] = true,
				[54510] = true,
				[53867] = true,
				[50544] = true,
				[47854] = true,
				[41777] = true,
				[47982] = true,
				[52140] = true,
				[52204] = true,
				[54315] = true,
				[50672] = true,
				[50349] = true,
				[52460] = true,
				[40242] = true,
				[31549] = true,
				[50605] = true,
				[50669] = true,
				[50733] = true,
				[50797] = true,
				[57002] = true,
				[52463] = true,
				[48942] = true,
				[55171] = true,
				[53164] = true,
				[49134] = true,
				[48753] = true,
				[51309] = true,
				[53167] = true,
				[55531] = true,
				[55595] = true,
				[55659] = true,
				[42740] = true,
				[48774] = true,
				[55851] = true,
				[42932] = true,
				[53551] = true,
				[56043] = true,
				[52013] = true,
				[48773] = true,
				[56494] = true,
				[48111] = true,
				[39987] = true,
				[54380] = true,
				[50417] = true,
				[48367] = true,
				[50609] = true,
				[48946] = true,
				[44465] = true,
				[48623] = true,
				[42293] = true,
				[31548] = true,
				[44721] = true,
				[52973] = true,
				[53037] = true,
				[47219] = true,
				[42933] = true,
				[54194] = true,
				[55340] = true,
				[51310] = true,
				[56177] = true,
				[31583] = true,
				[33079] = true,
				[51566] = true,
				[51630] = true,
				[51694] = true,
				[51758] = true,
				[53936] = true,
				[47792] = true,
				[47856] = true,
				[58155] = true,
				[57841] = true,
				[50095] = true,
				[50674] = true,
				[54317] = true,
				[52334] = true,
				[50351] = true,
				[48368] = true,
				[46772] = true,
				[55088] = true,
				[48560] = true,
				[53699] = true,
				[53635] = true,
				[55618] = true,
				[57004] = true,
				[52974] = true,
				[48944] = true,
				[46961] = true,
				[42931] = true,
				[42995] = true,
				[55341] = true,
				[51311] = true,
				[51122] = true,
				[55533] = true,
				[55597] = true,
				[47473] = true,
				[53678] = true,
				[51396] = true,
				[49285] = true,
				[49075] = true,
				[49267] = true,
				[55600] = true,
				[58156] = true,
				[49523] = true,
				[58284] = true,
				[48113] = true,
				[54318] = true,
				[51762] = true,
				[46258] = true,
				[48369] = true,
				[54574] = true,
				[54638] = true,
				[50608] = true,
				[56813] = true,
				[53186] = true,
				[44659] = true,
				[56240] = true,
				[46834] = true,
				[48945] = true,
				[38774] = true,
				[51120] = true,
				[42996] = true,
				[56961] = true,
				[45171] = true,
				[51376] = true,
				[49393] = true,
				[55598] = true,
				[48756] = true,
				[51632] = true,
				[55089] = true,
				[55153] = true,
				[42935] = true,
				[55982] = true,
				[56641] = true,
				[49969] = true,
				[47986] = true,
				[58285] = true,
				[52208] = true,
				[48178] = true,
				[47221] = true,
				[50353] = true,
				[42229] = true,
				[50481] = true,
				[42184] = true,
				[54703] = true,
				[56814] = true,
				[55729] = true,
				[52291] = true,
				[57006] = true,
				[42741] = true,
				[55087] = true,
				[55793] = true,
				[53168] = true,
				[42997] = true,
				[50036] = true,
				[55407] = true,
				[52147] = true,
				[49394] = true,
				[55599] = true,
				[49522] = true,
				[51633] = true,
				[51697] = true,
				[51761] = true,
				[44663] = true,
				[55983] = true,
				[50612] = true,
				[40761] = true,
				[47987] = true,
				[54192] = true,
				[50162] = true,
				[50226] = true,
				[49269] = true,
				[50354] = true,
				[51638] = true,
				[51572] = true,
				[53747] = true,
				[50610] = true,
				[56815] = true,
				[51892] = true,
				[52849] = true,
				[31582] = true,
				[56178] = true,
				[53041] = true,
				[56242] = true,
				[53169] = true,
				[42998] = true,
				[57391] = true,
				[47220] = true,
				[53442] = true,
				[49395] = true,
				[45365] = true,
				[53617] = true,
				[51331] = true,
				[52212] = true,
				[49715] = true,
				[54451] = true,
				[57280] = true,
				[40122] = true,
				[53172] = true,
				[54129] = true,
				[52146] = true,
				[50163] = true,
				[50227] = true,
				[57330] = true,
				[54449] = true,
				[48372] = true,
				[56624] = true,
				[44406] = true,
				[50611] = true,
				[50675] = true,
				[51637] = true,
				[50803] = true,
				[46773] = true,
				[50819] = true,
				[48948] = true,
				[57200] = true,
				[53170] = true,
				[42999] = true,
				[51251] = true,
				[49268] = true,
				[39097] = true,
				[56243] = true,
				[55601] = true,
				[51571] = true,
				[47541] = true,
				[53746] = true,
				[58290] = true,
				[44486] = true,
				[51891] = true,
				[49908] = true,
				[48311] = true,
				[47989] = true,
				[56241] = true,
				[56627] = true,
				[50228] = true,
				[31552] = true,
				[50356] = true,
				[56561] = true,
				[52789] = true,
				[54401] = true,
				[44471] = true,
				[40008] = true,
				[56881] = true,
				[56945] = true,
				[46774] = true,
				[53045] = true,
				[55090] = true,
				[49143] = true,
				[42936] = true,
				[43000] = true,
				[51190] = true,
				[47222] = true,
				[51446] = true,
				[51444] = true,
				[55602] = true,
				[53619] = true,
				[55730] = true,
				[51700] = true,
				[49923] = true,
				[55732] = true,
				[55986] = true,
				[55860] = true,
				[54453] = true,
				[50037] = true,
				[54195] = true,
				[50165] = true,
				[56370] = true,
				[48184] = true,
				[48310] = true,
				[46327] = true,
				[56626] = true,
				[58737] = true,
				[48440] = true,
				[50041] = true,
				[52788] = true,
				[56946] = true,
				[57010] = true,
				[46839] = true,
				[43334] = true,
				[57202] = true,
				[42937] = true,
				[43001] = true,
				[53174] = true,
				[47223] = true,
				[47287] = true,
				[49398] = true,
				[53441] = true,
				[47097] = true,
				[55731] = true,
				[53748] = true,
				[49718] = true,
				[47289] = true,
				[51447] = true,
				[53622] = true,
				[41786] = true,
				[47991] = true,
				[54196] = true,
				[54134] = true,
				[54324] = true,
				[46200] = true,
				[40123] = true,
				[52469] = true,
				[48439] = true,
				[54198] = true,
				[44473] = true,
				[48899] = true,
				[50742] = true,
				[58994] = true,
				[54964] = true,
				[46840] = true,
				[57139] = true,
				[57203] = true,
				[50168] = true,
				[43002] = true,
				[56629] = true,
				[47224] = true,
				[48505] = true,
				[49399] = true,
				[47416] = true,
				[53621] = true,
				[45497] = true,
				[53749] = true,
				[49719] = true,
				[53877] = true,
				[46842] = true,
				[51064] = true,
				[49975] = true,
				[47992] = true,
				[56244] = true,
				[56308] = true,
				[54325] = true,
				[54389] = true,
				[50359] = true,
				[57334] = true,
				[56628] = true,
				[48504] = true,
				[47098] = true,
				[50679] = true,
				[52790] = true,
				[45883] = true,
				[50233] = true,
				[46841] = true,
				[57140] = true,
				[54400] = true,
				[47033] = true,
				[43003] = true,
				[55349] = true,
				[51319] = true,
				[51383] = true,
				[49400] = true,
				[48195] = true,
				[49528] = true,
				[51639] = true,
				[53750] = true,
				[55861] = true,
				[54519] = true,
				[48442] = true,
				[51959] = true,
				[49976] = true,
				[47993] = true,
				[56245] = true,
				[56309] = true,
				[52279] = true,
				[51961] = true,
				[54454] = true,
				[54518] = true,
				[48441] = true,
				[40317] = true,
				[54710] = true,
				[56950] = true,
				[48954] = true,
				[31553] = true,
				[31585] = true,
				[55030] = true,
				[57141] = true,
				[38782] = true,
				[51129] = true,
				[51192] = true,
				[55350] = true,
				[51320] = true,
				[51384] = true,
				[49401] = true,
				[49465] = true,
				[53623] = true,
				[55734] = true,
				[53751] = true,
				[53815] = true,
				[43644] = true,
				[49794] = true,
				[51193] = true,
				[56118] = true,
				[47994] = true,
				[56246] = true,
				[51321] = true,
				[56374] = true,
				[51833] = true,
				[40126] = true,
				[52472] = true,
				[56630] = true,
				[50553] = true,
				[48570] = true,
				[47867] = true,
				[56119] = true,
				[48762] = true,
				[54200] = true,
				[46843] = true,
				[55095] = true,
				[56311] = true,
				[53176] = true,
				[47099] = true,
				[47235] = true,
				[49274] = true,
				[46268] = true,
				[49402] = true,
				[54201] = true,
				[49530] = true,
				[55735] = true,
				[54457] = true,
				[53816] = true,
				[43645] = true,
				[51897] = true,
				[56055] = true,
				[43837] = true,
				[43901] = true,
				[56247] = true,
				[50170] = true,
				[56375] = true,
				[53120] = true,
				[54456] = true,
				[52473] = true,
				[48443] = true,
				[48507] = true,
				[53369] = true,
				[57086] = true,
				[52793] = true,
				[50810] = true,
				[31586] = true,
				[51386] = true,
				[55096] = true,
				[52282] = true,
				[52154] = true,
				[47100] = true,
				[46781] = true,
				[47228] = true,
				[55480] = true,
				[49403] = true,
				[55608] = true,
				[55033] = true,
				[55736] = true,
				[53753] = true,
				[47101] = true,
				[49787] = true,
				[49276] = true,
				[56056] = true,
				[52026] = true,
				[50043] = true,
				[56248] = true,
				[55737] = true,
				[56376] = true,
				[50299] = true,
				[50363] = true,
				[58615] = true,
				[56632] = true,
				[48508] = true,
				[56057] = true,
				[42117] = true,
				[52027] = true,
				[56185] = true,
				[54969] = true,
				[50939] = true,
				[52283] = true,
				[56190] = true,
				[53178] = true,
				[57336] = true,
				[53306] = true,
				[53370] = true,
				[53434] = true,
				[48317] = true,
				[56633] = true,
				[47485] = true,
				[45502] = true,
				[55801] = true,
				[53818] = true,
				[51835] = true,
				[53951] = true,
				[47869] = true,
				[56121] = true,
				[50044] = true,
				[54202] = true,
				[50172] = true,
				[56377] = true,
				[54394] = true,
				[54458] = true,
				[52475] = true,
				[48445] = true,
				[53887] = true,
				[49793] = true,
				[59000] = true,
				[52795] = true,
				[52859] = true,
				[55425] = true,
				[52987] = true,
				[51584] = true,
				[47238] = true,
				[49725] = true,
				[39746] = true,
				[53307] = true,
				[46079] = true,
				[53435] = true,
				[57593] = true,
				[55610] = true,
				[47486] = true,
				[45503] = true,
				[53755] = true,
				[53819] = true,
				[45123] = true,
				[51200] = true,
				[56058] = true,
				[52028] = true,
				[56186] = true,
				[54203] = true,
				[50173] = true,
				[52284] = true,
				[50301] = true,
				[56506] = true,
				[56378] = true,
				[50493] = true,
				[38275] = true,
				[50621] = true,
				[44544] = true,
				[52796] = true,
				[56313] = true,
				[47218] = true,
				[44800] = true,
				[53436] = true,
				[56635] = true,
				[56315] = true,
				[57338] = true,
				[52285] = true,
				[53372] = true,
				[51389] = true,
				[46272] = true,
				[48447] = true,
				[51581] = true,
				[45504] = true,
				[51709] = true,
				[53820] = true,
				[47743] = true,
				[55995] = true,
				[48575] = true,
				[52029] = true,
				[56187] = true,
				[54204] = true,
				[46080] = true,
				[50238] = true,
				[42114] = true,
				[50366] = true,
				[56571] = true,
				[38212] = true,
				[31556] = true,
				[50622] = true,
				[31588] = true,
				[56891] = true,
				[50814] = true,
				[54972] = true,
				[46274] = true,
				[46845] = true,
				[45971] = true,
				[53181] = true,
				[46078] = true,
				[54206] = true,
				[46297] = true,
				[51390] = true,
				[49407] = true,
				[52031] = true,
				[47488] = true,
				[49791] = true,
				[54141] = true,
				[57915] = true,
				[55932] = true,
				[50047] = true,
				[52158] = true,
				[52030] = true,
				[56188] = true,
				[54205] = true,
				[51774] = true,
				[50239] = true,
				[42115] = true,
				[50367] = true,
				[52040] = true,
				[48448] = true,
				[52123] = true,
				[49981] = true,
				[51314] = true,
				[56892] = true,
				[52062] = true,
				[51582] = true,
				[57340] = true,
				[55101] = true,
				[53118] = true,
				[53182] = true,
				[51199] = true,
				[49216] = true,
				[51569] = true,
				[51391] = true,
				[43993] = true,
				[47487] = true,
				[47489] = true,
				[52286] = true,
				[51711] = true,
				[48064] = true,
				[49792] = true,
				[50111] = true,
				[51967] = true,
				[49984] = true,
				[56189] = true,
				[37830] = true,
				[46082] = true,
				[52287] = true,
				[42116] = true,
				[50368] = true,
				[50432] = true,
				[48449] = true,
				[48513] = true,
				[44483] = true,
				[50688] = true,
				[40517] = true,
				[56957] = true,
				[31589] = true,
				[50365] = true,
				[48446] = true,
				[54459] = true,
				[53183] = true,
				[47106] = true,
				[55358] = true,
				[52156] = true,
				[53439] = true,
				[49409] = true,
				[51644] = true,
				[53631] = true,
				[49601] = true,
				[51712] = true,
				[54143] = true,
				[55934] = true,
				[45763] = true,
				[51968] = true,
				[52032] = true,
				[50049] = true,
				[52219] = true,
				[50177] = true,
				[52288] = true,
				[52352] = true,
				[46275] = true,
				[52480] = true,
				[52544] = true,
				[54266] = true,
				[44484] = true,
				[56504] = true,
				[50753] = true,
				[58167] = true,
				[54975] = true,
				[48898] = true,
				[48962] = true,
				[51073] = true,
				[53184] = true,
				[51201] = true,
				[49218] = true,
				[49282] = true,
				[52281] = true,
				[51457] = true,
				[47995] = true,
				[51585] = true,
				[49602] = true,
				[53624] = true,
				[49730] = true,
				[53888] = true,
				[47035] = true,
				[51969] = true,
				[52033] = true,
				[48003] = true,
				[48506] = true,
				[54272] = true,
				[52289] = true,
				[42118] = true,
				[50370] = true,
				[54199] = true,
				[39806] = true,
				[50562] = true,
				[51576] = true,
				[50616] = true,
				[40519] = true,
				[52865] = true,
				[54647] = true,
				[55040] = true,
				[48963] = true,
				[53814] = true,
				[53185] = true,
				[57343] = true,
				[55360] = true,
				[51191] = true,
				[51394] = true,
				[50306] = true,
				[47428] = true,
				[51586] = true,
				[48196] = true,
				[51714] = true,
				[54197] = true,
				[51842] = true,
				[45765] = true,
				[56064] = true,
				[52034] = true,
				[48004] = true,
				[49015] = true,
				[56320] = true,
				[52290] = true,
				[46213] = true,
				[50371] = true,
				[50614] = true,
				[56640] = true,
				[48516] = true,
				[58815] = true,
				[50691] = true,
				[57524] = true,
				[52866] = true,
				[43449] = true,
				[49014] = true,
				[50741] = true,
				[43900] = true,
				[51139] = true,
				[51203] = true,
				[55361] = true,
				[49284] = true,
				[51395] = true,
				[49412] = true,
				[55617] = true,
				[52150] = true,
				[45510] = true,
				[51715] = true,
				[47685] = true,
				[55937] = true,
				[53171] = true,
				[57009] = true,
				[52035] = true,
				[48005] = true,
				[52163] = true,
				[56321] = true,
				[40009] = true,
				[58496] = true,
				[50372] = true,
				[57392] = true,
				[48453] = true,
				[48517] = true,
				[56944] = true,
				[48500] = true,
				[56304] = true,
				[52867] = true,
				[31591] = true,
				[47988] = true,
				[48965] = true,
				[51076] = true,
				[53187] = true,
				[51204] = true,
				[55362] = true,
				[55426] = true,
				[53443] = true,
				[47990] = true,
				[53571] = true,
				[51588] = true,
				[45511] = true,
				[48947] = true,
				[47686] = true,
				[56943] = true,
				[45767] = true,
				[56239] = true,
				[52036] = true,
				[39607] = true,
				[48070] = true,
				[53616] = true,
				[48198] = true,
				[51185] = true,
				[50373] = true,
				[44296] = true,
				[56642] = true,
				[48518] = true,
				[50161] = true,
				[54787] = true,
				[51312] = true,
				[46727] = true,
				[49137] = true,
				[48902] = true,
				[52975] = true,
				[53124] = true,
				[54193] = true,
				[51205] = true,
				[55363] = true,
				[49286] = true,
				[53444] = true,
				[50352] = true,
				[53572] = true,
				[50096] = true,
				[52654] = true,
				[39435] = true,
				[47687] = true,
				[51845] = true,
				[53956] = true,
				[49926] = true,
				[56131] = true,
				[31580] = true,
				[52461] = true,
				[52205] = true,
				[48199] = true,
				[54404] = true,
				[50374] = true,
				[56962] = true,
				[48455] = true,
				[48519] = true,
				[56771] = true,
				[50694] = true,
				[56899] = true,
				[52869] = true,
				[57027] = true,
				[52997] = true,
				[48366] = true,
				[41335] = true,
				[51142] = true,
				[31752] = true,
				[49223] = true,
				[49287] = true,
				[53445] = true,
				[47431] = true,
				[43338] = true,
				[40753] = true,
				[53701] = true,
				[48109] = true,
				[47688] = true,
				[51846] = true,
				[56004] = true,
				[39692] = true,
				[52038] = true,
				[48008] = true,
				[46253] = true,
				[54507] = true,
				[48200] = true,
				[55300] = true,
				[53673] = true,
				[51851] = true,
				[56644] = true,
				[48520] = true,
				[44653] = true,
				[44397] = true,
				[48171] = true,
				[56964] = true,
				[47979] = true,
				[55045] = true,
				[39471] = true,
				[57220] = true,
				[45769] = true,
				[51207] = true,
				[52840] = true,
				[49288] = true,
				[53446] = true,
				[40302] = true,
				[49480] = true,
				[41773] = true,
				[58085] = true,
				[49769] = true,
				[47689] = true,
				[45706] = true,
				[48776] = true,
				[41740] = true,
				[47945] = true,
				[48009] = true,
				[56261] = true,
				[41900] = true,
				[49960] = true,
				[50312] = true,
				[42188] = true,
				[54631] = true,
				[50504] = true,
				[48521] = true,
				[56740] = true,
				[50696] = true,
				[46057] = true,
				[46730] = true,
				[46794] = true,
				[41899] = true,
				[52327] = true,
				[57221] = true,
				[38862] = true,
				[51208] = true,
				[49225] = true,
				[49289] = true,
				[54662] = true,
				[51464] = true,
				[49481] = true,
				[55686] = true,
				[39595] = true,
				[51720] = true,
				[47690] = true,
				[47754] = true,
				[53959] = true,
				[41741] = true,
				[47946] = true,
				[50057] = true,
				[56262] = true,
				[50149] = true,
				[48202] = true,
				[54407] = true,
				[54471] = true,
				[57249] = true,
				[54946] = true,
				[48522] = true,
				[52259] = true,
				[50697] = true,
				[51427] = true,
				[48778] = true,
				[48842] = true,
				[59141] = true,
				[51017] = true,
				[57222] = true,
				[51145] = true,
				[51209] = true,
				[49226] = true,
				[49290] = true,
				[51401] = true,
				[49418] = true,
				[43341] = true,
				[49443] = true,
				[53704] = true,
				[53768] = true,
				[47691] = true,
				[47755] = true,
				[51913] = true,
				[47883] = true,
				[54088] = true,
				[50058] = true,
				[41934] = true,
				[56607] = true,
				[48203] = true,
				[40079] = true,
				[45477] = true,
				[52489] = true,
				[53960] = true,
				[48523] = true,
				[52448] = true,
				[50698] = true,
				[53919] = true,
				[52873] = true,
				[46796] = true,
				[48354] = true,
				[54878] = true,
				[50640] = true,
				[51352] = true,
				[48347] = true,
				[47180] = true,
				[49233] = true,
				[51402] = true,
				[49419] = true,
				[47329] = true,
				[50386] = true,
				[55752] = true,
				[51722] = true,
				[52318] = true,
				[49803] = true,
				[53961] = true,
				[41743] = true,
				[49995] = true,
				[50059] = true,
				[52170] = true,
				[54281] = true,
				[50251] = true,
				[51358] = true,
				[56520] = true,
				[58631] = true,
				[58695] = true,
				[42383] = true,
				[50635] = true,
				[50699] = true,
				[48524] = true,
				[56968] = true,
				[46797] = true,
				[50955] = true,
				[42831] = true,
				[51083] = true,
				[53276] = true,
				[51211] = true,
				[47181] = true,
				[49292] = true,
				[51403] = true,
				[51467] = true,
				[53450] = true,
				[50653] = true,
				[53706] = true,
				[51723] = true,
				[37726] = true,
				[49804] = true,
				[51349] = true,
				[41744] = true,
				[49996] = true,
				[51151] = true,
				[48077] = true,
				[56729] = true,
				[54618] = true,
				[40081] = true,
				[46286] = true,
				[52491] = true,
				[48461] = true,
				[56025] = true,
				[56777] = true,
				[50700] = true,
				[53267] = true,
				[40593] = true,
				[46798] = true,
				[57097] = true,
				[48973] = true,
				[53131] = true,
				[38305] = true,
				[52762] = true,
				[49229] = true,
				[50331] = true,
				[56024] = true,
				[53849] = true,
				[55182] = true,
				[56277] = true,
				[51660] = true,
				[53771] = true,
				[8861] = true,
				[49805] = true,
				[51916] = true,
				[41745] = true,
				[49997] = true,
				[48014] = true,
				[52172] = true,
				[52236] = true,
				[42065] = true,
				[41694] = true,
				[52428] = true,
				[50445] = true,
				[47835] = true,
				[50573] = true,
				[56778] = true,
				[48654] = true,
				[50777] = true,
				[52876] = true,
				[46799] = true,
				[55894] = true,
				[44880] = true,
				[51085] = true,
				[51149] = true,
				[57354] = true,
				[47183] = true,
				[51341] = true,
				[53452] = true,
				[51469] = true,
				[57674] = true,
				[47961] = true,
				[55755] = true,
				[53772] = true,
				[56980] = true,
				[49806] = true,
				[56724] = true,
				[41746] = true,
				[49998] = true,
				[48015] = true,
				[52173] = true,
				[56979] = true,
				[54992] = true,
				[31308] = true,
				[58506] = true,
				[58634] = true,
				[56143] = true,
				[52493] = true,
				[42450] = true,
				[47186] = true,
				[48273] = true,
				[52877] = true,
				[46800] = true,
				[57170] = true,
				[53069] = true,
				[51150] = true,
				[47056] = true,
				[51214] = true,
				[47184] = true,
				[49295] = true,
				[53453] = true,
				[51470] = true,
				[45393] = true,
				[53265] = true,
				[51662] = true,
				[51726] = true,
				[55884] = true,
				[55948] = true,
				[51918] = true,
				[51982] = true,
				[47952] = true,
				[50063] = true,
				[48080] = true,
				[37909] = true,
				[56526] = true,
				[48272] = true,
				[55760] = true,
				[48400] = true,
				[50511] = true,
				[49234] = true,
				[49620] = true,
				[55758] = true,
				[51026] = true,
				[49299] = true,
				[57036] = true,
				[58638] = true,
			},
			["rares_killed"] = {
				[132319] = -1,
				[144857] = -1,
				[138972] = -1,
				[137181] = -1,
				[135902] = -1,
				[152790] = -1,
				[137182] = -1,
				[135903] = -1,
				[137183] = -1,
				[133345] = -1,
				[137951] = -1,
				[152792] = -1,
				[145372] = -1,
				[135905] = -1,
				[138464] = -1,
				[144861] = -1,
				[132835] = -1,
				[153561] = -1,
				[147932] = -1,
				[131812] = -1,
				[138465] = -1,
				[153818] = -1,
				[147933] = -1,
				[137954] = -1,
				[138466] = -1,
				[134884] = -1,
				[153563] = -1,
				[158169] = -1,
				[137955] = -1,
				[139235] = -1,
				[147935] = -1,
				[137956] = -1,
				[140259] = -1,
				[139748] = -1,
				[140260] = -1,
				[138469] = -1,
				[136934] = -1,
				[156125] = -1,
				[152287] = -1,
				[126455] = -1,
				[138470] = -1,
				[141029] = -1,
				[153567] = -1,
				[133353] = -1,
				[156126] = -1,
				[131818] = -1,
				[129526] = -1,
				[138471] = -1,
				[153568] = -1,
				[131819] = -1,
				[130550] = -1,
				[130678] = -1,
				[129015] = -1,
				[129527] = -1,
				[146917] = -1,
				[133356] = -1,
				[130679] = -1,
				[126969] = -1,
				[148454] = -1,
				[136428] = -1,
				[131311] = -1,
				[133870] = -1,
				[130680] = -1,
				[134638] = -1,
				[131568] = -1,
				[131824] = -1,
				[148456] = -1,
				[131825] = -1,
				[130681] = -1,
				[132849] = -1,
				[133361] = -1,
				[145132] = -1,
				[130298] = -1,
				[152297] = -1,
				[126460] = -1,
				[110340] = -1,
				[141039] = -1,
				[147948] = -1,
				[137969] = -1,
				[127484] = -1,
				[136690] = -1,
				[134899] = -1,
				[137458] = -1,
				[126205] = -1,
				[138226] = -1,
				[130683] = -1,
				[153067] = -1,
				[126845] = -1,
				[126973] = -1,
				[131318] = -1,
				[154347] = -1,
				[132086] = -1,
				[129788] = -1,
				[154092] = -1,
				[136181] = -1,
				[152813] = -1,
				[157419] = -1,
				[126974] = -1,
				[127486] = -1,
				[126463] = -1,
				[130685] = -1,
				[126847] = -1,
				[134137] = -1,
				[152816] = -1,
				[154352] = -1,
				[126848] = -1,
				[148212] = -1,
				[127488] = -1,
				[140792] = -1,
				[162030] = -1,
				[156145] = -1,
				[154354] = -1,
				[148469] = -1,
				[145399] = -1,
				[162287] = -1,
				[150773] = -1,
				[153332] = -1,
				[128385] = -1,
				[153333] = -1,
				[127106] = -1,
				[127490] = -1,
				[142587] = -1,
				[136702] = -1,
				[139005] = -1,
				[145402] = -1,
				[131585] = -1,
				[134144] = -1,
				[124548] = -1,
				[139006] = -1,
				[131586] = -1,
				[156406] = -1,
				[138495] = -1,
				[125828] = -1,
				[131587] = -1,
				[138496] = -1,
				[137473] = -1,
				[134147] = -1,
				[138497] = -1,
				[132868] = -1,
				[137474] = -1,
				[147965] = -1,
				[152315] = -1,
				[138498] = -1,
				[136196] = -1,
				[138499] = -1,
				[131847] = -1,
				[138500] = -1,
				[144897] = -1,
				[141059] = -1,
				[151806] = -1,
				[147968] = -1,
				[154365] = -1,
				[140292] = -1,
				[138501] = -1,
				[144898] = -1,
				[139269] = -1,
				[137478] = -1,
				[126215] = -1,
				[152319] = -1,
				[140293] = -1,
				[147202] = -1,
				[126983] = -1,
				[127111] = -1,
				[140038] = -1,
				[138247] = -1,
				[127879] = -1,
				[126216] = -1,
				[140295] = -1,
				[2442] = -1,
				[154113] = -1,
				[152834] = -1,
				[151811] = -1,
				[124170] = -1,
				[142088] = -1,
				[128648] = -1,
				[145159] = -1,
				[145415] = -1,
				[127497] = -1,
				[161280] = -1,
				[129928] = -1,
				[137484] = -1,
				[134158] = -1,
				[145161] = -1,
				[137485] = -1,
				[131600] = -1,
				[146185] = -1,
				[127626] = -1,
				[153094] = -1,
				[153862] = -1,
				[146186] = -1,
				[138254] = -1,
				[128650] = -1,
				[153095] = -1,
				[145163] = -1,
				[139278] = -1,
				[137487] = -1,
				[146187] = -1,
				[138255] = -1,
				[134417] = -1,
				[129802] = -1,
				[151305] = -1,
				[134418] = -1,
				[153097] = -1,
				[145421] = -1,
				[139536] = -1,
				[78116] = -1,
				[129547] = -1,
				[129803] = -1,
				[151307] = -1,
				[139537] = -1,
				[139793] = -1,
				[138002] = -1,
				[144911] = -1,
				[141585] = -1,
				[129548] = -1,
				[127757] = -1,
				[139283] = -1,
				[131863] = -1,
				[140563] = -1,
				[13359] = -1,
				[131864] = -1,
				[136214] = -1,
				[136470] = -1,
				[129805] = -1,
				[139285] = -1,
				[155917] = -1,
				[133912] = -1,
				[144915] = -1,
				[157709] = -1,
				[147730] = -1,
				[129550] = -1,
				[129806] = -1,
				[136984] = -1,
				[139287] = -1,
				[139799] = -1,
				[131356] = -1,
				[135706] = -1,
				[135962] = -1,
				[153618] = -1,
				[130191] = -1,
				[135963] = -1,
				[139290] = -1,
				[135964] = -1,
				[132126] = -1,
				[140059] = -1,
				[144409] = -1,
				[155412] = -1,
				[139804] = -1,
				[144410] = -1,
				[127762] = -1,
				[139805] = -1,
				[139806] = -1,
				[161812] = -1,
				[151833] = -1,
				[139807] = -1,
				[145181] = -1,
				[133155] = -1,
				[127124] = -1,
				[139808] = -1,
				[123286] = -1,
				[139297] = -1,
				[122263] = -1,
				[136483] = -1,
				[139298] = -1,
				[151836] = -1,
				[137763] = -1,
				[127381] = -1,
				[148510] = -1,
				[122264] = -1,
				[140835] = -1,
				[131112] = -1,
				[140068] = -1,
				[132904] = -1,
				[149536] = -1,
				[151839] = -1,
				[130325] = -1,
				[140069] = -1,
				[148513] = -1,
				[153119] = -1,
				[151840] = -1,
				[123289] = -1,
				[124185] = -1,
				[122266] = -1,
				[130582] = -1,
				[123290] = -1,
				[138281] = -1,
				[152866] = -1,
				[140585] = -1,
				[883] = -1,
				[156706] = -1,
				[134701] = -1,
				[132910] = -1,
				[137516] = -1,
				[135981] = -1,
				[132911] = -1,
				[137517] = -1,
				[140076] = -1,
				[131377] = -1,
				[140077] = -1,
				[155686] = -1,
				[140334] = -1,
				[153896] = -1,
				[138288] = -1,
				[134706] = -1,
				[137521] = -1,
				[140336] = -1,
				[153130] = -1,
				[155689] = -1,
				[154154] = -1,
				[140337] = -1,
				[132917] = -1,
				[145967] = -1,
				[123423] = -1,
				[144944] = -1,
				[132918] = -1,
				[133430] = -1,
				[134966] = -1,
				[13329] = -1,
				[129181] = -1,
				[133943] = -1,
				[132920] = -1,
				[130077] = -1,
				[133432] = -1,
				[130333] = -1,
				[140085] = -1,
				[154670] = -1,
				[140086] = -1,
				[144948] = -1,
				[139063] = -1,
				[130334] = -1,
				[156463] = -1,
				[152881] = -1,
				[144949] = -1,
				[132923] = -1,
				[137529] = -1,
				[130079] = -1,
				[133436] = -1,
				[130335] = -1,
				[126497] = -1,
				[152883] = -1,
				[128928] = -1,
				[141625] = -1,
				[145975] = -1,
				[152884] = -1,
				[145976] = -1,
				[152885] = -1,
				[153141] = -1,
				[149303] = -1,
				[145465] = -1,
				[141627] = -1,
				[145977] = -1,
				[125347] = -1,
				[138557] = -1,
				[135231] = -1,
				[153910] = -1,
				[138558] = -1,
				[155702] = -1,
				[141629] = -1,
				[140094] = -1,
				[138559] = -1,
				[140095] = -1,
				[124581] = -1,
				[137025] = -1,
				[135234] = -1,
				[141631] = -1,
				[154681] = -1,
				[129699] = -1,
				[144958] = -1,
				[135235] = -1,
				[140353] = -1,
				[138562] = -1,
				[151612] = -1,
				[141633] = -1,
				[140354] = -1,
				[134725] = -1,
				[133190] = -1,
				[139843] = -1,
				[136005] = -1,
				[140355] = -1,
				[124583] = -1,
				[138820] = -1,
				[137029] = -1,
				[139844] = -1,
				[136006] = -1,
				[140356] = -1,
				[138821] = -1,
				[135239] = -1,
				[139845] = -1,
				[144707] = -1,
				[138822] = -1,
				[135240] = -1,
				[151872] = -1,
				[139846] = -1,
				[148290] = -1,
				[136264] = -1,
				[138823] = -1,
				[135241] = -1,
				[128551] = -1,
				[132683] = -1,
				[131404] = -1,
				[133963] = -1,
				[129575] = -1,
				[144966] = -1,
				[119724] = -1,
				[139337] = -1,
				[12051] = -1,
				[151876] = -1,
				[139339] = -1,
				[131407] = -1,
				[140107] = -1,
				[128553] = -1,
				[139340] = -1,
				[140108] = -1,
				[129961] = -1,
				[139341] = -1,
				[130217] = -1,
				[152135] = -1,
				[136015] = -1,
				[139342] = -1,
				[131666] = -1,
				[134993] = -1,
				[139343] = -1,
				[131411] = -1,
				[131667] = -1,
				[132179] = -1,
				[134994] = -1,
				[137553] = -1,
				[148300] = -1,
				[144974] = -1,
				[131669] = -1,
				[154698] = -1,
				[144975] = -1,
				[141905] = -1,
				[144976] = -1,
				[135765] = -1,
				[138836] = -1,
				[134998] = -1,
				[135254] = -1,
				[153933] = -1,
				[144722] = -1,
				[138837] = -1,
				[134232] = -1,
				[128686] = -1,
				[138838] = -1,
				[144212] = -1,
				[138839] = -1,
				[144213] = -1,
				[148563] = -1,
				[144725] = -1,
				[147028] = -1,
				[149331] = -1,
				[135258] = -1,
				[149843] = -1,
				[154705] = -1,
				[146773] = -1,
				[138841] = -1,
				[155985] = -1,
				[131677] = -1,
				[144727] = -1,
				[145495] = -1,
				[138332] = -1,
				[126642] = -1,
				[136797] = -1,
				[135774] = -1,
				[152918] = -1,
				[136798] = -1,
				[139357] = -1,
				[153942] = -1,
				[142172] = -1,
				[140381] = -1,
				[140637] = -1,
				[144987] = -1,
				[139614] = -1,
				[156502] = -1,
				[140382] = -1,
				[134753] = -1,
				[137824] = -1,
				[128435] = -1,
				[140383] = -1,
				[136545] = -1,
				[134754] = -1,
				[139360] = -1,
				[151898] = -1,
				[136546] = -1,
				[126133] = -1,
				[131685] = -1,
				[136547] = -1,
				[139362] = -1,
				[136548] = -1,
				[128181] = -1,
				[133990] = -1,
				[152669] = -1,
				[136549] = -1,
				[144993] = -1,
				[151902] = -1,
				[136550] = -1,
				[153694] = -1,
				[137830] = -1,
				[130485] = -1,
				[136295] = -1,
				[136551] = -1,
				[132713] = -1,
				[126903] = -1,
				[136552] = -1,
				[127799] = -1,
				[139111] = -1,
				[133482] = -1,
				[136297] = -1,
				[136553] = -1,
				[128951] = -1,
				[131436] = -1,
				[152162] = -1,
				[150371] = -1,
				[154721] = -1,
				[129719] = -1,
				[145510] = -1,
				[152675] = -1,
				[136555] = -1,
				[136811] = -1,
				[12053] = -1,
				[139626] = -1,
				[136812] = -1,
				[130488] = -1,
				[127290] = -1,
				[49844] = -1,
				[150376] = -1,
				[126907] = -1,
				[147562] = -1,
				[153959] = -1,
				[140398] = -1,
				[153192] = -1,
				[128699] = -1,
				[137585] = -1,
				[159335] = -1,
				[131445] = -1,
				[138866] = -1,
				[126909] = -1,
				[151660] = -1,
				[137587] = -1,
				[135796] = -1,
				[134005] = -1,
				[145008] = -1,
				[126142] = -1,
				[143985] = -1,
				[124351] = -1,
				[126526] = -1,
				[152686] = -1,
				[151663] = -1,
				[124352] = -1,
				[136823] = -1,
				[129214] = -1,
				[129470] = -1,
				[136824] = -1,
				[137336] = -1,
				[145013] = -1,
				[141175] = -1,
				[129471] = -1,
				[129599] = -1,
				[147061] = -1,
				[151667] = -1,
				[134012] = -1,
				[147062] = -1,
				[129600] = -1,
				[136828] = -1,
				[4075] = -1,
				[126530] = -1,
				[145017] = -1,
				[136318] = -1,
				[145018] = -1,
				[128578] = -1,
				[136831] = -1,
				[131009] = -1,
				[129602] = -1,
				[138623] = -1,
				[136832] = -1,
				[141182] = -1,
				[128707] = -1,
				[139392] = -1,
				[132740] = -1,
				[139393] = -1,
				[152699] = -1,
				[138626] = -1,
				[134788] = -1,
				[151676] = -1,
				[138627] = -1,
				[134789] = -1,
				[139395] = -1,
				[152445] = -1,
				[138628] = -1,
				[145281] = -1,
				[139396] = -1,
				[139652] = -1,
				[144770] = -1,
				[132744] = -1,
				[129989] = -1,
				[151679] = -1,
				[134024] = -1,
				[132745] = -1,
				[135048] = -1,
				[139398] = -1,
				[152704] = -1,
				[146819] = -1,
				[145028] = -1,
				[137096] = -1,
				[139399] = -1,
				[139655] = -1,
				[138888] = -1,
				[128967] = -1,
				[139400] = -1,
				[152450] = -1,
				[136330] = -1,
				[133004] = -1,
				[128584] = -1,
				[135052] = -1,
				[157825] = -1,
				[152452] = -1,
				[136844] = -1,
				[130248] = -1,
				[152709] = -1,
				[144777] = -1,
				[136845] = -1,
				[128969] = -1,
				[152710] = -1,
				[144778] = -1,
				[137614] = -1,
				[152711] = -1,
				[146826] = -1,
				[145035] = -1,
				[137103] = -1,
				[146059] = -1,
				[140430] = -1,
				[146827] = -1,
				[155271] = -1,
				[97754] = -1,
				[140431] = -1,
				[146828] = -1,
				[132755] = -1,
				[139152] = -1,
				[153737] = -1,
				[129227] = -1,
				[146061] = -1,
				[140432] = -1,
				[129995] = -1,
				[131221] = -1,
				[139665] = -1,
				[136083] = -1,
				[130635] = -1,
				[141201] = -1,
				[153739] = -1,
				[146063] = -1,
				[152460] = -1,
				[140434] = -1,
				[140690] = -1,
				[129996] = -1,
				[153740] = -1,
				[152461] = -1,
				[146832] = -1,
				[155276] = -1,
				[128973] = -1,
				[153741] = -1,
				[152462] = -1,
				[146833] = -1,
				[145298] = -1,
				[134296] = -1,
				[146834] = -1,
				[155278] = -1,
				[134041] = -1,
				[146835] = -1,
				[126928] = -1,
				[143510] = -1,
				[137625] = -1,
				[136346] = -1,
				[137626] = -1,
				[140441] = -1,
				[146838] = -1,
				[122963] = -1,
				[129232] = -1,
				[152724] = -1,
				[145304] = -1,
				[146072] = -1,
				[130640] = -1,
				[146840] = -1,
				[130896] = -1,
				[145817] = -1,
				[140188] = -1,
				[140444] = -1,
				[141980] = -1,
				[153943] = -1,
				[137948] = -1,
				[156146] = -1,
				[130897] = -1,
				[145307] = -1,
				[160755] = -1,
				[151960] = -1,
				[141981] = -1,
				[153401] = -1,
				[129904] = -1,
				[146843] = -1,
				[152367] = -1,
				[145308] = -1,
				[135329] = -1,
				[150928] = -1,
				[149004] = -1,
				[134739] = -1,
				[136353] = -1,
				[135699] = -1,
				[153738] = -1,
				[124885] = -1,
				[155920] = -1,
				[131492] = -1,
				[14881] = -1,
				[144855] = -1,
				[134157] = -1,
				[152288] = -1,
				[137946] = -1,
				[145310] = -1,
				[157441] = -1,
				[162291] = -1,
				[153907] = -1,
				[145110] = -1,
				[136965] = -1,
				[152987] = -1,
				[157337] = -1,
				[135167] = -1,
				[133285] = -1,
				[133865] = -1,
				[141985] = -1,
				[136100] = -1,
				[152274] = -1,
				[152988] = -1,
				[153244] = -1,
				[157594] = -1,
				[152089] = -1,
				[100943] = -1,
				[135975] = -1,
				[154524] = -1,
				[148639] = -1,
				[136613] = -1,
				[136869] = -1,
				[138968] = -1,
				[122968] = -1,
				[139684] = -1,
				[140759] = -1,
				[123352] = -1,
				[126422] = -1,
				[136614] = -1,
				[145058] = -1,
				[135322] = -1,
				[139429] = -1,
				[152479] = -1,
				[126295] = -1,
				[126423] = -1,
				[127807] = -1,
				[136615] = -1,
				[148874] = -1,
				[158168] = -1,
				[122969] = -1,
				[152685] = -1,
				[129366] = -1,
				[154720] = -1,
				[136830] = -1,
				[129750] = -1,
				[145060] = -1,
				[153504] = -1,
				[153906] = -1,
				[153066] = -1,
				[133593] = -1,
				[126424] = -1,
				[140455] = -1,
				[127479] = -1,
				[132741] = -1,
				[126918] = -1,
				[122970] = -1,
				[132226] = -1,
				[129367] = -1,
				[140200] = -1,
				[140456] = -1,
				[127485] = -1,
				[140968] = -1,
				[137949] = -1,
				[139433] = -1,
				[135895] = -1,
				[127805] = -1,
				[140201] = -1,
				[140457] = -1,
				[130437] = -1,
				[134828] = -1,
				[137131] = -1,
				[122971] = -1,
				[139690] = -1,
				[145282] = -1,
				[139135] = -1,
				[140458] = -1,
				[137714] = -1,
				[145153] = -1,
				[137132] = -1,
				[132056] = -1,
				[139691] = -1,
				[154276] = -1,
				[148391] = -1,
				[139988] = -1,
				[138245] = -1,
				[136186] = -1,
				[145026] = -1,
				[122972] = -1,
				[130722] = -1,
				[129369] = -1,
				[148392] = -1,
				[134782] = -1,
				[144810] = -1,
				[124527] = -1,
				[137134] = -1,
				[127048] = -1,
				[139693] = -1,
				[135939] = -1,
				[130521] = -1,
				[150696] = -1,
				[129340] = -1,
				[145067] = -1,
				[134269] = -1,
				[122973] = -1,
				[136870] = -1,
				[129370] = -1,
				[140206] = -1,
				[153068] = -1,
				[131850] = -1,
				[126578] = -1,
				[145324] = -1,
				[130138] = -1,
				[127503] = -1,
				[131849] = -1,
				[140207] = -1,
				[139630] = -1,
				[153327] = -1,
				[139394] = -1,
				[130307] = -1,
				[136807] = -1,
				[130299] = -1,
				[129371] = -1,
				[140208] = -1,
				[140980] = -1,
				[129835] = -1,
				[140976] = -1,
				[145326] = -1,
				[139338] = -1,
				[133463] = -1,
				[142000] = -1,
				[126429] = -1,
				[145358] = -1,
				[146862] = -1,
				[140977] = -1,
				[130435] = -1,
				[135561] = -1,
				[128434] = -1,
				[123231] = -1,
				[134069] = -1,
				[146607] = -1,
				[146863] = -1,
				[136884] = -1,
				[130012] = -1,
				[134423] = -1,
				[132742] = -1,
				[134897] = -1,
				[151754] = -1,
				[140058] = -1,
				[146864] = -1,
				[136885] = -1,
				[138960] = -1,
				[139003] = -1,
				[123288] = -1,
				[154285] = -1,
				[132051] = -1,
				[154312] = -1,
				[134284] = -1,
				[157356] = -1,
				[140691] = -1,
				[145356] = -1,
				[141239] = -1,
				[130639] = -1,
				[153263] = -1,
				[130653] = -1,
				[146866] = -1,
				[134840] = -1,
				[128651] = -1,
				[135263] = -1,
				[135245] = -1,
				[139958] = -1,
				[151674] = -1,
				[136600] = -1,
				[146867] = -1,
				[129601] = -1,
				[137144] = -1,
				[140264] = -1,
				[136347] = -1,
				[134514] = -1,
				[154310] = -1,
				[139800] = -1,
				[132007] = -1,
				[137950] = -1,
				[145333] = -1,
				[153655] = -1,
				[129559] = -1,
				[132076] = -1,
				[136944] = -1,
				[134331] = -1,
				[140443] = -1,
				[144803] = -1,
				[137146] = -1,
				[130143] = -1,
				[136335] = -1,
				[135474] = -1,
				[134076] = -1,
				[130655] = -1,
				[144823] = -1,
				[140985] = -1,
				[137147] = -1,
				[131262] = -1,
				[151988] = -1,
				[137915] = -1,
				[138171] = -1,
				[138427] = -1,
				[122076] = -1,
				[134845] = -1,
				[129016] = -1,
				[140205] = -1,
				[151989] = -1,
				[124259] = -1,
				[123287] = -1,
				[138428] = -1,
				[145339] = -1,
				[153269] = -1,
				[145337] = -1,
				[137405] = -1,
				[151990] = -1,
				[123236] = -1,
				[138472] = -1,
				[138429] = -1,
				[131383] = -1,
				[140447] = -1,
				[130421] = -1,
				[127480] = -1,
				[147938] = -1,
				[131858] = -1,
				[134080] = -1,
				[130011] = -1,
				[127129] = -1,
				[138561] = -1,
				[137151] = -1,
				[151901] = -1,
				[139710] = -1,
				[140866] = -1,
				[127119] = -1,
				[137155] = -1,
				[132778] = -1,
				[146118] = -1,
				[137152] = -1,
				[126185] = -1,
				[137511] = -1,
				[148155] = -1,
				[147936] = -1,
				[134338] = -1,
				[133685] = -1,
				[153026] = -1,
				[137153] = -1,
				[140986] = -1,
				[137665] = -1,
				[139968] = -1,
				[127478] = -1,
				[148164] = -1,
				[151886] = -1,
				[157368] = -1,
				[135107] = -1,
				[139457] = -1,
				[138675] = -1,
				[140335] = -1,
				[139205] = -1,
				[138434] = -1,
				[138696] = -1,
				[140993] = -1,
				[145343] = -1,
				[155834] = -1,
				[149437] = -1,
				[127333] = -1,
				[145603] = -1,
				[130909] = -1,
				[129373] = -1,
				[151745] = -1,
				[137156] = -1,
				[135365] = -1,
				[135366] = -1,
				[130404] = -1,
				[131431] = -1,
				[133836] = -1,
				[129950] = -1,
				[132807] = -1,
				[137157] = -1,
				[139460] = -1,
				[130087] = -1,
				[138938] = -1,
				[132919] = -1,
				[148146] = -1,
				[144834] = -1,
				[131520] = -1,
				[145346] = -1,
				[139461] = -1,
				[132922] = -1,
				[131785] = -1,
				[129828] = -1,
				[130661] = -1,
				[131817] = -1,
				[148185] = -1,
				[151742] = -1,
				[139462] = -1,
				[144733] = -1,
				[138556] = -1,
				[134056] = -1,
				[130522] = -1,
				[144836] = -1,
				[144731] = -1,
				[133183] = -1,
				[139463] = -1,
				[130508] = -1,
				[134060] = -1,
				[137958] = -1,
				[132299] = -1,
				[144837] = -1,
				[130400] = -1,
				[127482] = -1,
				[137663] = -1,
				[139720] = -1,
				[133835] = -1,
				[129208] = -1,
				[129529] = -1,
				[140744] = -1,
				[129374] = -1,
				[137162] = -1,
				[139465] = -1,
				[162238] = -1,
				[144071] = -1,
				[136139] = -1,
				[129879] = -1,
				[144839] = -1,
				[145286] = -1,
				[129000] = -1,
				[134173] = -1,
				[154051] = -1,
				[146119] = -1,
				[138187] = -1,
				[129640] = -1,
				[140442] = -1,
				[139289] = -1,
				[130024] = -1,
				[132127] = -1,
				[136598] = -1,
				[142403] = -1,
				[14282] = -1,
				[140067] = -1,
				[136541] = -1,
				[126100] = -1,
				[129624] = -1,
				[139280] = -1,
				[133663] = -1,
				[139980] = -1,
				[124890] = -1,
				[129032] = -1,
				[152835] = -1,
				[129231] = -1,
				[130025] = -1,
				[125453] = -1,
				[128965] = -1,
				[130409] = -1,
				[138840] = -1,
				[145020] = -1,
				[136336] = -1,
				[138958] = -1,
				[129002] = -1,
				[151752] = -1,
				[130765] = -1,
				[154311] = -1,
				[136599] = -1,
				[158917] = -1,
				[131670] = -1,
				[129372] = -1,
				[130026] = -1,
				[144977] = -1,
				[154056] = -1,
				[137936] = -1,
				[124397] = -1,
				[132692] = -1,
				[144845] = -1,
				[132819] = -1,
				[134838] = -1,
				[149707] = -1,
				[137681] = -1,
				[133843] = -1,
				[139397] = -1,
				[135541] = -1,
				[145287] = -1,
				[132820] = -1,
				[130027] = -1,
				[151755] = -1,
				[154058] = -1,
				[161273] = -1,
				[134787] = -1,
				[123146] = -1,
				[134612] = -1,
				[138962] = -1,
				[141286] = -1,
				[122967] = -1,
				[136616] = -1,
				[135892] = -1,
				[134139] = -1,
				[151327] = -1,
				[126919] = -1,
				[138963] = -1,
				[130028] = -1,
				[153804] = -1,
				[126190] = -1,
				[135893] = -1,
				[139750] = -1,
				[130668] = -1,
				[126702] = -1,
				[153293] = -1,
				[135049] = -1,
				[139476] = -1,
				[130436] = -1,
				[135894] = -1,
				[129517] = -1,
				[141226] = -1,
				[134271] = -1,
				[131823] = -1,
				[139004] = -1,
				[155272] = -1,
				[131545] = -1,
				[133848] = -1,
				[157483] = -1,
				[127315] = -1,
				[136825] = -1,
				[151534] = -1,
				[155984] = -1,
				[161813] = -1,
				[154063] = -1,
				[151610] = -1,
				[157275] = -1,
				[62899] = -1,
				[138711] = -1,
				[152827] = -1,
				[147411] = -1,
				[133935] = -1,
				[157333] = -1,
				[152273] = -1,
				[134106] = -1,
				[142550] = -1,
				[136665] = -1,
				[126832] = -1,
				[161815] = -1,
				[153065] = -1,
				[135642] = -1,
				[137945] = -1,
				[154367] = -1,
				[127600] = -1,
				[154353] = -1,
				[138969] = -1,
				[135759] = -1,
				[162181] = -1,
				[159345] = -1,
				[133852] = -1,
				[134174] = -1,
				[49999] = -1,
				[157137] = -1,
				[138970] = -1,
				[137486] = -1,
				[134251] = -1,
				[149973] = -1,
				[137947] = -1,
				[137989] = -1,
				[135204] = -1,
				[137591] = -1,
				[145112] = -1,
				[135192] = -1,
				[135764] = -1,
				[135761] = -1,
				[135901] = -1,
				[136976] = -1,
			},
			["events_completed"] = {
			},
		},
		["무시중한디 - 굴단"] = {
			["scannerXPos"] = 1740.939697265625,
			["containers_opened"] = {
				[293884] = -1,
				[326415] = -1,
				[326407] = -1,
				[298920] = -1,
				[297893] = -1,
				[326409] = -1,
			},
			["rares_killed"] = {
				[132319] = -1,
				[138972] = -1,
				[155860] = -1,
				[136158] = -1,
				[152790] = -1,
				[153814] = -1,
				[135903] = -1,
				[152791] = -1,
				[133345] = -1,
				[137951] = -1,
				[152792] = -1,
				[129778] = -1,
				[145372] = -1,
				[149722] = -1,
				[152793] = -1,
				[144861] = -1,
				[132835] = -1,
				[127092] = -1,
				[147932] = -1,
				[131812] = -1,
				[132068] = -1,
				[139233] = -1,
				[153818] = -1,
				[147933] = -1,
				[152283] = -1,
				[138466] = -1,
				[126709] = -1,
				[134884] = -1,
				[129140] = -1,
				[158169] = -1,
				[137955] = -1,
				[138467] = -1,
				[129908] = -1,
				[139235] = -1,
				[147935] = -1,
				[137956] = -1,
				[140259] = -1,
				[138468] = -1,
				[155612] = -1,
				[147936] = -1,
				[140260] = -1,
				[138469] = -1,
				[129781] = -1,
				[136934] = -1,
				[155869] = -1,
				[152287] = -1,
				[126455] = -1,
				[138470] = -1,
				[153055] = -1,
				[141029] = -1,
				[147938] = -1,
				[152288] = -1,
				[140262] = -1,
				[138471] = -1,
				[138983] = -1,
				[141286] = -1,
				[155871] = -1,
				[137704] = -1,
				[131819] = -1,
				[130550] = -1,
				[138472] = -1,
				[61325] = -1,
				[155616] = -1,
				[135402] = -1,
				[140264] = -1,
				[155361] = -1,
				[130039] = -1,
				[133356] = -1,
				[152035] = -1,
				[152547] = -1,
				[130679] = -1,
				[155618] = -1,
				[135404] = -1,
				[156130] = -1,
				[148198] = -1,
				[148454] = -1,
				[136428] = -1,
				[155619] = -1,
				[131311] = -1,
				[156131] = -1,
				[131823] = -1,
				[130680] = -1,
				[134638] = -1,
				[145129] = -1,
				[131568] = -1,
				[131824] = -1,
				[129529] = -1,
				[144874] = -1,
				[3625] = -1,
				[156133] = -1,
				[131825] = -1,
				[152551] = -1,
				[132849] = -1,
				[133361] = -1,
				[129786] = -1,
				[145132] = -1,
				[131571] = -1,
				[152297] = -1,
				[126460] = -1,
				[163044] = -1,
				[110340] = -1,
				[141039] = -1,
				[147948] = -1,
				[152298] = -1,
				[152554] = -1,
				[163045] = -1,
				[137458] = -1,
				[126205] = -1,
				[138226] = -1,
				[130683] = -1,
				[10990] = -1,
				[126845] = -1,
				[126973] = -1,
				[131318] = -1,
				[137715] = -1,
				[154347] = -1,
				[132086] = -1,
				[152812] = -1,
				[129788] = -1,
				[154092] = -1,
				[140275] = -1,
				[152813] = -1,
				[153069] = -1,
				[157419] = -1,
				[126974] = -1,
				[127486] = -1,
				[159211] = -1,
				[153326] = -1,
				[155629] = -1,
				[126463] = -1,
				[130685] = -1,
				[126719] = -1,
				[126847] = -1,
				[134137] = -1,
				[154863] = -1,
				[103563] = -1,
				[126848] = -1,
				[135418] = -1,
				[136186] = -1,
				[140792] = -1,
				[147189] = -1,
				[162030] = -1,
				[156145] = -1,
				[154354] = -1,
				[148469] = -1,
				[145399] = -1,
				[153843] = -1,
				[162287] = -1,
				[150773] = -1,
				[153332] = -1,
				[162288] = -1,
				[152565] = -1,
				[153333] = -1,
				[129025] = -1,
				[127106] = -1,
				[162289] = -1,
				[148472] = -1,
				[152822] = -1,
				[136702] = -1,
				[127874] = -1,
				[145402] = -1,
				[151799] = -1,
				[131585] = -1,
				[134144] = -1,
				[124548] = -1,
				[67360] = -1,
				[153335] = -1,
				[151800] = -1,
				[131586] = -1,
				[156406] = -1,
				[138495] = -1,
				[153080] = -1,
				[125828] = -1,
				[147451] = -1,
				[151801] = -1,
				[131587] = -1,
				[67361] = -1,
				[137473] = -1,
				[134147] = -1,
				[138497] = -1,
				[132868] = -1,
				[137474] = -1,
				[147965] = -1,
				[152315] = -1,
				[148477] = -1,
				[152827] = -1,
				[164086] = -1,
				[123399] = -1,
				[138499] = -1,
				[138755] = -1,
				[127877] = -1,
				[143361] = -1,
				[155899] = -1,
				[131847] = -1,
				[134150] = -1,
				[138500] = -1,
				[144897] = -1,
				[145153] = -1,
				[141315] = -1,
				[155900] = -1,
				[147968] = -1,
				[137989] = -1,
				[140292] = -1,
				[138501] = -1,
				[144898] = -1,
				[139269] = -1,
				[137478] = -1,
				[131849] = -1,
				[140293] = -1,
				[147202] = -1,
				[126983] = -1,
				[127111] = -1,
				[140038] = -1,
				[140294] = -1,
				[127879] = -1,
				[154112] = -1,
				[140295] = -1,
				[152833] = -1,
				[130822] = -1,
				[131084] = -1,
				[123146] = -1,
				[134155] = -1,
				[142599] = -1,
				[131085] = -1,
				[124170] = -1,
				[130439] = -1,
				[144647] = -1,
				[153091] = -1,
				[157441] = -1,
				[145415] = -1,
				[134157] = -1,
				[155139] = -1,
				[151301] = -1,
				[137484] = -1,
				[152069] = -1,
				[148231] = -1,
				[136205] = -1,
				[130824] = -1,
				[145161] = -1,
				[137485] = -1,
				[152070] = -1,
				[146185] = -1,
				[153094] = -1,
				[137486] = -1,
				[152071] = -1,
				[146186] = -1,
				[156677] = -1,
				[67368] = -1,
				[145163] = -1,
				[139278] = -1,
				[137487] = -1,
				[137743] = -1,
				[146187] = -1,
				[125452] = -1,
				[134417] = -1,
				[129802] = -1,
				[153352] = -1,
				[134418] = -1,
				[153097] = -1,
				[139280] = -1,
				[139536] = -1,
				[129547] = -1,
				[129803] = -1,
				[147469] = -1,
				[139537] = -1,
				[135699] = -1,
				[154378] = -1,
				[69161] = -1,
				[140561] = -1,
				[144911] = -1,
				[141585] = -1,
				[150541] = -1,
				[140562] = -1,
				[127757] = -1,
				[155403] = -1,
				[131863] = -1,
				[140563] = -1,
				[149007] = -1,
				[132887] = -1,
				[141587] = -1,
				[139796] = -1,
				[131864] = -1,
				[136214] = -1,
				[134423] = -1,
				[129805] = -1,
				[139285] = -1,
				[155917] = -1,
				[133912] = -1,
				[144915] = -1,
				[135192] = -1,
				[155918] = -1,
				[147219] = -1,
				[139287] = -1,
				[155919] = -1,
				[139799] = -1,
				[135961] = -1,
				[134426] = -1,
				[155920] = -1,
				[139800] = -1,
				[135962] = -1,
				[139289] = -1,
				[130191] = -1,
				[135963] = -1,
				[139290] = -1,
				[140058] = -1,
				[134173] = -1,
				[122004] = -1,
				[140059] = -1,
				[132127] = -1,
				[152853] = -1,
				[139804] = -1,
				[140060] = -1,
				[144410] = -1,
				[139805] = -1,
				[163091] = -1,
				[145180] = -1,
				[151833] = -1,
				[139807] = -1,
				[145181] = -1,
				[133155] = -1,
				[127124] = -1,
				[139808] = -1,
				[127636] = -1,
				[141088] = -1,
				[139297] = -1,
				[136995] = -1,
				[139298] = -1,
				[155930] = -1,
				[152092] = -1,
				[127381] = -1,
				[148510] = -1,
				[151581] = -1,
				[135717] = -1,
				[140067] = -1,
				[151326] = -1,
				[131112] = -1,
				[140068] = -1,
				[155421] = -1,
				[149536] = -1,
				[151839] = -1,
				[130325] = -1,
				[135975] = -1,
				[148513] = -1,
				[153119] = -1,
				[145443] = -1,
				[151840] = -1,
				[131626] = -1,
				[123289] = -1,
				[138279] = -1,
				[140838] = -1,
				[137000] = -1,
				[145444] = -1,
				[153888] = -1,
				[124185] = -1,
				[122266] = -1,
				[138280] = -1,
				[140839] = -1,
				[155424] = -1,
				[155680] = -1,
				[123290] = -1,
				[129559] = -1,
				[152866] = -1,
				[43622] = -1,
				[140585] = -1,
				[140841] = -1,
				[127129] = -1,
				[137771] = -1,
				[152356] = -1,
				[156706] = -1,
				[134701] = -1,
				[131631] = -1,
				[152357] = -1,
				[138540] = -1,
				[155172] = -1,
				[132911] = -1,
				[155684] = -1,
				[153893] = -1,
				[152358] = -1,
				[125467] = -1,
				[155173] = -1,
				[155685] = -1,
				[131377] = -1,
				[140077] = -1,
				[150568] = -1,
				[145195] = -1,
				[155686] = -1,
				[153895] = -1,
				[140078] = -1,
				[140334] = -1,
				[138543] = -1,
				[153896] = -1,
				[154152] = -1,
				[140335] = -1,
				[134450] = -1,
				[134706] = -1,
				[155688] = -1,
				[135474] = -1,
				[152362] = -1,
				[140336] = -1,
				[153130] = -1,
				[155689] = -1,
				[131381] = -1,
				[154154] = -1,
				[152363] = -1,
				[140337] = -1,
				[126621] = -1,
				[129180] = -1,
				[145967] = -1,
				[152364] = -1,
				[148782] = -1,
				[144944] = -1,
				[132918] = -1,
				[133430] = -1,
				[34605] = -1,
				[132919] = -1,
				[13329] = -1,
				[133943] = -1,
				[130077] = -1,
				[133432] = -1,
				[130333] = -1,
				[152367] = -1,
				[136247] = -1,
				[153903] = -1,
				[140086] = -1,
				[152624] = -1,
				[134713] = -1,
				[132922] = -1,
				[139319] = -1,
				[153904] = -1,
				[130334] = -1,
				[140087] = -1,
				[136249] = -1,
				[152881] = -1,
				[144949] = -1,
				[149555] = -1,
				[137529] = -1,
				[152882] = -1,
				[139321] = -1,
				[133436] = -1,
				[130335] = -1,
				[126497] = -1,
				[152883] = -1,
				[128928] = -1,
				[155698] = -1,
				[153907] = -1,
				[152884] = -1,
				[151605] = -1,
				[141626] = -1,
				[145976] = -1,
				[34607] = -1,
				[152885] = -1,
				[130848] = -1,
				[149303] = -1,
				[145465] = -1,
				[145977] = -1,
				[138557] = -1,
				[155701] = -1,
				[153910] = -1,
				[49832] = -1,
				[138558] = -1,
				[130849] = -1,
				[128930] = -1,
				[155702] = -1,
				[140094] = -1,
				[127651] = -1,
				[129826] = -1,
				[143677] = -1,
				[140095] = -1,
				[154936] = -1,
				[137025] = -1,
				[139328] = -1,
				[14881] = -1,
				[154681] = -1,
				[129699] = -1,
				[144958] = -1,
				[135235] = -1,
				[141632] = -1,
				[152635] = -1,
				[151612] = -1,
				[156161] = -1,
				[155872] = -1,
				[152380] = -1,
				[134213] = -1,
				[156146] = -1,
				[155195] = -1,
				[153812] = -1,
				[133190] = -1,
				[13218] = -1,
				[161273] = -1,
				[152381] = -1,
				[140355] = -1,
				[152893] = -1,
				[138820] = -1,
				[141123] = -1,
				[155708] = -1,
				[145112] = -1,
				[129776] = -1,
				[136006] = -1,
				[152638] = -1,
				[154365] = -1,
				[138821] = -1,
				[160755] = -1,
				[130085] = -1,
				[151871] = -1,
				[154174] = -1,
				[152383] = -1,
				[136422] = -1,
				[144707] = -1,
				[138822] = -1,
				[159209] = -1,
				[135240] = -1,
				[131402] = -1,
				[154175] = -1,
				[152384] = -1,
				[154687] = -1,
				[137763] = -1,
				[138823] = -1,
				[161813] = -1,
				[136183] = -1,
				[141638] = -1,
				[161815] = -1,
				[132317] = -1,
				[152641] = -1,
				[157483] = -1,
				[137946] = -1,
				[128935] = -1,
				[156463] = -1,
				[131404] = -1,
				[156452] = -1,
				[148292] = -1,
				[126969] = -1,
				[138969] = -1,
				[155201] = -1,
				[119724] = -1,
				[130087] = -1,
				[141640] = -1,
				[153095] = -1,
				[153906] = -1,
				[154329] = -1,
				[137945] = -1,
				[70963] = -1,
				[153905] = -1,
				[12051] = -1,
				[141641] = -1,
				[67366] = -1,
				[67391] = -1,
				[158168] = -1,
				[137954] = -1,
				[153348] = -1,
				[148179] = -1,
				[130088] = -1,
				[131407] = -1,
				[131663] = -1,
				[140107] = -1,
				[161342] = -1,
				[126634] = -1,
				[155204] = -1,
				[53140] = -1,
				[125455] = -1,
				[131408] = -1,
				[138061] = -1,
				[140108] = -1,
				[159210] = -1,
				[159208] = -1,
				[129833] = -1,
				[129961] = -1,
				[138561] = -1,
				[130217] = -1,
				[154182] = -1,
				[128426] = -1,
				[132177] = -1,
				[154619] = -1,
				[131141] = -1,
				[123291] = -1,
				[137551] = -1,
				[151880] = -1,
				[131666] = -1,
				[152392] = -1,
				[136181] = -1,
				[41948] = -1,
				[129834] = -1,
				[130678] = -1,
				[130299] = -1,
				[151881] = -1,
				[131667] = -1,
				[129526] = -1,
				[132179] = -1,
				[138576] = -1,
				[134738] = -1,
				[134994] = -1,
				[153908] = -1,
				[137553] = -1,
				[153826] = -1,
				[148300] = -1,
				[154697] = -1,
				[152906] = -1,
				[144974] = -1,
				[155465] = -1,
				[137741] = -1,
				[34606] = -1,
				[131669] = -1,
				[131670] = -1,
				[154698] = -1,
				[144719] = -1,
				[144975] = -1,
				[128554] = -1,
				[132056] = -1,
				[139988] = -1,
				[135764] = -1,
				[153078] = -1,
				[132182] = -1,
				[144720] = -1,
				[144976] = -1,
				[134987] = -1,
				[155723] = -1,
				[154700] = -1,
				[135765] = -1,
				[144977] = -1,
				[128557] = -1,
				[144721] = -1,
				[140883] = -1,
				[155468] = -1,
				[1412] = -1,
				[151886] = -1,
				[137969] = -1,
				[155634] = -1,
				[152546] = -1,
				[144722] = -1,
				[138837] = -1,
				[135204] = -1,
				[103673] = -1,
				[135511] = -1,
				[150248] = -1,
				[122673] = -1,
				[134232] = -1,
				[128686] = -1,
				[138838] = -1,
				[127480] = -1,
				[133935] = -1,
				[153935] = -1,
				[125232] = -1,
				[131411] = -1,
				[136280] = -1,
				[144724] = -1,
				[134745] = -1,
				[135239] = -1,
				[50734] = -1,
				[138212] = -1,
				[135403] = -1,
				[154448] = -1,
				[148563] = -1,
				[144725] = -1,
				[147028] = -1,
				[149331] = -1,
				[155984] = -1,
				[149843] = -1,
				[130307] = -1,
				[140055] = -1,
				[154705] = -1,
				[146773] = -1,
				[138841] = -1,
				[135759] = -1,
				[152915] = -1,
				[155985] = -1,
				[131677] = -1,
				[142168] = -1,
				[154706] = -1,
				[144727] = -1,
				[132341] = -1,
				[50159] = -1,
				[145495] = -1,
				[148185] = -1,
				[130421] = -1,
				[152916] = -1,
				[154707] = -1,
				[144728] = -1,
				[140890] = -1,
				[145358] = -1,
				[137564] = -1,
				[151893] = -1,
				[136688] = -1,
				[142170] = -1,
				[138332] = -1,
				[152917] = -1,
				[136797] = -1,
				[148817] = -1,
				[154569] = -1,
				[136166] = -1,
				[136439] = -1,
				[139793] = -1,
				[127478] = -1,
				[152918] = -1,
				[157383] = -1,
				[146892] = -1,
				[140637] = -1,
				[153942] = -1,
				[134240] = -1,
				[128434] = -1,
				[154710] = -1,
				[152919] = -1,
				[144987] = -1,
				[162500] = -1,
				[151640] = -1,
				[153943] = -1,
				[135761] = -1,
				[156502] = -1,
				[154711] = -1,
				[144731] = -1,
				[129842] = -1,
				[145356] = -1,
				[126132] = -1,
				[149850] = -1,
				[154200] = -1,
				[128435] = -1,
				[134739] = -1,
				[152921] = -1,
				[134754] = -1,
				[136547] = -1,
				[140069] = -1,
				[130582] = -1,
				[137825] = -1,
				[142175] = -1,
				[154713] = -1,
				[136546] = -1,
				[152667] = -1,
				[155481] = -1,
				[126645] = -1,
				[139617] = -1,
				[131685] = -1,
				[152411] = -1,
				[138338] = -1,
				[10981] = -1,
				[153179] = -1,
				[126901] = -1,
				[139362] = -1,
				[153947] = -1,
				[155859] = -1,
				[152412] = -1,
				[131431] = -1,
				[136548] = -1,
				[146890] = -1,
				[129972] = -1,
				[128181] = -1,
				[151901] = -1,
				[144993] = -1,
				[152413] = -1,
				[152669] = -1,
				[140643] = -1,
				[157275] = -1,
				[127482] = -1,
				[152835] = -1,
				[151902] = -1,
				[123192] = -1,
				[122284] = -1,
				[154717] = -1,
				[136550] = -1,
				[129835] = -1,
				[141599] = -1,
				[153694] = -1,
				[136295] = -1,
				[137830] = -1,
				[130485] = -1,
				[126519] = -1,
				[136551] = -1,
				[134760] = -1,
				[126903] = -1,
				[126774] = -1,
				[133663] = -1,
				[135981] = -1,
				[142106] = -1,
				[152672] = -1,
				[136552] = -1,
				[127799] = -1,
				[151750] = -1,
				[143718] = -1,
				[133482] = -1,
				[135785] = -1,
				[150371] = -1,
				[154720] = -1,
				[136553] = -1,
				[144997] = -1,
				[128951] = -1,
				[142403] = -1,
				[131436] = -1,
				[152162] = -1,
				[142183] = -1,
				[154721] = -1,
				[86732] = -1,
				[136810] = -1,
				[127119] = -1,
				[74834] = -1,
				[14282] = -1,
				[131693] = -1,
				[126578] = -1,
				[152675] = -1,
				[153699] = -1,
				[136811] = -1,
				[126905] = -1,
				[12053] = -1,
				[139626] = -1,
				[50355] = -1,
				[150373] = -1,
				[152676] = -1,
				[132713] = -1,
				[136812] = -1,
				[127484] = -1,
				[144948] = -1,
				[153956] = -1,
				[133870] = -1,
				[130488] = -1,
				[139322] = -1,
				[154312] = -1,
				[138839] = -1,
				[127290] = -1,
				[145513] = -1,
				[153957] = -1,
				[154213] = -1,
				[129062] = -1,
				[154725] = -1,
				[126708] = -1,
				[17252] = -1,
				[127150] = -1,
				[147561] = -1,
				[131697] = -1,
				[49844] = -1,
				[150376] = -1,
				[139630] = -1,
				[146118] = -1,
				[162238] = -1,
				[126907] = -1,
				[147562] = -1,
				[153959] = -1,
				[130194] = -1,
				[137162] = -1,
				[136304] = -1,
				[130436] = -1,
				[153192] = -1,
				[155176] = -1,
				[138498] = -1,
				[142172] = -1,
				[77140] = -1,
				[148164] = -1,
				[132211] = -1,
				[134514] = -1,
				[140263] = -1,
				[158399] = -1,
				[122264] = -1,
				[138819] = -1,
				[138696] = -1,
				[152426] = -1,
				[153194] = -1,
				[126440] = -1,
				[159335] = -1,
				[158398] = -1,
				[138992] = -1,
				[131445] = -1,
				[139463] = -1,
				[158568] = -1,
				[152683] = -1,
				[140657] = -1,
				[138866] = -1,
				[140914] = -1,
				[151660] = -1,
				[153963] = -1,
				[129340] = -1,
				[134005] = -1,
				[136541] = -1,
				[159165] = -1,
				[145008] = -1,
				[129980] = -1,
				[138556] = -1,
				[126142] = -1,
				[143985] = -1,
				[152685] = -1,
				[126526] = -1,
				[133463] = -1,
				[128699] = -1,
				[143218] = -1,
				[145603] = -1,
				[141143] = -1,
				[142587] = -1,
				[142195] = -1,
				[152686] = -1,
				[134519] = -1,
				[134775] = -1,
				[129981] = -1,
				[135287] = -1,
				[133429] = -1,
				[134139] = -1,
				[137713] = -1,
				[152687] = -1,
				[139973] = -1,
				[138870] = -1,
				[152653] = -1,
				[129214] = -1,
				[137591] = -1,
				[145346] = -1,
				[152128] = -1,
				[138693] = -1,
				[123713] = -1,
				[145012] = -1,
				[143221] = -1,
				[130441] = -1,
				[141059] = -1,
				[151900] = -1,
				[142198] = -1,
				[142454] = -1,
				[151742] = -1,
				[145013] = -1,
				[136807] = -1,
				[139384] = -1,
				[128551] = -1,
				[126263] = -1,
				[129471] = -1,
				[129599] = -1,
				[125453] = -1,
				[147061] = -1,
				[131817] = -1,
				[139385] = -1,
				[151604] = -1,
				[138618] = -1,
				[154482] = -1,
				[135365] = -1,
				[128704] = -1,
				[147062] = -1,
				[130437] = -1,
				[158396] = -1,
				[131389] = -1,
				[125250] = -1,
				[150389] = -1,
				[129600] = -1,
				[137958] = -1,
				[151157] = -1,
				[149839] = -1,
				[155763] = -1,
				[4075] = -1,
				[134270] = -1,
				[136830] = -1,
				[126530] = -1,
				[129601] = -1,
				[145017] = -1,
				[145343] = -1,
				[155764] = -1,
				[147730] = -1,
				[156788] = -1,
				[159347] = -1,
				[100943] = -1,
				[127682] = -1,
				[145018] = -1,
				[153462] = -1,
				[149437] = -1,
				[156132] = -1,
				[131818] = -1,
				[152439] = -1,
				[128578] = -1,
				[140669] = -1,
				[151775] = -1,
				[131009] = -1,
				[148163] = -1,
				[140670] = -1,
				[139135] = -1,
				[150393] = -1,
				[129602] = -1,
				[138623] = -1,
				[145020] = -1,
				[141182] = -1,
				[155404] = -1,
				[135964] = -1,
				[155873] = -1,
				[155768] = -1,
				[132742] = -1,
				[128707] = -1,
				[136470] = -1,
				[155512] = -1,
				[151674] = -1,
				[129527] = -1,
				[152699] = -1,
				[134788] = -1,
				[138176] = -1,
				[138625] = -1,
				[134787] = -1,
				[145278] = -1,
				[139393] = -1,
				[151676] = -1,
				[122086] = -1,
				[129476] = -1,
				[136323] = -1,
				[138626] = -1,
				[67426] = -1,
				[145340] = -1,
				[139394] = -1,
				[134789] = -1,
				[139395] = -1,
				[154491] = -1,
				[150653] = -1,
				[138627] = -1,
				[129860] = -1,
				[145280] = -1,
				[130116] = -1,
				[147839] = -1,
				[144769] = -1,
				[152445] = -1,
				[135796] = -1,
				[138628] = -1,
				[163704] = -1,
				[128965] = -1,
				[139396] = -1,
				[139710] = -1,
				[149004] = -1,
				[137151] = -1,
				[153470] = -1,
				[144770] = -1,
				[132744] = -1,
				[163705] = -1,
				[151679] = -1,
				[148353] = -1,
				[139400] = -1,
				[134024] = -1,
				[134080] = -1,
				[152960] = -1,
				[132745] = -1,
				[131013] = -1,
				[139398] = -1,
				[145028] = -1,
				[135817] = -1,
				[127048] = -1,
				[152704] = -1,
				[140678] = -1,
				[138887] = -1,
				[135049] = -1,
				[139399] = -1,
				[153984] = -1,
				[154240] = -1,
				[36609] = -1,
				[138245] = -1,
				[140679] = -1,
				[153217] = -1,
				[153473] = -1,
				[129095] = -1,
				[145286] = -1,
				[141959] = -1,
				[152450] = -1,
				[136330] = -1,
				[152962] = -1,
				[153218] = -1,
				[139145] = -1,
				[151683] = -1,
				[128584] = -1,
				[132741] = -1,
				[152451] = -1,
				[134284] = -1,
				[153219] = -1,
				[159360] = -1,
				[145287] = -1,
				[157825] = -1,
				[131520] = -1,
				[155935] = -1,
				[133373] = -1,
				[129652] = -1,
				[136844] = -1,
				[140938] = -1,
				[143488] = -1,
				[147321] = -1,
				[140943] = -1,
				[137103] = -1,
				[146826] = -1,
				[152709] = -1,
				[144777] = -1,
				[146827] = -1,
				[133007] = -1,
				[129097] = -1,
				[155271] = -1,
				[127876] = -1,
				[12122] = -1,
				[152710] = -1,
				[144778] = -1,
				[136846] = -1,
				[14774] = -1,
				[136338] = -1,
				[139661] = -1,
				[130634] = -1,
				[132755] = -1,
				[152711] = -1,
				[136591] = -1,
				[145035] = -1,
				[153479] = -1,
				[153523] = -1,
				[153991] = -1,
				[146059] = -1,
				[143032] = -1,
				[136336] = -1,
				[144780] = -1,
				[136848] = -1,
				[137104] = -1,
				[131476] = -1,
				[152755] = -1,
				[65205] = -1,
				[140432] = -1,
				[140431] = -1,
				[152969] = -1,
				[155272] = -1,
				[139152] = -1,
				[153737] = -1,
				[129227] = -1,
				[146061] = -1,
				[144966] = -1,
				[132244] = -1,
				[127820] = -1,
				[155273] = -1,
				[129995] = -1,
				[49725] = -1,
				[139665] = -1,
				[150156] = -1,
				[136083] = -1,
				[130635] = -1,
				[137413] = -1,
				[131850] = -1,
				[136340] = -1,
				[153739] = -1,
				[130508] = -1,
				[148367] = -1,
				[152460] = -1,
				[140434] = -1,
				[140690] = -1,
				[155275] = -1,
				[136598] = -1,
				[153740] = -1,
				[141716] = -1,
				[141970] = -1,
				[152461] = -1,
				[136341] = -1,
				[138644] = -1,
				[155276] = -1,
				[126926] = -1,
				[153741] = -1,
				[129827] = -1,
				[136599] = -1,
				[141239] = -1,
				[53189] = -1,
				[138645] = -1,
				[129869] = -1,
				[145298] = -1,
				[70762] = -1,
				[153998] = -1,
				[122961] = -1,
				[130509] = -1,
				[134296] = -1,
				[146834] = -1,
				[155278] = -1,
				[128974] = -1,
				[137367] = -1,
				[150667] = -1,
				[130298] = -1,
				[138135] = -1,
				[144789] = -1,
				[146835] = -1,
				[129870] = -1,
				[141750] = -1,
				[155791] = -1,
				[135322] = -1,
				[133531] = -1,
				[129886] = -1,
				[154768] = -1,
				[159118] = -1,
				[146867] = -1,
				[126928] = -1,
				[137369] = -1,
				[129231] = -1,
				[151946] = -1,
				[154769] = -1,
				[136346] = -1,
				[136189] = -1,
				[124581] = -1,
				[134041] = -1,
				[140441] = -1,
				[153263] = -1,
				[146866] = -1,
				[146838] = -1,
				[136347] = -1,
				[159120] = -1,
				[155228] = -1,
				[151534] = -1,
				[122963] = -1,
				[129232] = -1,
				[130638] = -1,
				[154771] = -1,
				[152724] = -1,
				[140691] = -1,
				[157356] = -1,
				[127939] = -1,
				[140443] = -1,
				[70893] = -1,
				[146072] = -1,
				[126546] = -1,
				[122452] = -1,
				[146840] = -1,
				[130896] = -1,
				[145305] = -1,
				[138888] = -1,
				[145817] = -1,
				[134625] = -1,
				[140188] = -1,
				[140444] = -1,
				[137255] = -1,
				[126583] = -1,
				[132904] = -1,
				[155797] = -1,
				[146864] = -1,
				[141980] = -1,
				[134048] = -1,
				[154775] = -1,
				[140446] = -1,
				[157333] = -1,
				[145307] = -1,
				[122965] = -1,
				[151960] = -1,
				[127315] = -1,
				[152984] = -1,
				[50496] = -1,
				[127699] = -1,
				[140076] = -1,
				[145308] = -1,
				[135329] = -1,
				[151327] = -1,
				[130012] = -1,
				[140354] = -1,
				[122454] = -1,
				[138675] = -1,
				[133539] = -1,
				[124885] = -1,
				[153753] = -1,
				[131492] = -1,
				[152492] = -1,
				[136297] = -1,
				[134333] = -1,
				[123292] = -1,
				[154776] = -1,
				[145310] = -1,
				[140977] = -1,
				[155050] = -1,
				[138288] = -1,
				[140209] = -1,
				[141985] = -1,
				[152987] = -1,
				[157337] = -1,
				[157594] = -1,
				[122967] = -1,
				[148639] = -1,
				[129364] = -1,
				[136100] = -1,
				[145326] = -1,
				[152988] = -1,
				[153244] = -1,
				[3300] = -1,
				[140976] = -1,
				[154780] = -1,
				[136613] = -1,
				[154524] = -1,
				[134310] = -1,
				[159130] = -1,
				[130779] = -1,
				[126429] = -1,
				[122968] = -1,
				[139684] = -1,
				[159131] = -1,
				[123352] = -1,
				[129749] = -1,
				[136614] = -1,
				[145058] = -1,
				[13448] = -1,
				[139429] = -1,
				[128991] = -1,
				[159129] = -1,
				[134056] = -1,
				[155048] = -1,
				[136615] = -1,
				[145059] = -1,
				[144803] = -1,
				[122969] = -1,
				[146860] = -1,
				[152992] = -1,
				[130006] = -1,
				[70775] = -1,
				[136616] = -1,
				[132778] = -1,
				[153504] = -1,
				[155807] = -1,
				[145060] = -1,
				[152994] = -1,
				[126424] = -1,
				[140455] = -1,
				[144805] = -1,
				[145061] = -1,
				[146859] = -1,
				[122970] = -1,
				[129626] = -1,
				[134571] = -1,
				[140200] = -1,
				[154785] = -1,
				[159135] = -1,
				[124890] = -1,
				[155553] = -1,
				[134317] = -1,
				[151720] = -1,
				[152227] = -1,
				[154530] = -1,
				[134316] = -1,
				[159136] = -1,
				[134828] = -1,
				[137131] = -1,
				[122971] = -1,
				[139690] = -1,
				[135852] = -1,
				[141226] = -1,
				[140458] = -1,
				[159137] = -1,
				[145067] = -1,
				[137132] = -1,
				[140457] = -1,
				[139691] = -1,
				[154787] = -1,
				[148391] = -1,
				[140205] = -1,
				[134060] = -1,
				[145065] = -1,
				[110562] = -1,
				[122972] = -1,
				[136110] = -1,
				[155045] = -1,
				[148392] = -1,
				[144810] = -1,
				[129753] = -1,
				[130008] = -1,
				[137134] = -1,
				[155813] = -1,
				[139693] = -1,
				[146843] = -1,
				[130521] = -1,
				[150696] = -1,
				[139063] = -1,
				[140973] = -1,
				[145323] = -1,
				[155814] = -1,
				[154786] = -1,
				[140456] = -1,
				[140206] = -1,
				[152744] = -1,
				[155047] = -1,
				[136880] = -1,
				[145324] = -1,
				[130138] = -1,
				[129750] = -1,
				[130513] = -1,
				[130522] = -1,
				[150698] = -1,
				[130778] = -1,
				[136881] = -1,
				[134012] = -1,
				[131252] = -1,
				[148290] = -1,
				[138660] = -1,
				[140208] = -1,
				[140464] = -1,
				[155049] = -1,
				[136882] = -1,
				[130011] = -1,
				[132007] = -1,
				[141744] = -1,
				[142000] = -1,
				[124382] = -1,
				[130079] = -1,
				[146862] = -1,
				[136883] = -1,
				[145327] = -1,
				[137155] = -1,
				[126056] = -1,
				[152236] = -1,
				[134069] = -1,
				[146607] = -1,
				[146863] = -1,
				[136353] = -1,
				[145328] = -1,
				[140353] = -1,
				[145510] = -1,
				[139955] = -1,
				[130897] = -1,
				[132797] = -1,
				[155052] = -1,
				[152135] = -1,
				[153948] = -1,
				[140442] = -1,
				[131858] = -1,
				[154285] = -1,
				[154772] = -1,
				[132280] = -1,
				[155053] = -1,
				[140980] = -1,
				[139460] = -1,
				[145339] = -1,
				[131513] = -1,
				[151663] = -1,
				[130639] = -1,
				[130653] = -1,
				[155054] = -1,
				[130909] = -1,
				[144409] = -1,
				[128648] = -1,
				[121242] = -1,
				[148146] = -1,
				[145029] = -1,
				[154799] = -1,
				[155055] = -1,
				[111463] = -1,
				[137144] = -1,
				[136847] = -1,
				[151985] = -1,
				[159117] = -1,
				[138168] = -1,
				[160652] = -1,
				[145299] = -1,
				[140983] = -1,
				[145333] = -1,
				[159116] = -1,
				[146833] = -1,
				[128973] = -1,
				[146832] = -1,
				[134331] = -1,
				[133158] = -1,
				[140984] = -1,
				[137146] = -1,
				[130143] = -1,
				[153738] = -1,
				[150859] = -1,
				[138170] = -1,
				[156849] = -1,
				[144823] = -1,
				[138938] = -1,
				[137147] = -1,
				[131262] = -1,
				[151988] = -1,
				[137915] = -1,
				[138171] = -1,
				[138427] = -1,
				[155059] = -1,
				[153224] = -1,
				[148874] = -1,
				[140430] = -1,
				[151989] = -1,
				[130400] = -1,
				[154548] = -1,
				[138428] = -1,
				[152541] = -1,
				[153269] = -1,
				[145337] = -1,
				[129121] = -1,
				[151990] = -1,
				[135052] = -1,
				[146819] = -1,
				[138429] = -1,
				[155061] = -1,
				[139397] = -1,
				[145338] = -1,
				[137406] = -1,
				[137096] = -1,
				[126919] = -1,
				[154550] = -1,
				[135048] = -1,
				[155062] = -1,
				[145026] = -1,
				[128994] = -1,
				[137663] = -1,
				[151992] = -1,
				[131778] = -1,
				[126918] = -1,
				[156854] = -1,
				[145281] = -1,
				[153327] = -1,
				[137152] = -1,
				[163703] = -1,
				[141758] = -1,
				[148155] = -1,
				[154552] = -1,
				[134338] = -1,
				[155064] = -1,
				[143038] = -1,
				[137153] = -1,
				[152543] = -1,
				[136944] = -1,
				[139968] = -1,
				[134897] = -1,
				[140866] = -1,
				[136832] = -1,
				[157368] = -1,
				[140356] = -1,
				[139457] = -1,
				[126659] = -1,
				[126904] = -1,
				[154554] = -1,
				[138434] = -1,
				[136643] = -1,
				[129857] = -1,
				[153531] = -1,
				[151740] = -1,
				[134782] = -1,
				[127333] = -1,
				[154555] = -1,
				[136828] = -1,
				[152816] = -1,
				[129548] = -1,
				[137156] = -1,
				[139459] = -1,
				[131527] = -1,
				[130404] = -1,
				[151667] = -1,
				[125214] = -1,
				[151155] = -1,
				[132807] = -1,
				[136005] = -1,
				[135366] = -1,
				[151998] = -1,
				[158395] = -1,
				[155628] = -1,
				[138871] = -1,
				[144834] = -1,
				[127807] = -1,
				[139205] = -1,
				[139461] = -1,
				[131529] = -1,
				[131785] = -1,
				[138840] = -1,
				[130661] = -1,
				[138836] = -1,
				[140997] = -1,
				[152673] = -1,
				[139462] = -1,
				[141765] = -1,
				[158397] = -1,
				[152512] = -1,
				[154815] = -1,
				[144836] = -1,
				[136490] = -1,
				[137587] = -1,
				[151745] = -1,
				[153933] = -1,
				[146116] = -1,
				[142278] = -1,
				[136393] = -1,
				[153025] = -1,
				[126824] = -1,
				[147396] = -1,
				[137417] = -1,
				[139720] = -1,
				[133835] = -1,
				[138281] = -1,
				[129013] = -1,
				[153026] = -1,
				[138863] = -1,
				[155585] = -1,
				[140398] = -1,
				[126185] = -1,
				[133836] = -1,
				[136139] = -1,
				[132076] = -1,
				[153027] = -1,
				[133685] = -1,
				[132126] = -1,
				[135939] = -1,
				[154051] = -1,
				[146119] = -1,
				[138187] = -1,
				[127485] = -1,
				[135234] = -1,
				[132180] = -1,
				[130024] = -1,
				[154113] = -1,
				[127289] = -1,
				[95034] = -1,
				[132047] = -1,
				[48972] = -1,
				[129719] = -1,
				[134251] = -1,
				[136545] = -1,
				[133327] = -1,
				[154719] = -1,
				[139980] = -1,
				[138189] = -1,
				[152559] = -1,
				[152159] = -1,
				[148451] = -1,
				[130025] = -1,
				[127488] = -1,
				[126187] = -1,
				[154310] = -1,
				[129030] = -1,
				[156869] = -1,
				[122605] = -1,
				[129950] = -1,
				[130094] = -1,
				[155738] = -1,
				[133988] = -1,
				[154311] = -1,
				[135706] = -1,
				[153064] = -1,
				[144844] = -1,
				[137824] = -1,
				[130026] = -1,
				[137568] = -1,
				[154056] = -1,
				[133842] = -1,
				[132051] = -1,
				[131383] = -1,
				[144845] = -1,
				[132819] = -1,
				[136174] = -1,
				[149707] = -1,
				[137708] = -1,
				[133843] = -1,
				[150475] = -1,
				[152560] = -1,
				[144846] = -1,
				[136914] = -1,
				[130027] = -1,
				[134237] = -1,
				[154058] = -1,
				[134158] = -1,
				[136976] = -1,
				[133399] = -1,
				[134612] = -1,
				[143056] = -1,
				[130823] = -1,
				[135231] = -1,
				[135977] = -1,
				[135892] = -1,
				[131376] = -1,
				[148456] = -1,
				[146895] = -1,
				[138963] = -1,
				[145148] = -1,
				[153804] = -1,
				[126190] = -1,
				[135893] = -1,
				[138294] = -1,
				[139790] = -1,
				[128749] = -1,
				[153293] = -1,
				[129005] = -1,
				[139476] = -1,
				[138493] = -1,
				[135894] = -1,
				[129517] = -1,
				[152834] = -1,
				[151813] = -1,
				[134966] = -1,
				[164088] = -1,
				[136204] = -1,
				[131545] = -1,
				[133848] = -1,
				[143606] = -1,
				[151610] = -1,
				[137950] = -1,
				[155706] = -1,
				[131053] = -1,
				[136984] = -1,
				[133593] = -1,
				[130435] = -1,
				[133963] = -1,
				[21364] = -1,
				[153654] = -1,
				[153065] = -1,
				[147411] = -1,
				[135167] = -1,
				[162252] = -1,
				[152273] = -1,
				[134106] = -1,
				[137758] = -1,
				[140759] = -1,
				[126832] = -1,
				[137177] = -1,
				[139480] = -1,
				[130205] = -1,
				[152274] = -1,
				[134174] = -1,
				[130443] = -1,
				[162291] = -1,
				[145110] = -1,
				[137178] = -1,
				[157904] = -1,
				[147507] = -1,
				[133852] = -1,
				[157709] = -1,
				[49999] = -1,
				[144855] = -1,
				[138970] = -1,
				[163025] = -1,
				[125469] = -1,
				[153141] = -1,
				[137947] = -1,
				[140250] = -1,
				[132318] = -1,
				[150997] = -1,
				[129904] = -1,
				[137029] = -1,
				[130160] = -1,
				[153401] = -1,
				[137948] = -1,
				[158953] = -1,
			},
			["quests_completed"] = {
				[49162] = true,
				[49290] = true,
				[49418] = true,
				[50058] = true,
				[54281] = true,
				[54665] = true,
				[38413] = true,
				[42892] = true,
				[55561] = true,
				[55689] = true,
				[39437] = true,
				[47755] = true,
				[47883] = true,
				[52234] = true,
				[40077] = true,
				[52490] = true,
				[48523] = true,
				[52874] = true,
				[57097] = true,
				[44940] = true,
				[57353] = true,
				[49419] = true,
				[41485] = true,
				[49803] = true,
				[50059] = true,
				[38286] = true,
				[50699] = true,
				[46732] = true,
				[50955] = true,
				[51083] = true,
				[51211] = true,
				[51339] = true,
				[51467] = true,
				[55690] = true,
				[51723] = true,
				[51851] = true,
				[47884] = true,
				[56330] = true,
				[52363] = true,
				[52491] = true,
				[48524] = true,
				[52875] = true,
				[53131] = true,
				[57354] = true,
				[49292] = true,
				[53771] = true,
				[49804] = true,
				[54283] = true,
				[58506] = true,
				[58634] = true,
				[50700] = true,
				[46733] = true,
				[38671] = true,
				[55179] = true,
				[55691] = true,
				[39439] = true,
				[51852] = true,
				[52492] = true,
				[48525] = true,
				[52876] = true,
				[48909] = true,
				[53772] = true,
				[49805] = true,
				[50061] = true,
				[54284] = true,
				[54412] = true,
				[50445] = true,
				[50573] = true,
				[46734] = true,
				[38672] = true,
				[51085] = true,
				[51341] = true,
				[39440] = true,
				[55948] = true,
				[56076] = true,
				[48014] = true,
				[40080] = true,
				[52493] = true,
				[48654] = true,
				[52877] = true,
				[49806] = true,
				[50446] = true,
				[51214] = true,
				[51470] = true,
				[51726] = true,
				[51982] = true,
				[48015] = true,
				[40081] = true,
				[48399] = true,
				[52750] = true,
				[53006] = true,
				[49039] = true,
				[49295] = true,
				[49807] = true,
				[50063] = true,
				[50447] = true,
				[55182] = true,
				[51215] = true,
				[51343] = true,
				[51471] = true,
				[55694] = true,
				[55950] = true,
				[47888] = true,
				[56334] = true,
				[48272] = true,
				[48400] = true,
				[53007] = true,
				[45329] = true,
				[49936] = true,
				[50064] = true,
				[38035] = true,
				[50448] = true,
				[50576] = true,
				[50704] = true,
				[38675] = true,
				[51088] = true,
				[51472] = true,
				[55695] = true,
				[51728] = true,
				[55951] = true,
				[43794] = true,
				[56207] = true,
				[52240] = true,
				[48273] = true,
				[52496] = true,
				[40339] = true,
				[45330] = true,
				[50065] = true,
				[54288] = true,
				[38036] = true,
				[50449] = true,
				[38420] = true,
				[55056] = true,
				[51217] = true,
				[39316] = true,
				[55824] = true,
				[39572] = true,
				[47890] = true,
				[56208] = true,
				[52241] = true,
				[53265] = true,
				[37653] = true,
				[37909] = true,
				[42132] = true,
				[50450] = true,
				[50706] = true,
				[54929] = true,
				[55057] = true,
				[55185] = true,
				[51218] = true,
				[55569] = true,
				[43412] = true,
				[55825] = true,
				[47891] = true,
				[56209] = true,
				[52242] = true,
				[40085] = true,
				[56593] = true,
				[56721] = true,
				[49299] = true,
				[49427] = true,
				[57873] = true,
				[37526] = true,
				[49939] = true,
				[45972] = true,
				[31308] = true,
				[50451] = true,
				[54930] = true,
				[55058] = true,
				[51091] = true,
				[47252] = true,
				[55570] = true,
				[39318] = true,
				[47892] = true,
				[56594] = true,
				[56722] = true,
				[44821] = true,
				[53267] = true,
				[49428] = true,
				[41494] = true,
				[54035] = true,
				[54163] = true,
				[50452] = true,
				[51220] = true,
				[55571] = true,
				[39575] = true,
				[52116] = true,
				[48277] = true,
				[56595] = true,
				[44694] = true,
				[53268] = true,
				[53652] = true,
				[37528] = true,
				[37656] = true,
				[50069] = true,
				[54292] = true,
				[31309] = true,
				[50453] = true,
				[38424] = true,
				[50965] = true,
				[38808] = true,
				[51221] = true,
				[51349] = true,
				[55700] = true,
				[55828] = true,
				[55956] = true,
				[51989] = true,
				[56212] = true,
				[52245] = true,
				[48406] = true,
				[56724] = true,
				[56980] = true,
				[45079] = true,
				[49302] = true,
				[53909] = true,
				[49942] = true,
				[50070] = true,
				[54293] = true,
				[54421] = true,
				[50454] = true,
				[42776] = true,
				[51222] = true,
				[51350] = true,
				[55573] = true,
				[39321] = true,
				[55829] = true,
				[39577] = true,
				[52118] = true,
				[52246] = true,
				[44184] = true,
				[40217] = true,
				[40345] = true,
				[52886] = true,
				[49431] = true,
				[53910] = true,
				[37658] = true,
				[50071] = true,
				[50327] = true,
				[50455] = true,
				[50583] = true,
				[46744] = true,
				[42777] = true,
				[47000] = true,
				[51351] = true,
				[55574] = true,
				[39322] = true,
				[39578] = true,
				[56086] = true,
				[52247] = true,
				[48280] = true,
				[56598] = true,
				[52631] = true,
				[48792] = true,
				[53783] = true,
				[37659] = true,
				[50456] = true,
				[50584] = true,
				[42522] = true,
				[55063] = true,
				[51352] = true,
				[55575] = true,
				[39323] = true,
				[47641] = true,
				[39579] = true,
				[56087] = true,
				[48025] = true,
				[48281] = true,
				[40219] = true,
				[40347] = true,
				[40475] = true,
				[48793] = true,
				[49305] = true,
				[49433] = true,
				[53784] = true,
				[37660] = true,
				[50329] = true,
				[50457] = true,
				[50585] = true,
				[38684] = true,
				[51225] = true,
				[51353] = true,
				[51609] = true,
				[39580] = true,
				[52121] = true,
				[56472] = true,
				[48538] = true,
				[40476] = true,
				[49178] = true,
				[45339] = true,
				[49818] = true,
				[54041] = true,
				[54169] = true,
				[42268] = true,
				[50586] = true,
				[55065] = true,
				[38813] = true,
				[51226] = true,
				[51354] = true,
				[51610] = true,
				[55833] = true,
				[47771] = true,
				[51994] = true,
				[52250] = true,
				[48283] = true,
				[48539] = true,
				[52762] = true,
				[44700] = true,
				[49435] = true,
				[50075] = true,
				[54298] = true,
				[50331] = true,
				[54554] = true,
				[38558] = true,
				[55066] = true,
				[51611] = true,
				[52123] = true,
				[56346] = true,
				[40222] = true,
				[48540] = true,
				[48668] = true,
				[44701] = true,
				[53275] = true,
				[45853] = true,
				[54171] = true,
				[54299] = true,
				[50332] = true,
				[50460] = true,
				[50588] = true,
				[38431] = true,
				[54939] = true,
				[50972] = true,
				[39071] = true,
				[55707] = true,
				[39455] = true,
				[56091] = true,
				[52252] = true,
				[56475] = true,
				[56603] = true,
				[40479] = true,
				[49181] = true,
				[41119] = true,
				[37536] = true,
				[54172] = true,
				[50333] = true,
				[42271] = true,
				[54940] = true,
				[50973] = true,
				[51229] = true,
				[55708] = true,
				[39456] = true,
				[56092] = true,
				[52125] = true,
				[52253] = true,
				[56476] = true,
				[56604] = true,
				[48542] = true,
				[48670] = true,
				[57244] = true,
				[57372] = true,
				[41120] = true,
				[45727] = true,
				[45855] = true,
				[50334] = true,
				[38305] = true,
				[38433] = true,
				[50974] = true,
				[51102] = true,
				[51358] = true,
				[55837] = true,
				[51870] = true,
				[56221] = true,
				[56349] = true,
				[56605] = true,
				[44448] = true,
				[48671] = true,
				[57373] = true,
				[49311] = true,
				[49439] = true,
				[37538] = true,
				[49951] = true,
				[54174] = true,
				[54302] = true,
				[38690] = true,
				[51359] = true,
				[51487] = true,
				[51615] = true,
				[51743] = true,
				[51999] = true,
				[56350] = true,
				[56606] = true,
				[48544] = true,
				[48672] = true,
				[48928] = true,
				[57374] = true,
				[8237] = true,
				[53919] = true,
				[41762] = true,
				[41890] = true,
				[54303] = true,
				[54559] = true,
				[38435] = true,
				[50976] = true,
				[38819] = true,
				[47137] = true,
				[51488] = true,
				[51872] = true,
				[52000] = true,
				[52128] = true,
				[52256] = true,
				[56479] = true,
				[56607] = true,
				[56735] = true,
				[48673] = true,
				[48929] = true,
				[57247] = true,
				[41763] = true,
				[41891] = true,
				[54304] = true,
				[42147] = true,
				[50593] = true,
				[38436] = true,
				[31571] = true,
				[42787] = true,
				[55200] = true,
				[51489] = true,
				[51617] = true,
				[51873] = true,
				[52001] = true,
				[52257] = true,
				[56608] = true,
				[48674] = true,
				[40612] = true,
				[57248] = true,
				[49698] = true,
				[54305] = true,
				[38053] = true,
				[50594] = true,
				[54945] = true,
				[50978] = true,
				[51490] = true,
				[55713] = true,
				[51746] = true,
				[52130] = true,
				[52258] = true,
				[48419] = true,
				[56737] = true,
				[48675] = true,
				[56993] = true,
				[57249] = true,
				[49443] = true,
				[45476] = true,
				[37542] = true,
				[41893] = true,
				[54306] = true,
				[50339] = true,
				[50595] = true,
				[31572] = true,
				[51363] = true,
				[47652] = true,
				[39590] = true,
				[52003] = true,
				[52259] = true,
				[44325] = true,
				[48676] = true,
				[48804] = true,
				[49060] = true,
				[57378] = true,
				[45477] = true,
				[54307] = true,
				[50340] = true,
				[54947] = true,
				[51492] = true,
				[51748] = true,
				[51876] = true,
				[52132] = true,
				[48165] = true,
				[56483] = true,
				[48421] = true,
				[56739] = true,
				[48677] = true,
				[48805] = true,
				[53028] = true,
				[49317] = true,
				[49445] = true,
				[54436] = true,
				[38312] = true,
				[50725] = true,
				[31573] = true,
				[39080] = true,
				[47526] = true,
				[51749] = true,
				[51877] = true,
				[56100] = true,
				[52261] = true,
				[56612] = true,
				[44455] = true,
				[48678] = true,
				[48806] = true,
				[45863] = true,
				[38057] = true,
				[50726] = true,
				[42664] = true,
				[55077] = true,
				[42920] = true,
				[43176] = true,
				[39593] = true,
				[44072] = true,
				[40233] = true,
				[56741] = true,
				[48679] = true,
				[40617] = true,
				[53030] = true,
				[41129] = true,
				[49703] = true,
				[49831] = true,
				[54182] = true,
				[54310] = true,
				[50343] = true,
				[50599] = true,
				[38442] = true,
				[42665] = true,
				[42921] = true,
				[51367] = true,
				[43305] = true,
				[43433] = true,
				[51879] = true,
				[56358] = true,
				[44457] = true,
				[48680] = true,
				[56998] = true,
				[57126] = true,
				[49704] = true,
				[45865] = true,
				[50088] = true,
				[38059] = true,
				[50600] = true,
				[38443] = true,
				[50856] = true,
				[55079] = true,
				[55207] = true,
				[51240] = true,
				[51368] = true,
				[55719] = true,
				[51752] = true,
				[51880] = true,
				[52008] = true,
				[56615] = true,
				[53160] = true,
				[53672] = true,
				[49705] = true,
				[50089] = true,
				[54312] = true,
				[38060] = true,
				[50601] = true,
				[38444] = true,
				[51113] = true,
				[51369] = true,
				[55720] = true,
				[51881] = true,
				[56104] = true,
				[48170] = true,
				[56744] = true,
				[48682] = true,
				[53161] = true,
				[49450] = true,
				[53673] = true,
				[49706] = true,
				[50090] = true,
				[46251] = true,
				[42284] = true,
				[38445] = true,
				[54953] = true,
				[51242] = true,
				[55465] = true,
				[55593] = true,
				[51626] = true,
				[39597] = true,
				[56105] = true,
				[48171] = true,
				[48683] = true,
				[48939] = true,
				[57385] = true,
				[49451] = true,
				[53674] = true,
				[53802] = true,
				[37678] = true,
				[50091] = true,
				[37934] = true,
				[38318] = true,
				[50731] = true,
				[31576] = true,
				[55082] = true,
				[55210] = true,
				[51371] = true,
				[47532] = true,
				[56106] = true,
				[56234] = true,
				[40238] = true,
				[57002] = true,
				[53163] = true,
				[49452] = true,
				[53675] = true,
				[50092] = true,
				[37935] = true,
				[46253] = true,
				[42286] = true,
				[29401] = true,
				[46765] = true,
				[50988] = true,
				[55211] = true,
				[39087] = true,
				[55595] = true,
				[47533] = true,
				[55851] = true,
				[51884] = true,
				[56107] = true,
				[39983] = true,
				[48557] = true,
				[48941] = true,
				[49069] = true,
				[57387] = true,
				[49453] = true,
				[53804] = true,
				[54060] = true,
				[54188] = true,
				[50349] = true,
				[50605] = true,
				[50733] = true,
				[42671] = true,
				[50989] = true,
				[47022] = true,
				[55340] = true,
				[51757] = true,
				[52013] = true,
				[39856] = true,
				[40112] = true,
				[56620] = true,
				[48558] = true,
				[57004] = true,
				[48942] = true,
				[57260] = true,
				[57388] = true,
				[49454] = true,
				[53677] = true,
				[49710] = true,
				[58156] = true,
				[50094] = true,
				[54317] = true,
				[50734] = true,
				[47023] = true,
				[55341] = true,
				[43184] = true,
				[55597] = true,
				[55725] = true,
				[47663] = true,
				[47919] = true,
				[56237] = true,
				[39985] = true,
				[56493] = true,
				[56621] = true,
				[48559] = true,
				[44720] = true,
				[48943] = true,
				[57389] = true,
				[53678] = true,
				[53806] = true,
				[50095] = true,
				[54318] = true,
				[50351] = true,
				[54574] = true,
				[42673] = true,
				[42801] = true,
				[47024] = true,
				[43185] = true,
				[55598] = true,
				[55726] = true,
				[55854] = true,
				[47792] = true,
				[52015] = true,
				[39858] = true,
				[39986] = true,
				[56494] = true,
				[44337] = true,
				[48560] = true,
				[44721] = true,
				[48944] = true,
				[49072] = true,
				[53295] = true,
				[53551] = true,
				[41778] = true,
				[50096] = true,
				[50352] = true,
				[50608] = true,
				[42802] = true,
				[47025] = true,
				[43186] = true,
				[51504] = true,
				[51632] = true,
				[55855] = true,
				[51888] = true,
				[52016] = true,
				[43954] = true,
				[39987] = true,
				[44338] = true,
				[44466] = true,
				[56879] = true,
				[48945] = true,
				[53168] = true,
				[57391] = true,
				[45490] = true,
				[53936] = true,
				[49969] = true,
				[54192] = true,
				[50225] = true,
				[50353] = true,
				[50481] = true,
				[50609] = true,
				[31579] = true,
				[55088] = true,
				[55600] = true,
				[51633] = true,
				[55856] = true,
				[51889] = true,
				[52017] = true,
				[39860] = true,
				[48178] = true,
				[56624] = true,
				[53041] = true,
				[53169] = true,
				[57392] = true,
				[53937] = true,
				[54193] = true,
				[50226] = true,
				[50354] = true,
				[42292] = true,
				[50610] = true,
				[55089] = true,
				[51122] = true,
				[55601] = true,
				[55729] = true,
				[51762] = true,
				[39733] = true,
				[52146] = true,
				[48179] = true,
				[40373] = true,
				[56881] = true,
				[57009] = true,
				[49075] = true,
				[45492] = true,
				[49715] = true,
				[54194] = true,
				[50227] = true,
				[50355] = true,
				[42293] = true,
				[50611] = true,
				[42677] = true,
				[55090] = true,
				[51251] = true,
				[55602] = true,
				[55730] = true,
				[55986] = true,
				[47924] = true,
				[48052] = true,
				[39990] = true,
				[48308] = true,
				[56626] = true,
				[40374] = true,
				[44597] = true,
				[57010] = true,
				[53043] = true,
				[53171] = true,
				[45365] = true,
				[45493] = true,
				[49716] = true,
				[49972] = true,
				[54195] = true,
				[50228] = true,
				[50356] = true,
				[50612] = true,
				[38455] = true,
				[46773] = true,
				[51380] = true,
				[47541] = true,
				[55859] = true,
				[43702] = true,
				[47925] = true,
				[52148] = true,
				[48181] = true,
				[48309] = true,
				[40247] = true,
				[44598] = true,
				[53044] = true,
				[49077] = true,
				[36920] = true,
				[53812] = true,
				[54196] = true,
				[50229] = true,
				[50741] = true,
				[46774] = true,
				[43191] = true,
				[43447] = true,
				[55860] = true,
				[39864] = true,
				[44087] = true,
				[48310] = true,
				[56628] = true,
				[44471] = true,
				[44599] = true,
				[53045] = true,
				[57524] = true,
				[49718] = true,
				[54197] = true,
				[54325] = true,
				[54453] = true,
				[50614] = true,
				[50742] = true,
				[54965] = true,
				[42808] = true,
				[51126] = true,
				[55349] = true,
				[47287] = true,
				[51638] = true,
				[43576] = true,
				[56117] = true,
				[52150] = true,
				[48183] = true,
				[48311] = true,
				[40249] = true,
				[44600] = true,
				[40761] = true,
				[53174] = true,
				[49719] = true,
				[37690] = true,
				[54198] = true,
				[50359] = true,
				[54710] = true,
				[42681] = true,
				[38714] = true,
				[55350] = true,
				[51383] = true,
				[47416] = true,
				[43449] = true,
				[56118] = true,
				[56246] = true,
				[52279] = true,
				[40122] = true,
				[48440] = true,
				[44473] = true,
				[44601] = true,
				[57142] = true,
				[40890] = true,
				[45497] = true,
				[49720] = true,
				[49976] = true,
				[54199] = true,
				[38331] = true,
				[42682] = true,
				[42810] = true,
				[47289] = true,
				[55735] = true,
				[51896] = true,
				[43834] = true,
				[48057] = true,
				[56375] = true,
				[40123] = true,
				[48441] = true,
				[40379] = true,
				[44602] = true,
				[53176] = true,
				[49465] = true,
				[53816] = true,
				[58167] = true,
				[54200] = true,
				[46266] = true,
				[38460] = true,
				[42683] = true,
				[51001] = true,
				[51129] = true,
				[55480] = true,
				[55608] = true,
				[55736] = true,
				[51897] = true,
				[56248] = true,
				[52281] = true,
				[56504] = true,
				[48442] = true,
				[48570] = true,
				[52793] = true,
				[48954] = true,
				[53177] = true,
				[57528] = true,
				[37565] = true,
				[37821] = true,
				[50362] = true,
				[38333] = true,
				[54969] = true,
				[38717] = true,
				[51386] = true,
				[55737] = true,
				[43580] = true,
				[52026] = true,
				[52154] = true,
				[52282] = true,
				[48443] = true,
				[44604] = true,
				[53178] = true,
				[53306] = true,
				[53434] = true,
				[49467] = true,
				[53818] = true,
				[37566] = true,
				[54202] = true,
				[50363] = true,
				[38206] = true,
				[46780] = true,
				[38718] = true,
				[55354] = true,
				[55610] = true,
				[39614] = true,
				[52027] = true,
				[52283] = true,
				[40126] = true,
				[40254] = true,
				[44605] = true,
				[53307] = true,
				[53435] = true,
				[49468] = true,
				[53819] = true,
				[53947] = true,
				[37823] = true,
				[54459] = true,
				[38719] = true,
				[38847] = true,
				[39487] = true,
				[55995] = true,
				[52028] = true,
				[52156] = true,
				[52284] = true,
				[48317] = true,
				[48445] = true,
				[52796] = true,
				[52924] = true,
				[53052] = true,
				[49341] = true,
				[45502] = true,
				[49725] = true,
				[53948] = true,
				[49981] = true,
				[54204] = true,
				[50365] = true,
				[50493] = true,
				[50621] = true,
				[31585] = true,
				[51389] = true,
				[39488] = true,
				[52029] = true,
				[52157] = true,
				[52285] = true,
				[44223] = true,
				[48446] = true,
				[44479] = true,
				[44607] = true,
				[53181] = true,
				[53309] = true,
				[45503] = true,
				[53949] = true,
				[50110] = true,
				[50238] = true,
				[50366] = true,
				[38337] = true,
				[38721] = true,
				[51134] = true,
				[51390] = true,
				[51646] = true,
				[39489] = true,
				[55997] = true,
				[52030] = true,
				[48063] = true,
				[52286] = true,
				[48447] = true,
				[48575] = true,
				[56893] = true,
				[53182] = true,
				[53310] = true,
				[45504] = true,
				[50111] = true,
				[50239] = true,
				[50367] = true,
				[38210] = true,
				[38466] = true,
				[31586] = true,
				[51135] = true,
				[51391] = true,
				[39490] = true,
				[51903] = true,
				[52031] = true,
				[48064] = true,
				[52287] = true,
				[48448] = true,
				[40386] = true,
				[53183] = true,
				[49216] = true,
				[53439] = true,
				[53951] = true,
				[49984] = true,
				[50368] = true,
				[38595] = true,
				[38723] = true,
				[51136] = true,
				[55359] = true,
				[39235] = true,
				[55743] = true,
				[39491] = true,
				[51904] = true,
				[52032] = true,
				[52288] = true,
				[44226] = true,
				[52544] = true,
				[52672] = true,
				[40515] = true,
				[53184] = true,
				[53312] = true,
				[49601] = true,
				[38212] = true,
				[58815] = true,
				[50753] = true,
				[38596] = true,
				[38724] = true,
				[55360] = true,
				[47554] = true,
				[56000] = true,
				[52033] = true,
				[56256] = true,
				[52289] = true,
				[56640] = true,
				[44483] = true,
				[52801] = true,
				[48962] = true,
				[53185] = true,
				[49218] = true,
				[53441] = true,
				[49602] = true,
				[49730] = true,
				[37957] = true,
				[50370] = true,
				[29412] = true,
				[50754] = true,
				[38725] = true,
				[47043] = true,
				[55361] = true,
				[51394] = true,
				[55617] = true,
				[52034] = true,
				[48195] = true,
				[56641] = true,
				[44484] = true,
				[52802] = true,
				[48963] = true,
				[53186] = true,
				[53442] = true,
				[45764] = true,
				[54082] = true,
				[50371] = true,
				[38342] = true,
				[31588] = true,
				[51139] = true,
				[55362] = true,
				[51395] = true,
				[47428] = true,
				[52035] = true,
				[48196] = true,
				[56642] = true,
				[53187] = true,
				[53443] = true,
				[53571] = true,
				[53699] = true,
				[37447] = true,
				[54083] = true,
				[37831] = true,
				[37959] = true,
				[50372] = true,
				[38727] = true,
				[51140] = true,
				[55363] = true,
				[51396] = true,
				[55619] = true,
				[47685] = true,
				[51908] = true,
				[52036] = true,
				[48453] = true,
				[44486] = true,
				[56899] = true,
				[57027] = true,
				[48965] = true,
				[53316] = true,
				[53444] = true,
				[53572] = true,
				[49733] = true,
				[53956] = true,
				[37960] = true,
				[50373] = true,
				[58691] = true,
				[42567] = true,
				[42695] = true,
				[38728] = true,
				[47046] = true,
				[43207] = true,
				[47686] = true,
				[56004] = true,
				[48070] = true,
				[48198] = true,
				[56644] = true,
				[40520] = true,
				[57028] = true,
				[53445] = true,
				[53573] = true,
				[45511] = true,
				[37449] = true,
				[53957] = true,
				[50374] = true,
				[38217] = true,
				[50758] = true,
				[38729] = true,
				[47047] = true,
				[47431] = true,
				[47687] = true,
				[52038] = true,
				[56261] = true,
				[48199] = true,
				[48455] = true,
				[57029] = true,
				[40905] = true,
				[49223] = true,
				[53446] = true,
				[53574] = true,
				[37450] = true,
				[54086] = true,
				[50759] = true,
				[42697] = true,
				[47048] = true,
				[55366] = true,
				[55622] = true,
				[47688] = true,
				[56006] = true,
				[52039] = true,
				[48200] = true,
				[52807] = true,
				[49224] = true,
				[53575] = true,
				[49736] = true,
				[53959] = true,
				[54087] = true,
				[37963] = true,
				[50376] = true,
				[50504] = true,
				[50760] = true,
				[51144] = true,
				[55623] = true,
				[47689] = true,
				[56007] = true,
				[47945] = true,
				[56263] = true,
				[48201] = true,
				[49225] = true,
				[49481] = true,
				[53704] = true,
				[49737] = true,
				[53960] = true,
				[41803] = true,
				[50249] = true,
				[50761] = true,
				[46794] = true,
				[42827] = true,
				[51145] = true,
				[51401] = true,
				[47562] = true,
				[47690] = true,
				[51913] = true,
				[47946] = true,
				[40012] = true,
				[56520] = true,
				[48842] = true,
				[49226] = true,
				[56074] = true,
				[49738] = true,
				[53961] = true,
				[41804] = true,
				[57915] = true,
				[52873] = true,
				[56840] = true,
				[58646] = true,
				[58645] = true,
				[50762] = true,
				[58288] = true,
				[51018] = true,
				[53945] = true,
				[56377] = true,
				[39117] = true,
				[39692] = true,
				[39373] = true,
				[47691] = true,
				[56009] = true,
				[47947] = true,
				[52170] = true,
				[48203] = true,
				[58641] = true,
				[58636] = true,
				[56777] = true,
				[58638] = true,
				[51465] = true,
				[58282] = true,
				[53194] = true,
				[41037] = true,
				[53450] = true,
				[58639] = true,
				[53706] = true,
				[49739] = true,
				[49867] = true,
				[49995] = true,
				[58155] = true,
				[50251] = true,
				[58285] = true,
				[46730] = true,
				[50635] = true,
				[50763] = true,
				[46796] = true,
				[51019] = true,
				[38862] = true,
				[47180] = true,
				[51403] = true,
				[43341] = true,
				[39374] = true,
				[43597] = true,
				[56010] = true,
				[47948] = true,
				[52171] = true,
				[50697] = true,
				[52040] = true,
				[48460] = true,
				[56778] = true,
				[55723] = true,
				[58642] = true,
				[48972] = true,
				[57290] = true,
				[57280] = true,
				[55983] = true,
				[57674] = true,
				[42181] = true,
				[49740] = true,
				[42510] = true,
				[41806] = true,
				[55698] = true,
				[40087] = true,
				[58438] = true,
				[50508] = true,
				[49289] = true,
				[50987] = true,
				[46797] = true,
				[51020] = true,
				[39741] = true,
				[47181] = true,
				[56348] = true,
				[39247] = true,
				[51660] = true,
				[51878] = true,
				[51916] = true,
				[47949] = true,
				[52172] = true,
				[38689] = true,
				[52428] = true,
				[48461] = true,
				[56779] = true,
				[57258] = true,
				[57362] = true,
				[48973] = true,
				[52800] = true,
				[49229] = true,
				[53452] = true,
				[58290] = true,
				[55479] = true,
				[49741] = true,
				[49869] = true,
				[41807] = true,
				[58643] = true,
				[50253] = true,
				[46286] = true,
				[56473] = true,
				[38352] = true,
				[39435] = true,
				[46798] = true,
				[42831] = true,
				[51149] = true,
				[47182] = true,
				[39120] = true,
				[39867] = true,
				[55756] = true,
				[55884] = true,
				[56374] = true,
				[47950] = true,
				[52173] = true,
				[55731] = true,
				[55752] = true,
				[48462] = true,
				[56780] = true,
				[56135] = true,
				[57036] = true,
				[53069] = true,
				[53197] = true,
				[49230] = true,
				[53453] = true,
				[45391] = true,
				[56354] = true,
				[46729] = true,
				[55718] = true,
				[49998] = true,
				[51776] = true,
				[46159] = true,
				[51661] = true,
				[38225] = true,
				[50312] = true,
				[51528] = true,
				[46799] = true,
				[55117] = true,
				[51150] = true,
				[47183] = true,
				[56347] = true,
				[51534] = true,
				[47567] = true,
				[55885] = true,
				[51918] = true,
				[56141] = true,
				[56585] = true,
				[56113] = true,
				[56525] = true,
				[51630] = true,
				[44496] = true,
				[56082] = true,
				[56351] = true,
				[53070] = true,
				[53198] = true,
				[49231] = true,
				[56108] = true,
				[56884] = true,
				[57222] = true,
				[48904] = true,
				[48776] = true,
				[49999] = true,
				[51618] = true,
				[51722] = true,
				[50616] = true,
				[50511] = true,
				[50639] = true,
				[54862] = true,
				[46800] = true,
				[55118] = true,
				[51151] = true,
				[47184] = true,
				[51407] = true,
				[42775] = true,
				[55758] = true,
				[47952] = true,
				[56014] = true,
				[52047] = true,
				[48080] = true,
				[52303] = true,
				[52431] = true,
				[52559] = true,
				[44497] = true,
				[55970] = true,
				[54703] = true,
				[53071] = true,
				[50459] = true,
				[49232] = true,
				[55627] = true,
				[45393] = true,
				[53711] = true,
				[49744] = true,
				[39438] = true,
				[39178] = true,
				[39050] = true,
				[38922] = true,
				[55069] = true,
				[54949] = true,
				[50640] = true,
				[38483] = true,
				[38611] = true,
				[55119] = true,
				[29675] = true,
				[51280] = true,
				[39123] = true,
				[55727] = true,
				[55759] = true,
				[55887] = true,
				[56015] = true,
				[56143] = true,
				[48081] = true,
				[42505] = true,
				[56527] = true,
				[52560] = true,
				[50567] = true,
				[56352] = true,
				[57039] = true,
				[57167] = true,
				[53200] = true,
				[49233] = true,
				[51891] = true,
				[45394] = true,
				[53712] = true,
				[49745] = true,
				[39859] = true,
				[50001] = true,
				[38834] = true,
				[52046] = true,
				[56211] = true,
				[53833] = true,
				[50975] = true,
				[56883] = true,
				[50897] = true,
				[44214] = true,
				[51625] = true,
				[47186] = true,
				[39124] = true,
				[56144] = true,
				[55760] = true,
				[55888] = true,
				[56016] = true,
				[52049] = true,
				[55821] = true,
				[52870] = true,
				[52433] = true,
				[51665] = true,
				[57141] = true,
				[40378] = true,
				[57040] = true,
				[48978] = true,
				[56979] = true,
				[49234] = true,
				[48180] = true,
				[45395] = true,
				[38994] = true,
				[49746] = true,
				[56078] = true,
				[50002] = true,
				[51846] = true,
				[56982] = true,
				[50386] = true,
				[54609] = true,
				[51781] = true,
				[51026] = true,
				[38613] = true,
				[55121] = true,
				[34774] = true,
				[51282] = true,
				[39765] = true,
				[43348] = true,
				[39381] = true,
				[55889] = true,
				[56017] = true,
				[52050] = true,
				[56273] = true,
				[56401] = true,
				[56529] = true,
				[52043] = true,
				[40405] = true,
				[55464] = true,
				[52946] = true,
				[53074] = true,
				[53202] = true,
				[41045] = true,
				[56378] = true,
				[45396] = true,
				[49619] = true,
				[48778] = true,
				[57166] = true,
				[50003] = true,
				[56630] = true,
				[50259] = true,
				[50387] = true,
				[54610] = true,
				[39372] = true,
				[38486] = true,
				[38614] = true,
				[56526] = true,
				[54449] = true,
				[51283] = true,
				[51892] = true,
				[51795] = true,
				[51667] = true,
				[55890] = true,
				[51923] = true,
				[38612] = true,
				[52179] = true,
				[56508] = true,
				[56530] = true,
				[51875] = true,
				[53820] = true,
				[41096] = true,
				[51506] = true,
				[57170] = true,
				[57298] = true,
				[55957] = true,
				[53701] = true,
				[44679] = true,
				[49620] = true,
				[53387] = true,
				[55853] = true,
				[56013] = true,
				[51627] = true,
				[50260] = true,
				[55757] = true,
				[54611] = true,
				[50644] = true,
				[51796] = true,
				[46805] = true,
				[51028] = true,
				[51156] = true,
				[47189] = true,
				[51412] = true,
				[51540] = true,
				[39383] = true,
				[55891] = true,
				[56019] = true,
				[55818] = true,
				[54183] = true,
				[52308] = true,
				[56370] = true,
				[57168] = true,
				[48597] = true,
				[48974] = true,
				[48853] = true,
				[48981] = true,
				[56891] = true,
				[53332] = true,
				[55300] = true,
				[56719] = true,
				[49621] = true,
				[54454] = true,
				[53814] = true,
				[55754] = true,
				[50133] = true,
				[50773] = true,
				[58579] = true,
				[38232] = true,
				[50645] = true,
				[38488] = true,
				[38616] = true,
				[51029] = true,
				[54456] = true,
				[55380] = true,
				[39768] = true,
				[43351] = true,
				[39384] = true,
				[55892] = true,
				[56020] = true,
				[52053] = true,
				[56276] = true,
				[54458] = true,
				[56532] = true,
				[56660] = true,
				[56788] = true,
				[55060] = true,
				[57044] = true,
				[51639] = true,
				[53205] = true,
				[58013] = true,
				[53461] = true,
				[56238] = true,
				[53717] = true,
				[55463] = true,
				[55852] = true,
				[56335] = true,
				[50134] = true,
				[51030] = true,
				[54485] = true,
				[58708] = true,
				[46772] = true,
				[50774] = true,
				[38617] = true,
				[46935] = true,
				[43480] = true,
				[48773] = true,
				[52310] = true,
				[48087] = true,
				[55765] = true,
				[55893] = true,
				[56021] = true,
				[39769] = true,
				[56277] = true,
				[44120] = true,
				[56533] = true,
				[55823] = true,
				[56789] = true,
				[43837] = true,
				[44760] = true,
				[40921] = true,
				[53206] = true,
				[53334] = true,
				[49367] = true,
				[56729] = true,
				[31580] = true,
				[56142] = true,
				[53974] = true,
				[50391] = true,
				[50135] = true,
				[50263] = true,
				[58581] = true,
				[56121] = true,
				[38618] = true,
				[54870] = true,
				[50903] = true,
				[51031] = true,
				[51159] = true,
				[52055] = true,
				[47960] = true,
				[51543] = true,
				[51076] = true,
				[55894] = true,
				[56022] = true,
				[56150] = true,
				[48088] = true,
				[52311] = true,
				[52439] = true,
				[56662] = true,
				[48600] = true,
				[52871] = true,
				[42630] = true,
				[40794] = true,
				[38407] = true,
				[53164] = true,
				[49368] = true,
				[45785] = true,
				[46213] = true,
				[37467] = true,
				[53975] = true,
				[56380] = true,
				[50136] = true,
				[50264] = true,
				[46297] = true,
				[38235] = true,
				[38363] = true,
				[54871] = true,
				[51662] = true,
				[51032] = true,
				[54555] = true,
				[39515] = true,
				[53763] = true,
				[51544] = true,
				[39387] = true,
				[55895] = true,
				[56023] = true,
				[47961] = true,
				[48089] = true,
				[52639] = true,
				[48345] = true,
				[48601] = true,
				[52696] = true,
				[55973] = true,
				[52296] = true,
				[56011] = true,
				[40923] = true,
				[53336] = true,
				[53464] = true,
				[52260] = true,
				[44677] = true,
				[53848] = true,
				[37596] = true,
				[51033] = true,
				[50137] = true,
				[50265] = true,
				[54488] = true,
				[40326] = true,
				[50649] = true,
				[50777] = true,
				[47962] = true,
				[46938] = true,
				[47066] = true,
				[57169] = true,
				[55512] = true,
				[51545] = true,
				[43483] = true,
				[55896] = true,
				[56024] = true,
				[52057] = true,
				[56280] = true,
				[53337] = true,
				[52441] = true,
				[44379] = true,
				[48602] = true,
				[57165] = true,
				[39686] = true,
				[48986] = true,
				[40924] = true,
				[49242] = true,
				[53465] = true,
				[53849] = true,
				[53977] = true,
				[37469] = true,
				[45787] = true,
				[54090] = true,
				[37853] = true,
				[50266] = true,
				[56534] = true,
				[38237] = true,
				[38365] = true,
				[50778] = true,
				[51331] = true,
				[51034] = true,
				[56599] = true,
				[53037] = true,
				[55513] = true,
				[39261] = true,
				[53436] = true,
				[39517] = true,
				[47835] = true,
				[52058] = true,
				[50819] = true,
				[54786] = true,
				[48347] = true,
				[48475] = true,
				[40413] = true,
				[56537] = true,
				[37657] = true,
				[50307] = true,
				[55880] = true,
				[53414] = true,
				[56025] = true,
				[40009] = true,
				[58498] = true,
				[49755] = true,
				[53978] = true,
				[37726] = true,
				[50139] = true,
				[39498] = true,
				[54618] = true,
				[38238] = true,
				[40753] = true,
				[56278] = true,
				[57133] = true,
				[51035] = true,
				[51163] = true,
				[47196] = true,
				[39134] = true,
				[51547] = true,
				[48899] = true,
				[55898] = true,
				[39646] = true,
				[52866] = true,
				[56652] = true,
				[56410] = true,
				[52443] = true,
				[48476] = true,
				[40414] = true,
				[43467] = true,
				[56079] = true,
				[37969] = true,
				[48202] = true,
				[41054] = true,
				[55831] = true,
				[51418] = true,
				[53723] = true,
				[51842] = true,
				[41694] = true,
				[37727] = true,
				[37855] = true,
				[54363] = true,
				[51714] = true,
				[56501] = true,
				[56538] = true,
				[50780] = true,
				[50908] = true,
				[46941] = true,
				[29681] = true,
				[47235] = true,
				[56139] = true,
				[43358] = true,
				[39391] = true,
				[55899] = true,
				[51074] = true,
				[52060] = true,
				[56892] = true,
				[44678] = true,
				[56539] = true,
				[48477] = true,
				[48605] = true,
				[44638] = true,
				[56471] = true,
				[55064] = true,
				[54946] = true,
				[58496] = true,
				[49373] = true,
				[57134] = true,
				[53724] = true,
				[49757] = true,
				[55857] = true,
				[37728] = true,
				[37856] = true,
				[50269] = true,
				[38810] = true,
				[50525] = true,
				[50653] = true,
				[50781] = true,
				[50909] = true,
				[45117] = true,
				[51165] = true,
				[53715] = true,
				[56149] = true,
				[56156] = true,
				[39392] = true,
				[55900] = true,
				[41092] = true,
				[39776] = true,
				[56284] = true,
				[56635] = true,
				[56540] = true,
				[44383] = true,
				[48606] = true,
				[44639] = true,
				[55836] = true,
				[54876] = true,
				[56586] = true,
				[41056] = true,
				[38473] = true,
				[55994] = true,
				[39718] = true,
				[56247] = true,
				[49886] = true,
				[37729] = true,
				[37857] = true,
				[56787] = true,
				[56528] = true,
				[56064] = true,
				[56119] = true,
				[45843] = true,
				[50910] = true,
				[38753] = true,
				[55261] = true,
				[38472] = true,
				[55517] = true,
				[55645] = true,
				[47583] = true,
				[55901] = true,
				[39777] = true,
				[52062] = true,
				[56413] = true,
				[52318] = true,
				[56541] = true,
				[47106] = true,
				[51073] = true,
				[55497] = true,
				[39873] = true,
				[47508] = true,
				[55734] = true,
				[56241] = true,
				[53470] = true,
				[42115] = true,
				[53726] = true,
				[50177] = true,
				[49887] = true,
				[37730] = true,
				[50049] = true,
				[46176] = true,
				[31589] = true,
				[49793] = true,
				[45570] = true,
				[50783] = true,
				[50911] = true,
				[48184] = true,
				[51167] = true,
				[55390] = true,
				[55518] = true,
				[49735] = true,
				[47584] = true,
				[51807] = true,
				[55902] = true,
				[47968] = true,
				[56286] = true,
				[56414] = true,
				[48352] = true,
				[52575] = true,
				[48608] = true,
				[44641] = true,
				[48864] = true,
				[56542] = true,
				[56244] = true,
				[38857] = true,
				[55183] = true,
				[55068] = true,
				[56613] = true,
				[52869] = true,
				[56633] = true,
				[40388] = true,
				[37859] = true,
				[46177] = true,
				[54495] = true,
				[50528] = true,
				[46244] = true,
				[50784] = true,
				[50912] = true,
				[39683] = true,
				[51168] = true,
				[51808] = true,
				[47329] = true,
				[51552] = true,
				[47585] = true,
				[55903] = true,
				[56031] = true,
				[47969] = true,
				[56245] = true,
				[47489] = true,
				[48353] = true,
				[56740] = true,
				[55618] = true,
				[52832] = true,
				[51200] = true,
				[54879] = true,
				[49734] = true,
				[56791] = true,
				[31752] = true,
				[56627] = true,
				[50432] = true,
				[42701] = true,
				[31582] = true,
				[55697] = true,
				[37860] = true,
				[58463] = true,
				[55519] = true,
				[37507] = true,
				[55520] = true,
				[57726] = true,
				[46818] = true,
				[50361] = true,
				[51169] = true,
				[55392] = true,
				[47330] = true,
				[47586] = true,
				[55776] = true,
				[51809] = true,
				[39652] = true,
				[52065] = true,
				[55264] = true,
				[52321] = true,
				[48354] = true,
				[39742] = true,
				[54201] = true,
				[56958] = true,
				[44771] = true,
				[44545] = true,
				[42590] = true,
				[41060] = true,
				[56610] = true,
				[51298] = true,
				[51426] = true,
				[53857] = true,
				[49890] = true,
				[37733] = true,
				[37861] = true,
				[58464] = true,
				[52450] = true,
				[50530] = true,
				[50658] = true,
				[42596] = true,
				[50914] = true,
				[51967] = true,
				[51170] = true,
				[55393] = true,
				[55521] = true,
				[51554] = true,
				[47587] = true,
				[55905] = true,
				[55934] = true,
				[51711] = true,
				[56289] = true,
				[52322] = true,
				[48355] = true,
				[48483] = true,
				[47488] = true,
				[52834] = true,
				[52962] = true,
				[54975] = true,
				[48449] = true,
				[51199] = true,
				[56131] = true,
				[45412] = true,
				[56242] = true,
				[42213] = true,
				[53986] = true,
				[54114] = true,
				[37862] = true,
				[58465] = true,
				[54498] = true,
				[54626] = true,
				[38374] = true,
				[50787] = true,
				[50915] = true,
				[44480] = true,
				[38886] = true,
				[55394] = true,
				[51427] = true,
				[55451] = true,
				[31592] = true,
				[55906] = true,
				[51939] = true,
				[52067] = true,
				[56290] = true,
				[55374] = true,
				[52451] = true,
				[37890] = true,
				[40422] = true,
				[53347] = true,
				[52963] = true,
				[57186] = true,
				[53219] = true,
				[41062] = true,
				[53475] = true,
				[45413] = true,
				[55999] = true,
				[54964] = true,
				[41702] = true,
				[58466] = true,
				[50148] = true,
				[37991] = true,
				[54206] = true,
				[54627] = true,
				[56239] = true,
				[50788] = true,
				[55095] = true,
				[38759] = true,
				[54922] = true,
				[55395] = true,
				[51428] = true,
				[39496] = true,
				[47589] = true,
				[55907] = true,
				[54972] = true,
				[56163] = true,
				[52196] = true,
				[44672] = true,
				[40167] = true,
				[56356] = true,
				[40796] = true,
				[42809] = true,
				[56089] = true,
				[55213] = true,
				[50824] = true,
				[53988] = true,
				[53476] = true,
				[41319] = true,
				[47743] = true,
				[57955] = true,
				[45798] = true,
				[37736] = true,
				[50149] = true,
				[58467] = true,
				[39425] = true,
				[50533] = true,
				[47487] = true,
				[50789] = true,
				[55549] = true,
				[53847] = true,
				[50348] = true,
				[55396] = true,
				[56095] = true,
				[39272] = true,
				[43495] = true,
				[51813] = true,
				[56036] = true,
				[55908] = true,
				[52197] = true,
				[48230] = true,
				[50814] = true,
				[49997] = true,
				[43855] = true,
				[52837] = true,
				[57060] = true,
				[55096] = true,
				[53221] = true,
				[41064] = true,
				[50325] = true,
				[45415] = true,
				[37889] = true,
				[50046] = true,
				[41704] = true,
				[54117] = true,
				[54245] = true,
				[58468] = true,
				[40253] = true,
				[54629] = true,
				[50662] = true,
				[50790] = true,
				[55116] = true,
				[40584] = true,
				[48946] = true,
				[55397] = true,
				[51430] = true,
				[56162] = true,
				[43496] = true,
				[55565] = true,
				[56037] = true,
				[52070] = true,
				[57700] = true,
				[52326] = true,
				[44481] = true,
				[52582] = true,
				[44213] = true,
				[54324] = true,
				[57061] = true,
				[51613] = true,
				[53222] = true,
				[56506] = true,
				[49383] = true,
				[57701] = true,
				[42670] = true,
				[54113] = true,
				[58085] = true,
				[54118] = true,
				[50151] = true,
				[40255] = true,
				[56188] = true,
				[54630] = true,
				[53405] = true,
				[38615] = true,
				[50919] = true,
				[42857] = true,
				[52787] = true,
				[55398] = true,
				[51581] = true,
				[44137] = true,
				[51687] = true,
				[55910] = true,
				[56038] = true,
				[42118] = true,
				[44009] = true,
				[52327] = true,
				[40170] = true,
				[47102] = true,
				[48616] = true,
				[54938] = true,
				[45908] = true,
				[54417] = true,
				[55960] = true,
				[41066] = true,
				[49384] = true,
				[57702] = true,
				[53989] = true,
				[38144] = true,
				[49896] = true,
				[41834] = true,
				[50152] = true,
				[50280] = true,
				[50301] = true,
				[54631] = true,
				[52147] = true,
				[37530] = true,
				[48182] = true,
				[31577] = true,
				[56039] = true,
				[55399] = true,
				[52072] = true,
				[49405] = true,
				[55783] = true,
				[55911] = true,
				[51944] = true,
				[56167] = true,
				[55101] = true,
				[56218] = true,
				[37654] = true,
				[55373] = true,
				[57063] = true,
				[52840] = true,
				[48873] = true,
				[57191] = true,
				[47827] = true,
				[41067] = true,
				[54628] = true,
				[57703] = true,
				[49897] = true,
				[49769] = true,
				[41707] = true,
				[53976] = true,
				[54504] = true,
				[58471] = true,
				[46314] = true,
				[54632] = true,
				[55528] = true,
				[50793] = true,
				[42731] = true,
				[47869] = true,
				[51177] = true,
				[55400] = true,
				[51433] = true,
				[51281] = true,
				[55784] = true,
				[55912] = true,
				[51945] = true,
				[47978] = true,
				[56168] = true,
				[52329] = true,
				[51356] = true,
				[13807] = true,
				[56808] = true,
				[41749] = true,
				[52969] = true,
				[53097] = true,
				[47101] = true,
				[42669] = true,
				[38655] = true,
				[57704] = true,
				[41452] = true,
				[42622] = true,
				[49898] = true,
				[50026] = true,
				[37869] = true,
				[54992] = true,
				[42220] = true,
				[51279] = true,
				[38381] = true,
				[56041] = true,
				[38637] = true,
				[42860] = true,
				[48107] = true,
				[52330] = true,
				[51434] = true,
				[55657] = true,
				[51690] = true,
				[55913] = true,
				[51946] = true,
				[47979] = true,
				[56297] = true,
				[44140] = true,
				[48619] = true,
				[40301] = true,
				[56809] = true,
				[56220] = true,
				[52291] = true,
				[53098] = true,
				[41069] = true,
				[49259] = true,
				[41197] = true,
				[38765] = true,
				[41453] = true,
				[37486] = true,
				[53994] = true,
				[37470] = true,
				[50155] = true,
				[53371] = true,
				[42221] = true,
				[49480] = true,
				[38382] = true,
				[50795] = true,
				[42733] = true,
				[38766] = true,
				[38894] = true,
				[48344] = true,
				[47980] = true,
				[55658] = true,
				[43501] = true,
				[55914] = true,
				[56042] = true,
				[56170] = true,
				[48108] = true,
				[56426] = true,
				[48764] = true,
				[40302] = true,
				[56810] = true,
				[54878] = true,
				[40814] = true,
				[49004] = true,
				[49260] = true,
				[41070] = true,
				[49388] = true,
				[53611] = true,
				[52494] = true,
				[53867] = true,
				[47654] = true,
				[56186] = true,
				[50156] = true,
				[40256] = true,
				[54507] = true,
				[51538] = true,
				[38715] = true,
				[47853] = true,
				[56171] = true,
				[38767] = true,
				[40175] = true,
				[51308] = true,
				[55531] = true,
				[55659] = true,
				[55787] = true,
				[47100] = true,
				[56043] = true,
				[47981] = true,
				[48109] = true,
				[48621] = true,
				[52460] = true,
				[50939] = true,
				[56811] = true,
				[41121] = true,
				[44782] = true,
				[40815] = true,
				[49133] = true,
				[53356] = true,
				[48365] = true,
				[57707] = true,
				[29674] = true,
				[43993] = true,
				[38014] = true,
				[38384] = true,
				[50157] = true,
				[54380] = true,
				[54508] = true,
				[50541] = true,
				[50669] = true,
				[50043] = true,
				[42735] = true,
				[52204] = true,
				[42223] = true,
				[55404] = true,
				[42732] = true,
				[56812] = true,
				[43503] = true,
				[55916] = true,
				[47854] = true,
				[47982] = true,
				[48110] = true,
				[56428] = true,
				[48366] = true,
				[57593] = true,
				[48622] = true,
				[52845] = true,
				[52973] = true,
				[40816] = true,
				[49134] = true,
				[38687] = true,
				[53406] = true,
				[54401] = true,
				[51384] = true,
				[52858] = true,
				[56300] = true,
				[39775] = true,
				[50158] = true,
				[44464] = true,
				[52205] = true,
				[50542] = true,
				[38641] = true,
				[47995] = true,
				[42736] = true,
				[51962] = true,
				[51310] = true,
				[39025] = true,
				[55533] = true,
				[55405] = true,
				[42666] = true,
				[55917] = true,
				[47855] = true,
				[48367] = true,
				[48111] = true,
				[48879] = true,
				[52462] = true,
				[44400] = true,
				[48623] = true,
				[47099] = true,
				[52974] = true,
				[57197] = true,
				[52074] = true,
				[55033] = true,
				[52041] = true,
				[39607] = true,
				[39133] = true,
				[46816] = true,
				[53276] = true,
				[54126] = true,
				[54254] = true,
				[50170] = true,
				[54510] = true,
				[54638] = true,
				[42786] = true,
				[50159] = true,
				[42737] = true,
				[42865] = true,
				[52461] = true,
				[39026] = true,
				[52790] = true,
				[48368] = true,
				[55790] = true,
				[55918] = true,
				[47856] = true,
				[41212] = true,
				[56302] = true,
				[53369] = true,
				[56558] = true,
				[52975] = true,
				[56814] = true,
				[48752] = true,
				[44785] = true,
				[48880] = true,
				[47627] = true,
				[48774] = true,
				[53887] = true,
				[39596] = true,
				[47706] = true,
				[38643] = true,
				[47217] = true,
				[54127] = true,
				[50160] = true,
				[56184] = true,
				[46321] = true,
				[50544] = true,
				[50672] = true,
				[54895] = true,
				[42738] = true,
				[51961] = true,
				[51833] = true,
				[55407] = true,
				[40051] = true,
				[47473] = true,
				[55791] = true,
				[55919] = true,
				[52976] = true,
				[56175] = true,
				[48113] = true,
				[56431] = true,
				[48369] = true,
				[52592] = true,
				[56815] = true,
				[56943] = true,
				[48881] = true,
				[40819] = true,
				[49137] = true,
				[44914] = true,
				[49393] = true,
				[53616] = true,
				[39988] = true,
				[37492] = true,
				[47098] = true,
				[51065] = true,
				[50161] = true,
				[46842] = true,
				[50417] = true,
				[39789] = true,
				[44070] = true,
				[58991] = true,
				[46834] = true,
				[38772] = true,
				[38644] = true,
				[47218] = true,
				[44004] = true,
				[51569] = true,
				[56816] = true,
				[51825] = true,
				[56048] = true,
				[47986] = true,
				[56304] = true,
				[56944] = true,
				[48370] = true,
				[48882] = true,
				[48626] = true,
				[52849] = true,
				[52977] = true,
				[44915] = true,
				[48474] = true,
				[45171] = true,
				[49394] = true,
				[53617] = true,
				[52789] = true,
				[33071] = true,
				[55260] = true,
				[54129] = true,
				[50162] = true,
				[47219] = true,
				[50418] = true,
				[50546] = true,
				[50674] = true,
				[50802] = true,
				[38645] = true,
				[51058] = true,
				[55921] = true,
				[51314] = true,
				[55537] = true,
				[51570] = true,
				[51698] = true,
				[51826] = true,
				[48874] = true,
				[47987] = true,
				[31574] = true,
				[49960] = true,
				[52466] = true,
				[56951] = true,
				[49522] = true,
				[56945] = true,
				[48883] = true,
				[57201] = true,
				[57841] = true,
				[49267] = true,
				[49395] = true,
				[49523] = true,
				[53746] = true,
				[39592] = true,
				[50803] = true,
				[42741] = true,
				[50163] = true,
				[47993] = true,
				[42229] = true,
				[58737] = true,
				[50675] = true,
				[31548] = true,
				[38646] = true,
				[42869] = true,
				[50937] = true,
				[47220] = true,
				[55538] = true,
				[51571] = true,
				[52075] = true,
				[55922] = true,
				[55799] = true,
				[47988] = true,
				[56306] = true,
				[56434] = true,
				[48372] = true,
				[48500] = true,
				[52158] = true,
				[52851] = true,
				[47653] = true,
				[57202] = true,
				[57330] = true,
				[49268] = true,
				[45301] = true,
				[53619] = true,
				[53747] = true,
				[37495] = true,
				[49908] = true,
				[50036] = true,
				[50164] = true,
				[39788] = true,
				[51192] = true,
				[42721] = true,
				[55031] = true,
				[58994] = true,
				[38647] = true,
				[47994] = true,
				[41462] = true,
				[47221] = true,
				[55539] = true,
				[51572] = true,
				[51700] = true,
				[56307] = true,
				[51956] = true,
				[47989] = true,
				[52212] = true,
				[49266] = true,
				[44278] = true,
				[52852] = true,
				[50168] = true,
				[56947] = true,
				[52980] = true,
				[57203] = true,
				[57331] = true,
				[45174] = true,
				[39594] = true,
				[49269] = true,
				[41463] = true,
				[37496] = true,
				[45414] = true,
				[50037] = true,
				[50165] = true,
				[38246] = true,
				[49528] = true,
				[52042] = true,
				[50677] = true,
				[31549] = true,
				[55028] = true,
				[46245] = true,
				[47222] = true,
				[51317] = true,
				[42594] = true,
				[39800] = true,
				[43511] = true,
				[55924] = true,
				[56180] = true,
				[47990] = true,
				[56308] = true,
				[52208] = true,
				[52469] = true,
				[40568] = true,
				[56948] = true,
				[52853] = true,
				[49014] = true,
				[53109] = true,
				[50299] = true,
				[45175] = true,
				[49398] = true,
				[53621] = true,
				[41464] = true,
				[37497] = true,
				[46843] = true,
				[51959] = true,
				[54261] = true,
				[42104] = true,
				[41099] = true,
				[55153] = true,
				[55032] = true,
				[47203] = true,
				[46839] = true,
				[42872] = true,
				[51190] = true,
				[47223] = true,
				[47224] = true,
				[51958] = true,
				[51063] = true,
				[46840] = true,
				[56053] = true,
				[56181] = true,
				[56309] = true,
				[55414] = true,
				[47991] = true,
				[56165] = true,
				[56949] = true,
				[52854] = true,
				[49143] = true,
				[53110] = true,
				[57333] = true,
				[53750] = true,
				[49399] = true,
				[53622] = true,
				[57845] = true,
				[44920] = true,
				[53749] = true,
				[54134] = true,
				[54262] = true,
				[49015] = true,
				[54518] = true,
				[56057] = true,
				[50679] = true,
				[38377] = true,
				[55030] = true,
				[38778] = true,
				[51191] = true,
				[51319] = true,
				[44071] = true,
				[55670] = true,
				[44663] = true,
				[55926] = true,
				[11970] = true,
				[47992] = true,
				[53877] = true,
				[44153] = true,
				[38691] = true,
				[48504] = true,
				[38052] = true,
				[43900] = true,
				[49312] = true,
				[53111] = true,
				[57334] = true,
				[51309] = true,
				[49400] = true,
				[53623] = true,
				[53751] = true,
				[53748] = true,
				[39972] = true,
				[50040] = true,
				[54263] = true,
				[40567] = true,
				[54519] = true,
				[54647] = true,
				[51444] = true,
				[49066] = true,
				[46841] = true,
				[41708] = true,
				[38907] = true,
				[51320] = true,
				[49975] = true,
				[55671] = true,
				[39419] = true,
				[41760] = true,
				[56055] = true,
				[39803] = true,
				[56311] = true,
				[47967] = true,
				[52472] = true,
				[48505] = true,
				[42079] = true,
				[48761] = true,
				[56561] = true,
				[44922] = true,
				[57335] = true,
				[55793] = true,
				[49401] = true,
				[53624] = true,
				[41467] = true,
				[52788] = true,
				[55920] = true,
				[50041] = true,
				[43942] = true,
				[39796] = true,
				[58615] = true,
				[50553] = true,
				[50929] = true,
				[56813] = true,
				[42747] = true,
				[38780] = true,
				[51193] = true,
				[42739] = true,
				[55544] = true,
				[55672] = true,
				[51568] = true,
				[55928] = true,
				[56056] = true,
				[39804] = true,
				[39027] = true,
				[41475] = true,
				[52473] = true,
				[48506] = true,
				[52149] = true,
				[52654] = true,
				[52203] = true,
				[53155] = true,
				[57336] = true,
				[49274] = true,
				[49402] = true,
				[49530] = true,
				[53753] = true,
				[46832] = true,
				[41724] = true,
				[39591] = true,
				[54265] = true,
				[48348] = true,
				[52795] = true,
				[50554] = true,
				[42593] = true,
				[50810] = true,
				[50938] = true,
				[47134] = true,
				[38909] = true,
				[40817] = true,
				[55545] = true,
				[56301] = true,
				[55801] = true,
				[55929] = true,
				[47867] = true,
				[56185] = true,
				[56313] = true,
				[39588] = true,
				[39595] = true,
				[48507] = true,
				[51949] = true,
				[40573] = true,
				[57081] = true,
				[44924] = true,
				[47889] = true,
				[53370] = true,
				[49403] = true,
				[49531] = true,
				[41469] = true,
				[49787] = true,
				[53916] = true,
				[54138] = true,
				[54266] = true,
				[54394] = true,
				[38142] = true,
				[48026] = true,
				[55087] = true,
				[31552] = true,
				[42749] = true,
				[38782] = true,
				[38910] = true,
				[47228] = true,
				[55546] = true,
				[39663] = true,
				[51707] = true,
				[51835] = true,
				[56058] = true,
				[43901] = true,
				[52219] = true,
				[38916] = true,
				[52475] = true,
				[48508] = true,
				[53073] = true,
				[52859] = true,
				[55786] = true,
				[44925] = true,
				[57338] = true,
				[49276] = true,
				[49404] = true,
				[39772] = true,
				[53755] = true,
				[50705] = true,
				[31591] = true,
				[50044] = true,
				[50172] = true,
				[38015] = true,
				[38143] = true,
				[39277] = true,
				[39149] = true,
				[46717] = true,
				[46845] = true,
				[55529] = true,
				[38911] = true,
				[39661] = true,
				[55547] = true,
				[47485] = true,
				[54203] = true,
				[55931] = true,
				[51964] = true,
				[56187] = true,
				[56315] = true,
				[50281] = true,
				[56571] = true,
				[31015] = true,
				[44382] = true,
				[52860] = true,
				[56935] = true,
				[39862] = true,
				[51142] = true,
				[53372] = true,
				[41215] = true,
				[52862] = true,
				[44381] = true,
				[54205] = true,
				[50622] = true,
				[31568] = true,
				[50173] = true,
				[46206] = true,
				[54524] = true,
				[42367] = true,
				[39262] = true,
				[31553] = true,
				[38656] = true,
				[51069] = true,
				[38912] = true,
				[56422] = true,
				[55548] = true,
				[47486] = true,
				[53583] = true,
				[55932] = true,
				[51965] = true,
				[47998] = true,
				[38414] = true,
				[53990] = true,
				[56572] = true,
				[54058] = true,
				[55070] = true,
				[56956] = true,
				[57084] = true,
				[53117] = true,
				[57340] = true,
				[53373] = true,
				[50698] = true,
				[39991] = true,
				[56790] = true,
				[50692] = true,
				[50534] = true,
				[54141] = true,
				[50174] = true,
				[54441] = true,
				[38145] = true,
				[42368] = true,
				[50686] = true,
				[38529] = true,
				[42752] = true,
				[54088] = true,
				[38913] = true,
				[54705] = true,
				[51454] = true,
				[51582] = true,
				[51710] = true,
				[55933] = true,
				[53815] = true,
				[56189] = true,
				[54418] = true,
				[53167] = true,
				[56573] = true,
				[55955] = true,
				[54433] = true,
				[48767] = true,
				[55061] = true,
				[31583] = true,
				[51278] = true,
				[55777] = true,
				[49407] = true,
				[41149] = true,
				[41473] = true,
				[49791] = true,
				[50637] = true,
				[50047] = true,
				[50175] = true,
				[48356] = true,
				[38146] = true,
				[42369] = true,
				[51402] = true,
				[50531] = true,
				[42753] = true,
				[53602] = true,
				[47104] = true,
				[55599] = true,
				[55550] = true,
				[51583] = true,
				[39426] = true,
				[51839] = true,
				[39682] = true,
				[56190] = true,
				[52194] = true,
				[44161] = true,
				[55072] = true,
				[50898] = true,
				[56830] = true,
				[48768] = true,
				[57086] = true,
				[53119] = true,
				[55861] = true,
				[56032] = true,
				[55904] = true,
				[53631] = true,
				[41474] = true,
				[49792] = true,
				[56243] = true,
				[54143] = true,
				[55753] = true,
				[56215] = true,
				[38147] = true,
				[42370] = true,
				[50688] = true,
				[56632] = true,
				[42754] = true,
				[39992] = true,
				[38915] = true,
				[39043] = true,
				[46268] = true,
				[51584] = true,
				[51712] = true,
				[55935] = true,
				[51968] = true,
				[55775] = true,
				[56319] = true,
				[52352] = true,
				[52480] = true,
				[48513] = true,
				[57006] = true,
				[39684] = true,
				[52992] = true,
				[53120] = true,
				[40008] = true,
				[56240] = true,
				[49409] = true,
				[42131] = true,
				[53760] = true,
				[53888] = true,
				[49921] = true,
				[54144] = true,
				[54272] = true,
				[54400] = true,
				[45385] = true,
				[42371] = true,
				[44463] = true,
				[55947] = true,
				[55040] = true,
				[42883] = true,
				[51201] = true,
				[56136] = true,
				[55552] = true,
				[51585] = true,
				[46815] = true,
				[55936] = true,
				[51969] = true,
				[41033] = true,
				[56320] = true,
				[56611] = true,
				[46247] = true,
				[42116] = true,
				[52737] = true,
				[48770] = true,
				[48898] = true,
				[57135] = true,
				[56609] = true,
				[49282] = true,
				[41220] = true,
				[38624] = true,
				[53761] = true,
				[49794] = true,
				[44606] = true,
				[55103] = true,
				[39735] = true,
				[50306] = true,
				[42244] = true,
				[50562] = true,
				[38405] = true,
				[55945] = true,
				[42756] = true,
				[42884] = true,
				[47107] = true,
				[55425] = true,
				[55553] = true,
				[51586] = true,
				[39429] = true,
				[55937] = true,
				[39685] = true,
				[48003] = true,
				[56321] = true,
				[56994] = true,
				[48077] = true,
				[56355] = true,
				[39694] = true,
				[56961] = true,
				[52994] = true,
				[57217] = true,
				[55701] = true,
				[56597] = true,
				[41221] = true,
				[55073] = true,
				[53762] = true,
				[37510] = true,
				[49923] = true,
				[56643] = true,
				[41989] = true,
				[42117] = true,
				[38058] = true,
				[56996] = true,
				[50691] = true,
				[31556] = true,
				[38662] = true,
				[51075] = true,
				[51203] = true,
				[55426] = true,
				[55554] = true,
				[56361] = true,
				[51715] = true,
				[51843] = true,
				[51971] = true,
				[48004] = true,
				[56536] = true,
				[39516] = true,
				[54315] = true,
				[48516] = true,
				[43446] = true,
				[56962] = true,
				[37468] = true,
				[49028] = true,
				[44879] = true,
				[49284] = true,
				[49412] = true,
				[53635] = true,
				[41478] = true,
				[54187] = true,
				[44106] = true,
				[56844] = true,
				[56523] = true,
				[50308] = true,
				[43857] = true,
				[39495] = true,
				[54787] = true,
				[46725] = true,
				[38663] = true,
				[55171] = true,
				[51204] = true,
				[39047] = true,
				[55555] = true,
				[56629] = true,
				[56756] = true,
				[51844] = true,
				[55982] = true,
				[48005] = true,
				[53462] = true,
				[49239] = true,
				[46802] = true,
				[48517] = true,
				[56751] = true,
				[56963] = true,
				[37518] = true,
				[53124] = true,
				[50604] = true,
				[49285] = true,
				[42679] = true,
				[37256] = true,
				[41479] = true,
				[39089] = true,
				[57300] = true,
				[41863] = true,
				[51366] = true,
				[54404] = true,
				[51017] = true,
				[42375] = true,
				[50693] = true,
				[50960] = true,
				[55044] = true,
				[55976] = true,
				[51205] = true,
				[47238] = true,
				[55556] = true,
				[55684] = true,
				[51021] = true,
				[51845] = true,
				[39688] = true,
				[38743] = true,
				[50516] = true,
				[54457] = true,
				[51120] = true,
				[48518] = true,
				[51909] = true,
				[56964] = true,
				[48902] = true,
				[57220] = true,
				[54471] = true,
				[49286] = true,
				[38582] = true,
				[37257] = true,
				[41480] = true,
				[55761] = true,
				[49926] = true,
				[55820] = true,
				[53714] = true,
				[40401] = true,
				[50438] = true,
				[42376] = true,
				[50694] = true,
				[46727] = true,
				[55045] = true,
				[56760] = true,
				[55712] = true,
				[39049] = true,
				[51922] = true,
				[54451] = true,
				[55813] = true,
				[55941] = true,
				[39689] = true,
				[51637] = true,
				[56325] = true,
				[51882] = true,
				[44296] = true,
				[48519] = true,
				[49996] = true,
				[56965] = true,
				[48903] = true,
				[57221] = true,
				[52495] = true,
				[49287] = true,
				[55755] = true,
				[55206] = true,
				[55584] = true,
				[52367] = true,
				[56981] = true,
				[52044] = true,
				[55732] = true,
				[50311] = true,
				[55696] = true,
				[54662] = true,
				[38410] = true,
				[46728] = true,
				[59141] = true,
				[52014] = true,
				[51207] = true,
				[51335] = true,
				[55558] = true,
				[55686] = true,
				[55814] = true,
				[55942] = true,
				[39690] = true,
				[48008] = true,
				[56326] = true,
				[54407] = true,
				[56582] = true,
				[48520] = true,
				[50461] = true,
				[56966] = true,
				[52999] = true,
				[49032] = true,
				[52290] = true,
				[49288] = true,
				[41226] = true,
				[56727] = true,
				[52891] = true,
				[51759] = true,
				[51628] = true,
				[50056] = true,
				[40229] = true,
				[58502] = true,
				[56103] = true,
				[51623] = true,
				[50696] = true,
				[42634] = true,
				[58284] = true,
				[55175] = true,
				[51208] = true,
				[39051] = true,
				[56587] = true,
				[56353] = true,
				[51720] = true,
				[55943] = true,
				[39691] = true,
				[48009] = true,
				[56327] = true,
				[51905] = true,
				[56583] = true,
				[48521] = true,
				[56376] = true,
				[52872] = true,
				[53000] = true,
				[57223] = true,
				[49161] = true,
				[53384] = true,
				[49417] = true,
				[56771] = true,
				[53768] = true,
				[53896] = true,
				[49929] = true,
				[50057] = true,
				[45507] = true,
				[45856] = true,
				[58631] = true,
				[48439] = true,
				[38412] = true,
				[50825] = true,
				[50953] = true,
				[58291] = true,
				[51209] = true,
				[58286] = true,
				[55560] = true,
				[55688] = true,
				[55816] = true,
				[47754] = true,
				[47882] = true,
				[58640] = true,
				[56328] = true,
				[40076] = true,
				[52489] = true,
				[48522] = true,
				[44555] = true,
				[56968] = true,
				[58896] = true,
				[58895] = true,
			},
			["events_completed"] = {
			},
			["scannerYPos"] = 478.7450866699219,
		},
		["국제금융로 - 굴단"] = {
			["scannerXPos"] = 1747.844116210938,
			["containers_opened"] = {
				[326418] = -1,
				[278694] = -1,
				[287320] = -1,
				[279609] = -1,
				[326404] = -1,
				[297892] = -1,
				[303170] = -1,
				[297893] = -1,
				[316780] = -1,
				[326406] = -1,
				[294174] = -1,
				[297825] = -1,
				[282721] = -1,
				[326407] = -1,
				[278436] = -1,
				[326410] = -1,
				[278793] = -1,
				[281646] = -1,
				[297891] = -1,
				[279373] = -1,
				[279042] = -1,
				[326409] = -1,
			},
			["events_completed"] = {
				[137183] = -1,
				[327554] = 1579733999,
			},
			["quests_completed"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				true, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				nil, -- [15]
				nil, -- [16]
				nil, -- [17]
				nil, -- [18]
				true, -- [19]
				true, -- [20]
				nil, -- [21]
				true, -- [22]
				nil, -- [23]
				nil, -- [24]
				nil, -- [25]
				nil, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				nil, -- [31]
				nil, -- [32]
				nil, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				nil, -- [41]
				nil, -- [42]
				nil, -- [43]
				nil, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				nil, -- [48]
				nil, -- [49]
				nil, -- [50]
				nil, -- [51]
				true, -- [52]
				nil, -- [53]
				nil, -- [54]
				true, -- [55]
				true, -- [56]
				true, -- [57]
				true, -- [58]
				true, -- [59]
				true, -- [60]
				true, -- [61]
				true, -- [62]
				nil, -- [63]
				true, -- [64]
				true, -- [65]
				true, -- [66]
				true, -- [67]
				true, -- [68]
				true, -- [69]
				true, -- [70]
				true, -- [71]
				true, -- [72]
				nil, -- [73]
				true, -- [74]
				nil, -- [75]
				true, -- [76]
				nil, -- [77]
				true, -- [78]
				true, -- [79]
				true, -- [80]
				nil, -- [81]
				true, -- [82]
				true, -- [83]
				true, -- [84]
				true, -- [85]
				true, -- [86]
				nil, -- [87]
				true, -- [88]
				true, -- [89]
				true, -- [90]
				true, -- [91]
				true, -- [92]
				true, -- [93]
				nil, -- [94]
				true, -- [95]
				nil, -- [96]
				true, -- [97]
				true, -- [98]
				nil, -- [99]
				nil, -- [100]
				true, -- [101]
				true, -- [102]
				nil, -- [103]
				nil, -- [104]
				nil, -- [105]
				true, -- [106]
				true, -- [107]
				nil, -- [108]
				true, -- [109]
				true, -- [110]
				true, -- [111]
				true, -- [112]
				true, -- [113]
				true, -- [114]
				true, -- [115]
				nil, -- [116]
				nil, -- [117]
				true, -- [118]
				true, -- [119]
				true, -- [120]
				true, -- [121]
				true, -- [122]
				nil, -- [123]
				true, -- [124]
				true, -- [125]
				true, -- [126]
				true, -- [127]
				true, -- [128]
				true, -- [129]
				true, -- [130]
				true, -- [131]
				true, -- [132]
				true, -- [133]
				true, -- [134]
				true, -- [135]
				nil, -- [136]
				nil, -- [137]
				nil, -- [138]
				nil, -- [139]
				nil, -- [140]
				true, -- [141]
				true, -- [142]
				true, -- [143]
				true, -- [144]
				true, -- [145]
				true, -- [146]
				nil, -- [147]
				true, -- [148]
				true, -- [149]
				true, -- [150]
				true, -- [151]
				nil, -- [152]
				true, -- [153]
				true, -- [154]
				true, -- [155]
				true, -- [156]
				true, -- [157]
				true, -- [158]
				true, -- [159]
				true, -- [160]
				nil, -- [161]
				true, -- [162]
				true, -- [163]
				true, -- [164]
				true, -- [165]
				true, -- [166]
				true, -- [167]
				true, -- [168]
				true, -- [169]
				nil, -- [170]
				nil, -- [171]
				nil, -- [172]
				true, -- [173]
				true, -- [174]
				true, -- [175]
				true, -- [176]
				true, -- [177]
				true, -- [178]
				nil, -- [179]
				true, -- [180]
				true, -- [181]
				nil, -- [182]
				nil, -- [183]
				nil, -- [184]
				nil, -- [185]
				nil, -- [186]
				nil, -- [187]
				nil, -- [188]
				nil, -- [189]
				nil, -- [190]
				nil, -- [191]
				nil, -- [192]
				nil, -- [193]
				nil, -- [194]
				nil, -- [195]
				nil, -- [196]
				nil, -- [197]
				nil, -- [198]
				nil, -- [199]
				nil, -- [200]
				nil, -- [201]
				nil, -- [202]
				true, -- [203]
				true, -- [204]
				nil, -- [205]
				nil, -- [206]
				nil, -- [207]
				nil, -- [208]
				nil, -- [209]
				nil, -- [210]
				nil, -- [211]
				nil, -- [212]
				nil, -- [213]
				true, -- [214]
				nil, -- [215]
				nil, -- [216]
				nil, -- [217]
				nil, -- [218]
				true, -- [219]
				nil, -- [220]
				true, -- [221]
				true, -- [222]
				true, -- [223]
				nil, -- [224]
				true, -- [225]
				nil, -- [226]
				true, -- [227]
				true, -- [228]
				true, -- [229]
				true, -- [230]
				true, -- [231]
				nil, -- [232]
				nil, -- [233]
				nil, -- [234]
				nil, -- [235]
				nil, -- [236]
				nil, -- [237]
				nil, -- [238]
				true, -- [239]
				true, -- [240]
				nil, -- [241]
				nil, -- [242]
				nil, -- [243]
				true, -- [244]
				nil, -- [245]
				true, -- [246]
				nil, -- [247]
				nil, -- [248]
				nil, -- [249]
				nil, -- [250]
				true, -- [251]
				true, -- [252]
				true, -- [253]
				nil, -- [254]
				nil, -- [255]
				true, -- [256]
				[10279] = true,
				[33038] = true,
				[50058] = true,
				[54281] = true,
				[50442] = true,
				[54665] = true,
				[34446] = true,
				[29576] = true,
				[42892] = true,
				[34958] = true,
				[39181] = true,
				[10887] = true,
				[55945] = true,
				[56329] = true,
				[52490] = true,
				[11175] = true,
				[11207] = true,
				[53386] = true,
				[33039] = true,
				[11495] = true,
				[11527] = true,
				[11559] = true,
				[11623] = true,
				[50699] = true,
				[34575] = true,
				[51083] = true,
				[31752] = true,
				[51467] = true,
				[11879] = true,
				[11911] = true,
				[11943] = true,
				[47884] = true,
				[12007] = true,
				[56330] = true,
				[35983] = true,
				[52491] = true,
				[12167] = true,
				[12199] = true,
				[12231] = true,
				[53131] = true,
				[12295] = true,
				[12327] = true,
				[33168] = true,
				[12423] = true,
				[12455] = true,
				[525] = true,
				[8424] = true,
				[12551] = true,
				[58506] = true,
				[54539] = true,
				[34192] = true,
				[50700] = true,
				[46733] = true,
				[25546] = true,
				[12871] = true,
				[12903] = true,
				[12935] = true,
				[12967] = true,
				[12999] = true,
				[559] = true,
				[13063] = true,
				[563] = true,
				[565] = true,
				[13159] = true,
				[36624] = true,
				[13415] = true,
				[53772] = true,
				[587] = true,
				[9512] = true,
				[597] = true,
				[34193] = true,
				[13703] = true,
				[13735] = true,
				[607] = true,
				[609] = true,
				[51341] = true,
				[9800] = true,
				[617] = true,
				[9896] = true,
				[9928] = true,
				[623] = true,
				[9992] = true,
				[52493] = true,
				[10088] = true,
				[10120] = true,
				[52877] = true,
				[36881] = true,
				[41360] = true,
				[657] = true,
				[659] = true,
				[34194] = true,
				[25547] = true,
				[29898] = true,
				[681] = true,
				[685] = true,
				[56333] = true,
				[2763] = true,
				[5541] = true,
				[695] = true,
				[697] = true,
				[40593] = true,
				[36626] = true,
				[11240] = true,
				[41105] = true,
				[33043] = true,
				[11464] = true,
				[2875] = true,
				[11560] = true,
				[2923] = true,
				[2939] = true,
				[11912] = true,
				[11944] = true,
				[56078] = true,
				[56334] = true,
				[52495] = true,
				[12168] = true,
				[52879] = true,
				[12328] = true,
				[49936] = true,
				[12520] = true,
				[38035] = true,
				[12648] = true,
				[58894] = true,
				[55055] = true,
				[51088] = true,
				[12872] = true,
				[12904] = true,
				[12936] = true,
				[12968] = true,
				[56207] = true,
				[13064] = true,
				[52496] = true,
				[56719] = true,
				[52880] = true,
				[53008] = true,
				[6661] = true,
				[9289] = true,
				[13416] = true,
				[9385] = true,
				[9417] = true,
				[33813] = true,
				[9513] = true,
				[9545] = true,
				[13672] = true,
				[13704] = true,
				[13736] = true,
				[38676] = true,
				[3451] = true,
				[9801] = true,
				[39316] = true,
				[39572] = true,
				[52241] = true,
				[10057] = true,
				[10121] = true,
				[36629] = true,
				[53265] = true,
				[37653] = true,
				[50322] = true,
				[25357] = true,
				[34582] = true,
				[55185] = true,
				[51218] = true,
				[25805] = true,
				[55825] = true,
				[3763] = true,
				[56209] = true,
				[40085] = true,
				[11145] = true,
				[11177] = true,
				[36630] = true,
				[11273] = true,
				[7733] = true,
				[57873] = true,
				[49811] = true,
				[11465] = true,
				[33815] = true,
				[11561] = true,
				[11625] = true,
				[11657] = true,
				[34583] = true,
				[47252] = true,
				[11913] = true,
				[56082] = true,
				[12009] = true,
				[12105] = true,
				[12137] = true,
				[12169] = true,
				[12201] = true,
				[12297] = true,
				[12329] = true,
				[49556] = true,
				[12425] = true,
				[12457] = true,
				[1050] = true,
				[12521] = true,
				[42134] = true,
				[12617] = true,
				[12681] = true,
				[12713] = true,
				[34584] = true,
				[12841] = true,
				[12873] = true,
				[12905] = true,
				[12937] = true,
				[12969] = true,
				[13001] = true,
				[56211] = true,
				[26190] = true,
				[56979] = true,
				[53268] = true,
				[13417] = true,
				[37528] = true,
				[37656] = true,
				[31309] = true,
				[13641] = true,
				[13737] = true,
				[34585] = true,
				[1218] = true,
				[1222] = true,
				[9802] = true,
				[55828] = true,
				[55956] = true,
				[1242] = true,
				[9962] = true,
				[1250] = true,
				[10026] = true,
				[10058] = true,
				[56724] = true,
				[1266] = true,
				[56980] = true,
				[1274] = true,
				[5142] = true,
				[14409] = true,
				[1302] = true,
				[10442] = true,
				[54421] = true,
				[34586] = true,
				[51350] = true,
				[55701] = true,
				[55957] = true,
				[52118] = true,
				[52246] = true,
				[44184] = true,
				[11146] = true,
				[56981] = true,
				[11210] = true,
				[11274] = true,
				[11434] = true,
				[11466] = true,
				[11530] = true,
				[11562] = true,
				[11626] = true,
				[11658] = true,
				[34587] = true,
				[51351] = true,
				[11882] = true,
				[11914] = true,
				[11946] = true,
				[12010] = true,
				[12042] = true,
				[12074] = true,
				[12138] = true,
				[12202] = true,
				[12298] = true,
				[12330] = true,
				[12522] = true,
				[42650] = true,
				[12874] = true,
				[12906] = true,
				[12938] = true,
				[12970] = true,
				[56087] = true,
				[39963] = true,
				[1638] = true,
				[6662] = true,
				[1678] = true,
				[9355] = true,
				[1690] = true,
				[50073] = true,
				[1702] = true,
				[1706] = true,
				[13706] = true,
				[13738] = true,
				[9739] = true,
				[9803] = true,
				[9835] = true,
				[9931] = true,
				[52121] = true,
				[56472] = true,
				[40220] = true,
				[10123] = true,
				[1782] = true,
				[49178] = true,
				[10443] = true,
				[54169] = true,
				[58776] = true,
				[34462] = true,
				[55065] = true,
				[51226] = true,
				[39197] = true,
				[29904] = true,
				[55833] = true,
				[35614] = true,
				[40221] = true,
				[56729] = true,
				[11147] = true,
				[44700] = true,
				[11211] = true,
				[11243] = true,
				[11467] = true,
				[50075] = true,
				[54298] = true,
				[11563] = true,
				[54554] = true,
				[58777] = true,
				[50715] = true,
				[31568] = true,
				[11723] = true,
				[27729] = true,
				[11915] = true,
				[12011] = true,
				[56346] = true,
				[12107] = true,
				[12171] = true,
				[12203] = true,
				[12235] = true,
				[12299] = true,
				[4135] = true,
				[12523] = true,
				[8460] = true,
				[50460] = true,
				[12683] = true,
				[34592] = true,
				[12843] = true,
				[12875] = true,
				[12907] = true,
				[12939] = true,
				[12971] = true,
				[43806] = true,
				[13035] = true,
				[52252] = true,
				[56475] = true,
				[49181] = true,
				[9356] = true,
				[37536] = true,
				[9420] = true,
				[9452] = true,
				[13643] = true,
				[54684] = true,
				[13739] = true,
				[9708] = true,
				[13835] = true,
				[9804] = true,
				[55708] = true,
				[55836] = true,
				[9900] = true,
				[9932] = true,
				[56220] = true,
				[52253] = true,
				[10028] = true,
				[10124] = true,
				[57244] = true,
				[10476] = true,
				[50846] = true,
				[51358] = true,
				[29906] = true,
				[55837] = true,
				[56221] = true,
				[56349] = true,
				[2764] = true,
				[2772] = true,
				[11180] = true,
				[11212] = true,
				[11244] = true,
				[11276] = true,
				[2844] = true,
				[11436] = true,
				[11468] = true,
				[2876] = true,
				[54302] = true,
				[11564] = true,
				[11692] = true,
				[5863] = true,
				[2940] = true,
				[11788] = true,
				[51359] = true,
				[51487] = true,
				[11884] = true,
				[51743] = true,
				[2988] = true,
				[51999] = true,
				[12012] = true,
				[56350] = true,
				[36131] = true,
				[12236] = true,
				[12300] = true,
				[8237] = true,
				[8365] = true,
				[12524] = true,
				[8461] = true,
				[12620] = true,
				[12652] = true,
				[50720] = true,
				[12844] = true,
				[12876] = true,
				[12908] = true,
				[12972] = true,
				[52000] = true,
				[13036] = true,
				[56351] = true,
				[36132] = true,
				[56735] = true,
				[9293] = true,
				[9453] = true,
				[38052] = true,
				[27348] = true,
				[13740] = true,
				[9709] = true,
				[9805] = true,
				[51617] = true,
				[9869] = true,
				[9901] = true,
				[9933] = true,
				[56352] = true,
				[10061] = true,
				[10093] = true,
				[10125] = true,
				[57248] = true,
				[33062] = true,
				[10349] = true,
				[38053] = true,
				[54945] = true,
				[51490] = true,
				[55713] = true,
				[52002] = true,
				[52258] = true,
				[48419] = true,
				[11181] = true,
				[11245] = true,
				[11277] = true,
				[37542] = true,
				[11469] = true,
				[7799] = true,
				[11565] = true,
				[11693] = true,
				[11725] = true,
				[11789] = true,
				[51363] = true,
				[51491] = true,
				[11949] = true,
				[11981] = true,
				[12013] = true,
				[52259] = true,
				[12109] = true,
				[12141] = true,
				[56994] = true,
				[12237] = true,
				[12269] = true,
				[12301] = true,
				[8366] = true,
				[12525] = true,
				[8462] = true,
				[12589] = true,
				[12621] = true,
				[50724] = true,
				[54947] = true,
				[34600] = true,
				[25558] = true,
				[12845] = true,
				[39207] = true,
				[35240] = true,
				[12973] = true,
				[13005] = true,
				[52260] = true,
				[48421] = true,
				[53028] = true,
				[57379] = true,
				[9294] = true,
				[9390] = true,
				[9454] = true,
				[54436] = true,
				[9582] = true,
				[31573] = true,
				[13837] = true,
				[31829] = true,
				[39208] = true,
				[35241] = true,
				[9870] = true,
				[9902] = true,
				[9934] = true,
				[52261] = true,
				[10062] = true,
				[56740] = true,
				[48806] = true,
				[5128] = true,
				[33066] = true,
				[10382] = true,
				[33834] = true,
				[38057] = true,
				[50726] = true,
				[54949] = true,
				[51366] = true,
				[39209] = true,
				[35242] = true,
				[51878] = true,
				[11182] = true,
				[11214] = true,
				[11246] = true,
				[11278] = true,
				[53414] = true,
				[11406] = true,
				[11470] = true,
				[54182] = true,
				[54310] = true,
				[38058] = true,
				[50599] = true,
				[38442] = true,
				[31574] = true,
				[11726] = true,
				[11790] = true,
				[34987] = true,
				[39210] = true,
				[43433] = true,
				[11918] = true,
				[11950] = true,
				[11982] = true,
				[12014] = true,
				[12142] = true,
				[12174] = true,
				[40618] = true,
				[57126] = true,
				[28631] = true,
				[12302] = true,
				[12462] = true,
				[12494] = true,
				[12526] = true,
				[12558] = true,
				[38059] = true,
				[12654] = true,
				[38443] = true,
				[12846] = true,
				[12878] = true,
				[12942] = true,
				[39595] = true,
				[52008] = true,
				[35884] = true,
				[53672] = true,
				[53800] = true,
				[9423] = true,
				[9455] = true,
				[54312] = true,
				[38060] = true,
				[13678] = true,
				[13838] = true,
				[51369] = true,
				[39212] = true,
				[9839] = true,
				[9871] = true,
				[56104] = true,
				[9967] = true,
				[9999] = true,
				[36141] = true,
				[10159] = true,
				[10255] = true,
				[33070] = true,
				[10351] = true,
				[10479] = true,
				[54441] = true,
				[34478] = true,
				[55081] = true,
				[51242] = true,
				[55465] = true,
				[55593] = true,
				[51626] = true,
				[10895] = true,
				[51882] = true,
				[56105] = true,
				[11183] = true,
				[11215] = true,
				[11247] = true,
				[11343] = true,
				[53674] = true,
				[11439] = true,
				[11471] = true,
				[7800] = true,
				[11567] = true,
				[11599] = true,
				[11663] = true,
				[31576] = true,
				[11727] = true,
				[55210] = true,
				[11791] = true,
				[39214] = true,
				[51627] = true,
				[11919] = true,
				[11951] = true,
				[43949] = true,
				[12143] = true,
				[12207] = true,
				[33072] = true,
				[53675] = true,
				[12463] = true,
				[12495] = true,
				[54187] = true,
				[12559] = true,
				[4265] = true,
				[4281] = true,
				[55339] = true,
				[12879] = true,
				[12943] = true,
				[12975] = true,
				[13007] = true,
				[43950] = true,
				[48557] = true,
				[53164] = true,
				[33073] = true,
				[53804] = true,
				[9424] = true,
				[9456] = true,
				[50349] = true,
				[13679] = true,
				[46766] = true,
				[50989] = true,
				[34737] = true,
				[13839] = true,
				[9776] = true,
				[9808] = true,
				[55724] = true,
				[51757] = true,
				[51885] = true,
				[9936] = true,
				[10160] = true,
				[53037] = true,
				[10288] = true,
				[2581] = true,
				[10352] = true,
				[2605] = true,
				[58156] = true,
				[58284] = true,
				[54317] = true,
				[2661] = true,
				[55341] = true,
				[55597] = true,
				[10896] = true,
				[52014] = true,
				[52142] = true,
				[2765] = true,
				[2773] = true,
				[2781] = true,
				[11184] = true,
				[40753] = true,
				[11248] = true,
				[2821] = true,
				[11344] = true,
				[53678] = true,
				[11440] = true,
				[2869] = true,
				[11504] = true,
				[54318] = true,
				[11568] = true,
				[11600] = true,
				[50863] = true,
				[11728] = true,
				[2941] = true,
				[11792] = true,
				[55598] = true,
				[55726] = true,
				[11920] = true,
				[2989] = true,
				[11984] = true,
				[12016] = true,
				[56494] = true,
				[12144] = true,
				[57006] = true,
				[12272] = true,
				[53295] = true,
				[33076] = true,
				[12464] = true,
				[12528] = true,
				[12560] = true,
				[12592] = true,
				[12624] = true,
				[54703] = true,
				[12688] = true,
				[55087] = true,
				[25564] = true,
				[12880] = true,
				[12912] = true,
				[12976] = true,
				[13008] = true,
				[13040] = true,
				[36404] = true,
				[33077] = true,
				[9361] = true,
				[53936] = true,
				[6761] = true,
				[54192] = true,
				[13680] = true,
				[31579] = true,
				[3445] = true,
				[34741] = true,
				[9777] = true,
				[55600] = true,
				[35253] = true,
				[9873] = true,
				[3501] = true,
				[9937] = true,
				[14064] = true,
				[10001] = true,
				[10033] = true,
				[56624] = true,
				[10129] = true,
				[10161] = true,
				[53041] = true,
				[54193] = true,
				[7321] = true,
				[3701] = true,
				[38837] = true,
				[51506] = true,
				[3741] = true,
				[51890] = true,
				[56113] = true,
				[52146] = true,
				[3789] = true,
				[56881] = true,
				[11185] = true,
				[11217] = true,
				[11249] = true,
				[33079] = true,
				[49715] = true,
				[11473] = true,
				[54194] = true,
				[58417] = true,
				[11569] = true,
				[11601] = true,
				[31580] = true,
				[11729] = true,
				[11793] = true,
				[55602] = true,
				[11889] = true,
				[51891] = true,
				[11985] = true,
				[12017] = true,
				[56370] = true,
				[12081] = true,
				[56626] = true,
				[12145] = true,
				[56882] = true,
				[57010] = true,
				[12241] = true,
				[53171] = true,
				[12305] = true,
				[33080] = true,
				[49716] = true,
				[1047] = true,
				[12497] = true,
				[12529] = true,
				[12561] = true,
				[46261] = true,
				[4266] = true,
				[34616] = true,
				[29725] = true,
				[51380] = true,
				[43446] = true,
				[39607] = true,
				[39735] = true,
				[56243] = true,
				[56627] = true,
				[52788] = true,
				[57139] = true,
				[36920] = true,
				[33081] = true,
				[53812] = true,
				[9426] = true,
				[54196] = true,
				[9490] = true,
				[13713] = true,
				[1219] = true,
				[9810] = true,
				[55732] = true,
				[9874] = true,
				[51893] = true,
				[9938] = true,
				[9970] = true,
				[10034] = true,
				[1259] = true,
				[1267] = true,
				[5082] = true,
				[57524] = true,
				[10354] = true,
				[10386] = true,
				[10482] = true,
				[54325] = true,
				[1319] = true,
				[54965] = true,
				[29726] = true,
				[51638] = true,
				[1363] = true,
				[56245] = true,
				[56373] = true,
				[56629] = true,
				[1395] = true,
				[11186] = true,
				[11218] = true,
				[11250] = true,
				[53814] = true,
				[11474] = true,
				[54198] = true,
				[1447] = true,
				[54710] = true,
				[31582] = true,
				[11730] = true,
				[38842] = true,
				[11794] = true,
				[55734] = true,
				[11922] = true,
				[11986] = true,
				[56246] = true,
				[56374] = true,
				[12082] = true,
				[12114] = true,
				[12146] = true,
				[12210] = true,
				[12242] = true,
				[49720] = true,
				[12466] = true,
				[12498] = true,
				[12530] = true,
				[12658] = true,
				[34364] = true,
				[55095] = true,
				[34876] = true,
				[12882] = true,
				[12914] = true,
				[12978] = true,
				[13010] = true,
				[13042] = true,
				[56375] = true,
				[13106] = true,
				[56887] = true,
				[44730] = true,
				[1667] = true,
				[49465] = true,
				[1683] = true,
				[6762] = true,
				[54200] = true,
				[1699] = true,
				[9523] = true,
				[1707] = true,
				[13714] = true,
				[31583] = true,
				[55096] = true,
				[51129] = true,
				[9747] = true,
				[35005] = true,
				[55608] = true,
				[55736] = true,
				[51897] = true,
				[9939] = true,
				[56248] = true,
				[52281] = true,
				[56504] = true,
				[56632] = true,
				[10099] = true,
				[10163] = true,
				[36797] = true,
				[57528] = true,
				[10355] = true,
				[14482] = true,
				[37565] = true,
				[10483] = true,
				[54969] = true,
				[34622] = true,
				[43196] = true,
				[29920] = true,
				[52026] = true,
				[52154] = true,
				[52282] = true,
				[56633] = true,
				[11123] = true,
				[11155] = true,
				[11187] = true,
				[57145] = true,
				[53306] = true,
				[53434] = true,
				[49467] = true,
				[53818] = true,
				[37566] = true,
				[11475] = true,
				[11507] = true,
				[11571] = true,
				[38206] = true,
				[11699] = true,
				[11731] = true,
				[11795] = true,
				[55610] = true,
				[11891] = true,
				[11923] = true,
				[39614] = true,
				[43837] = true,
				[56378] = true,
				[12083] = true,
				[12147] = true,
				[36799] = true,
				[12307] = true,
				[53435] = true,
				[49468] = true,
				[53819] = true,
				[12467] = true,
				[12499] = true,
				[12531] = true,
				[12595] = true,
				[4267] = true,
				[34496] = true,
				[42814] = true,
				[12819] = true,
				[12851] = true,
				[12883] = true,
				[12915] = true,
				[39487] = true,
				[12979] = true,
				[13011] = true,
				[13043] = true,
				[52284] = true,
				[56635] = true,
				[56891] = true,
				[53436] = true,
				[49725] = true,
				[37824] = true,
				[13715] = true,
				[31585] = true,
				[42815] = true,
				[9716] = true,
				[9780] = true,
				[39488] = true,
				[55996] = true,
				[9940] = true,
				[9972] = true,
				[40000] = true,
				[56508] = true,
				[44351] = true,
				[10132] = true,
				[5083] = true,
				[10324] = true,
				[10356] = true,
				[2606] = true,
				[10484] = true,
				[54717] = true,
				[2662] = true,
				[55101] = true,
				[29922] = true,
				[39489] = true,
				[51902] = true,
				[52030] = true,
				[52158] = true,
				[2758] = true,
				[11124] = true,
				[11156] = true,
				[11188] = true,
				[11220] = true,
				[11252] = true,
				[11476] = true,
				[11508] = true,
				[58461] = true,
				[11572] = true,
				[11604] = true,
				[54718] = true,
				[58465] = true,
				[31586] = true,
				[58467] = true,
				[2942] = true,
				[11796] = true,
				[51391] = true,
				[31549] = true,
				[11892] = true,
				[39490] = true,
				[35523] = true,
				[11988] = true,
				[58167] = true,
				[52287] = true,
				[3022] = true,
				[12116] = true,
				[12148] = true,
				[12180] = true,
				[12212] = true,
				[1666] = true,
				[12276] = true,
				[12308] = true,
				[53439] = true,
				[37187] = true,
				[48778] = true,
				[51989] = true,
				[53951] = true,
				[55721] = true,
				[12532] = true,
				[10055] = true,
				[58285] = true,
				[56328] = true,
				[12660] = true,
				[11886] = true,
				[54975] = true,
				[58634] = true,
				[55944] = true,
				[12820] = true,
				[44701] = true,
				[12884] = true,
				[12916] = true,
				[39491] = true,
				[12980] = true,
				[52032] = true,
				[13044] = true,
				[52288] = true,
				[13108] = true,
				[52544] = true,
				[13807] = true,
				[40515] = true,
				[51465] = true,
				[56348] = true,
				[55997] = true,
				[53312] = true,
				[51637] = true,
				[55691] = true,
				[13734] = true,
				[37444] = true,
				[56234] = true,
				[13524] = true,
				[37828] = true,
				[56084] = true,
				[9543] = true,
				[56118] = true,
				[58815] = true,
				[13716] = true,
				[55350] = true,
				[56121] = true,
				[57373] = true,
				[53896] = true,
				[9781] = true,
				[9351] = true,
				[55986] = true,
				[49453] = true,
				[7003] = true,
				[9973] = true,
				[56256] = true,
				[52289] = true,
				[693] = true,
				[56640] = true,
				[44483] = true,
				[52125] = true,
				[57280] = true,
				[49218] = true,
				[53185] = true,
				[53313] = true,
				[53441] = true,
				[56377] = true,
				[49602] = true,
				[37445] = true,
				[10485] = true,
				[29092] = true,
				[50114] = true,
				[55982] = true,
				[56353] = true,
				[50498] = true,
				[55349] = true,
				[56895] = true,
				[42692] = true,
				[3702] = true,
				[34758] = true,
				[55361] = true,
				[51394] = true,
				[55720] = true,
				[52889] = true,
				[12690] = true,
				[12902] = true,
				[52034] = true,
				[56586] = true,
				[48195] = true,
				[3790] = true,
				[56641] = true,
				[44484] = true,
				[40517] = true,
				[56587] = true,
				[52290] = true,
				[53186] = true,
				[38795] = true,
				[53442] = true,
				[55861] = true,
				[46729] = true,
				[56126] = true,
				[8551] = true,
				[11477] = true,
				[11509] = true,
				[56982] = true,
				[54407] = true,
				[11605] = true,
				[11443] = true,
				[34375] = true,
				[42693] = true,
				[11733] = true,
				[51084] = true,
				[11797] = true,
				[51395] = true,
				[55618] = true,
				[51651] = true,
				[57354] = true,
				[11957] = true,
				[11989] = true,
				[52163] = true,
				[48196] = true,
				[55601] = true,
				[12117] = true,
				[12149] = true,
				[52031] = true,
				[12213] = true,
				[50576] = true,
				[12277] = true,
				[12309] = true,
				[4124] = true,
				[52291] = true,
				[53699] = true,
				[53816] = true,
				[262] = true,
				[12821] = true,
				[12533] = true,
				[265] = true,
				[266] = true,
				[12629] = true,
				[12661] = true,
				[269] = true,
				[270] = true,
				[284] = true,
				[12789] = true,
				[29733] = true,
				[12853] = true,
				[275] = true,
				[276] = true,
				[277] = true,
				[286] = true,
				[279] = true,
				[52871] = true,
				[281] = true,
				[13109] = true,
				[56643] = true,
				[56771] = true,
				[285] = true,
				[57027] = true,
				[287] = true,
				[288] = true,
				[289] = true,
				[290] = true,
				[291] = true,
				[292] = true,
				[293] = true,
				[294] = true,
				[9430] = true,
				[296] = true,
				[53316] = true,
				[1639] = true,
				[299] = true,
				[31589] = true,
				[13717] = true,
				[50885] = true,
				[39191] = true,
				[9718] = true,
				[305] = true,
				[306] = true,
				[55584] = true,
				[57028] = true,
				[39496] = true,
				[51909] = true,
				[53701] = true,
				[43975] = true,
				[313] = true,
				[10038] = true,
				[315] = true,
				[55942] = true,
				[10134] = true,
				[318] = true,
				[319] = true,
				[320] = true,
				[321] = true,
				[53445] = true,
				[323] = true,
				[324] = true,
				[325] = true,
				[53957] = true,
				[10454] = true,
				[5244] = true,
				[55814] = true,
				[51507] = true,
				[56103] = true,
				[51618] = true,
				[34378] = true,
				[52015] = true,
				[54433] = true,
				[38857] = true,
				[337] = true,
				[55830] = true,
				[54454] = true,
				[54559] = true,
				[54202] = true,
				[56493] = true,
				[343] = true,
				[344] = true,
				[345] = true,
				[51877] = true,
				[56970] = true,
				[11126] = true,
				[11158] = true,
				[11190] = true,
				[351] = true,
				[51639] = true,
				[353] = true,
				[53446] = true,
				[54206] = true,
				[55179] = true,
				[37450] = true,
				[31571] = true,
				[54086] = true,
				[11510] = true,
				[55955] = true,
				[50573] = true,
				[52891] = true,
				[350] = true,
				[11670] = true,
				[11702] = true,
				[52875] = true,
				[54163] = true,
				[11798] = true,
				[35019] = true,
				[11174] = true,
				[51655] = true,
				[373] = true,
				[11958] = true,
				[11990] = true,
				[56262] = true,
				[6028] = true,
				[12086] = true,
				[12118] = true,
				[12150] = true,
				[50352] = true,
				[29351] = true,
				[12246] = true,
				[36811] = true,
				[12310] = true,
				[386] = true,
				[387] = true,
				[388] = true,
				[37451] = true,
				[53959] = true,
				[391] = true,
				[12534] = true,
				[8471] = true,
				[394] = true,
				[58694] = true,
				[396] = true,
				[12694] = true,
				[56605] = true,
				[400] = true,
				[12790] = true,
				[12822] = true,
				[12854] = true,
				[12886] = true,
				[54188] = true,
				[35404] = true,
				[12982] = true,
				[52040] = true,
				[56263] = true,
				[49450] = true,
				[41359] = true,
				[50351] = true,
				[412] = true,
				[57142] = true,
				[54459] = true,
				[55821] = true,
				[51776] = true,
				[49225] = true,
				[57002] = true,
				[9303] = true,
				[53704] = true,
				[31591] = true,
				[9399] = true,
				[54088] = true,
				[9463] = true,
				[50249] = true,
				[51657] = true,
				[58695] = true,
				[46727] = true,
				[13718] = true,
				[46794] = true,
				[51017] = true,
				[34765] = true,
				[436] = true,
				[9783] = true,
				[9815] = true,
				[55752] = true,
				[9879] = true,
				[56008] = true,
				[52041] = true,
				[54171] = true,
				[50438] = true,
				[10039] = true,
				[53444] = true,
				[51761] = true,
				[12198] = true,
				[57032] = true,
				[55735] = true,
				[48842] = true,
				[49226] = true,
				[52147] = true,
				[54172] = true,
				[455] = true,
				[453] = true,
				[53961] = true,
				[54089] = true,
				[54041] = true,
				[52870] = true,
				[10551] = true,
				[29352] = true,
				[10214] = true,
				[52997] = true,
				[56964] = true,
				[463] = true,
				[464] = true,
				[465] = true,
				[466] = true,
				[55497] = true,
				[51658] = true,
				[10903] = true,
				[10935] = true,
				[471] = true,
				[472] = true,
				[26153] = true,
				[474] = true,
				[51613] = true,
				[56777] = true,
				[11159] = true,
				[11191] = true,
				[56606] = true,
				[11255] = true,
				[55182] = true,
				[53387] = true,
				[49483] = true,
				[484] = true,
				[33359] = true,
				[7804] = true,
				[11479] = true,
				[50123] = true,
				[50965] = true,
				[11575] = true,
				[11607] = true,
				[51749] = true,
				[11671] = true,
				[31592] = true,
				[54183] = true,
				[38862] = true,
				[11959] = true,
				[51403] = true,
				[55556] = true,
				[55754] = true,
				[11927] = true,
				[56010] = true,
				[11991] = true,
				[52171] = true,
				[12055] = true,
				[12279] = true,
				[12119] = true,
				[56778] = true,
				[12183] = true,
				[510] = true,
				[12247] = true,
				[57290] = true,
				[12311] = true,
				[4125] = true,
				[57674] = true,
				[13829] = true,
				[51077] = true,
				[56240] = true,
				[12503] = true,
				[12535] = true,
				[52001] = true,
				[12631] = true,
				[50508] = true,
				[536] = true,
				[38479] = true,
				[46797] = true,
				[48077] = true,
				[12791] = true,
				[12823] = true,
				[12855] = true,
				[12887] = true,
				[55755] = true,
				[29993] = true,
				[12983] = true,
				[52044] = true,
				[13047] = true,
				[4493] = true,
				[564] = true,
				[50853] = true,
				[56779] = true,
				[13207] = true,
				[58013] = true,
				[48973] = true,
				[576] = true,
				[49229] = true,
				[580] = true,
				[52762] = true,
				[562] = true,
				[54199] = true,
				[54315] = true,
				[54303] = true,
				[55066] = true,
				[53916] = true,
				[54203] = true,
				[4861] = true,
				[46798] = true,
				[608] = true,
				[604] = true,
				[606] = true,
				[9720] = true,
				[9752] = true,
				[35281] = true,
				[614] = true,
				[55756] = true,
				[55884] = true,
				[9912] = true,
				[53909] = true,
				[52173] = true,
				[52038] = true,
				[10040] = true,
				[56652] = true,
				[10104] = true,
				[48974] = true,
				[5085] = true,
				[53069] = true,
				[56506] = true,
				[49230] = true,
				[53275] = true,
				[54201] = true,
				[648] = true,
				[10392] = true,
				[40585] = true,
				[389] = true,
				[55811] = true,
				[10520] = true,
				[10552] = true,
				[51588] = true,
				[29866] = true,
				[2783] = true,
				[46799] = true,
				[55117] = true,
				[51150] = true,
				[29701] = true,
				[51406] = true,
				[35154] = true,
				[51662] = true,
				[682] = true,
				[10936] = true,
				[52046] = true,
				[11224] = true,
				[2759] = true,
				[56525] = true,
				[694] = true,
				[11128] = true,
				[11160] = true,
				[11192] = true,
				[53070] = true,
				[11288] = true,
				[49231] = true,
				[38331] = true,
				[54787] = true,
				[56136] = true,
				[57133] = true,
				[11448] = true,
				[11480] = true,
				[11512] = true,
				[12581] = true,
				[42193] = true,
				[11672] = true,
				[46800] = true,
				[50767] = true,
				[11704] = true,
				[55118] = true,
				[2943] = true,
				[51279] = true,
				[9848] = true,
				[11864] = true,
				[55758] = true,
				[11928] = true,
				[56014] = true,
				[47952] = true,
				[48080] = true,
				[57166] = true,
				[12088] = true,
				[12120] = true,
				[12152] = true,
				[12184] = true,
				[12216] = true,
				[12248] = true,
				[54197] = true,
				[12312] = true,
				[39864] = true,
				[53583] = true,
				[53711] = true,
				[54991] = true,
				[12472] = true,
				[51280] = true,
				[12536] = true,
				[55887] = true,
				[42194] = true,
				[29355] = true,
				[12664] = true,
				[12696] = true,
				[12728] = true,
				[55119] = true,
				[12792] = true,
				[12824] = true,
				[12856] = true,
				[56015] = true,
				[55759] = true,
				[29995] = true,
				[12984] = true,
				[56143] = true,
				[52432] = true,
				[56962] = true,
				[56527] = true,
				[50605] = true,
				[48593] = true,
				[56247] = true,
				[51896] = true,
				[57167] = true,
				[53652] = true,
				[49233] = true,
				[836] = true,
				[9305] = true,
				[53712] = true,
				[9369] = true,
				[53673] = true,
				[52790] = true,
				[51971] = true,
				[54417] = true,
				[9849] = true,
				[52049] = true,
				[56528] = true,
				[51331] = true,
				[54992] = true,
				[51025] = true,
				[55298] = true,
				[47186] = true,
				[9785] = true,
				[9817] = true,
				[55760] = true,
				[35413] = true,
				[9913] = true,
				[56144] = true,
				[9977] = true,
				[3527] = true,
				[10041] = true,
				[51911] = true,
				[36309] = true,
				[46802] = true,
				[57040] = true,
				[53073] = true,
				[34439] = true,
				[49234] = true,
				[11653] = true,
				[5066] = true,
				[54418] = true,
				[10393] = true,
				[7261] = true,
				[50356] = true,
				[53919] = true,
				[54609] = true,
				[10553] = true,
				[29356] = true,
				[34646] = true,
				[11429] = true,
				[29548] = true,
				[55121] = true,
				[51154] = true,
				[51282] = true,
				[34824] = true,
				[50601] = true,
				[55761] = true,
				[10937] = true,
				[51922] = true,
				[52050] = true,
				[51759] = true,
				[56401] = true,
				[56529] = true,
				[55619] = true,
				[53074] = true,
				[11161] = true,
				[11193] = true,
				[57169] = true,
				[52170] = true,
				[11289] = true,
				[56961] = true,
				[1691] = true,
				[53714] = true,
				[12556] = true,
				[52150] = true,
				[53771] = true,
				[7805] = true,
				[50259] = true,
				[54610] = true,
				[11609] = true,
				[56100] = true,
				[11673] = true,
				[52043] = true,
				[55890] = true,
				[992] = true,
				[51283] = true,
				[51411] = true,
				[11865] = true,
				[11897] = true,
				[51795] = true,
				[11961] = true,
				[11993] = true,
				[52789] = true,
				[12249] = true,
				[56530] = true,
				[12121] = true,
				[12153] = true,
				[12185] = true,
				[36567] = true,
				[57170] = true,
				[12281] = true,
				[50260] = true,
				[28781] = true,
				[33112] = true,
				[53715] = true,
				[12441] = true,
				[12473] = true,
				[54611] = true,
				[12537] = true,
				[12569] = true,
				[34822] = true,
				[29357] = true,
				[52003] = true,
				[34392] = true,
				[55851] = true,
				[51028] = true,
				[12793] = true,
				[47189] = true,
				[12857] = true,
				[51284] = true,
				[12921] = true,
				[55891] = true,
				[12985] = true,
				[51918] = true,
				[56630] = true,
				[52308] = true,
				[52947] = true,
				[1132] = true,
				[48597] = true,
				[42116] = true,
				[53706] = true,
				[48981] = true,
				[53307] = true,
				[53332] = true,
				[12953] = true,
				[33113] = true,
				[55363] = true,
				[53761] = true,
				[54035] = true,
				[49410] = true,
				[56261] = true,
				[13593] = true,
				[9530] = true,
				[50517] = true,
				[11209] = true,
				[1204] = true,
				[55495] = true,
				[52053] = true,
				[48770] = true,
				[1220] = true,
				[9786] = true,
				[9818] = true,
				[9850] = true,
				[9882] = true,
				[9914] = true,
				[1244] = true,
				[1248] = true,
				[52309] = true,
				[5054] = true,
				[10074] = true,
				[48598] = true,
				[57044] = true,
				[5086] = true,
				[57300] = true,
				[53205] = true,
				[1284] = true,
				[54574] = true,
				[33114] = true,
				[53717] = true,
				[10394] = true,
				[51876] = true,
				[50461] = true,
				[9925] = true,
				[1324] = true,
				[1320] = true,
				[58708] = true,
				[9799] = true,
				[55731] = true,
				[12217] = true,
				[11956] = true,
				[34778] = true,
				[13828] = true,
				[51073] = true,
				[55040] = true,
				[13732] = true,
				[55893] = true,
				[52310] = true,
				[56149] = true,
				[56277] = true,
				[44120] = true,
				[56533] = true,
				[56900] = true,
				[11154] = true,
				[11162] = true,
				[11194] = true,
				[53334] = true,
				[53206] = true,
				[11290] = true,
				[49367] = true,
				[33115] = true,
				[52035] = true,
				[37466] = true,
				[53974] = true,
				[51401] = true,
				[52172] = true,
				[48670] = true,
				[31342] = true,
				[11610] = true,
				[53760] = true,
				[54870] = true,
				[52055] = true,
				[51031] = true,
				[34779] = true,
				[12026] = true,
				[51415] = true,
				[11866] = true,
				[52311] = true,
				[55894] = true,
				[11962] = true,
				[56150] = true,
				[56278] = true,
				[12058] = true,
				[52439] = true,
				[52567] = true,
				[12154] = true,
				[1719] = true,
				[24432] = true,
				[12250] = true,
				[12282] = true,
				[34740] = true,
				[28783] = true,
				[41306] = true,
				[56000] = true,
				[12442] = true,
				[12474] = true,
				[50604] = true,
				[12538] = true,
				[12570] = true,
				[42202] = true,
				[12634] = true,
				[38363] = true,
				[50776] = true,
				[56244] = true,
				[51672] = true,
				[12794] = true,
				[12826] = true,
				[12858] = true,
				[51544] = true,
				[12922] = true,
				[12954] = true,
				[56023] = true,
				[47961] = true,
				[13050] = true,
				[56119] = true,
				[1640] = true,
				[13092] = true,
				[51969] = true,
				[52433] = true,
				[12996] = true,
				[12951] = true,
				[52867] = true,
				[51584] = true,
				[56476] = true,
				[39043] = true,
				[9418] = true,
				[56004] = true,
				[53976] = true,
				[9435] = true,
				[50137] = true,
				[31279] = true,
				[54488] = true,
				[9563] = true,
				[13690] = true,
				[56239] = true,
				[57004] = true,
				[51033] = true,
				[34781] = true,
				[50688] = true,
				[9787] = true,
				[9819] = true,
				[9851] = true,
				[47962] = true,
				[56024] = true,
				[56152] = true,
				[52866] = true,
				[35933] = true,
				[56536] = true,
				[52057] = true,
				[57097] = true,
				[28464] = true,
				[3130] = true,
				[57009] = true,
				[1792] = true,
				[41052] = true,
				[53887] = true,
				[54087] = true,
				[57726] = true,
				[10395] = true,
				[53977] = true,
				[53849] = true,
				[53960] = true,
				[51875] = true,
				[42204] = true,
				[393] = true,
				[51610] = true,
				[34398] = true,
				[29552] = true,
				[51034] = true,
				[34782] = true,
				[12196] = true,
				[51418] = true,
				[35166] = true,
				[12164] = true,
				[38407] = true,
				[56025] = true,
				[56241] = true,
				[53030] = true,
				[52047] = true,
				[56537] = true,
				[12004] = true,
				[51644] = true,
				[52036] = true,
				[51871] = true,
				[51583] = true,
				[54449] = true,
				[11291] = true,
				[54871] = true,
				[42694] = true,
				[31588] = true,
				[52042] = true,
				[53978] = true,
				[11483] = true,
				[34435] = true,
				[47181] = true,
				[55712] = true,
				[54618] = true,
				[54953] = true,
				[11176] = true,
				[11707] = true,
				[51035] = true,
				[34783] = true,
				[49232] = true,
				[55514] = true,
				[55898] = true,
				[54014] = true,
				[11931] = true,
				[11963] = true,
				[11995] = true,
				[12027] = true,
				[51489] = true,
				[52443] = true,
				[51889] = true,
				[56794] = true,
				[2040] = true,
				[12219] = true,
				[12251] = true,
				[48965] = true,
				[3362] = true,
				[4127] = true,
				[33120] = true,
				[12411] = true,
				[53979] = true,
				[12475] = true,
				[37193] = true,
				[12539] = true,
				[54363] = true,
				[12603] = true,
				[56892] = true,
				[48767] = true,
				[12699] = true,
				[29553] = true,
				[12763] = true,
				[12795] = true,
				[55387] = true,
				[12859] = true,
				[12891] = true,
				[35552] = true,
				[12955] = true,
				[12987] = true,
				[39775] = true,
				[13051] = true,
				[48070] = true,
				[56539] = true,
				[39323] = true,
				[51144] = true,
				[10254] = true,
				[2746] = true,
				[55729] = true,
				[10344] = true,
				[11208] = true,
				[29890] = true,
				[51454] = true,
				[53724] = true,
				[9372] = true,
				[2877] = true,
				[38913] = true,
				[51281] = true,
				[377] = true,
				[34434] = true,
				[50525] = true,
				[31577] = true,
				[13723] = true,
				[11511] = true,
				[5283] = true,
				[9724] = true,
				[49451] = true,
				[38036] = true,
				[9852] = true,
				[35297] = true,
				[55900] = true,
				[51389] = true,
				[56156] = true,
				[469] = true,
				[48575] = true,
				[56540] = true,
				[10076] = true,
				[48606] = true,
				[10140] = true,
				[5087] = true,
				[29547] = true,
				[49039] = true,
				[11701] = true,
				[5123] = true,
				[5055] = true,
				[44473] = true,
				[10396] = true,
				[51229] = true,
				[52946] = true,
				[54237] = true,
				[50270] = true,
				[42782] = true,
				[12695] = true,
				[11698] = true,
				[50782] = true,
				[55645] = true,
				[29618] = true,
				[34786] = true,
				[9956] = true,
				[29810] = true,
				[51550] = true,
				[9924] = true,
				[55901] = true,
				[560] = true,
				[2760] = true,
				[51581] = true,
				[52318] = true,
				[56541] = true,
				[56797] = true,
				[48607] = true,
				[11228] = true,
				[34817] = true,
				[36706] = true,
				[2768] = true,
				[55480] = true,
				[53470] = true,
				[11356] = true,
				[53726] = true,
				[11420] = true,
				[53784] = true,
				[11484] = true,
				[2880] = true,
				[50271] = true,
				[34019] = true,
				[11612] = true,
				[54324] = true,
				[4787] = true,
				[11708] = true,
				[51167] = true,
				[2944] = true,
				[55390] = true,
				[51935] = true,
				[11868] = true,
				[11900] = true,
				[11932] = true,
				[11964] = true,
				[47968] = true,
				[12028] = true,
				[56414] = true,
				[56542] = true,
				[12092] = true,
				[56798] = true,
				[49454] = true,
				[12220] = true,
				[36707] = true,
				[36311] = true,
				[12900] = true,
				[7803] = true,
				[56644] = true,
				[9514] = true,
				[53975] = true,
				[12476] = true,
				[38797] = true,
				[12540] = true,
				[50272] = true,
				[54495] = true,
				[51168] = true,
				[55775] = true,
				[38499] = true,
				[29555] = true,
				[29619] = true,
				[12796] = true,
				[12828] = true,
				[55519] = true,
				[51808] = true,
				[12924] = true,
				[12956] = true,
				[56031] = true,
				[47969] = true,
				[13052] = true,
				[13084] = true,
				[48608] = true,
				[4863] = true,
				[48609] = true,
				[52832] = true,
				[52027] = true,
				[36708] = true,
				[658] = true,
				[56315] = true,
				[51880] = true,
				[9309] = true,
				[49999] = true,
				[9373] = true,
				[33765] = true,
				[34789] = true,
				[9469] = true,
				[58463] = true,
				[47485] = true,
				[55547] = true,
				[38372] = true,
				[13724] = true,
				[55776] = true,
				[3448] = true,
				[51169] = true,
				[55392] = true,
				[9789] = true,
				[9821] = true,
				[9853] = true,
				[55904] = true,
				[9917] = true,
				[38911] = true,
				[3520] = true,
				[52321] = true,
				[47488] = true,
				[4101] = true,
				[10109] = true,
				[28468] = true,
				[10141] = true,
				[36709] = true,
				[30757] = true,
				[53857] = true,
				[12611] = true,
				[28852] = true,
				[12579] = true,
				[10397] = true,
				[29903] = true,
				[54113] = true,
				[9398] = true,
				[50274] = true,
				[49916] = true,
				[54537] = true,
				[8464] = true,
				[38501] = true,
				[29556] = true,
				[29620] = true,
				[34790] = true,
				[55393] = true,
				[55521] = true,
				[35174] = true,
				[55777] = true,
				[10909] = true,
				[51938] = true,
				[51170] = true,
				[52194] = true,
				[11603] = true,
				[52450] = true,
				[12465] = true,
				[48611] = true,
				[52834] = true,
				[57338] = true,
				[7791] = true,
				[54114] = true,
				[48764] = true,
				[11485] = true,
				[53602] = true,
				[39654] = true,
				[11421] = true,
				[53986] = true,
				[45924] = true,
				[7807] = true,
				[50275] = true,
				[54498] = true,
				[54626] = true,
				[11645] = true,
				[42597] = true,
				[52475] = true,
				[12093] = true,
				[34791] = true,
				[55394] = true,
				[52219] = true,
				[11869] = true,
				[11901] = true,
				[55906] = true,
				[11965] = true,
				[56162] = true,
				[12029] = true,
				[43901] = true,
				[52451] = true,
				[36199] = true,
				[48612] = true,
				[29353] = true,
				[11613] = true,
				[12253] = true,
				[12285] = true,
				[51396] = true,
				[9878] = true,
				[28853] = true,
				[11133] = true,
				[54627] = true,
				[12477] = true,
				[33640] = true,
				[50148] = true,
				[50276] = true,
				[34024] = true,
				[12637] = true,
				[12669] = true,
				[42598] = true,
				[55395] = true,
				[30069] = true,
				[12797] = true,
				[12829] = true,
				[12861] = true,
				[35176] = true,
				[12925] = true,
				[12957] = true,
				[12989] = true,
				[4512] = true,
				[13053] = true,
				[13085] = true,
				[40167] = true,
				[31552] = true,
				[9806] = true,
				[54650] = true,
				[31360] = true,
				[34784] = true,
				[34787] = true,
				[11491] = true,
				[53476] = true,
				[52874] = true,
				[54500] = true,
				[57955] = true,
				[53988] = true,
				[56036] = true,
				[9470] = true,
				[50277] = true,
				[58595] = true,
				[54628] = true,
				[50661] = true,
				[13725] = true,
				[39656] = true,
				[11331] = true,
				[4864] = true,
				[55396] = true,
				[9790] = true,
				[39272] = true,
				[9854] = true,
				[11299] = true,
				[9918] = true,
				[12438] = true,
				[9982] = true,
				[434] = true,
				[52837] = true,
				[10078] = true,
				[5056] = true,
				[10142] = true,
				[57060] = true,
				[4901] = true,
				[53221] = true,
				[38558] = true,
				[10302] = true,
				[57700] = true,
				[29617] = true,
				[505] = true,
				[53989] = true,
				[54117] = true,
				[54245] = true,
				[58468] = true,
				[12605] = true,
				[54629] = true,
				[33116] = true,
				[38505] = true,
				[29558] = true,
				[29622] = true,
				[43900] = true,
				[55397] = true,
				[56057] = true,
				[10387] = true,
				[10878] = true,
				[13039] = true,
				[56037] = true,
				[36201] = true,
				[55545] = true,
				[11198] = true,
				[38909] = true,
				[36202] = true,
				[11134] = true,
				[55161] = true,
				[57061] = true,
				[1718] = true,
				[53222] = true,
				[53990] = true,
				[54118] = true,
				[57701] = true,
				[11390] = true,
				[25281] = true,
				[58085] = true,
				[45928] = true,
				[46184] = true,
				[50279] = true,
				[54502] = true,
				[54630] = true,
				[11646] = true,
				[38506] = true,
				[50919] = true,
				[1560] = true,
				[31734] = true,
				[55398] = true,
				[51431] = true,
				[39274] = true,
				[11902] = true,
				[55910] = true,
				[56038] = true,
				[11998] = true,
				[12030] = true,
				[44137] = true,
				[12094] = true,
				[36633] = true,
				[12158] = true,
				[12190] = true,
				[12222] = true,
				[4421] = true,
				[28854] = true,
				[51942] = true,
				[45563] = true,
				[57702] = true,
				[12414] = true,
				[34780] = true,
				[12478] = true,
				[34775] = true,
				[12542] = true,
				[12574] = true,
				[1246] = true,
				[54631] = true,
				[38507] = true,
				[50792] = true,
				[29559] = true,
				[12630] = true,
				[56039] = true,
				[12830] = true,
				[12862] = true,
				[12894] = true,
				[55783] = true,
				[55911] = true,
				[51944] = true,
				[56167] = true,
				[31732] = true,
				[40043] = true,
				[12893] = true,
				[12003] = true,
				[48873] = true,
				[56935] = true,
				[57063] = true,
				[57191] = true,
				[11710] = true,
				[49257] = true,
				[9279] = true,
				[57703] = true,
				[42651] = true,
				[9955] = true,
				[9407] = true,
				[51961] = true,
				[9471] = true,
				[50281] = true,
				[54504] = true,
				[54632] = true,
				[12565] = true,
				[9859] = true,
				[55400] = true,
				[9791] = true,
				[51177] = true,
				[34925] = true,
				[51433] = true,
				[52457] = true,
				[55784] = true,
				[31743] = true,
				[10111] = true,
				[47978] = true,
				[9983] = true,
				[52969] = true,
				[10047] = true,
				[10079] = true,
				[48618] = true,
				[10143] = true,
				[48874] = true,
				[10207] = true,
				[11501] = true,
				[7721] = true,
				[10303] = true,
				[57704] = true,
				[10367] = true,
				[10399] = true,
				[29899] = true,
				[13634] = true,
				[1701] = true,
				[55399] = true,
				[401] = true,
				[39204] = true,
				[7802] = true,
				[54889] = true,
				[29560] = true,
				[295] = true,
				[53624] = true,
				[55657] = true,
				[51434] = true,
				[39277] = true,
				[34599] = true,
				[57335] = true,
				[51946] = true,
				[44140] = true,
				[56297] = true,
				[52330] = true,
				[2870] = true,
				[29727] = true,
				[11135] = true,
				[53956] = true,
				[11199] = true,
				[53098] = true,
				[34739] = true,
				[53994] = true,
				[11327] = true,
				[33135] = true,
				[37658] = true,
				[11455] = true,
				[45804] = true,
				[50155] = true,
				[7808] = true,
				[3368] = true,
				[1260] = true,
				[11679] = true,
				[29887] = true,
				[42605] = true,
				[51193] = true,
				[1705] = true,
				[38894] = true,
				[12802] = true,
				[1264] = true,
				[11871] = true,
				[11903] = true,
				[52459] = true,
				[11967] = true,
				[56170] = true,
				[52203] = true,
				[56426] = true,
				[36079] = true,
				[49260] = true,
				[12159] = true,
				[49388] = true,
				[24442] = true,
				[12255] = true,
				[12287] = true,
				[12319] = true,
				[4129] = true,
				[2871] = true,
				[12543] = true,
				[53867] = true,
				[12607] = true,
				[12511] = true,
				[50156] = true,
				[12575] = true,
				[54507] = true,
				[12948] = true,
				[12671] = true,
				[42606] = true,
				[39661] = true,
				[348] = true,
				[12863] = true,
				[51308] = true,
				[55531] = true,
				[55659] = true,
				[55787] = true,
				[684] = true,
				[56043] = true,
				[56171] = true,
				[52204] = true,
				[29905] = true,
				[12991] = true,
				[2982] = true,
				[48621] = true,
				[57334] = true,
				[36592] = true,
				[40815] = true,
				[57707] = true,
				[53356] = true,
				[9280] = true,
				[9312] = true,
				[5084] = true,
				[38502] = true,
				[1708] = true,
				[33905] = true,
				[13663] = true,
				[54380] = true,
				[54508] = true,
				[50541] = true,
				[11697] = true,
				[42607] = true,
				[11870] = true,
				[51309] = true,
				[31737] = true,
				[55404] = true,
				[9792] = true,
				[11970] = true,
				[9856] = true,
				[43750] = true,
				[9920] = true,
				[10016] = true,
				[52205] = true,
				[56428] = true,
				[2879] = true,
				[9855] = true,
				[48622] = true,
				[10144] = true,
				[51192] = true,
				[10208] = true,
				[5121] = true,
				[31742] = true,
				[56042] = true,
				[2585] = true,
				[10368] = true,
				[2601] = true,
				[485] = true,
				[31733] = true,
				[5249] = true,
				[46191] = true,
				[2641] = true,
				[50542] = true,
				[31486] = true,
				[9731] = true,
				[29562] = true,
				[29626] = true,
				[55405] = true,
				[39025] = true,
				[55533] = true,
				[55789] = true,
				[10880] = true,
				[55917] = true,
				[621] = true,
				[2745] = true,
				[56301] = true,
				[2761] = true,
				[52462] = true,
				[10390] = true,
				[56813] = true,
				[49911] = true,
				[2801] = true,
				[38834] = true,
				[11394] = true,
				[268] = true,
				[11328] = true,
				[11360] = true,
				[11392] = true,
				[11570] = true,
				[11456] = true,
				[2873] = true,
				[54254] = true,
				[9558] = true,
				[54510] = true,
				[54638] = true,
				[11648] = true,
				[42609] = true,
				[11712] = true,
				[51201] = true,
				[31738] = true,
				[39026] = true,
				[317] = true,
				[11872] = true,
				[35315] = true,
				[11936] = true,
				[11968] = true,
				[12000] = true,
				[12032] = true,
				[9782] = true,
				[52854] = true,
				[12128] = true,
				[12160] = true,
				[48752] = true,
				[31745] = true,
				[12256] = true,
				[11680] = true,
				[12320] = true,
				[10162] = true,
				[50160] = true,
				[12576] = true,
				[12608] = true,
				[34420] = true,
				[54127] = true,
				[12544] = true,
				[50288] = true,
				[54511] = true,
				[50544] = true,
				[39027] = true,
				[54895] = true,
				[29883] = true,
				[29627] = true,
				[55791] = true,
				[12832] = true,
				[12864] = true,
				[51568] = true,
				[12928] = true,
				[35444] = true,
				[12992] = true,
				[12113] = true,
				[52208] = true,
				[56431] = true,
				[48369] = true,
				[44658] = true,
				[56815] = true,
				[56943] = true,
				[9833] = true,
				[3321] = true,
				[11566] = true,
				[48879] = true,
				[9505] = true,
				[9313] = true,
				[33269] = true,
				[31355] = true,
				[9409] = true,
				[9857] = true,
				[9473] = true,
				[46194] = true,
				[54512] = true,
				[13664] = true,
				[50673] = true,
				[34421] = true,
				[3441] = true,
				[9697] = true,
				[31739] = true,
				[9921] = true,
				[9793] = true,
				[51569] = true,
				[55792] = true,
				[55920] = true,
				[14016] = true,
				[2865] = true,
				[56304] = true,
				[56432] = true,
				[33786] = true,
				[11136] = true,
				[10113] = true,
				[56944] = true,
				[12896] = true,
				[57200] = true,
				[9728] = true,
				[34461] = true,
				[10881] = true,
				[25405] = true,
				[10369] = true,
				[1285] = true,
				[29884] = true,
				[50034] = true,
				[52853] = true,
				[46195] = true,
				[54513] = true,
				[51698] = true,
				[44663] = true,
				[34422] = true,
				[42740] = true,
				[55153] = true,
				[52466] = true,
				[1245] = true,
				[55537] = true,
				[51570] = true,
				[55793] = true,
				[55921] = true,
				[52469] = true,
				[9922] = true,
				[56305] = true,
				[56308] = true,
				[56561] = true,
				[9954] = true,
				[11137] = true,
				[11169] = true,
				[14017] = true,
				[57201] = true,
				[53746] = true,
				[11489] = true,
				[11617] = true,
				[31548] = true,
				[11393] = true,
				[42741] = true,
				[11457] = true,
				[7793] = true,
				[7809] = true,
				[46196] = true,
				[31356] = true,
				[58737] = true,
				[31741] = true,
				[34423] = true,
				[11713] = true,
				[11873] = true,
				[31740] = true,
				[52339] = true,
				[55538] = true,
				[51571] = true,
				[11905] = true,
				[55922] = true,
				[39670] = true,
				[56178] = true,
				[56306] = true,
				[12065] = true,
				[3661] = true,
				[12129] = true,
				[12161] = true,
				[38904] = true,
				[12225] = true,
				[12257] = true,
				[57330] = true,
				[12321] = true,
				[4130] = true,
				[9538] = true,
				[53747] = true,
				[37495] = true,
				[2990] = true,
				[54771] = true,
				[12545] = true,
				[12577] = true,
				[54515] = true,
				[58994] = true,
				[12673] = true,
				[42614] = true,
				[31357] = true,
				[55539] = true,
				[12865] = true,
				[29885] = true,
				[51444] = true,
				[51572] = true,
				[12929] = true,
				[13057] = true,
				[12993] = true,
				[52212] = true,
				[56307] = true,
				[52340] = true,
				[11700] = true,
				[35320] = true,
				[12275] = true,
				[56947] = true,
				[52980] = true,
				[57203] = true,
				[57331] = true,
				[49269] = true,
				[42610] = true,
				[9314] = true,
				[53748] = true,
				[37496] = true,
				[37538] = true,
				[50037] = true,
				[54129] = true,
				[9506] = true,
				[13633] = true,
				[57202] = true,
				[56056] = true,
				[34425] = true,
				[56434] = true,
				[11969] = true,
				[9730] = true,
				[51699] = true,
				[11681] = true,
				[50419] = true,
				[9858] = true,
				[55924] = true,
				[1241] = true,
				[39800] = true,
				[1249] = true,
				[1253] = true,
				[10050] = true,
				[56945] = true,
				[1265] = true,
				[10146] = true,
				[5090] = true,
				[10210] = true,
				[977] = true,
				[49270] = true,
				[5601] = true,
				[29891] = true,
				[53749] = true,
				[53877] = true,
				[511] = true,
				[56814] = true,
				[5250] = true,
				[42104] = true,
				[56048] = true,
				[58991] = true,
				[54773] = true,
				[42611] = true,
				[13408] = true,
				[38777] = true,
				[51190] = true,
				[1243] = true,
				[6031] = true,
				[55919] = true,
				[39417] = true,
				[35450] = true,
				[55407] = true,
				[3161] = true,
				[56309] = true,
				[8417] = true,
				[52428] = true,
				[11694] = true,
				[11138] = true,
				[56949] = true,
				[11202] = true,
				[11904] = true,
				[57333] = true,
				[54126] = true,
				[11330] = true,
				[2771] = true,
				[53750] = true,
				[11426] = true,
				[11458] = true,
				[54134] = true,
				[31230] = true,
				[12898] = true,
				[54518] = true,
				[31736] = true,
				[11650] = true,
				[11682] = true,
				[54950] = true,
				[29900] = true,
				[51191] = true,
				[29901] = true,
				[5057] = true,
				[595] = true,
				[51807] = true,
				[11938] = true,
				[51959] = true,
				[12002] = true,
				[51994] = true,
				[9427] = true,
				[12098] = true,
				[12130] = true,
				[34785] = true,
				[599] = true,
				[12226] = true,
				[12258] = true,
				[12290] = true,
				[12818] = true,
				[12831] = true,
				[53623] = true,
				[53751] = true,
				[12927] = true,
				[12895] = true,
				[50040] = true,
				[12546] = true,
				[12578] = true,
				[54519] = true,
				[54647] = true,
				[54775] = true,
				[12223] = true,
				[12031] = true,
				[12770] = true,
				[38907] = true,
				[29759] = true,
				[12866] = true,
				[51576] = true,
				[12930] = true,
				[11157] = true,
				[56055] = true,
				[11519] = true,
				[56311] = true,
				[2867] = true,
				[1712] = true,
				[48505] = true,
				[1019] = true,
				[48761] = true,
				[9311] = true,
				[53112] = true,
				[1665] = true,
				[56041] = true,
				[9283] = true,
				[13410] = true,
				[55529] = true,
				[616] = true,
				[48539] = true,
				[54136] = true,
				[9475] = true,
				[42107] = true,
				[58615] = true,
				[1709] = true,
				[1713] = true,
				[34429] = true,
				[55032] = true,
				[13794] = true,
				[47098] = true,
				[51321] = true,
				[56296] = true,
				[9827] = true,
				[35325] = true,
				[31735] = true,
				[9923] = true,
				[56184] = true,
				[53992] = true,
				[4902] = true,
				[52473] = true,
				[51796] = true,
				[10115] = true,
				[48616] = true,
				[12926] = true,
				[10211] = true,
				[57336] = true,
				[27243] = true,
				[46185] = true,
				[45435] = true,
				[53753] = true,
				[10403] = true,
				[11582] = true,
				[52654] = true,
				[54265] = true,
				[56422] = true,
				[30070] = true,
				[34174] = true,
				[54777] = true,
				[50278] = true,
				[55033] = true,
				[29632] = true,
				[47099] = true,
				[33061] = true,
				[35070] = true,
				[29888] = true,
				[55801] = true,
				[470] = true,
				[51962] = true,
				[56185] = true,
				[56313] = true,
				[26177] = true,
				[52474] = true,
				[12949] = true,
				[11139] = true,
				[1206] = true,
				[57081] = true,
				[9743] = true,
				[39235] = true,
				[53370] = true,
				[57593] = true,
				[49531] = true,
				[11395] = true,
				[11427] = true,
				[11459] = true,
				[54138] = true,
				[53847] = true,
				[37449] = true,
				[11587] = true,
				[11619] = true,
				[11576] = true,
				[34431] = true,
				[11715] = true,
				[52196] = true,
				[31744] = true,
				[12573] = true,
				[37660] = true,
				[1791] = true,
				[51707] = true,
				[51835] = true,
				[56058] = true,
				[56186] = true,
				[12035] = true,
				[12067] = true,
				[12099] = true,
				[12131] = true,
				[50531] = true,
				[52859] = true,
				[12227] = true,
				[12259] = true,
				[12291] = true,
				[56801] = true,
				[4131] = true,
				[395] = true,
				[53755] = true,
				[555] = true,
				[12483] = true,
				[51151] = true,
				[12547] = true,
				[42110] = true,
				[29313] = true,
				[52128] = true,
				[54779] = true,
				[34432] = true,
				[5545] = true,
				[31572] = true,
				[12803] = true,
				[55520] = true,
				[12867] = true,
				[29889] = true,
				[12931] = true,
				[13820] = true,
				[51964] = true,
				[56187] = true,
				[13059] = true,
				[13091] = true,
				[56571] = true,
				[29865] = true,
				[39498] = true,
				[12988] = true,
				[52988] = true,
				[12860] = true,
				[12572] = true,
				[53372] = true,
				[33075] = true,
				[56628] = true,
				[29893] = true,
				[561] = true,
				[31130] = true,
				[11529] = true,
				[9476] = true,
				[12060] = true,
				[54524] = true,
				[13667] = true,
				[13699] = true,
				[31553] = true,
				[3367] = true,
				[13795] = true,
				[9732] = true,
				[384] = true,
				[55548] = true,
				[47486] = true,
				[56413] = true,
				[55932] = true,
				[51965] = true,
				[56188] = true,
				[3450] = true,
				[51021] = true,
				[51225] = true,
				[55899] = true,
				[10116] = true,
				[56956] = true,
				[5091] = true,
				[51722] = true,
				[57340] = true,
				[53373] = true,
				[5155] = true,
				[10340] = true,
				[10108] = true,
				[44255] = true,
				[12215] = true,
				[54141] = true,
				[53187] = true,
				[49733] = true,
				[29314] = true,
				[2866] = true,
				[514] = true,
				[38529] = true,
				[12827] = true,
				[38785] = true,
				[29698] = true,
				[29762] = true,
				[55549] = true,
				[47487] = true,
				[51710] = true,
				[10916] = true,
				[39681] = true,
				[56189] = true,
				[49734] = true,
				[2762] = true,
				[2770] = true,
				[51149] = true,
				[11140] = true,
				[52862] = true,
				[49452] = true,
				[12571] = true,
				[57341] = true,
				[11300] = true,
				[11332] = true,
				[12885] = true,
				[11396] = true,
				[56538] = true,
				[11460] = true,
				[2874] = true,
				[51916] = true,
				[55057] = true,
				[55623] = true,
				[11620] = true,
				[54782] = true,
				[11684] = true,
				[52039] = true,
				[51349] = true,
				[51199] = true,
				[34393] = true,
				[55550] = true,
				[11876] = true,
				[11908] = true,
				[35459] = true,
				[51967] = true,
				[56190] = true,
				[6030] = true,
				[12068] = true,
				[56998] = true,
				[44417] = true,
				[3042] = true,
				[48768] = true,
				[57086] = true,
				[55340] = true,
				[12292] = true,
				[53443] = true,
				[51488] = true,
				[53631] = true,
				[38210] = true,
				[37507] = true,
				[12484] = true,
				[54143] = true,
				[12548] = true,
				[12580] = true,
				[12612] = true,
				[12644] = true,
				[12676] = true,
				[34436] = true,
				[12740] = true,
				[34692] = true,
				[12804] = true,
				[12836] = true,
				[12868] = true,
				[47489] = true,
				[12932] = true,
				[12964] = true,
				[51968] = true,
				[12877] = true,
				[13060] = true,
				[52352] = true,
				[56212] = true,
				[12986] = true,
				[55895] = true,
				[40579] = true,
				[49703] = true,
				[8470] = true,
				[55827] = true,
				[56534] = true,
				[47960] = true,
				[55362] = true,
				[9349] = true,
				[53888] = true,
				[26192] = true,
				[54144] = true,
				[54272] = true,
				[42115] = true,
				[31363] = true,
				[52285] = true,
				[13700] = true,
				[34437] = true,
				[3442] = true,
				[9701] = true,
				[9733] = true,
				[56471] = true,
				[55552] = true,
				[660] = true,
				[9861] = true,
				[51841] = true,
				[56064] = true,
				[54862] = true,
				[56320] = true,
				[55707] = true,
				[54299] = true,
				[44419] = true,
				[10117] = true,
				[40580] = true,
				[1252] = true,
				[979] = true,
				[54205] = true,
				[53267] = true,
				[41220] = true,
				[51632] = true,
				[10373] = true,
				[52156] = true,
				[54017] = true,
				[538] = true,
				[54471] = true,
				[58496] = true,
				[29316] = true,
				[50562] = true,
				[50600] = true,
				[34438] = true,
				[55089] = true,
				[52028] = true,
				[29700] = true,
				[55425] = true,
				[55553] = true,
				[29892] = true,
				[51714] = true,
				[55937] = true,
				[39718] = true,
				[48003] = true,
				[56321] = true,
				[978] = true,
				[51402] = true,
				[52017] = true,
				[11141] = true,
				[11173] = true,
				[52029] = true,
				[53276] = true,
				[691] = true,
				[3783] = true,
				[11333] = true,
				[34774] = true,
				[53762] = true,
				[37510] = true,
				[51026] = true,
				[51873] = true,
				[7811] = true,
				[13205] = true,
				[31364] = true,
				[53677] = true,
				[54786] = true,
				[31556] = true,
				[51872] = true,
				[52665] = true,
				[34823] = true,
				[55426] = true,
				[39174] = true,
				[55888] = true,
				[51715] = true,
				[11941] = true,
				[11973] = true,
				[51135] = true,
				[51121] = true,
				[53328] = true,
				[55730] = true,
				[48516] = true,
				[12165] = true,
				[12197] = true,
				[12229] = true,
				[49028] = true,
				[12293] = true,
				[12325] = true,
				[55819] = true,
				[54195] = true,
				[53763] = true,
				[56526] = true,
				[49924] = true,
				[55374] = true,
				[12549] = true,
				[58498] = true,
				[12613] = true,
				[12645] = true,
				[12677] = true,
				[34440] = true,
				[55757] = true,
				[55171] = true,
				[12805] = true,
				[696] = true,
				[50894] = true,
				[12901] = true,
				[12933] = true,
				[12965] = true,
				[12997] = true,
				[54204] = true,
				[13061] = true,
				[54946] = true,
				[57036] = true,
				[54972] = true,
				[392] = true,
				[56963] = true,
				[55116] = true,
				[53124] = true,
				[50893] = true,
				[54412] = true,
				[35747] = true,
				[9623] = true,
				[56131] = true,
				[12151] = true,
				[49925] = true,
				[50987] = true,
				[56242] = true,
				[54404] = true,
				[55088] = true,
				[56011] = true,
				[12919] = true,
				[13733] = true,
				[55044] = true,
				[9702] = true,
				[9734] = true,
				[52283] = true,
				[9798] = true,
				[9830] = true,
				[9862] = true,
				[46796] = true,
				[53910] = true,
				[52286] = true,
				[52016] = true,
				[52882] = true,
				[53385] = true,
				[10086] = true,
				[10118] = true,
				[52869] = true,
				[5092] = true,
				[57220] = true,
				[51899] = true,
				[49481] = true,
				[5156] = true,
				[56520] = true,
				[56993] = true,
				[53815] = true,
				[8465] = true,
				[13009] = true,
				[31308] = true,
				[52494] = true,
				[29318] = true,
				[52492] = true,
				[51913] = true,
				[34442] = true,
				[55045] = true,
				[13654] = true,
				[55301] = true,
				[51615] = true,
				[51609] = true,
				[29894] = true,
				[52247] = true,
				[55183] = true,
				[51621] = true,
				[54174] = true,
				[54821] = true,
				[26183] = true,
				[44296] = true,
				[49480] = true,
				[11142] = true,
				[56965] = true,
				[12489] = true,
				[57221] = true,
				[51633] = true,
				[56092] = true,
				[1247] = true,
				[55595] = true,
				[51758] = true,
				[11430] = true,
				[54058] = true,
				[11494] = true,
				[54278] = true,
				[52013] = true,
				[11590] = true,
				[50567] = true,
				[1015] = true,
				[46728] = true,
				[11718] = true,
				[51884] = true,
				[55983] = true,
				[55823] = true,
				[53945] = true,
				[11878] = true,
				[11910] = true,
				[11942] = true,
				[322] = true,
				[12006] = true,
				[310] = true,
				[12070] = true,
				[55599] = true,
				[12134] = true,
				[12166] = true,
				[56966] = true,
				[40519] = true,
				[57222] = true,
				[12294] = true,
				[12326] = true,
				[56089] = true,
				[53820] = true,
				[56354] = true,
				[56642] = true,
				[49942] = true,
				[8423] = true,
				[12550] = true,
				[58502] = true,
				[12614] = true,
				[54663] = true,
				[25545] = true,
				[12710] = true,
				[50952] = true,
				[55175] = true,
				[55090] = true,
				[55860] = true,
				[12870] = true,
				[55687] = true,
				[12934] = true,
				[12966] = true,
				[12998] = true,
				[56095] = true,
				[13062] = true,
				[13094] = true,
				[55820] = true,
				[13158] = true,
				[12686] = true,
				[52872] = true,
				[53000] = true,
				[56894] = true,
				[55737] = true,
				[53384] = true,
				[56347] = true,
				[53640] = true,
				[53768] = true,
				[9383] = true,
				[49929] = true,
				[51211] = true,
				[58290] = true,
				[52160] = true,
				[58631] = true,
				[57249] = true,
				[13702] = true,
				[34445] = true,
				[52873] = true,
				[38796] = true,
				[56376] = true,
				[49072] = true,
				[39180] = true,
				[51982] = true,
				[55995] = true,
				[9895] = true,
				[9927] = true,
				[57362] = true,
				[9991] = true,
				[58155] = true,
				[52489] = true,
				[10087] = true,
				[10119] = true,
				[56968] = true,
				[57374] = true,
				[57915] = true,
			},
			["rares_killed"] = {
				[126578] = -1,
				[108283] = -1,
				[96129] = -1,
				[148184] = -1,
				[136158] = -1,
				[152790] = -1,
				[146905] = -1,
				[39381] = -1,
				[153814] = -1,
				[109819] = -1,
				[148185] = -1,
				[97793] = -1,
				[106109] = -1,
				[146906] = -1,
				[137183] = -1,
				[141533] = -1,
				[139742] = -1,
				[86535] = -1,
				[140510] = -1,
				[146907] = -1,
				[129906] = -1,
				[151769] = -1,
				[93444] = -1,
				[59084] = -1,
				[44819] = -1,
				[152793] = -1,
				[144861] = -1,
				[132835] = -1,
				[137185] = -1,
				[141535] = -1,
				[147932] = -1,
				[131812] = -1,
				[100993] = -1,
				[139233] = -1,
				[153818] = -1,
				[147933] = -1,
				[137954] = -1,
				[106111] = -1,
				[126709] = -1,
				[82315] = -1,
				[148446] = -1,
				[136420] = -1,
				[139235] = -1,
				[147935] = -1,
				[138212] = -1,
				[136421] = -1,
				[102274] = -1,
				[126966] = -1,
				[147936] = -1,
				[45268] = -1,
				[138469] = -1,
				[80653] = -1,
				[136934] = -1,
				[145634] = -1,
				[156125] = -1,
				[137958] = -1,
				[152543] = -1,
				[138470] = -1,
				[153055] = -1,
				[141029] = -1,
				[126967] = -1,
				[145635] = -1,
				[147938] = -1,
				[131818] = -1,
				[152544] = -1,
				[56719] = -1,
				[141286] = -1,
				[155871] = -1,
				[137704] = -1,
				[131819] = -1,
				[81422] = -1,
				[130678] = -1,
				[40855] = -1,
				[96135] = -1,
				[139240] = -1,
				[145637] = -1,
				[139752] = -1,
				[59598] = -1,
				[134123] = -1,
				[145638] = -1,
				[148197] = -1,
				[152547] = -1,
				[130679] = -1,
				[58319] = -1,
				[129016] = -1,
				[145639] = -1,
				[145895] = -1,
				[148198] = -1,
				[148454] = -1,
				[136428] = -1,
				[134637] = -1,
				[93066] = -1,
				[155619] = -1,
				[131311] = -1,
				[137708] = -1,
				[131823] = -1,
				[93834] = -1,
				[130808] = -1,
				[131568] = -1,
				[131824] = -1,
				[148456] = -1,
				[101127] = -1,
				[103430] = -1,
				[130297] = -1,
				[131825] = -1,
				[140525] = -1,
				[43927] = -1,
				[132849] = -1,
				[39961] = -1,
				[133361] = -1,
				[146667] = -1,
				[136688] = -1,
				[80786] = -1,
				[131571] = -1,
				[152297] = -1,
				[130554] = -1,
				[104583] = -1,
				[147948] = -1,
				[152298] = -1,
				[152554] = -1,
				[140784] = -1,
				[153322] = -1,
				[39450] = -1,
				[137458] = -1,
				[126205] = -1,
				[146158] = -1,
				[150508] = -1,
				[154858] = -1,
				[126845] = -1,
				[39962] = -1,
				[131318] = -1,
				[82323] = -1,
				[140530] = -1,
				[129788] = -1,
				[93070] = -1,
				[62991] = -1,
				[154092] = -1,
				[79253] = -1,
				[152813] = -1,
				[126718] = -1,
				[126846] = -1,
				[151534] = -1,
				[82196] = -1,
				[107400] = -1,
				[155629] = -1,
				[135415] = -1,
				[136183] = -1,
				[136439] = -1,
				[126719] = -1,
				[126847] = -1,
				[88466] = -1,
				[152560] = -1,
				[152816] = -1,
				[107401] = -1,
				[101644] = -1,
				[154352] = -1,
				[126720] = -1,
				[126848] = -1,
				[135418] = -1,
				[148212] = -1,
				[59666] = -1,
				[140536] = -1,
				[103180] = -1,
				[88979] = -1,
				[101645] = -1,
				[154354] = -1,
				[148469] = -1,
				[39900] = -1,
				[155634] = -1,
				[150773] = -1,
				[90899] = -1,
				[107403] = -1,
				[155635] = -1,
				[139515] = -1,
				[81432] = -1,
				[94098] = -1,
				[127106] = -1,
				[108939] = -1,
				[148472] = -1,
				[142587] = -1,
				[80793] = -1,
				[145402] = -1,
				[131585] = -1,
				[133888] = -1,
				[160755] = -1,
				[140541] = -1,
				[2110] = -1,
				[92180] = -1,
				[131586] = -1,
				[108940] = -1,
				[138495] = -1,
				[125828] = -1,
				[135169] = -1,
				[131587] = -1,
				[57109] = -1,
				[140543] = -1,
				[88087] = -1,
				[31889] = -1,
				[90902] = -1,
				[132868] = -1,
				[43612] = -1,
				[147965] = -1,
				[135939] = -1,
				[148477] = -1,
				[75422] = -1,
				[135684] = -1,
				[135940] = -1,
				[123399] = -1,
				[138499] = -1,
				[90903] = -1,
				[131847] = -1,
				[138244] = -1,
				[65362] = -1,
				[144897] = -1,
				[145153] = -1,
				[141315] = -1,
				[147968] = -1,
				[123272] = -1,
				[138245] = -1,
				[138501] = -1,
				[144898] = -1,
				[72609] = -1,
				[139269] = -1,
				[131849] = -1,
				[140293] = -1,
				[98069] = -1,
				[147202] = -1,
				[126983] = -1,
				[127111] = -1,
				[131850] = -1,
				[140294] = -1,
				[66213] = -1,
				[127879] = -1,
				[140295] = -1,
				[152833] = -1,
				[2442] = -1,
				[123146] = -1,
				[134155] = -1,
				[152834] = -1,
				[97175] = -1,
				[101525] = -1,
				[124170] = -1,
				[142088] = -1,
				[152835] = -1,
				[108306] = -1,
				[145415] = -1,
				[129288] = -1,
				[123275] = -1,
				[148998] = -1,
				[56792] = -1,
				[141322] = -1,
				[75043] = -1,
				[148231] = -1,
				[55193] = -1,
				[59351] = -1,
				[146185] = -1,
				[149000] = -1,
				[97177] = -1,
				[152071] = -1,
				[146186] = -1,
				[62358] = -1,
				[145163] = -1,
				[139278] = -1,
				[139534] = -1,
				[80162] = -1,
				[90525] = -1,
				[125452] = -1,
				[129802] = -1,
				[88990] = -1,
				[141326] = -1,
				[126092] = -1,
				[99609] = -1,
				[108309] = -1,
				[139280] = -1,
				[139536] = -1,
				[59544] = -1,
				[129547] = -1,
				[59800] = -1,
				[139537] = -1,
				[139793] = -1,
				[101785] = -1,
				[130699] = -1,
				[144911] = -1,
				[132885] = -1,
				[119185] = -1,
				[129548] = -1,
				[40290] = -1,
				[127757] = -1,
				[139283] = -1,
				[126094] = -1,
				[131863] = -1,
				[44896] = -1,
				[55195] = -1,
				[110614] = -1,
				[133399] = -1,
				[59545] = -1,
				[131864] = -1,
				[140564] = -1,
				[59801] = -1,
				[139285] = -1,
				[99484] = -1,
				[45728] = -1,
				[133912] = -1,
				[62360] = -1,
				[721] = -1,
				[126991] = -1,
				[127119] = -1,
				[127247] = -1,
				[129550] = -1,
				[40291] = -1,
				[44577] = -1,
				[93344] = -1,
				[61081] = -1,
				[135961] = -1,
				[44897] = -1,
				[108441] = -1,
				[88099] = -1,
				[131356] = -1,
				[59546] = -1,
				[135962] = -1,
				[135963] = -1,
				[75434] = -1,
				[139034] = -1,
				[88100] = -1,
				[139546] = -1,
				[119189] = -1,
				[90659] = -1,
				[152852] = -1,
				[133406] = -1,
				[130448] = -1,
				[132127] = -1,
				[44898] = -1,
				[139036] = -1,
				[88101] = -1,
				[104605] = -1,
				[59547] = -1,
				[90660] = -1,
				[139805] = -1,
				[39909] = -1,
				[90661] = -1,
				[78507] = -1,
				[40357] = -1,
				[130194] = -1,
				[40677] = -1,
				[134178] = -1,
				[59356] = -1,
				[133155] = -1,
				[141599] = -1,
				[59804] = -1,
				[141088] = -1,
				[139297] = -1,
				[79020] = -1,
				[122263] = -1,
				[140833] = -1,
				[132901] = -1,
				[139298] = -1,
				[151836] = -1,
				[141857] = -1,
				[44260] = -1,
				[54559] = -1,
				[78637] = -1,
				[151581] = -1,
				[59037] = -1,
				[140067] = -1,
				[140579] = -1,
				[59357] = -1,
				[141859] = -1,
				[140068] = -1,
				[140324] = -1,
				[78510] = -1,
				[132904] = -1,
				[149536] = -1,
				[101667] = -1,
				[122265] = -1,
				[148513] = -1,
				[97957] = -1,
				[137255] = -1,
				[151840] = -1,
				[148002] = -1,
				[44261] = -1,
				[138279] = -1,
				[141350] = -1,
				[66869] = -1,
				[122266] = -1,
				[57119] = -1,
				[83629] = -1,
				[140839] = -1,
				[127000] = -1,
				[152098] = -1,
				[123290] = -1,
				[129559] = -1,
				[136490] = -1,
				[147493] = -1,
				[138794] = -1,
				[108578] = -1,
				[883] = -1,
				[137771] = -1,
				[152356] = -1,
				[136236] = -1,
				[134701] = -1,
				[153826] = -1,
				[131631] = -1,
				[135981] = -1,
				[138284] = -1,
				[154378] = -1,
				[130840] = -1,
				[79793] = -1,
				[160652] = -1,
				[153913] = -1,
				[81360] = -1,
				[148264] = -1,
				[131628] = -1,
				[129517] = -1,
				[130435] = -1,
				[126969] = -1,
				[130073] = -1,
				[131377] = -1,
				[73013] = -1,
				[140077] = -1,
				[150568] = -1,
				[31216] = -1,
				[130160] = -1,
				[145444] = -1,
				[155686] = -1,
				[161280] = -1,
				[156452] = -1,
				[119199] = -1,
				[140334] = -1,
				[129527] = -1,
				[126463] = -1,
				[80818] = -1,
				[148182] = -1,
				[153896] = -1,
				[145443] = -1,
				[154353] = -1,
				[140335] = -1,
				[89884] = -1,
				[98090] = -1,
				[39892] = -1,
				[155688] = -1,
				[135474] = -1,
				[59552] = -1,
				[82354] = -1,
				[66106] = -1,
				[101120] = -1,
				[59808] = -1,
				[147245] = -1,
				[97323] = -1,
				[103592] = -1,
				[126237] = -1,
				[133940] = -1,
				[140337] = -1,
				[95916] = -1,
				[89731] = -1,
				[145199] = -1,
				[153812] = -1,
				[137946] = -1,
				[145967] = -1,
				[152364] = -1,
				[97289] = -1,
				[148782] = -1,
				[144944] = -1,
				[132918] = -1,
				[152822] = -1,
				[56930] = -1,
				[118050] = -1,
				[152357] = -1,
				[80775] = -1,
				[40810] = -1,
				[83763] = -1,
				[132919] = -1,
				[145457] = -1,
				[129526] = -1,
				[59553] = -1,
				[156130] = -1,
				[154909] = -1,
				[154113] = -1,
				[103210] = -1,
				[59873] = -1,
				[154871] = -1,
				[133432] = -1,
				[130333] = -1,
				[152827] = -1,
				[138294] = -1,
				[156132] = -1,
				[154859] = -1,
				[81670] = -1,
				[155919] = -1,
				[144874] = -1,
				[148018] = -1,
				[140086] = -1,
				[148530] = -1,
				[140563] = -1,
				[152577] = -1,
				[147251] = -1,
				[155689] = -1,
				[153904] = -1,
				[130334] = -1,
				[156463] = -1,
				[126496] = -1,
				[40811] = -1,
				[150541] = -1,
				[155139] = -1,
				[151602] = -1,
				[137713] = -1,
				[54557] = -1,
				[148276] = -1,
				[144857] = -1,
				[152882] = -1,
				[133593] = -1,
				[127874] = -1,
				[139321] = -1,
				[131389] = -1,
				[130335] = -1,
				[47720] = -1,
				[154674] = -1,
				[152883] = -1,
				[131626] = -1,
				[128928] = -1,
				[123289] = -1,
				[153907] = -1,
				[102701] = -1,
				[136416] = -1,
				[138299] = -1,
				[152884] = -1,
				[66367] = -1,
				[103339] = -1,
				[144409] = -1,
				[152358] = -1,
				[93490] = -1,
				[56589] = -1,
				[145465] = -1,
				[146744] = -1,
				[138812] = -1,
				[149303] = -1,
				[133183] = -1,
				[49832] = -1,
				[102702] = -1,
				[125347] = -1,
				[94846] = -1,
				[138557] = -1,
				[78650] = -1,
				[39405] = -1,
				[153654] = -1,
				[153910] = -1,
				[126243] = -1,
				[93619] = -1,
				[82308] = -1,
				[138558] = -1,
				[130849] = -1,
				[128930] = -1,
				[153655] = -1,
				[145202] = -1,
				[155702] = -1,
				[140094] = -1,
				[131624] = -1,
				[153332] = -1,
				[78651] = -1,
				[126702] = -1,
				[126455] = -1,
				[143677] = -1,
				[135457] = -1,
				[40685] = -1,
				[127876] = -1,
				[124581] = -1,
				[81156] = -1,
				[56906] = -1,
				[135234] = -1,
				[14881] = -1,
				[120593] = -1,
				[82362] = -1,
				[154681] = -1,
				[129699] = -1,
				[127780] = -1,
				[133436] = -1,
				[151327] = -1,
				[139585] = -1,
				[151305] = -1,
				[141033] = -1,
				[140353] = -1,
				[138562] = -1,
				[39854] = -1,
				[140325] = -1,
				[94261] = -1,
				[127092] = -1,
				[138561] = -1,
				[128653] = -1,
				[140354] = -1,
				[39890] = -1,
				[138819] = -1,
				[130795] = -1,
				[127901] = -1,
				[137029] = -1,
				[139843] = -1,
				[136005] = -1,
				[140355] = -1,
				[144705] = -1,
				[138820] = -1,
				[141123] = -1,
				[130411] = -1,
				[127142] = -1,
				[117035] = -1,
				[136006] = -1,
				[142403] = -1,
				[127129] = -1,
				[103218] = -1,
				[133685] = -1,
				[130085] = -1,
				[49770] = -1,
				[139845] = -1,
				[152383] = -1,
				[91704] = -1,
				[144707] = -1,
				[133663] = -1,
				[136914] = -1,
				[135240] = -1,
				[131402] = -1,
				[139846] = -1,
				[152384] = -1,
				[80062] = -1,
				[146755] = -1,
				[138823] = -1,
				[126974] = -1,
				[154569] = -1,
				[133843] = -1,
				[93496] = -1,
				[138281] = -1,
				[128551] = -1,
				[151754] = -1,
				[152282] = -1,
				[128935] = -1,
				[55336] = -1,
				[157383] = -1,
				[132126] = -1,
				[158527] = -1,
				[103067] = -1,
				[146757] = -1,
				[133963] = -1,
				[119724] = -1,
				[154312] = -1,
				[152881] = -1,
				[49835] = -1,
				[137950] = -1,
				[59555] = -1,
				[152812] = -1,
				[94009] = -1,
				[133870] = -1,
				[139338] = -1,
				[82111] = -1,
				[58696] = -1,
				[140106] = -1,
				[142285] = -1,
				[146759] = -1,
				[152641] = -1,
				[154347] = -1,
				[130088] = -1,
				[145209] = -1,
				[93498] = -1,
				[122284] = -1,
				[140107] = -1,
				[128681] = -1,
				[155204] = -1,
				[151110] = -1,
				[139340] = -1,
				[82112] = -1,
				[122605] = -1,
				[138061] = -1,
				[49996] = -1,
				[59751] = -1,
				[129833] = -1,
				[135905] = -1,
				[99384] = -1,
				[93371] = -1,
				[152135] = -1,
				[148297] = -1,
				[101943] = -1,
				[152069] = -1,
				[155206] = -1,
				[132177] = -1,
				[139342] = -1,
				[139063] = -1,
				[131666] = -1,
				[40177] = -1,
				[154083] = -1,
				[131817] = -1,
				[129834] = -1,
				[91069] = -1,
				[139343] = -1,
				[131411] = -1,
				[131667] = -1,
				[130075] = -1,
				[132179] = -1,
				[128683] = -1,
				[127124] = -1,
				[94714] = -1,
				[152262] = -1,
				[41073] = -1,
				[132180] = -1,
				[78276] = -1,
				[90686] = -1,
				[138577] = -1,
				[144974] = -1,
				[145230] = -1,
				[128044] = -1,
				[133327] = -1,
				[131669] = -1,
				[118193] = -1,
				[154698] = -1,
				[144719] = -1,
				[72647] = -1,
				[124536] = -1,
				[59752] = -1,
				[134350] = -1,
				[141905] = -1,
				[130680] = -1,
				[64806] = -1,
				[144720] = -1,
				[144976] = -1,
				[107447] = -1,
				[152623] = -1,
				[134717] = -1,
				[128286] = -1,
				[134147] = -1,
				[146760] = -1,
				[144721] = -1,
				[144977] = -1,
				[153933] = -1,
				[1412] = -1,
				[149839] = -1,
				[133463] = -1,
				[127143] = -1,
				[150475] = -1,
				[144722] = -1,
				[138837] = -1,
				[129030] = -1,
				[147537] = -1,
				[135511] = -1,
				[137955] = -1,
				[95881] = -1,
				[134232] = -1,
				[148817] = -1,
				[140058] = -1,
				[141641] = -1,
				[92224] = -1,
				[141530] = -1,
				[56747] = -1,
				[144212] = -1,
				[136280] = -1,
				[144724] = -1,
				[138839] = -1,
				[146118] = -1,
				[56875] = -1,
				[45007] = -1,
				[133842] = -1,
				[144213] = -1,
				[148563] = -1,
				[95935] = -1,
				[147028] = -1,
				[149331] = -1,
				[154448] = -1,
				[149843] = -1,
				[156126] = -1,
				[153026] = -1,
				[154705] = -1,
				[146773] = -1,
				[140888] = -1,
				[136196] = -1,
				[135914] = -1,
				[89283] = -1,
				[131677] = -1,
				[133835] = -1,
				[140069] = -1,
				[144727] = -1,
				[91970] = -1,
				[152148] = -1,
				[145495] = -1,
				[78025] = -1,
				[94529] = -1,
				[147396] = -1,
				[154707] = -1,
				[144728] = -1,
				[141051] = -1,
				[127921] = -1,
				[56876] = -1,
				[89284] = -1,
				[91459] = -1,
				[138696] = -1,
				[140866] = -1,
				[136541] = -1,
				[126770] = -1,
				[126440] = -1,
				[151638] = -1,
				[148163] = -1,
				[155195] = -1,
				[136174] = -1,
				[140571] = -1,
				[152918] = -1,
				[152136] = -1,
				[147289] = -1,
				[139357] = -1,
				[56711] = -1,
				[142172] = -1,
				[128434] = -1,
				[152512] = -1,
				[144731] = -1,
				[144987] = -1,
				[147290] = -1,
				[151640] = -1,
				[139614] = -1,
				[134212] = -1,
				[119223] = -1,
				[154711] = -1,
				[156502] = -1,
				[129842] = -1,
				[147291] = -1,
				[103231] = -1,
				[148016] = -1,
				[127224] = -1,
				[97730] = -1,
				[128435] = -1,
				[136545] = -1,
				[134754] = -1,
				[65317] = -1,
				[139360] = -1,
				[142276] = -1,
				[146187] = -1,
				[104895] = -1,
				[154713] = -1,
				[109807] = -1,
				[80715] = -1,
				[131381] = -1,
				[153534] = -1,
				[139617] = -1,
				[131685] = -1,
				[152411] = -1,
				[138338] = -1,
				[126645] = -1,
				[119435] = -1,
				[129529] = -1,
				[155738] = -1,
				[104640] = -1,
				[151900] = -1,
				[152412] = -1,
				[89013] = -1,
				[136548] = -1,
				[138280] = -1,
				[138840] = -1,
				[151742] = -1,
				[89288] = -1,
				[153948] = -1,
				[152413] = -1,
				[136293] = -1,
				[91847] = -1,
				[126774] = -1,
				[132807] = -1,
				[77518] = -1,
				[150464] = -1,
				[3343] = -1,
				[123192] = -1,
				[154717] = -1,
				[152159] = -1,
				[130485] = -1,
				[135365] = -1,
				[153694] = -1,
				[89289] = -1,
				[137830] = -1,
				[81357] = -1,
				[126519] = -1,
				[136551] = -1,
				[132713] = -1,
				[126903] = -1,
				[89673] = -1,
				[154154] = -1,
				[40166] = -1,
				[154719] = -1,
				[136296] = -1,
				[136552] = -1,
				[127799] = -1,
				[103363] = -1,
				[125414] = -1,
				[133482] = -1,
				[135785] = -1,
				[89290] = -1,
				[154720] = -1,
				[136553] = -1,
				[144997] = -1,
				[126904] = -1,
				[151108] = -1,
				[156000] = -1,
				[152162] = -1,
				[150371] = -1,
				[154721] = -1,
				[129124] = -1,
				[137155] = -1,
				[127928] = -1,
				[77488] = -1,
				[49779] = -1,
				[118077] = -1,
				[97735] = -1,
				[133738] = -1,
				[136555] = -1,
				[82057] = -1,
				[56304] = -1,
				[12053] = -1,
				[78033] = -1,
				[127289] = -1,
				[103176] = -1,
				[152917] = -1,
				[138603] = -1,
				[140540] = -1,
				[44981] = -1,
				[147208] = -1,
				[153956] = -1,
				[118078] = -1,
				[130488] = -1,
				[131787] = -1,
				[97992] = -1,
				[44982] = -1,
				[140759] = -1,
				[115008] = -1,
				[139968] = -1,
				[55473] = -1,
				[138093] = -1,
				[154725] = -1,
				[113345] = -1,
				[96548] = -1,
				[97781] = -1,
				[146686] = -1,
				[128285] = -1,
				[131697] = -1,
				[150376] = -1,
				[127290] = -1,
				[97993] = -1,
				[136385] = -1,
				[79355] = -1,
				[148155] = -1,
				[153959] = -1,
				[140398] = -1,
				[135902] = -1,
				[82513] = -1,
				[137152] = -1,
				[151301] = -1,
				[159335] = -1,
				[83025] = -1,
				[144725] = -1,
				[77140] = -1,
				[113130] = -1,
				[132211] = -1,
				[97994] = -1,
				[59312] = -1,
				[153962] = -1,
				[137329] = -1,
				[137585] = -1,
				[115010] = -1,
				[152426] = -1,
				[140913] = -1,
				[153963] = -1,
				[153194] = -1,
				[145339] = -1,
				[83026] = -1,
				[128188] = -1,
				[130363] = -1,
				[91598] = -1,
				[83538] = -1,
				[44976] = -1,
				[138866] = -1,
				[126909] = -1,
				[143985] = -1,
				[137587] = -1,
				[129340] = -1,
				[134005] = -1,
				[152684] = -1,
				[66267] = -1,
				[145008] = -1,
				[136821] = -1,
				[134080] = -1,
				[140915] = -1,
				[130364] = -1,
				[134519] = -1,
				[83539] = -1,
				[151151] = -1,
				[151150] = -1,
				[139124] = -1,
				[151662] = -1,
				[55411] = -1,
				[131704] = -1,
				[66652] = -1,
				[152686] = -1,
				[66268] = -1,
				[136822] = -1,
				[129981] = -1,
				[83028] = -1,
				[141049] = -1,
				[91472] = -1,
				[136823] = -1,
				[152687] = -1,
				[157293] = -1,
				[126783] = -1,
				[82425] = -1,
				[40600] = -1,
				[129214] = -1,
				[136824] = -1,
				[140150] = -1,
				[123713] = -1,
				[66269] = -1,
				[138871] = -1,
				[145337] = -1,
				[130347] = -1,
				[147249] = -1,
				[136825] = -1,
				[142198] = -1,
				[134078] = -1,
				[93904] = -1,
				[145013] = -1,
				[94877] = -1,
				[4076] = -1,
				[136826] = -1,
				[129343] = -1,
				[123714] = -1,
				[129599] = -1,
				[66270] = -1,
				[147061] = -1,
				[128674] = -1,
				[154482] = -1,
				[127127] = -1,
				[91474] = -1,
				[81367] = -1,
				[138618] = -1,
				[75482] = -1,
				[147062] = -1,
				[135868] = -1,
				[126583] = -1,
				[136828] = -1,
				[153523] = -1,
				[138938] = -1,
				[134269] = -1,
				[66271] = -1,
				[159345] = -1,
				[58803] = -1,
				[155763] = -1,
				[140542] = -1,
				[134076] = -1,
				[39984] = -1,
				[126530] = -1,
				[75483] = -1,
				[134782] = -1,
				[145017] = -1,
				[75431] = -1,
				[91122] = -1,
				[128684] = -1,
				[134271] = -1,
				[100943] = -1,
				[66272] = -1,
				[145018] = -1,
				[136318] = -1,
				[98602] = -1,
				[133504] = -1,
				[130369] = -1,
				[130497] = -1,
				[101967] = -1,
				[128578] = -1,
				[159348] = -1,
				[131009] = -1,
				[76438] = -1,
				[85294] = -1,
				[145333] = -1,
				[103226] = -1,
				[129602] = -1,
				[119495] = -1,
				[136832] = -1,
				[141182] = -1,
				[139135] = -1,
				[162164] = -1,
				[145020] = -1,
				[128685] = -1,
				[140821] = -1,
				[138624] = -1,
				[128707] = -1,
				[141183] = -1,
				[155768] = -1,
				[100433] = -1,
				[91121] = -1,
				[131972] = -1,
				[74206] = -1,
				[66274] = -1,
				[132740] = -1,
				[145278] = -1,
				[138625] = -1,
				[79354] = -1,
				[83674] = -1,
				[139958] = -1,
				[141185] = -1,
				[138626] = -1,
				[39870] = -1,
				[56310] = -1,
				[143488] = -1,
				[129860] = -1,
				[131718] = -1,
				[154491] = -1,
				[150653] = -1,
				[66275] = -1,
				[155259] = -1,
				[62899] = -1,
				[130909] = -1,
				[147839] = -1,
				[155054] = -1,
				[152445] = -1,
				[138628] = -1,
				[44924] = -1,
				[144769] = -1,
				[145281] = -1,
				[83628] = -1,
				[130269] = -1,
				[140336] = -1,
				[74208] = -1,
				[66148] = -1,
				[66276] = -1,
				[132744] = -1,
				[140805] = -1,
				[153262] = -1,
				[135048] = -1,
				[131013] = -1,
				[148353] = -1,
				[146819] = -1,
				[138887] = -1,
				[72674] = -1,
				[126919] = -1,
				[136584] = -1,
				[56439] = -1,
				[115021] = -1,
				[142213] = -1,
				[50490] = -1,
				[140678] = -1,
				[145028] = -1,
				[89050] = -1,
				[135817] = -1,
				[130246] = -1,
				[154240] = -1,
				[153261] = -1,
				[155052] = -1,
				[79583] = -1,
				[153217] = -1,
				[118051] = -1,
				[147588] = -1,
				[127176] = -1,
				[135818] = -1,
				[134725] = -1,
				[136330] = -1,
				[143678] = -1,
				[153218] = -1,
				[139145] = -1,
				[81603] = -1,
				[91354] = -1,
				[85341] = -1,
				[66273] = -1,
				[134284] = -1,
				[130012] = -1,
				[159360] = -1,
				[135052] = -1,
				[145287] = -1,
				[123083] = -1,
				[127048] = -1,
				[73805] = -1,
				[58807] = -1,
				[123231] = -1,
				[136844] = -1,
				[40448] = -1,
				[131431] = -1,
				[152283] = -1,
				[144777] = -1,
				[57080] = -1,
				[152709] = -1,
				[79585] = -1,
				[136845] = -1,
				[133007] = -1,
				[129097] = -1,
				[44926] = -1,
				[72677] = -1,
				[131984] = -1,
				[152710] = -1,
				[144778] = -1,
				[136846] = -1,
				[89053] = -1,
				[135311] = -1,
				[152711] = -1,
				[126429] = -1,
				[142000] = -1,
				[136335] = -1,
				[146826] = -1,
				[39873] = -1,
				[137103] = -1,
				[136847] = -1,
				[56441] = -1,
				[155271] = -1,
				[130011] = -1,
				[66153] = -1,
				[119503] = -1,
				[136848] = -1,
				[144780] = -1,
				[106752] = -1,
				[141710] = -1,
				[14774] = -1,
				[146652] = -1,
				[43614] = -1,
				[155272] = -1,
				[85856] = -1,
				[162181] = -1,
				[153737] = -1,
				[141711] = -1,
				[146061] = -1,
				[80574] = -1,
				[82530] = -1,
				[45439] = -1,
				[155273] = -1,
				[45063] = -1,
				[153738] = -1,
				[139665] = -1,
				[129227] = -1,
				[97755] = -1,
				[130635] = -1,
				[93485] = -1,
				[130508] = -1,
				[152462] = -1,
				[153739] = -1,
				[146832] = -1,
				[146063] = -1,
				[152460] = -1,
				[94813] = -1,
				[140690] = -1,
				[155275] = -1,
				[89056] = -1,
				[153740] = -1,
				[136598] = -1,
				[79205] = -1,
				[152461] = -1,
				[129869] = -1,
				[140691] = -1,
				[155276] = -1,
				[136343] = -1,
				[153741] = -1,
				[63607] = -1,
				[88417] = -1,
				[154509] = -1,
				[146577] = -1,
				[146833] = -1,
				[132760] = -1,
				[145298] = -1,
				[79590] = -1,
				[146859] = -1,
				[117344] = -1,
				[150416] = -1,
				[134296] = -1,
				[146834] = -1,
				[155278] = -1,
				[145299] = -1,
				[122961] = -1,
				[141717] = -1,
				[98653] = -1,
				[150417] = -1,
				[56763] = -1,
				[136600] = -1,
				[58810] = -1,
				[141206] = -1,
				[146835] = -1,
				[130765] = -1,
				[148115] = -1,
				[122973] = -1,
				[130638] = -1,
				[81406] = -1,
				[126905] = -1,
				[126928] = -1,
				[120147] = -1,
				[129231] = -1,
				[55484] = -1,
				[94688] = -1,
				[117333] = -1,
				[94687] = -1,
				[140205] = -1,
				[77522] = -1,
				[49727] = -1,
				[92034] = -1,
				[136346] = -1,
				[123868] = -1,
				[130639] = -1,
				[146838] = -1,
				[145047] = -1,
				[133021] = -1,
				[122963] = -1,
				[129232] = -1,
				[141977] = -1,
				[56444] = -1,
				[152724] = -1,
				[119509] = -1,
				[56764] = -1,
				[144810] = -1,
				[148367] = -1,
				[111074] = -1,
				[146072] = -1,
				[56636] = -1,
				[122452] = -1,
				[146840] = -1,
				[130896] = -1,
				[109592] = -1,
				[135326] = -1,
				[145817] = -1,
				[55485] = -1,
				[153263] = -1,
				[140444] = -1,
				[110562] = -1,
				[59835] = -1,
				[133024] = -1,
				[131233] = -1,
				[81129] = -1,
				[141980] = -1,
				[134048] = -1,
				[130641] = -1,
				[126929] = -1,
				[90621] = -1,
				[98273] = -1,
				[122965] = -1,
				[56765] = -1,
				[127315] = -1,
				[64761] = -1,
				[50496] = -1,
				[146843] = -1,
				[58812] = -1,
				[145308] = -1,
				[135329] = -1,
				[135585] = -1,
				[48833] = -1,
				[140441] = -1,
				[122454] = -1,
				[45122] = -1,
				[131858] = -1,
				[124885] = -1,
				[127060] = -1,
				[131492] = -1,
				[58108] = -1,
				[130008] = -1,
				[141981] = -1,
				[146866] = -1,
				[97123] = -1,
				[133028] = -1,
				[130131] = -1,
				[127699] = -1,
				[145052] = -1,
				[79340] = -1,
				[148637] = -1,
				[109591] = -1,
				[136944] = -1,
				[148392] = -1,
				[122967] = -1,
				[124890] = -1,
				[141985] = -1,
				[149400] = -1,
				[97176] = -1,
				[145307] = -1,
				[56766] = -1,
				[3300] = -1,
				[48706] = -1,
				[154530] = -1,
				[72362] = -1,
				[132007] = -1,
				[56754] = -1,
				[136613] = -1,
				[149406] = -1,
				[96229] = -1,
				[122968] = -1,
				[139684] = -1,
				[150667] = -1,
				[107362] = -1,
				[79342] = -1,
				[136614] = -1,
				[145058] = -1,
				[78830] = -1,
				[139429] = -1,
				[136615] = -1,
				[126295] = -1,
				[126423] = -1,
				[154529] = -1,
				[144803] = -1,
				[126807] = -1,
				[44932] = -1,
				[122969] = -1,
				[153504] = -1,
				[56511] = -1,
				[117212] = -1,
				[135338] = -1,
				[136616] = -1,
				[145060] = -1,
				[130006] = -1,
				[56895] = -1,
				[132778] = -1,
				[81774] = -1,
				[126424] = -1,
				[124382] = -1,
				[144805] = -1,
				[145061] = -1,
				[73766] = -1,
				[122970] = -1,
				[41095] = -1,
				[137915] = -1,
				[140200] = -1,
				[154785] = -1,
				[152994] = -1,
				[153250] = -1,
				[155553] = -1,
				[135339] = -1,
				[97511] = -1,
				[95013] = -1,
				[140201] = -1,
				[114717] = -1,
				[108289] = -1,
				[82881] = -1,
				[137131] = -1,
				[122971] = -1,
				[142106] = -1,
				[45467] = -1,
				[148874] = -1,
				[94691] = -1,
				[138667] = -1,
				[137413] = -1,
				[137132] = -1,
				[134024] = -1,
				[156067] = -1,
				[50883] = -1,
				[148391] = -1,
				[61562] = -1,
				[146856] = -1,
				[154772] = -1,
				[45062] = -1,
				[122972] = -1,
				[130640] = -1,
				[134041] = -1,
				[136110] = -1,
				[82544] = -1,
				[146857] = -1,
				[146159] = -1,
				[137134] = -1,
				[155813] = -1,
				[139693] = -1,
				[39625] = -1,
				[130521] = -1,
				[150696] = -1,
				[130777] = -1,
				[145067] = -1,
				[137949] = -1,
				[155814] = -1,
				[45269] = -1,
				[129870] = -1,
				[140206] = -1,
				[129626] = -1,
				[155047] = -1,
				[95083] = -1,
				[136599] = -1,
				[150415] = -1,
				[94046] = -1,
				[128347] = -1,
				[130522] = -1,
				[56890] = -1,
				[79589] = -1,
				[80181] = -1,
				[81906] = -1,
				[97976] = -1,
				[136849] = -1,
				[132755] = -1,
				[140208] = -1,
				[140464] = -1,
				[146861] = -1,
				[153224] = -1,
				[145326] = -1,
				[146827] = -1,
				[106197] = -1,
				[39626] = -1,
				[140209] = -1,
				[54558] = -1,
				[130779] = -1,
				[62313] = -1,
				[96236] = -1,
				[98411] = -1,
				[141745] = -1,
				[152236] = -1,
				[98795] = -1,
				[146607] = -1,
				[146863] = -1,
				[56658] = -1,
				[145328] = -1,
				[55505] = -1,
				[61557] = -1,
				[139955] = -1,
				[123287] = -1,
				[137096] = -1,
				[146864] = -1,
				[134838] = -1,
				[81908] = -1,
				[98412] = -1,
				[135049] = -1,
				[154285] = -1,
				[40319] = -1,
				[132280] = -1,
				[155053] = -1,
				[107368] = -1,
				[140095] = -1,
				[129600] = -1,
				[131513] = -1,
				[126918] = -1,
				[54930] = -1,
				[130653] = -1,
				[73465] = -1,
				[134840] = -1,
				[147378] = -1,
				[82037] = -1,
				[129246] = -1,
				[148146] = -1,
				[138167] = -1,
				[75471] = -1,
				[138821] = -1,
				[111463] = -1,
				[137144] = -1,
				[42570] = -1,
				[133562] = -1,
				[39392] = -1,
				[75475] = -1,
				[126735] = -1,
				[138623] = -1,
				[140983] = -1,
				[45065] = -1,
				[156393] = -1,
				[130217] = -1,
				[84341] = -1,
				[127682] = -1,
				[129601] = -1,
				[59778] = -1,
				[140984] = -1,
				[137146] = -1,
				[130143] = -1,
				[43658] = -1,
				[44922] = -1,
				[150452] = -1,
				[134270] = -1,
				[126689] = -1,
				[132797] = -1,
				[137147] = -1,
				[50487] = -1,
				[138727] = -1,
				[44234] = -1,
				[138171] = -1,
				[40268] = -1,
				[134012] = -1,
				[134845] = -1,
				[137148] = -1,
				[140848] = -1,
				[151989] = -1,
				[130400] = -1,
				[154548] = -1,
				[138428] = -1,
				[73468] = -1,
				[101875] = -1,
				[137149] = -1,
				[141499] = -1,
				[134521] = -1,
				[123236] = -1,
				[138870] = -1,
				[151152] = -1,
				[155061] = -1,
				[134847] = -1,
				[145338] = -1,
				[137406] = -1,
				[98892] = -1,
				[97649] = -1,
				[142268] = -1,
				[152685] = -1,
				[155062] = -1,
				[140989] = -1,
				[137151] = -1,
				[80468] = -1,
				[139710] = -1,
				[55410] = -1,
				[94707] = -1,
				[138466] = -1,
				[77517] = -1,
				[140990] = -1,
				[145340] = -1,
				[141502] = -1,
				[139630] = -1,
				[93556] = -1,
				[142270] = -1,
				[55110] = -1,
				[155064] = -1,
				[140059] = -1,
				[137153] = -1,
				[90230] = -1,
				[137665] = -1,
				[45259] = -1,
				[113131] = -1,
				[150715] = -1,
				[105199] = -1,
				[12922] = -1,
				[135107] = -1,
				[134425] = -1,
				[139844] = -1,
				[126625] = -1,
				[56070] = -1,
				[138434] = -1,
				[136643] = -1,
				[86809] = -1,
				[149437] = -1,
				[151740] = -1,
				[131436] = -1,
				[127333] = -1,
				[113132] = -1,
				[40270] = -1,
				[105200] = -1,
				[127265] = -1,
				[137156] = -1,
				[139459] = -1,
				[131527] = -1,
				[130404] = -1,
				[150462] = -1,
				[40782] = -1,
				[152866] = -1,
				[136901] = -1,
				[44980] = -1,
				[139460] = -1,
				[135717] = -1,
				[158395] = -1,
				[126723] = -1,
				[139362] = -1,
				[144834] = -1,
				[133988] = -1,
				[145346] = -1,
				[139461] = -1,
				[122089] = -1,
				[130848] = -1,
				[93687] = -1,
				[130661] = -1,
				[144915] = -1,
				[138836] = -1,
				[96124] = -1,
				[145603] = -1,
				[137671] = -1,
				[153323] = -1,
				[150465] = -1,
				[154815] = -1,
				[144836] = -1,
				[158398] = -1,
				[152097] = -1,
				[130437] = -1,
				[152572] = -1,
				[93560] = -1,
				[93688] = -1,
				[136393] = -1,
				[144837] = -1,
				[128426] = -1,
				[108529] = -1,
				[137417] = -1,
				[139720] = -1,
				[158399] = -1,
				[151872] = -1,
				[145161] = -1,
				[140744] = -1,
				[136906] = -1,
				[44977] = -1,
				[139290] = -1,
				[124548] = -1,
				[133836] = -1,
				[136139] = -1,
				[82373] = -1,
				[153027] = -1,
				[148253] = -1,
				[148017] = -1,
				[127145] = -1,
				[92410] = -1,
				[146119] = -1,
				[138187] = -1,
				[40272] = -1,
				[129768] = -1,
				[138579] = -1,
				[130024] = -1,
				[133430] = -1,
				[138500] = -1,
				[132182] = -1,
				[131383] = -1,
				[148679] = -1,
				[152559] = -1,
				[133345] = -1,
				[138960] = -1,
				[84095] = -1,
				[147277] = -1,
				[135886] = -1,
				[154565] = -1,
				[138576] = -1,
				[39313] = -1,
				[145098] = -1,
				[127978] = -1,
				[130436] = -1,
				[141772] = -1,
				[93563] = -1,
				[40273] = -1,
				[95866] = -1,
				[144843] = -1,
				[138958] = -1,
				[90109] = -1,
				[151752] = -1,
				[141773] = -1,
				[154311] = -1,
				[109044] = -1,
				[158917] = -1,
				[105206] = -1,
				[157382] = -1,
				[145356] = -1,
				[88086] = -1,
				[68872] = -1,
				[130410] = -1,
				[132051] = -1,
				[61255] = -1,
				[144845] = -1,
				[132819] = -1,
				[136470] = -1,
				[149707] = -1,
				[145181] = -1,
				[55498] = -1,
				[148428] = -1,
				[74374] = -1,
				[144846] = -1,
				[132820] = -1,
				[126100] = -1,
				[151755] = -1,
				[144647] = -1,
				[81283] = -1,
				[152523] = -1,
				[130550] = -1,
				[124654] = -1,
				[138962] = -1,
				[122264] = -1,
				[43934] = -1,
				[152363] = -1,
				[152635] = -1,
				[64774] = -1,
				[136419] = -1,
				[101114] = -1,
				[144958] = -1,
				[136939] = -1,
				[153804] = -1,
				[126190] = -1,
				[133846] = -1,
				[78883] = -1,
				[124527] = -1,
				[65414] = -1,
				[128774] = -1,
				[102166] = -1,
				[139287] = -1,
				[92415] = -1,
				[139988] = -1,
				[132056] = -1,
				[134359] = -1,
				[103162] = -1,
				[130307] = -1,
				[153327] = -1,
				[128648] = -1,
				[81157] = -1,
				[133848] = -1,
				[145970] = -1,
				[149004] = -1,
				[138498] = -1,
				[126497] = -1,
				[94207] = -1,
				[90241] = -1,
				[154063] = -1,
				[138496] = -1,
				[40167] = -1,
				[152792] = -1,
				[138711] = -1,
				[2630] = -1,
				[137763] = -1,
				[129805] = -1,
				[155920] = -1,
				[152273] = -1,
				[134106] = -1,
				[153064] = -1,
				[146900] = -1,
				[126832] = -1,
				[154670] = -1,
				[155628] = -1,
				[135642] = -1,
				[152274] = -1,
				[155618] = -1,
				[152362] = -1,
				[163112] = -1,
				[145110] = -1,
				[155917] = -1,
				[49743] = -1,
				[148510] = -1,
				[133852] = -1,
				[155616] = -1,
				[132317] = -1,
				[144855] = -1,
				[138970] = -1,
				[135975] = -1,
				[69773] = -1,
				[139796] = -1,
				[137947] = -1,
				[153333] = -1,
				[132318] = -1,
				[150997] = -1,
				[145112] = -1,
				[78857] = -1,
				[155859] = -1,
				[154365] = -1,
				[135901] = -1,
				[154367] = -1,
			},
			["scannerYPos"] = 451.1371765136719,
		},
	},
	["profileKeys"] = {
		["뉘시빨라마 - 굴단"] = "뉘시빨라마 - 굴단",
		["무시중한디 - 굴단"] = "무시중한디 - 굴단",
		["국제금융로 - 굴단"] = "국제금융로 - 굴단",
	},
	["global"] = {
		["object_names"] = {
			["koKR"] = {
				[291258] = "작은 보물 상자",
				[297825] = "그물투성이 상자",
				[291259] = "작은 보물 상자",
				[297891] = "룬결속 보관함",
				[297828] = "상인의 상자",
				[297892] = "룬결속 상자",
				[275070] = "작은 보물 상자",
				[291263] = "작은 보물 상자",
				[275071] = "작은 보물 상자",
				[291264] = "작은 보물 상자",
				[282722] = "보물 상자",
				[291201] = "작은 보물 상자",
				[291265] = "작은 보물 상자",
				[280619] = "오래된 철제 궤짝",
				[282723] = "보물 상자",
				[252448] = "반짝이는 고대 마나 응집체",
				[291266] = "작은 보물 상자",
				[293880] = "묻힌 보물 상자",
				[275074] = "작은 보물 상자",
				[291267] = "작은 보물 상자",
				[293881] = "묻힌 보물 상자",
				[291204] = "작은 보물 상자",
				[237723] = "주둔지 보관함",
				[275076] = "작은 보물 상자",
				[154944] = "무성한 화단",
				[284448] = "숨겨진 학자의 상자",
				[280751] = "작은 보물 상자",
				[293884] = "묻힌 보물 상자",
				[287318] = "성난모래 보관함",
				[278713] = "보물 상자",
				[281646] = "꿀곰",
				[287320] = "떠밀려 온 보관함",
				[278459] = "보물 상자",
				[278460] = "보물 상자",
				[281903] = "보물 상자",
				[278716] = "보물 상자",
				[281904] = "보물 상자",
				[278462] = "보물 상자",
				[281905] = "보물 상자",
				[287324] = "발굴인부의 탐욕",
				[291213] = "작은 보물 상자",
				[280504] = "삼켜진 상자",
				[281397] = "바다가름 보물 상자",
				[316780] = "비밀의 보급품 상자",
				[291217] = "작은 보물 상자",
				[288604] = "보물 상자",
				[279042] = "밀수업자의 보관함",
				[279299] = "맹독의 문장",
				[293962] = "위태로운 보물 상자",
				[334189] = "검은 제국 보관함",
				[291222] = "작은 보물 상자",
				[293964] = "잊혀진 보물 상자",
				[291223] = "작은 보물 상자",
				[279366] = "보물 상자",
				[293965] = "뼈새김 보관함",
				[302954] = "잊혀진 보물 상자",
				[278793] = "보물 상자",
				[291225] = "작은 보물 상자",
				[319212] = "어둠해안 보관함",
				[291226] = "작은 보물 상자",
				[284469] = "작은 보물 상자",
				[291227] = "작은 보물 상자",
				[291228] = "작은 보물 상자",
				[287531] = "작은 보물 상자",
				[291229] = "작은 보물 상자",
				[325973] = "아마셋 보관함",
				[291230] = "작은 보물 상자",
				[325974] = "아마셋 보관함",
				[279373] = "보물 상자",
				[284410] = "보물 상자",
				[280522] = "반쯤 소화된 보물",
				[273956] = "작은 보물 상자",
				[284412] = "보물 상자",
				[277336] = "보물 상자",
				[325659] = "기계 상자",
				[284413] = "보물 상자",
				[290725] = "토르노와의 금은보화",
				[279378] = "보물 상자",
				[325661] = "기계 상자",
				[284415] = "보물 상자",
				[279379] = "보물 상자",
				[325662] = "기계 상자",
				[284416] = "보물 상자",
				[279253] = "운 좋은 호러스의 행운 상자",
				[284417] = "보물 상자",
				[325664] = "기계 상자",
				[273900] = "작은 보물 상자",
				[284419] = "보물 상자",
				[289647] = "오래된 보물 상자",
				[273901] = "작은 보물 상자",
				[294174] = "잊혀진 상자",
				[335703] = "검은 제국 함",
				[273902] = "작은 보물 상자",
				[284421] = "보물 상자",
				[279609] = "판다리아의 전리품",
				[273917] = "작은 보물 상자",
				[325668] = "기계 상자",
				[339247] = "감염된 보관함",
				[277561] = "전쟁군주의 보관함",
				[325660] = "기계 상자",
				[291244] = "작은 보물 상자",
				[339248] = "감염된 보관함",
				[237722] = "주둔지 보관함",
				[293852] = "묻힌 보물 상자",
				[279260] = "\"교묘하게\" 위장된 상자",
				[293349] = "버려진 도시락",
				[334213] = "검은 제국 보관함",
				[324407] = "공허 뿌리",
				[291246] = "작은 보물 상자",
				[279325] = "보물 상자",
				[303039] = "이상한 곡식 자루",
				[290129] = "전쟁 보급품 상자",
				[311902] = "거미 로봇 전리품",
				[311903] = "고릴라 로봇 전리품",
				[334215] = "검은 제국 보관함",
				[281494] = "서리 보물 상자",
				[236916] = "주둔지 보관함",
				[291211] = "작은 보물 상자",
				[334216] = "검은 제국 보관함",
				[327650] = "전쟁 보급품 상자",
				[273903] = "작은 보물 상자",
				[273955] = "작은 보물 상자",
				[284411] = "보물 상자",
				[278436] = "난파당한 상자",
				[273910] = "작은 보물 상자",
				[291257] = "작은 보물 상자",
				[284454] = "하얀 상어",
				[278437] = "브원삼디에게 바치는 제물",
				[273919] = "작은 보물 상자",
				[325667] = "기계 상자",
				[293350] = "조각한 나무 궤짝",
				[278456] = "보물 상자",
				[277885] = "운자의 보물",
				[325666] = "기계 상자",
				[334220] = "검은 제국 보관함",
				[278694] = "보물 상자",
				[291224] = "작은 보물 상자",
				[325665] = "기계 상자",
				[273918] = "작은 보물 상자",
				[325663] = "기계 상자",
				[291254] = "작은 보물 상자",
				[278461] = "보물 상자",
				[135238] = "전쟁 보급품 상자",
				[303170] = "이상한 곡식 자루",
				[291255] = "작은 보물 상자",
				[277715] = "저주받은 나즈마니 상자",
				[334223] = "검은 제국 보관함",
				[297893] = "룬결속 함",
				[273905] = "작은 보물 상자",
				[325981] = "아마셋 보관함",
				[325626] = "아마셋 성물함",
				[324413] = "아마셋 보관함",
				[294317] = "마른숲 상자",
				[325984] = "아마셋 보관함",
				[282721] = "보물 상자",
			},
		},
		["addonVersion"] = 600,
		["event_names"] = {
			["koKR"] = {
				[155059] = "젤리먹보 요라그",
				[277389] = "의식용 짐승 두개골",
				[327553] = "공허의 수송관",
				[154154] = "꿀 파쇄자",
				[327554] = "공허의 수송관",
				[97584] = "정찰병 헤어풋",
				[154328] = "속박된 수호자",
				[339856] = "잠식하는 아귀",
				[164361] = "태양왕의 봉화",
				[277329] = "고대 석관",
				[90804] = "지옥불정령의 보관 장소",
				[243009] = "세이렌의 뿔피리",
				[154187] = "속박된 수호자",
				[163204] = "기습당한 정착민",
				[156849] = "발굴된 수호자",
				[155172] = "들창 벌사냥꾼",
				[152227] = "승천의 의식",
				[241128] = "주인 없는 엉겅퀴잎 보물",
				[97215] = "야수조련사 파오레크",
				[127652] = "방치된 낚싯대",
				[155173] = "벌꿀등 강탈자",
				[82426] = "엠바리 방어 수정",
				[154118] = "타락의 샘",
				[163198] = "기습당한 정착민",
				[327229] = "공허의 수송관",
				[164331] = "심연의 의식",
				[154095] = "스타우트 보호",
				[163356] = "도사리는 공포",
				[163337] = "발화 고치",
				[163120] = "승천의 동력",
				[339870] = "잠식하는 아귀",
				[137180] = "위험에 처한 상인",
				[107922] = "대지의 성지",
				[155069] = "벌꿀등 수확벌",
				[282660] = "아구수의 단지",
				[163357] = "도사리는 공포",
				[154104] = "심연의 의식",
				[152628] = "아마셋 약탈 함대",
				[277896] = "끓어오르는 보관함",
				[156648] = "비르나알 전선",
				[241127] = "주인 없는 엉겅퀴잎 보물",
				[152439] = "봉인이 풀린 무덤",
				[156869] = "발굴된 수호자",
				[339756] = "잠식하는 아귀",
				[155176] = "늙은 나샤",
				[90775] = "세이렌의 뿔피리",
				[93677] = "벌벌 떠는 잿빛아귀 새끼",
				[156614] = "경도검 훈련장",
				[163132] = "아마셋 노예 수용소",
				[161181] = "감염된 비취 조각상",
				[157525] = "고동치는 무더기",
				[90232] = "해방된 균열",
				[156993] = "태양 수집기",
				[163361] = "잠든 파괴자",
			},
		},
		["quest_ids"] = {
			[77140] = {
				33061, -- [1]
			},
			[152697] = {
				56058, -- [1]
			},
			[148295] = {
				54862, -- [1]
			},
			[110562] = {
				43446, -- [1]
			},
			[128584] = {
				50366, -- [1]
			},
			[93371] = {
				38837, -- [1]
			},
			[137704] = {
				52000, -- [1]
			},
			[138279] = {
				54953, -- [1]
			},
			[97793] = {
				39963, -- [1]
			},
			[137665] = {
				52002, -- [1]
			},
			[140398] = {
				53624, -- [1]
			},
			[128935] = {
				50040, -- [1]
			},
			[157267] = {
				57343, -- [1]
			},
			[153314] = {
				57166, -- [1]
			},
			[81406] = {
				35281, -- [1]
			},
			[138667] = {
				52001, -- [1]
			},
			[155811] = {
				56882, -- [1]
			},
			[134147] = {
				50541, -- [1]
			},
			[152677] = {
				55684, -- [1]
			},
			[147708] = {
				54278, -- [1]
			},
			[72362] = {
				33039, -- [1]
			},
			[154087] = {
				56084, -- [1]
			},
			[89884] = {
				37824, -- [1]
			},
			[128578] = {
				50460, -- [1]
			},
			[157167] = {
				57280, -- [1]
			},
			[127901] = {
				48981, -- [1]
			},
			[134637] = {
				50661, -- [1]
			},
			[152671] = {
				56055, -- [1]
			},
			[155841] = {
				56894, -- [1]
			},
			[136323] = {
				51065, -- [1]
			},
			[132047] = {
				53611, -- [1]
			},
			[136385] = {
				52997, -- [1]
			},
			[74206] = {
				33043, -- [1]
			},
			[134717] = {
				50673, -- [1]
			},
			[133843] = {
				51073, -- [1]
			},
			[155838] = {
				56895, -- [1]
			},
			[92180] = {
				38479, -- [1]
			},
			[155840] = {
				56893, -- [1]
			},
			[153310] = {
				57170, -- [1]
			},
			[151897] = {
				55479, -- [1]
			},
			[152040] = {
				55518, -- [1]
			},
		},
		["lootdbversion"] = 21,
		["loot_info"] = {
			[154836] = {
				"|cff1eff00|Hitem:154836::::::::120:262::::::|h[혈사술 예복]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				1762576, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169421] = {
				"|cff1eff00|Hitem:169421::::::::120:577::::::|h[파도분쇄 가슴갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				2966767, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170189] = {
				"|cff0070dd|Hitem:170189::::::::120:262::::::|h[보이지 않는 눈]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1500930, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[131808] = {
				"|cff9d9d9d|Hitem:131808::::::::105:73::::::|h[글귀가 새겨진 핏빛토템 팔찌]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				457793, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[154837] = {
				"|cff1eff00|Hitem:154837::::::::120:262::::::|h[혈사술 발목보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1762574, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169422] = {
				"|cff1eff00|Hitem:169422::::::::120:577::::::|h[파도분쇄 파쇄장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2966766, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[155605] = {
				"|cff9d9d9d|Hitem:155605::::::::114:73::::::|h[거대한 다리뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133718, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170190] = {
				"|cff0070dd|Hitem:170190::::::::120:577::::::|h[마디바스의 억제의 가방]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133666, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[172493] = {
				"|cff0070dd|Hitem:172493::::::::120:262::::::|h[으르렁거리는 나비 상자]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132599, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160467] = {
				"|cff0070dd|Hitem:160467::::::::120:262::::::|h[히드라사냥꾼 다리보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1726335, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154838] = {
				"|cff1eff00|Hitem:154838::::::::120:262::::::|h[혈사술 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1762580, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169423] = {
				"|cff1eff00|Hitem:169423::::::::120:577::::::|h[파도분쇄 분쇄장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2966768, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170191] = {
				"|cff0070dd|Hitem:170191::::::::120:577::::::|h[해골 손]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				615099, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[163027] = {
				"|cff1eff00|Hitem:163027::::::::120:577::::::|h[도안: 수놓은 심해 가방]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387620, -- [4]
				9, -- [5]
				2, -- [6]
			},
			[169424] = {
				"|cff1eff00|Hitem:169424::::::::120:577::::::|h[파도분쇄 머리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2966769, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170192] = {
				"|cff1eff00|Hitem:170192::::::::120:577::::::|h[진흙 붕대]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				236155, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160469] = {
				"|cff0070dd|Hitem:160469::::::::120:73::::::|h[만능 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1726335, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169169] = {
				"|cff0070dd|Hitem:169169::::::::120:577::::::|h[도면: 파란색 분무로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169425] = {
				"|cff1eff00|Hitem:169425::::::::120:577::::::|h[깊은바다 로브]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				2973326, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163796] = {
				"|cff1eff00|Hitem:163796::::::::120:577::::::|h[새끼 늑대 척추]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133720, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[170193] = {
				"|cff1eff00|Hitem:170193::::::::120:577::::::|h[바다 토템]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				971076, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160470] = {
				"|cff0070dd|Hitem:160470::::::::120:262::::::|h[무리걸음 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1726331, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169170] = {
				"|cff0070dd|Hitem:169170::::::::120:577::::::|h[도면: 다용도 기계손톱]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[159191] = {
				"|cff1eff00|Hitem:159191::::::::120:262::::::|h[소금물 작업장 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1727710, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[155609] = {
				"|cff9d9d9d|Hitem:155609::::::::120:262::::::|h[탄력 넘치는 눈알]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237297, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170194] = {
				"|cff1eff00|Hitem:170194::::::::120:577::::::|h[폭풍 토템]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1020304, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160471] = {
				"|cff0070dd|Hitem:160471::::::::120:262::::::|h[현장감독의 안정화 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1726329, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154842] = {
				"|cff1eff00|Hitem:154842::::::::120:262::::::|h[콜레인 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1727707, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169427] = {
				"|cff1eff00|Hitem:169427::::::::120:577::::::|h[파도분쇄 어깨철갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2966771, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[155610] = {
				"|cff9d9d9d|Hitem:155610::::::::120:577::::::|h[뾰족한 쐐기풀]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134439, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170195] = {
				"|cff0070dd|Hitem:170195::::::::120:577::::::|h[공허술사의 보급품 가방]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133667, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160472] = {
				"|cff0070dd|Hitem:160472::::::::120:577::::::|h[꿀 바른 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1727711, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154843] = {
				"|cff1eff00|Hitem:154843::::::::120:262::::::|h[콜레인 철갑투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1727712, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169428] = {
				"|cff1eff00|Hitem:169428::::::::120:577::::::|h[파도분쇄 죔쇠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2966765, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170196] = {
				"|cff0070dd|Hitem:170196::::::::120:577::::::|h[쉬라케스 경고 표지]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134426, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160473] = {
				"|cff0070dd|Hitem:160473::::::::120:262::::::|h[버들가시 디딤장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1727708, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169173] = {
				"|cff0070dd|Hitem:169173::::::::120:577::::::|h[도면: 반중력 추진기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[159194] = {
				"|cff1eff00|Hitem:159194::::::::120:262::::::|h[소금물 작업장 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1727712, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[172500] = {
				"|cff9d9d9d|Hitem:172500::::::::120:73::::::|h[리사 허니서클의 사진]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1505948, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160474] = {
				"|cff0070dd|Hitem:160474::::::::120:262::::::|h[꼭집게 손목두르개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1727709, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158683] = {
				"|cff0070dd|Hitem:158683::::::::120:577::::::|h[거대한 설인의 밥그릇]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723673, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[169174] = {
				"|cff0070dd|Hitem:169174::::::::120:577::::::|h[도면: 녹슨나사 소형 포탑]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170198] = {
				"|cff0070dd|Hitem:170198::::::::120:577::::::|h[영원한 궁전 식기 묶음]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2264901, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[172501] = {
				"|cff9d9d9d|Hitem:172501::::::::120:262::::::|h[감질나는 감로]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				839406, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160475] = {
				"|cff0070dd|Hitem:160475::::::::120:262::::::|h[나무절단자 요대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1727707, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[152543] = {
				"|cffffffff|Hitem:152543::::::::120:577::::::|h[모래 꼬물치]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057315, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[160987] = {
				"|cff0070dd|Hitem:160987::::::::120:577::::::|h[불완전한 소화의 고리]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1043904, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169431] = {
				"|cff1eff00|Hitem:169431::::::::120:577::::::|h[암초지기 단망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2915285, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169943] = {
				"|cff0070dd|Hitem:169943::::::::120:73::::::|h[꼬마 공주 모자]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1670850, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[170199] = {
				"|cff0070dd|Hitem:170199::::::::120:577::::::|h[잔지르 무기 선반]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2735968, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[172502] = {
				"|cff9d9d9d|Hitem:172502::::::::120:73::::::|h[맛있는 설탕]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				2066015, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160476] = {
				"|cff0070dd|Hitem:160476::::::::120:262::::::|h[안개파도 전쟁장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1727708, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[152544] = {
				"|cffffffff|Hitem:152544::::::::120:577::::::|h[미끈 고등어]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057316, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[154847] = {
				"|cff1eff00|Hitem:154847::::::::120:577::::::|h[콜레인 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1727709, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169688] = {
				"|cff1eff00|Hitem:169688::::::::120:262::::::|h[음반: 놈리건은 영원하리]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[155615] = {
				"|cff9d9d9d|Hitem:155615::::::::120:577::::::|h[전염성 분뇨]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500940, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170200] = {
				"|cff1eff00|Hitem:170200::::::::120:577::::::|h[바다폭풍 토템]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				538570, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[172503] = {
				"|cff9d9d9d|Hitem:172503::::::::120:577::::::|h[벌지기 바이비의 사진]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1505947, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[152545] = {
				"|cffffffff|Hitem:152545::::::::120:577::::::|h[광포한 송곳니 청어]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057311, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[163036] = {
				"|cffffffff|Hitem:163036::::::::120:262::::::|h[광택나는 애완동물 부적]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2004597, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[116477] = {
				"|cff1eff00|Hitem:116477::::::::92:73::::::|h[달빛광휘 석궁]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				920736, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[169689] = {
				"|cff1eff00|Hitem:169689::::::::120:577::::::|h[음반: 미미론의 번뜩이는 생각]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170201] = {
				"|cff1eff00|Hitem:170201::::::::120:577::::::|h[깊은바다 두루마리]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				2830981, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[172504] = {
				"|cff9d9d9d|Hitem:172504::::::::120:73::::::|h[너울파괴수]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132830, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[152546] = {
				"|cffffffff|Hitem:152546::::::::120:577::::::|h[줄돔]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057313, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[160990] = {
				"|cff0070dd|Hitem:160990::::::::120:262::::::|h[매로우의 장식띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1698801, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159199] = {
				"|cff1eff00|Hitem:159199::::::::120:262::::::|h[현자의 영지 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1698804, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169690] = {
				"|cff1eff00|Hitem:169690::::::::120:577::::::|h[음반: 놈리건 전투]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168155] = {
				"|cffffffff|Hitem:168155::::::::120:577::::::|h[미끼]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				350570, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160735] = {
				"|cffffffff|Hitem:160735::::::::120:73::::::|h[애쉬베인 의상]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1063259, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154850] = {
				"|cff1eff00|Hitem:154850::::::::120:577::::::|h[진홍숲 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1733692, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159200] = {
				"|cff1eff00|Hitem:159200::::::::120:262::::::|h[뾰족털 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1733693, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169691] = {
				"|cff1eff00|Hitem:169691::::::::120:262::::::|h[음반: 울두아르 깊은 곳]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[155618] = {
				"|cff9d9d9d|Hitem:155618::::::::120:262::::::|h[버려진 허물]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134306, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154851] = {
				"|cff1eff00|Hitem:154851::::::::120:262::::::|h[진홍숲 짧은바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1733698, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169692] = {
				"|cff1eff00|Hitem:169692::::::::120:577::::::|h[음반: 놈리건의 승리]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[93194] = {
				"|cff9d9d9d|Hitem:93194::::::::120:73::::::|h[피에 젖은 두루마리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133675, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[152549] = {
				"|cffffffff|Hitem:152549::::::::120:577::::::|h[붉은꼬리 미꾸라지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057314, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[159202] = {
				"|cff1eff00|Hitem:159202::::::::120:262::::::|h[뾰족털 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1733698, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[141035] = {
				"|cffffffff|Hitem:141035::::::::102:73::::::|h[각인 기법: 지옥 날개]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				11, -- [6]
			},
			[154853] = {
				"|cff1eff00|Hitem:154853::::::::120:577::::::|h[진홍숲 수도두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1733697, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154854] = {
				"|cff1eff00|Hitem:154854::::::::120:262::::::|h[진홍숲 웃옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159204] = {
				"|cff1eff00|Hitem:159204::::::::120:577::::::|h[뾰족털 두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1733697, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[109060] = {
				"|cff0070dd|Hitem:109060::::::::93:73::::::|h[라일라크 비늘 조끼]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				929917, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154855] = {
				"|cff1eff00|Hitem:154855::::::::120:262::::::|h[진홍숲 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1733699, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159205] = {
				"|cff1eff00|Hitem:159205::::::::120:262::::::|h[뾰족털 조끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[138991] = {
				"|cffffffff|Hitem:138991::::::::99:73::::::|h[악마 피]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				576311, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168161] = {
				"|cff1eff00|Hitem:168161::::::::120:577::::::|h[탈피된 껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1508497, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160485] = {
				"|cffffffff|Hitem:160485::::::::120:577::::::|h[잊을 수 없는 점심]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1529266, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[134130] = {
				"|cffffffff|Hitem:134130::::::::104:73::::::|h[텁수룩한 호랑이 가죽]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134345, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[116481] = {
				"|cff1eff00|Hitem:116481::::::::96:73::::::|h[달빛광휘 총]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				947526, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[134131] = {
				"|cffffffff|Hitem:134131::::::::105:73::::::|h[뻣뻣한 곰 가죽]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				878263, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154857] = {
				"|cff0070dd|Hitem:154857::::::::120:73::::::|h[뼈가시 고리]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391713, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159207] = {
				"|cff1eff00|Hitem:159207::::::::120:262::::::|h[뾰족털 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1733691, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[130171] = {
				"|cff0070dd|Hitem:130171::::::::101:73::::::|h[저주받은 보주]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				644376, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[170466] = {
				"|cffa335ee|Hitem:170466::::::::120:577::::::|h[고철장 고문기]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2618150, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[154858] = {
				"|cff1eff00|Hitem:154858::::::::120:577::::::|h[무덤둔덕 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1726329, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170467] = {
				"|cffa335ee|Hitem:170467::::::::120:577::::::|h[예리한 사슬칼날]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2618146, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[154859] = {
				"|cff1eff00|Hitem:154859::::::::120:262::::::|h[무덤둔덕 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1726331, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170468] = {
				"|cffa335ee|Hitem:170468::::::::120:577::::::|h[초고전압 충격기]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				2735166, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[154860] = {
				"|cff1eff00|Hitem:154860::::::::120:262::::::|h[무덤둔덕 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1726333, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[137717] = {
				"|cffffffff|Hitem:137717::::::::106:73::::::|h[설계도: 쌍총신 머리 대포]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				3, -- [6]
			},
			[174819] = {
				"|cff9d9d9d|Hitem:174819::::::::120:262::::::|h[부서진 아퀴르 우상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134896, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159211] = {
				"|cff1eff00|Hitem:159211::::::::120:262::::::|h[어스름 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1726330, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[113541] = {
				"|cff0070dd|Hitem:113541::::::::96:73::::::|h[어둠발톱의 외투]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1035455, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[155629] = {
				"|cff9d9d9d|Hitem:155629::::::::120:262::::::|h[낡은 갈기털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237419, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170470] = {
				"|cffa335ee|Hitem:170470::::::::120:577::::::|h[강화된 기름 방패]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHIELD", -- [3]
				2902485, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[166888] = {
				"|cff1eff00|Hitem:166888::::::::120:577::::::|h[싹틔우는 씨앗]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				464030, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[154862] = {
				"|cff1eff00|Hitem:154862::::::::120:262::::::|h[무덤둔덕 코이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1726334, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159212] = {
				"|cff1eff00|Hitem:159212::::::::120:262::::::|h[어스름 코이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1726334, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[94223] = {
				"|cff0070dd|Hitem:94223::::::::90:73::::::|h[도둑맞은 음영파 휘장]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				645204, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[86547] = {
				"|cffa335ee|Hitem:86547::::::::120:73::::::|h[하늘조각]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				237230, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154863] = {
				"|cff1eff00|Hitem:154863::::::::120:577::::::|h[무덤둔덕 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1726335, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165610] = {
				"|cff0070dd|Hitem:165610::::::::120:73::::::|h[역병인도자의 단도]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2103032, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[155631] = {
				"|cff9d9d9d|Hitem:155631::::::::120:262::::::|h[마력을 잃은 돌]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135233, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162028] = {
				"|cffffffff|Hitem:162028::::::::120:262::::::|h[각인 기법: 파도돌고래]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				11, -- [6]
			},
			[170472] = {
				"|cff0070dd|Hitem:170472::::::::120:577::::::|h[딱딱한 동전]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2744751, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[174822] = {
				"|cff9d9d9d|Hitem:174822::::::::120:577::::::|h[찢어진 룬장식 주머니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133637, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154864] = {
				"|cff1eff00|Hitem:154864::::::::120:262::::::|h[무덤둔덕 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1726336, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159214] = {
				"|cff1eff00|Hitem:159214::::::::120:262::::::|h[어스름 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1726336, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165611] = {
				"|cff0070dd|Hitem:165611::::::::120:73::::::|h[죽음추적자의 두개골분쇄기]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2127474, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[174823] = {
				"|cff9d9d9d|Hitem:174823::::::::120:577::::::|h[소형 울둠의 원반 복제품]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134375, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154865] = {
				"|cff1eff00|Hitem:154865::::::::120:262::::::|h[무덤둔덕 쇠사슬갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1726332, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159215] = {
				"|cff1eff00|Hitem:159215::::::::120:262::::::|h[어스름 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1726332, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[174824] = {
				"|cff9d9d9d|Hitem:174824::::::::120:577::::::|h[고갈된 영혼 루비]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134130, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161007] = {
				"|cff0070dd|Hitem:161007::::::::120:73::::::|h[공포뿔 징 무릎바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[85781] = {
				"|cff9d9d9d|Hitem:85781::::::::120:73::::::|h[행운의 판다렌 동전]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133784, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165613] = {
				"|cff0070dd|Hitem:165613::::::::120:73::::::|h[역병인도자의 미늘창]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2406764, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[94225] = {
				"|cff0070dd|Hitem:94225::::::::90:73::::::|h[도둑맞은 천신회 휘장]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				636337, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[102541] = {
				"|cff1eff00|Hitem:102541::::::::120:73::::::|h[숙성된 발사믹 식초]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132797, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[170475] = {
				"|cff1eff00|Hitem:170475::::::::120:577::::::|h[마디바스의 차원 차압 창작품]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_BAG", -- [3]
				134430, -- [4]
				1, -- [5]
				0, -- [6]
			},
			[174825] = {
				"|cff9d9d9d|Hitem:174825::::::::120:577::::::|h[호박석 덩어리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				646670, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159217] = {
				"|cff1eff00|Hitem:159217::::::::120:262::::::|h[현자의 영지 머리장식]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1698807, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159473] = {
				"|cff1eff00|Hitem:159473::::::::120:262::::::|h[조선소 도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[155635] = {
				"|cff9d9d9d|Hitem:155635::::::::120:262::::::|h[튼튼한 날개]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134002, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[174826] = {
				"|cff9d9d9d|Hitem:174826::::::::120:577::::::|h[부서질 듯한 의식용 창]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135128, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159218] = {
				"|cff1eff00|Hitem:159218::::::::120:262::::::|h[현자의 영지 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159474] = {
				"|cff1eff00|Hitem:159474::::::::120:262::::::|h[파도수호병 손도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[94226] = {
				"|cff0070dd|Hitem:94226::::::::90:73::::::|h[도둑맞은 클락시 휘장]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				646377, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[102542] = {
				"|cff1eff00|Hitem:102542::::::::120:73::::::|h[고대 판다렌 향료]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133590, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[170477] = {
				"|cffa335ee|Hitem:170477::::::::120:577::::::|h[마디바스의 누구든 떠받드는 가방]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				133660, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159219] = {
				"|cff1eff00|Hitem:159219::::::::120:262::::::|h[현자의 영지 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1698808, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163569] = {
				"|cffffffff|Hitem:163569::::::::120:577::::::|h[단열 배선]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133243, -- [4]
				7, -- [5]
				1, -- [6]
			},
			[137726] = {
				"|cffffffff|Hitem:137726::::::::102:73::::::|h[설계도: 지맥 부표]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				3, -- [6]
			},
			[173293] = {
				"|cff1eff00|Hitem:173293::::::::120:262::::::|h[자기 보호의 약병]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132793, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[116488] = {
				"|cff1eff00|Hitem:116488::::::::96:73::::::|h[달빛광휘 검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1068836, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[159476] = {
				"|cff1eff00|Hitem:159476::::::::120:577::::::|h[황금 함대 전쟁도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1721570, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[94227] = {
				"|cff0070dd|Hitem:94227::::::::90:73::::::|h[도둑맞은 황금 연꽃 휘장]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				643910, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[141565] = {
				"|cffa335ee|Hitem:141565::::::::106:73::::::|h[미르의 사로잡는 손아귀]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				1306776, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[136704] = {
				"|cffffffff|Hitem:136704::::::::104:73::::::|h[주문식: 무결점 가닥]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134941, -- [4]
				9, -- [5]
				8, -- [6]
			},
			[159477] = {
				"|cff1eff00|Hitem:159477::::::::120:577::::::|h[조칼리 새김도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1721570, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[141566] = {
				"|cffa335ee|Hitem:141566::::::::104:73::::::|h[세린의 해로운 습관]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HEAD", -- [3]
				1336646, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158710] = {
				"|cff0070dd|Hitem:158710::::::::120:262::::::|h[뿔꼬챙이의 철퇴]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[171248] = {
				"|cffffffff|Hitem:171248::::::::120:262::::::|h[시험생산형 주입물]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				986489, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[116489] = {
				"|cff1eff00|Hitem:116489::::::::96:73::::::|h[달빛광휘 대검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				922559, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[139520] = {
				"|cffffffff|Hitem:139520::::::::98:73::::::|h[열기가 느껴지는 탄원]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134332, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[137729] = {
				"|cff0070dd|Hitem:137729::::::::106:73::::::|h[각인 기법: 고요한 정신의 전서]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1387620, -- [4]
				9, -- [5]
				11, -- [6]
			},
			[159223] = {
				"|cff1eff00|Hitem:159223::::::::120:262::::::|h[현자의 영지 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1698803, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163573] = {
				"|cffa335ee|Hitem:163573::::::::120:577::::::|h[황금갈기의 고삐]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				132261, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[139521] = {
				"|cffffffff|Hitem:139521::::::::98:73::::::|h[그슬린 쪽지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134945, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168435] = {
				"|cffa335ee|Hitem:168435::::::::120:577::::::|h[원격조종 회로 우회기]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134390, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[163062] = {
				"|cff9d9d9d|Hitem:163062::::::::120:73::::::|h[조잡한 사우리드 입상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134232, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165621] = {
				"|cff0070dd|Hitem:165621::::::::120:73::::::|h[명사수 손대포]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				2439521, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[118793] = {
				"|cff0070dd|Hitem:118793::::::::94:73::::::|h[쿠그라르의 주문 쐐기]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1003750, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[141569] = {
				"|cffa335ee|Hitem:141569::::::::104:73::::::|h[삼노아의 뛰어난 다리보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				1335535, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163575] = {
				"|cffa335ee|Hitem:163575::::::::120:73::::::|h[정맥수색 펄떡이 고삐]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1618564, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[139523] = {
				"|cffffffff|Hitem:139523::::::::104:73::::::|h[열기가 느껴지는 편지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134331, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[136709] = {
				"|cffffffff|Hitem:136709::::::::99:73::::::|h[도면: 악마강철 등자]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				4, -- [6]
			},
			[163576] = {
				"|cffa335ee|Hitem:163576::::::::120:577::::::|h[포획한 사막 청소부]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1519598, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[165879] = {
				"|cffffffff|Hitem:165879::::::::120:577::::::|h[짭짤한 소금]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134386, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[141571] = {
				"|cffa335ee|Hitem:141571::::::::105:73::::::|h[마바나의 변화하는 손목보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				1408493, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163065] = {
				"|cff9d9d9d|Hitem:163065::::::::120:577::::::|h[엄니 밀랍]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134743, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[139525] = {
				"|cffffffff|Hitem:139525::::::::106:73::::::|h[구겨진 쪽지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133673, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163066] = {
				"|cff9d9d9d|Hitem:163066::::::::120:73::::::|h[석회화한 모기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463485, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[116492] = {
				"|cff1eff00|Hitem:116492::::::::96:73::::::|h[덩굴에 휩싸인 넓적도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				925570, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[139526] = {
				"|cffffffff|Hitem:139526::::::::101:73::::::|h[열기가 느껴지는 쪽지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133209, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[152576] = {
				"|cffffffff|Hitem:152576::::::::120:262::::::|h[파도안개 리넨]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2067081, -- [4]
				7, -- [5]
				5, -- [6]
			},
			[163067] = {
				"|cff9d9d9d|Hitem:163067::::::::120:73::::::|h[자쿤다 이빨]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518096, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168185] = {
				"|cffffffff|Hitem:168185::::::::120:577::::::|h[오스미나이트 광석]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2543233, -- [4]
				7, -- [5]
				7, -- [6]
			},
			[152577] = {
				"|cff1eff00|Hitem:152577::::::::120:262::::::|h[심해 명주]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2067080, -- [4]
				7, -- [5]
				5, -- [6]
			},
			[163068] = {
				"|cff9d9d9d|Hitem:163068::::::::120:577::::::|h[칼부리 깃털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132917, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[141575] = {
				"|cffa335ee|Hitem:141575::::::::104:73::::::|h[고로그의 잔잔한 눈길]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HEAD", -- [3]
				1318381, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170489] = {
				"|cffffffff|Hitem:170489::::::::120:577::::::|h[마디바스의 손수 만든 손가방]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133644, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162557] = {
				"|cffffffff|Hitem:162557::::::::120:73::::::|h[절인 개구리 다리]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				644276, -- [4]
				0, -- [5]
				5, -- [6]
			},
			[163069] = {
				"|cff9d9d9d|Hitem:163069::::::::120:73::::::|h[저주받은 동전]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237281, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163581] = {
				"|cff9d9d9d|Hitem:163581::::::::120:577::::::|h[부실한 스톰윈드 왕궁 모형]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1033989, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[167931] = {
				"|cff0070dd|Hitem:167931::::::::120:577::::::|h[메카곤식 톱날]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134427, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[141576] = {
				"|cffa335ee|Hitem:141576::::::::106:73::::::|h[에이트린의 늘 따뜻한 가슴갑옷]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_ROBE", -- [3]
				1316217, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163070] = {
				"|cff9d9d9d|Hitem:163070::::::::120:577::::::|h[구겨진 모자]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				236571, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[116494] = {
				"|cff1eff00|Hitem:116494::::::::93:73::::::|h[덩굴에 휩싸인 석궁]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				920736, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[165629] = {
				"|cff0070dd|Hitem:165629::::::::120:73::::::|h[파수꾼의 마법단검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2180709, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[139530] = {
				"|cffffffff|Hitem:139530::::::::106:73::::::|h[그을린 편지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134942, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163071] = {
				"|cff9d9d9d|Hitem:163071::::::::120:73::::::|h[구린내폭탄 껍데기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133709, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[139531] = {
				"|cffffffff|Hitem:139531::::::::106:73::::::|h[구겨진 요청서]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134940, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158210] = {
				"|cff9d9d9d|Hitem:158210::::::::120:577::::::|h[무시무시한 발톱]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1508515, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[116495] = {
				"|cff1eff00|Hitem:116495::::::::94:73::::::|h[덩굴에 휩싸인 단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				924154, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[139532] = {
				"|cffffffff|Hitem:139532::::::::104:73::::::|h[열기가 느껴지는 기도문]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134471, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161026] = {
				"|cff0070dd|Hitem:161026::::::::120:262::::::|h[거미이빨 손목싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1674412, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165632] = {
				"|cff0070dd|Hitem:165632::::::::120:73::::::|h[파수꾼의 대검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2449692, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[169215] = {
				"|cffffffff|Hitem:169215::::::::120:577::::::|h[은 손칼]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				454059, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[116496] = {
				"|cff1eff00|Hitem:116496::::::::93:73::::::|h[성장술사 마법단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				926765, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[139534] = {
				"|cffffffff|Hitem:139534::::::::104:73::::::|h[피투성이 편지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				633007, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169216] = {
				"|cffffffff|Hitem:169216::::::::120:577::::::|h[은 손칼]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				454059, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163587] = {
				"|cff9d9d9d|Hitem:163587::::::::120:577::::::|h[버려진 잔달라 브로치]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				2032601, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[139535] = {
				"|cffffffff|Hitem:139535::::::::104:73::::::|h[피투성이 기도문]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1392955, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[138000] = {
				"|cffffffff|Hitem:138000::::::::106:73::::::|h[도안: 마력 깃든 비단매듭 그늘막]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				2, -- [6]
			},
			[161029] = {
				"|cff0070dd|Hitem:161029::::::::120:73::::::|h[불로의 독성 손장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159494] = {
				"|cff1eff00|Hitem:159494::::::::120:262::::::|h[윈터세일 연발 석궁]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1695549, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[129035] = {
				"|cff0070dd|Hitem:129035::::::::106:73::::::|h[불굴의 곰가죽 망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1325257, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[141583] = {
				"|cffa335ee|Hitem:141583::::::::103:73::::::|h[사미드의 환영 반지]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391705, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[158215] = {
				"|cff0070dd|Hitem:158215::::::::120:262::::::|h[휘리릭날개의 깃털]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103843, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[138001] = {
				"|cff0070dd|Hitem:138001::::::::109:73::::::|h[도안: 마력 깃든 비단매듭 그늘막]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				2, -- [6]
			},
			[169218] = {
				"|cff0070dd|Hitem:169218::::::::120:577::::::|h[낡고 녹슨 열쇠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134245, -- [4]
				13, -- [5]
				0, -- [6]
			},
			[163845] = {
				"|cff9d9d9d|Hitem:163845::::::::120:73::::::|h[은 동상 받침대]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				348553, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158216] = {
				"|cff0070dd|Hitem:158216::::::::120:73::::::|h[살아있는 기름통]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1131085, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[163078] = {
				"|cff9d9d9d|Hitem:163078::::::::120:577::::::|h[반짝이는 귀걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133857, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169475] = {
				"|cff1eff00|Hitem:169475::::::::120:577::::::|h[따개비가 붙은 금고]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				644388, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163590] = {
				"|cff9d9d9d|Hitem:163590::::::::120:262::::::|h[근심 가득한 로아 조각상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134452, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163846] = {
				"|cff9d9d9d|Hitem:163846::::::::120:73::::::|h[은 원숭이 머리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				877482, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[109078] = {
				"|cff0070dd|Hitem:109078::::::::93:73::::::|h[살육아귀의 송곳니]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				135705, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[163079] = {
				"|cff9d9d9d|Hitem:163079::::::::120:577::::::|h[부스러진 전리품 엄니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				236697, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163591] = {
				"|cff9d9d9d|Hitem:163591::::::::120:262::::::|h[황금 함대 해도]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237387, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163847] = {
				"|cff9d9d9d|Hitem:163847::::::::120:73::::::|h[은 원숭이 몸통]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				646680, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[141586] = {
				"|cffa335ee|Hitem:141586::::::::98:73::::::|h[마르피시의 거대 향로]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				651740, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[158218] = {
				"|cff0070dd|Hitem:158218::::::::120:577::::::|h[다달리아의 날개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103910, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[138004] = {
				"|cff0070dd|Hitem:138004::::::::102:73::::::|h[도안: 마력 깃든 비단매듭 장막]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				2, -- [6]
			},
			[163080] = {
				"|cff9d9d9d|Hitem:163080::::::::120:577::::::|h[반쯤 먹힌 해과일]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133960, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169477] = {
				"|cffa335ee|Hitem:169477::::::::120:577::::::|h[해저 요대]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002873, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[163592] = {
				"|cff9d9d9d|Hitem:163592::::::::120:577::::::|h[의식용 코걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1408444, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163848] = {
				"|cff9d9d9d|Hitem:163848::::::::120:577::::::|h[과다사용 부두 인형]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				458256, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168198] = {
				"|cffffffff|Hitem:168198::::::::120:577::::::|h[맹독 방울]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				132108, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161034] = {
				"|cff0070dd|Hitem:161034::::::::120:577::::::|h[천둥울음 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169478] = {
				"|cffa335ee|Hitem:169478::::::::120:577::::::|h[해저 팔보호구]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002875, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[163593] = {
				"|cff9d9d9d|Hitem:163593::::::::120:577::::::|h[잔달라 무역풍 지도]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163849] = {
				"|cff9d9d9d|Hitem:163849::::::::120:577::::::|h[나쁜 트롤의 연시]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134332, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170502] = {
				"|cffa335ee|Hitem:170502::::::::120:577::::::|h[물에 젖은 도구상자]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1529271, -- [4]
				0, -- [5]
				0, -- [6]
			},
			[87586] = {
				"|cff0070dd|Hitem:87586::::::::83:73::::::|h[숲 마귀의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				604464, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161035] = {
				"|cff0070dd|Hitem:161035::::::::120:73::::::|h[천둥충돌 발등덮개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169479] = {
				"|cffa335ee|Hitem:169479::::::::120:577::::::|h[해저 투구]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002878, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[106393] = {
				"|cff1eff00|Hitem:106393::::::::93:73::::::|h[칼날첨탑 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				947378, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163850] = {
				"|cff9d9d9d|Hitem:163850::::::::120:577::::::|h[사냥터지기의 피투성이 팔]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				999951, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[139542] = {
				"|cff9d9d9d|Hitem:139542::::::::120:577::::::|h[돛천 자락]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237276, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162571] = {
				"|cffffffff|Hitem:162571::::::::120:262::::::|h[눅눅한 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169224] = {
				"|cffffffff|Hitem:169224::::::::120:577::::::|h[큰 적색 단추]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				986488, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169480] = {
				"|cffa335ee|Hitem:169480::::::::120:577::::::|h[해저 가슴보호대]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002876, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[87587] = {
				"|cff0070dd|Hitem:87587::::::::83:73::::::|h[과수원 관리인의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				609751, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169225] = {
				"|cff1eff00|Hitem:169225::::::::120:577::::::|h[멈추지 않는 초시계]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132995, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169481] = {
				"|cffa335ee|Hitem:169481::::::::120:577::::::|h[해저 망토]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1625010, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[163852] = {
				"|cffffffff|Hitem:163852::::::::120:577::::::|h[토르톨란 순례자의 두루마리]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1500871, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170505] = {
				"|cffa335ee|Hitem:170505::::::::120:577::::::|h[때 묻은 마나진주 팔찌]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				415050, -- [4]
				0, -- [5]
				0, -- [6]
			},
			[138009] = {
				"|cffffffff|Hitem:138009::::::::101:73::::::|h[도안: 마력 깃든 비단매듭 외투]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				2, -- [6]
			},
			[169226] = {
				"|cff0070dd|Hitem:169226::::::::120:577::::::|h[찢어진 악보]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1392954, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169482] = {
				"|cffa335ee|Hitem:169482::::::::120:577::::::|h[해저 다리보호구]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002879, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[113559] = {
				"|cff0070dd|Hitem:113559::::::::96:73::::::|h[공허한 예언 곤봉]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				925571, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[158224] = {
				"|cff0070dd|Hitem:158224::::::::120:262::::::|h[폭풍의 약병]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				134800, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[87588] = {
				"|cff0070dd|Hitem:87588::::::::83:73::::::|h[정령노랫가락의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				646764, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169227] = {
				"|cffffffff|Hitem:169227::::::::120:577::::::|h[방사능에 노출된 볼트]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133008, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169483] = {
				"|cffa335ee|Hitem:169483::::::::120:577::::::|h[해저 발보호대]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002874, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[106395] = {
				"|cff1eff00|Hitem:106395::::::::94:73::::::|h[칼날첨탑 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				947380, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154899] = {
				"|cffffffff|Hitem:154899::::::::120:577::::::|h[무식하게 두꺼운 스테이크]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066022, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[169484] = {
				"|cffa335ee|Hitem:169484::::::::120:577::::::|h[해저 어깨덮개]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002881, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[87589] = {
				"|cff0070dd|Hitem:87589::::::::83:73::::::|h[흩어진 투영의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				615171, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163088] = {
				"|cff9d9d9d|Hitem:163088::::::::120:577::::::|h[정말 평범한 빗자루]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				655994, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169485] = {
				"|cffa335ee|Hitem:169485::::::::120:577::::::|h[해저 건틀릿]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1002877, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[106396] = {
				"|cff1eff00|Hitem:106396::::::::92:73::::::|h[칼날첨탑 발덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				947374, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163856] = {
				"|cffffffff|Hitem:163856::::::::120:577::::::|h[고대 순례자의 두루마리통]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				454060, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154389] = {
				"|cff0070dd|Hitem:154389::::::::120:73::::::|h[심연독사 견갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1727714, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163089] = {
				"|cff9d9d9d|Hitem:163089::::::::120:577::::::|h[오랜 시간 막힌 배출관]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134374, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[87590] = {
				"|cff0070dd|Hitem:87590::::::::83:73::::::|h[비취 심장 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				604464, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169231] = {
				"|cff0070dd|Hitem:169231::::::::120:577::::::|h[시각 효과 무효화 드라이브]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				321487, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[106397] = {
				"|cff1eff00|Hitem:106397::::::::93:73::::::|h[동상 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				942783, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[163091] = {
				"|cff9d9d9d|Hitem:163091::::::::120:262::::::|h[보석 박힌 망원경]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133033, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159509] = {
				"|cff1eff00|Hitem:159509::::::::120:262::::::|h[옹이나무 쐐기]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1730356, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[170512] = {
				"|cffffffff|Hitem:170512::::::::120:577::::::|h[하급 해저 비전수정]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1033170, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[162580] = {
				"|cffffffff|Hitem:162580::::::::120:262::::::|h[색 바랜 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[87591] = {
				"|cff0070dd|Hitem:87591::::::::83:73::::::|h[티엔 수련생 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				609751, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169233] = {
				"|cff1eff00|Hitem:169233::::::::120:577::::::|h[무한 회전 용수철]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				134065, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[106398] = {
				"|cff1eff00|Hitem:106398::::::::92:73::::::|h[칼날첨탑 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				947375, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[162581] = {
				"|cffffffff|Hitem:162581::::::::120:262::::::|h[누렇게 변한 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158743] = {
				"|cff9d9d9d|Hitem:158743::::::::120:577::::::|h[전도성 더듬이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237584, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163093] = {
				"|cff9d9d9d|Hitem:163093::::::::120:577::::::|h[마녀의 의식용 분필]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133751, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159511] = {
				"|cff1eff00|Hitem:159511::::::::120:72::::::|h[파도술사 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1730356, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[87592] = {
				"|cff0070dd|Hitem:87592::::::::83:73::::::|h[그루끼끼 바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				646764, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169235] = {
				"|cff1eff00|Hitem:169235::::::::120:577::::::|h[혼돈의 용수철 상자]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132997, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[116506] = {
				"|cff1eff00|Hitem:116506::::::::93:73::::::|h[덩굴에 휩싸인 대검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				922559, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[174353] = {
				"|cffffffff|Hitem:174353::::::::120:577::::::|h[미심쩍은 고기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1045941, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[158745] = {
				"|cff9d9d9d|Hitem:158745::::::::120:577::::::|h[영롱한 비늘]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				642723, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169236] = {
				"|cff1eff00|Hitem:169236::::::::120:577::::::|h[걸쇠와 자물쇠 연결 장치]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1405812, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[162584] = {
				"|cffffffff|Hitem:162584::::::::120:262::::::|h[그을린 보물 지도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237388, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[87593] = {
				"|cff0070dd|Hitem:87593::::::::83:73::::::|h[간 스 장군의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				615171, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169237] = {
				"|cffffffff|Hitem:169237::::::::120:577::::::|h[고동치는 대리석]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2057562, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[155164] = {
				"|cff0070dd|Hitem:155164::::::::120:577::::::|h[녹주석 파도 큰망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1698804, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[106400] = {
				"|cff1eff00|Hitem:106400::::::::93:73::::::|h[얼음주둥이 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				940655, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158747] = {
				"|cff9d9d9d|Hitem:158747::::::::120:262::::::|h[따가운 가시]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134203, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169238] = {
				"|cff0070dd|Hitem:169238::::::::120:577::::::|h[변형된 라디오 수신기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1405806, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168215] = {
				"|cffffffff|Hitem:168215::::::::120:577::::::|h[기계 장치 조립체]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				986486, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[87594] = {
				"|cff0070dd|Hitem:87594::::::::83:73::::::|h[잊혀진 전쟁의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				615171, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169239] = {
				"|cff0070dd|Hitem:169239::::::::120:577::::::|h[알 수 없는 큐브]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2000858, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169495] = {
				"|cffa335ee|Hitem:169495::::::::120:577::::::|h[조제법: 최상급 민첩의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[155422] = {
				"|cff0070dd|Hitem:155422::::::::120:262::::::|h[해적 대장의 작살총]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1695549, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[168216] = {
				"|cffffffff|Hitem:168216::::::::120:577::::::|h[담금질한 판]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				463887, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169496] = {
				"|cffa335ee|Hitem:169496::::::::120:577::::::|h[조제법: 최상급 강철피부 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[121754] = {
				"|cff0070dd|Hitem:121754::::::::104:73::::::|h[마나로 얼룩진 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1134730, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168217] = {
				"|cffffffff|Hitem:168217::::::::120:577::::::|h[경화 용수철]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134065, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[87595] = {
				"|cff0070dd|Hitem:87595::::::::91:73::::::|h[땅굴 탐험의 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				609749, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161053] = {
				"|cffffffff|Hitem:161053::::::::120:577::::::|h[짭짤한 바다 크래커]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				646175, -- [4]
				15, -- [5]
				1, -- [6]
			},
			[169497] = {
				"|cffa335ee|Hitem:169497::::::::120:577::::::|h[조제법: 최상급 지능의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[159518] = {
				"|cff0070dd|Hitem:159518::::::::120:73::::::|h[긴 송곳니]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720213, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[158751] = {
				"|cff9d9d9d|Hitem:158751::::::::120:577::::::|h[헝클어진 가죽]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134363, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169498] = {
				"|cffa335ee|Hitem:169498::::::::120:577::::::|h[조제법: 최상급 체력의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[159519] = {
				"|cff1eff00|Hitem:159519::::::::120:262::::::|h[강철문장 나이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720215, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[158752] = {
				"|cff9d9d9d|Hitem:158752::::::::120:262::::::|h[잘린 발]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1509634, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169499] = {
				"|cffa335ee|Hitem:169499::::::::120:577::::::|h[조제법: 최상급 힘의 전투 물약]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[159520] = {
				"|cff1eff00|Hitem:159520::::::::120:262::::::|h[산호껍질 단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720215, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[174873] = {
				"|cff0070dd|Hitem:174873::::::::120:262::::::|h[모구 변신 장치]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				801008, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159265] = {
				"|cff1eff00|Hitem:159265::::::::120:262::::::|h[소금물 작업장 외투]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1727718, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159521] = {
				"|cff1eff00|Hitem:159521::::::::120:262::::::|h[조선소 단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720214, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[164383] = {
				"|cffa335ee|Hitem:164383::::::::120:262::::::|h[죽음탐식 요대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				2054624, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[87597] = {
				"|cff0070dd|Hitem:87597::::::::91:73::::::|h[응결된 안개의 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				604462, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159522] = {
				"|cff1eff00|Hitem:159522::::::::120:262::::::|h[사슴심장 나이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720214, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[169246] = {
				"|cffffffff|Hitem:169246::::::::120:262::::::|h[이상한 양념을 친 고기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1046249, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[166432] = {
				"|cffa335ee|Hitem:166432::::::::120:73::::::|h[잿빛 골짜기 키메라]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2406628, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[87598] = {
				"|cff0070dd|Hitem:87598::::::::91:73::::::|h[기괴한 명주 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				604462, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169247] = {
				"|cffffffff|Hitem:169247::::::::120:262::::::|h[투척용 돌]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1044087, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[159524] = {
				"|cff1eff00|Hitem:159524::::::::120:262::::::|h[함선좌초자 나이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1720213, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[164386] = {
				"|cffa335ee|Hitem:164386::::::::120:577::::::|h[물어뜯는 바람의 요대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				2054624, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158757] = {
				"|cff9d9d9d|Hitem:158757::::::::120:73::::::|h[동요의 흙]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				399041, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169248] = {
				"|cffffffff|Hitem:169248::::::::120:262::::::|h[망가진 덧신]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				132579, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158758] = {
				"|cff9d9d9d|Hitem:158758::::::::120:577::::::|h[로열젤리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500971, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169249] = {
				"|cffffffff|Hitem:169249::::::::120:262::::::|h[상어이빨 목걸이]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				338666, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158759] = {
				"|cff9d9d9d|Hitem:158759::::::::120:262::::::|h[피가 밴 주머니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134343, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169250] = {
				"|cffffffff|Hitem:169250::::::::120:262::::::|h[조잡한 식기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				794853, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[159527] = {
				"|cff1eff00|Hitem:159527::::::::120:577::::::|h[로아의 축복을 받은 송곳니칼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1686940, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[158760] = {
				"|cff9d9d9d|Hitem:158760::::::::120:262::::::|h[지느러미줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134882, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169251] = {
				"|cffffffff|Hitem:169251::::::::120:262::::::|h[고대 벌레]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				516338, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[136755] = {
				"|cff1eff00|Hitem:136755::::::::101:73::::::|h[섬 감시자의 손장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1137680, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159528] = {
				"|cff1eff00|Hitem:159528::::::::120:577::::::|h[젬란 단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1686940, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[154411] = {
				"|cff0070dd|Hitem:154411::::::::120:577::::::|h[블라로스 라이플]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1719413, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[169252] = {
				"|cffffffff|Hitem:169252::::::::120:262::::::|h[공명의 진주]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				464023, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[87217] = {
				"|cff1eff00|Hitem:87217::::::::120:73::::::|h[물품이 든 작은 자루]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133642, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168741] = {
				"|cffa335ee|Hitem:168741::::::::120:577::::::|h[강인한 정제 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[87601] = {
				"|cff0070dd|Hitem:87601::::::::91:73::::::|h[쟁기끌이 손장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				615169, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163112] = {
				"|cff9d9d9d|Hitem:163112::::::::120:577::::::|h[임프의 혓바닥 부적]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				648547, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159530] = {
				"|cff1eff00|Hitem:159530::::::::114:73::::::|h[강늪지 비수]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1686940, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[141875] = {
				"|cff0070dd|Hitem:141875::::::::99:73::::::|h[분노칼날의 갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1116924, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168742] = {
				"|cffa335ee|Hitem:168742::::::::120:577::::::|h[강인한 적응성 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[163113] = {
				"|cff9d9d9d|Hitem:163113::::::::120:262::::::|h[부식된 구리 솥]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				629057, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159531] = {
				"|cff1eff00|Hitem:159531::::::::120:577::::::|h[전쟁항구 단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1670852, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[168487] = {
				"|cffffffff|Hitem:168487::::::::120:577::::::|h[진모래말미꽃]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2563958, -- [4]
				7, -- [5]
				9, -- [6]
			},
			[168743] = {
				"|cffa335ee|Hitem:168743::::::::120:577::::::|h[강인한 능률적 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[87602] = {
				"|cff0070dd|Hitem:87602::::::::91:73::::::|h[곡식 감시자의 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				615169, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169255] = {
				"|cffffffff|Hitem:169255::::::::120:262::::::|h[빨간 털 뭉치]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237421, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[106409] = {
				"|cff1eff00|Hitem:106409::::::::92:73::::::|h[달빛광휘 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				937858, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168744] = {
				"|cffa335ee|Hitem:168744::::::::120:577::::::|h[최적화된 능률적 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[158765] = {
				"|cff9d9d9d|Hitem:158765::::::::120:262::::::|h[바위껍칠 연체동물]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133797, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168745] = {
				"|cffa335ee|Hitem:168745::::::::120:577::::::|h[최적화된 유효 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[87603] = {
				"|cff0070dd|Hitem:87603::::::::91:73::::::|h[천둥 골짜기 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				615169, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169257] = {
				"|cffffffff|Hitem:169257::::::::120:262::::::|h[이빠진 룬]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134417, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[136761] = {
				"|cff1eff00|Hitem:136761::::::::101:73::::::|h[금고 관리자의 장식끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1134722, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[116773] = {
				"|cffa335ee|Hitem:116773::::::::93:73::::::|h[날쌘 산들바람 탈부크]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1032613, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[168490] = {
				"|cff0070dd|Hitem:168490::::::::120:262::::::|h[도면: 프로토콜 이전 장치]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168746] = {
				"|cffa335ee|Hitem:168746::::::::120:577::::::|h[최적화된 적응성 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[159535] = {
				"|cff1eff00|Hitem:159535::::::::120:577::::::|h[파도술사 철퇴]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1733923, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[87220] = {
				"|cff0070dd|Hitem:87220::::::::120:73::::::|h[수수께끼의 큰 자루]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133665, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168491] = {
				"|cff0070dd|Hitem:168491::::::::120:262::::::|h[도면: 개인용 시간 재배열기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168747] = {
				"|cffa335ee|Hitem:168747::::::::120:577::::::|h[고성능 적응성 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[159280] = {
				"|cff1eff00|Hitem:159280::::::::120:262::::::|h[진홍숲 외투]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1733694, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168748] = {
				"|cffa335ee|Hitem:168748::::::::120:577::::::|h[고성능 정제 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[86581] = {
				"|cff0070dd|Hitem:86581::::::::120:577::::::|h[머나먼 물의 소라]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133797, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159537] = {
				"|cff1eff00|Hitem:159537::::::::120:73::::::|h[심연지기 망치]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1733923, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[168749] = {
				"|cffa335ee|Hitem:168749::::::::120:577::::::|h[고성능 유효 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[158770] = {
				"|cff9d9d9d|Hitem:158770::::::::120:262::::::|h[끈끈한 어란]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1387651, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168750] = {
				"|cffa335ee|Hitem:168750::::::::120:577::::::|h[다목적 정제 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[158771] = {
				"|cff9d9d9d|Hitem:158771::::::::120:73::::::|h[영혼 수액]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				651086, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159283] = {
				"|cff1eff00|Hitem:159283::::::::120:262::::::|h[무덤둔덕 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1726328, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159539] = {
				"|cff1eff00|Hitem:159539::::::::120:262::::::|h[강철문장 곤봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[168751] = {
				"|cffa335ee|Hitem:168751::::::::120:577::::::|h[다목적 유효 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[152631] = {
				"|cffffffff|Hitem:152631::::::::120:577::::::|h[빙해 고기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066003, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[159284] = {
				"|cff1eff00|Hitem:159284::::::::120:262::::::|h[콜레인 단망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1727718, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159540] = {
				"|cff1eff00|Hitem:159540::::::::120:262::::::|h[산호껍질 망치]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[168752] = {
				"|cffa335ee|Hitem:168752::::::::120:577::::::|h[다목적 능률적 논리 기판]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134394, -- [4]
				3, -- [5]
				9, -- [6]
			},
			[86583] = {
				"|cff0070dd|Hitem:86583::::::::91:73::::::|h[살리인 전투 깃발]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132484, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160053] = {
				"|cff0070dd|Hitem:160053::::::::120:262::::::|h[전투 흉터 증강의 룬]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				840006, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[162612] = {
				"|cff0070dd|Hitem:162612::::::::120:577::::::|h[코브라 사제의 머리장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1762578, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[118824] = {
				"|cff0070dd|Hitem:118824::::::::92:73::::::|h[녹시아의 수갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				961486, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162613] = {
				"|cff0070dd|Hitem:162613::::::::114:73::::::|h[무리 의태의 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1762580, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158775] = {
				"|cff9d9d9d|Hitem:158775::::::::120:577::::::|h[꾸덕한 벌집밀랍]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500915, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159799] = {
				"|cff1eff00|Hitem:159799::::::::120:262::::::|h[윈터세일 보루 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723691, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[169779] = {
				"|cffffffff|Hitem:169779::::::::120:577::::::|h[찌그러진 바위비늘]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1526633, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[168244] = {
				"|cff1eff00|Hitem:168244::::::::120:577::::::|h[[PH] Treasure Reward]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1686587, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[87225] = {
				"|cff0070dd|Hitem:87225::::::::120:73::::::|h[음식이 든 큰 자루]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133642, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158778] = {
				"|cff9d9d9d|Hitem:158778::::::::120:577::::::|h[점액질 촉수]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134895, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162617] = {
				"|cff0070dd|Hitem:162617::::::::120:73::::::|h[샤드라혈족 어깨덧대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1674417, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163897] = {
				"|cff9d9d9d|Hitem:163897::::::::120:577::::::|h[개인 양념 보관함]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133877, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168247] = {
				"|cffffffff|Hitem:168247::::::::120:577::::::|h[치악룡 발톱]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134294, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[162618] = {
				"|cff0070dd|Hitem:162618::::::::120:73::::::|h[토템 여군주의 머리장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1762578, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[106417] = {
				"|cff1eff00|Hitem:106417::::::::94:73::::::|h[서리고리 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				929918, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[129190] = {
				"|cff0070dd|Hitem:129190::::::::104:73::::::|h[우정의 밧줄]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1119937, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[154431] = {
				"|cff0070dd|Hitem:154431::::::::120:262::::::|h[대지진의 화염]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				1723696, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[86587] = {
				"|cff0070dd|Hitem:86587::::::::120:577::::::|h[평온한 성장의 씨앗]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				464030, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165434] = {
				"|cff0070dd|Hitem:165434::::::::120:73::::::|h[달사제의 손등싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2444251, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159549] = {
				"|cff1eff00|Hitem:159549::::::::120:262::::::|h[조칼리 전쟁망치]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1661330, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[159805] = {
				"|cff1eff00|Hitem:159805::::::::120:262::::::|h[산호껍질 방벽 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723673, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[162620] = {
				"|cff0070dd|Hitem:162620::::::::120:73::::::|h[악마뼈 어깨보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1690125, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[166970] = {
				"|cff0070dd|Hitem:166970::::::::120:577::::::|h[마력 전지]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2902386, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[167738] = {
				"|cff1eff00|Hitem:167738::::::::120:577::::::|h[황금빛 바다직물]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2821693, -- [4]
				7, -- [5]
				5, -- [6]
			},
			[159806] = {
				"|cff1eff00|Hitem:159806::::::::120:262::::::|h[조선소 타지 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723673, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[166971] = {
				"|cff1eff00|Hitem:166971::::::::120:262::::::|h[고갈된 마력 전지]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2902385, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[165436] = {
				"|cff0070dd|Hitem:165436::::::::120:73::::::|h[달사제의 바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2444255, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159551] = {
				"|cff1eff00|Hitem:159551::::::::120:262::::::|h[파도수호병 마울]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1720432, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[159807] = {
				"|cff1eff00|Hitem:159807::::::::120:73::::::|h[젬란 죔쇠 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1721571, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[165437] = {
				"|cff0070dd|Hitem:165437::::::::120:73::::::|h[달사제의 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2444259, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161599] = {
				"|cff0070dd|Hitem:161599::::::::120:262::::::|h[기계 고양이 발톱]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1730356, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[129064] = {
				"|cff0070dd|Hitem:129064::::::::104:73::::::|h[신비의 판금 경갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1117703, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161344] = {
				"|cffffffff|Hitem:161344::::::::120:262::::::|h[심연의 조각]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				132885, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[87613] = {
				"|cff0070dd|Hitem:87613::::::::120:577::::::|h[얼어붙은 잔달라 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				609747, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165439] = {
				"|cff0070dd|Hitem:165439::::::::120:73::::::|h[달사제의 소매장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2444245, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[106420] = {
				"|cff1eff00|Hitem:106420::::::::93:73::::::|h[서리고리 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				929920, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[129065] = {
				"|cff0070dd|Hitem:129065::::::::102:73::::::|h[암흑 신탁의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1113075, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[165440] = {
				"|cff0070dd|Hitem:165440::::::::120:73::::::|h[어둠숲 파수꾼의 튜닉]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2351530, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[131921] = {
				"|cff0070dd|Hitem:131921::::::::105:73::::::|h[꿈흐름 목줄]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				632838, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[158788] = {
				"|cff9d9d9d|Hitem:158788::::::::120:262::::::|h[매끈한 가시]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				454058, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161091] = {
				"|cff0070dd|Hitem:161091::::::::120:73::::::|h[날쌘갈퀴 성큼장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1674411, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165441] = {
				"|cff0070dd|Hitem:165441::::::::120:73::::::|h[어둠숲 파수꾼의 발보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				2351527, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[129066] = {
				"|cff0070dd|Hitem:129066::::::::98:73::::::|h[나르탈라스 경비병의 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1115108, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154183] = {
				"|cff0070dd|Hitem:154183::::::::120:262::::::|h[보랄러스 선장의 사슬 장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1726330, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161092] = {
				"|cff0070dd|Hitem:161092::::::::120:577::::::|h[강늪지 빠른발톱 죔쇠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1674410, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165442] = {
				"|cff0070dd|Hitem:165442::::::::120:73::::::|h[어둠숲 파수꾼의 손장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2351531, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158790] = {
				"|cff9d9d9d|Hitem:158790::::::::120:262::::::|h[납골당 재]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134380, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165443] = {
				"|cff0070dd|Hitem:165443::::::::120:73::::::|h[어둠숲 파수꾼의 수도두건]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2351532, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159558] = {
				"|cff1eff00|Hitem:159558::::::::120:577::::::|h[표백된 해골파쇄기]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1692757, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[118832] = {
				"|cff0070dd|Hitem:118832::::::::94:73::::::|h[우딘의 늘어진 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				960146, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161094] = {
				"|cff0070dd|Hitem:161094::::::::120:73::::::|h[부두속박 손등싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161350] = {
				"|cffa335ee|Hitem:161350::::::::120:262::::::|h[바람소환사의 간편한 손등싸개]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				2059676, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[173888] = {
				"|cff1eff00|Hitem:173888::::::::120:262::::::|h[헌신의 파편]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132885, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[162630] = {
				"|cff9d9d9d|Hitem:162630::::::::120:577::::::|h[모래투성이의 정교한 유물]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				458246, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158792] = {
				"|cff9d9d9d|Hitem:158792::::::::120:577::::::|h[위산]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132108, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161095] = {
				"|cff0070dd|Hitem:161095::::::::120:262::::::|h[여왕 근위병 유령 다리싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165445] = {
				"|cff0070dd|Hitem:165445::::::::120:73::::::|h[어둠숲 파수꾼의 어깨받이]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2351534, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159560] = {
				"|cff1eff00|Hitem:159560::::::::120:262::::::|h[조선소 창]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661331, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[161352] = {
				"|cffa335ee|Hitem:161352::::::::120:262::::::|h[광포한 바람의 가슴보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CHEST", -- [3]
				2021683, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[162632] = {
				"|cff9d9d9d|Hitem:162632::::::::120:577::::::|h[화려한 세스랄리스 조각상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237234, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158794] = {
				"|cff9d9d9d|Hitem:158794::::::::120:577::::::|h[상아 엄니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				236697, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165447] = {
				"|cff0070dd|Hitem:165447::::::::120:73::::::|h[어둠숲 파수꾼의 손목보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2351528, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[106424] = {
				"|cff1eff00|Hitem:106424::::::::96:73::::::|h[서리판금 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				947377, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[129069] = {
				"|cff0070dd|Hitem:129069::::::::102:73::::::|h[추적자 목줄 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1116923, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[162633] = {
				"|cff9d9d9d|Hitem:162633::::::::120:577::::::|h[석화된 밀림 난초]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237578, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[140372] = {
				"|cff9d9d9d|Hitem:140372::::::::104:73::::::|h[고대 장인의 조작 장치]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133863, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[161098] = {
				"|cff0070dd|Hitem:161098::::::::120:73::::::|h[심연의 비늘 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159563] = {
				"|cff1eff00|Hitem:159563::::::::120:577::::::|h[로아의 축복을 받은 장창]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				797721, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[168519] = {
				"|cffffffff|Hitem:168519::::::::120:577::::::|h[히드라 비늘]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				443382, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[162634] = {
				"|cff9d9d9d|Hitem:162634::::::::120:577::::::|h[고대 나즈마니 주화]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1416740, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[87618] = {
				"|cff0070dd|Hitem:87618::::::::120:577::::::|h[얼음 덮인 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				646760, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[46000] = {
				"|cff9d9d9d|Hitem:46000::::::::120:577::::::|h[쓸모없는 붉은색 유리 조각]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134130, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159564] = {
				"|cff1eff00|Hitem:159564::::::::120:262::::::|h[사슴심장 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1694053, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[159820] = {
				"|cff1eff00|Hitem:159820::::::::120:262::::::|h[강철문장 초롱]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				1723696, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161100] = {
				"|cff0070dd|Hitem:161100::::::::120:577::::::|h[마력 깃든 잿가루 요대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161356] = {
				"|cffa335ee|Hitem:161356::::::::120:262::::::|h[깃털장식 풍력 벼슬]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HEAD", -- [3]
				1991836, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154448] = {
				"|cff0070dd|Hitem:154448::::::::120:262::::::|h[표류하는 메두사의 쇠사슬갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1726332, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[87619] = {
				"|cff0070dd|Hitem:87619::::::::120:577::::::|h[토우 수호자의 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				615167, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161101] = {
				"|cff0070dd|Hitem:161101::::::::120:262::::::|h[뼈 공포의 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165451] = {
				"|cff0070dd|Hitem:165451::::::::120:73::::::|h[칼도레이 궁수의 두건]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2373965, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159822] = {
				"|cff1eff00|Hitem:159822::::::::120:577::::::|h[전쟁항구 사술 집중기]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				1733401, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[129199] = {
				"|cff0070dd|Hitem:129199::::::::106:73::::::|h[타이드스코른 야를의 펜던트]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				632841, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[154449] = {
				"|cff0070dd|Hitem:154449::::::::120:262::::::|h[파도결속 가슴보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161102] = {
				"|cff0070dd|Hitem:161102::::::::120:73::::::|h[시체피 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165452] = {
				"|cff0070dd|Hitem:165452::::::::120:73::::::|h[칼도레이 궁수의 다리보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2373966, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168267] = {
				"|cff1eff00|Hitem:168267::::::::120:577::::::|h[태양손길 조각상]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				612362, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[87620] = {
				"|cff0070dd|Hitem:87620::::::::120:577::::::|h[얼어붙은 봉우리의 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				615167, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[46001] = {
				"|cff9d9d9d|Hitem:46001::::::::120:577::::::|h[쓸모없는 초록색 유리 조각]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134091, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159568] = {
				"|cff1eff00|Hitem:159568::::::::120:262::::::|h[윈터세일 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1721516, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[158801] = {
				"|cff9d9d9d|Hitem:158801::::::::120:262::::::|h[조밀한 톱니 이빨]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518086, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161104] = {
				"|cff0070dd|Hitem:161104::::::::120:73::::::|h[피의 연회 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161360] = {
				"|cffa335ee|Hitem:161360::::::::120:262::::::|h[보금자리 수호자의 다리보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				2054630, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159569] = {
				"|cff1eff00|Hitem:159569::::::::120:262::::::|h[파도술사 뾰족지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1721516, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[141914] = {
				"|cffffffff|Hitem:141914::::::::105:73::::::|h[주문식: 목걸이 마법부여 - 질긴 통가죽의 징표]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				8, -- [6]
			},
			[87621] = {
				"|cff0070dd|Hitem:87621::::::::120:577::::::|h[대단한 행운의 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				615167, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161105] = {
				"|cff0070dd|Hitem:161105::::::::120:577::::::|h[걸신들린 식인종 발보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161361] = {
				"|cffa335ee|Hitem:161361::::::::120:577::::::|h[살얼음 낀 끌신]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2059673, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[129073] = {
				"|cff0070dd|Hitem:129073::::::::102:73::::::|h[쓴소금물의 인장 반지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1408453, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[154453] = {
				"|cff0070dd|Hitem:154453::::::::120:577::::::|h[박사의 공기쿠션 장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1733692, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161106] = {
				"|cff0070dd|Hitem:161106::::::::120:73::::::|h[광포한 우두머리 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161362] = {
				"|cffa335ee|Hitem:161362::::::::120:577::::::|h[서리숨결 다리보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				2059678, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159571] = {
				"|cff1eff00|Hitem:159571::::::::120:262::::::|h[심연지기 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1721516, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[168271] = {
				"|cff1eff00|Hitem:168271::::::::120:577::::::|h[도둑맞은 람카헨 깃발]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				136005, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[87622] = {
				"|cff0070dd|Hitem:87622::::::::120:73::::::|h[니우짜오의 멍에]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				645519, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161107] = {
				"|cff0070dd|Hitem:161107::::::::120:73::::::|h[바닷물비늘 발등덮개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161363] = {
				"|cffa335ee|Hitem:161363::::::::120:262::::::|h[타닥거리는 분노의 덧신]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2059673, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159572] = {
				"|cff1eff00|Hitem:159572::::::::120:577::::::|h[젬란 뾰족지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661332, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[86471] = {
				"|cff9d9d9d|Hitem:86471::::::::120:73::::::|h[고대 모구 서판]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134458, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161108] = {
				"|cff0070dd|Hitem:161108::::::::119:73::::::|h[왕껍질 다리갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1672320, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161364] = {
				"|cffa335ee|Hitem:161364::::::::120:577::::::|h[극한 오한 손목보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				2021680, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159573] = {
				"|cff1eff00|Hitem:159573::::::::120:577::::::|h[표백된 해골 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661332, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[141918] = {
				"|cff0070dd|Hitem:141918::::::::99:73::::::|h[주문식: 목걸이 마법부여 - 훈련받은 병사의 징표]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				8, -- [6]
			},
			[158806] = {
				"|cff9d9d9d|Hitem:158806::::::::120:262::::::|h[갈고리 갈퀴]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1509625, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161365] = {
				"|cffa335ee|Hitem:161365::::::::120:262::::::|h[휘감기는 폭풍의 발보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2021679, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[129075] = {
				"|cff0070dd|Hitem:129075::::::::99:73::::::|h[분노아귀의 가죽]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1325253, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161110] = {
				"|cff0070dd|Hitem:161110::::::::120:73::::::|h[딱딱한 키틴질 손목보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1672315, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161366] = {
				"|cffa335ee|Hitem:161366::::::::120:577::::::|h[얼음 추적자 장화]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2021679, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[170066] = {
				"|cff1eff00|Hitem:170066::::::::120:577::::::|h[무두질 기법: 들춤 가죽]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[154458] = {
				"|cff0070dd|Hitem:154458::::::::120:262::::::|h[껍질파괴자 전쟁투구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1727712, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158808] = {
				"|cff9d9d9d|Hitem:158808::::::::120:262::::::|h[두꺼운 힘줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				645112, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161111] = {
				"|cff0070dd|Hitem:161111::::::::120:577::::::|h[습지여왕의 분쇄장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161367] = {
				"|cffa335ee|Hitem:161367::::::::120:577::::::|h[우박 갑옷]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CHEST", -- [3]
				1991834, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159576] = {
				"|cff1eff00|Hitem:159576::::::::120:73::::::|h[황금 함대 전쟁지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1664043, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[170067] = {
				"|cff1eff00|Hitem:170067::::::::120:577::::::|h[무두질 기법: 바위비늘]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[173394] = {
				"|cff0070dd|Hitem:173394::::::::120:577::::::|h[검은 제국 판금 장화]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917472, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161368] = {
				"|cffa335ee|Hitem:161368::::::::120:577::::::|h[얼어붙는 폭풍우 허리보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				1991830, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[127925] = {
				"|cffffffff|Hitem:127925::::::::99:73::::::|h[조제법: 불지옥 연금술사 돌]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				6, -- [6]
			},
			[170068] = {
				"|cff0070dd|Hitem:170068::::::::120:577::::::|h[마디바스의 훌륭한 탈염 주머니]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132825, -- [4]
				0, -- [5]
				5, -- [6]
			},
			[154460] = {
				"|cff0070dd|Hitem:154460::::::::120:262::::::|h[보물 수색꾼의 잠수모]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1726334, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[132199] = {
				"|cff9d9d9d|Hitem:132199::::::::120:577::::::|h[응고된 지옥피]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1117883, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[161113] = {
				"|cff0070dd|Hitem:161113::::::::120:262::::::|h[쉴 틈 없이 똑딱거리는 시계]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				134377, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161369] = {
				"|cffa335ee|Hitem:161369::::::::120:262::::::|h[날개 달린 태풍의 손목띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				1991832, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[106432] = {
				"|cff1eff00|Hitem:106432::::::::96:73::::::|h[공허소환사 손목띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				940656, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158299] = {
				"|cff0070dd|Hitem:158299::::::::120:73::::::|h[라사의 가시홀]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1083852, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[154461] = {
				"|cff0070dd|Hitem:154461::::::::120:262::::::|h[저주받은 멧돼지가죽 투구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1733697, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[132200] = {
				"|cff9d9d9d|Hitem:132200::::::::120:577::::::|h[잿빛 반지]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				803856, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173396] = {
				"|cff0070dd|Hitem:173396::::::::120:577::::::|h[검은 제국 판금 투구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917477, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161370] = {
				"|cffa335ee|Hitem:161370::::::::120:577::::::|h[빙하 쐐기 건틀릿]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				2054628, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158556] = {
				"|cff0070dd|Hitem:158556::::::::120:262::::::|h[세이렌의 혀]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1508509, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[87626] = {
				"|cff0070dd|Hitem:87626::::::::120:73::::::|h[쑤나의 부서진 정표]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				645514, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[173397] = {
				"|cff0070dd|Hitem:173397::::::::120:577::::::|h[검은 제국 판금 다리보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917478, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165465] = {
				"|cff0070dd|Hitem:165465::::::::120:73::::::|h[역병인도자의 장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				2450987, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[114877] = {
				"|cff0070dd|Hitem:114877::::::::96:73::::::|h[더러운 쪽지]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134331, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[162651] = {
				"|cff9d9d9d|Hitem:162651::::::::120:262::::::|h[녹슨 사슬]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132507, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158813] = {
				"|cff9d9d9d|Hitem:158813::::::::120:262::::::|h[소시지 껍질]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237412, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173398] = {
				"|cff0070dd|Hitem:173398::::::::120:577::::::|h[검은 제국 판금 어깨덮개]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917479, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161372] = {
				"|cffa335ee|Hitem:161372::::::::120:577::::::|h[얼음으로 조각한 어깨철갑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2054631, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[165722] = {
				"|cff0070dd|Hitem:165722::::::::120:72::::::|h[붉은마루 타란툴라 알]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132834, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[163931] = {
				"|cffa335ee|Hitem:163931::::::::120:262::::::|h[혹사된 경외심의 사슬 고리띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				973881, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154464] = {
				"|cff0070dd|Hitem:154464::::::::120:73::::::|h[얼어붙은 심장 다리보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1726335, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[173399] = {
				"|cff0070dd|Hitem:173399::::::::120:577::::::|h[검은 제국 판금 허리띠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917471, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165467] = {
				"|cff0070dd|Hitem:165467::::::::120:73::::::|h[역병인도자의 수도두건]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2450991, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[106434] = {
				"|cff1eff00|Hitem:106434::::::::94:73::::::|h[공허소환사 무릎바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				940660, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163932] = {
				"|cffa335ee|Hitem:163932::::::::120:262::::::|h[늑대모피 큰망토]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1589459, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[132204] = {
				"|cff9d9d9d|Hitem:132204::::::::120:577::::::|h[불안정한 끈끈이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463853, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173400] = {
				"|cff0070dd|Hitem:173400::::::::120:577::::::|h[검은 제국 쇠사슬 가슴보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036534, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165468] = {
				"|cff0070dd|Hitem:165468::::::::120:73::::::|h[역병인도자의 바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2478212, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[173912] = {
				"|cff9d9d9d|Hitem:173912::::::::120:577::::::|h[진물이 흐르는 울음주머니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				970833, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163933] = {
				"|cffa335ee|Hitem:163933::::::::120:577::::::|h[아구아스의 전조 고리]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FINGER", -- [3]
				2000807, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161119] = {
				"|cff0070dd|Hitem:161119::::::::120:577::::::|h[라바사우루스 해골 비쥬]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				135551, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165469] = {
				"|cff0070dd|Hitem:165469::::::::120:73::::::|h[역병인도자의 어깨보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2450992, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159584] = {
				"|cff1eff00|Hitem:159584::::::::120:262::::::|h[찬비늘 사브르]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729266, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[129080] = {
				"|cff0070dd|Hitem:129080::::::::99:73::::::|h[우두머리 물개 손등싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1115105, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158817] = {
				"|cff9d9d9d|Hitem:158817::::::::120:262::::::|h[칼날꽃잎]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134184, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173402] = {
				"|cff0070dd|Hitem:173402::::::::120:577::::::|h[검은 제국 쇠사슬 장갑]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036535, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165470] = {
				"|cff0070dd|Hitem:165470::::::::120:73::::::|h[역병인도자의 장식끈]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2450986, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159585] = {
				"|cff1eff00|Hitem:159585::::::::120:262::::::|h[강철문장 검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729266, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[163935] = {
				"|cffa335ee|Hitem:163935::::::::120:577::::::|h[란도이의 철저]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1100023, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[116415] = {
				"|cffffffff|Hitem:116415::::::::120:262::::::|h[반짝이는 애완동물 부적]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				413584, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[161377] = {
				"|cffa335ee|Hitem:161377::::::::120:262::::::|h[아주레토스의 그을린 깃털]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103829, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[106436] = {
				"|cff1eff00|Hitem:106436::::::::93:73::::::|h[공허소환사 두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				940659, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[140396] = {
				"|cff9d9d9d|Hitem:140396::::::::104:73::::::|h[인심 좋은 싸움꾼의 판돈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133858, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173404] = {
				"|cff0070dd|Hitem:173404::::::::120:577::::::|h[검은 제국 쇠사슬 다리보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036537, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161378] = {
				"|cffa335ee|Hitem:161378::::::::120:262::::::|h[바다새의 깃]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2103806, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159587] = {
				"|cff1eff00|Hitem:159587::::::::120:262::::::|h[조선소 커틀라스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729266, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[163937] = {
				"|cffa335ee|Hitem:163937::::::::120:577::::::|h[리쇼크의 위대한 장치]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				2000858, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[168019] = {
				"|cff9d9d9d|Hitem:168019::::::::120:72::::::|h[흑요석 푯돌]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134458, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[174356] = {
				"|cffffffff|Hitem:174356::::::::120:72::::::|h[아퀴르 표본]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133571, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158796] = {
				"|cff9d9d9d|Hitem:158796::::::::120:72::::::|h[맹독 촉수]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				254105, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162000] = {
				"|cff1eff00|Hitem:162000::::::::120:577::::::|h[돼지코]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2114667, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173405] = {
				"|cff0070dd|Hitem:173405::::::::120:577::::::|h[검은 제국 쇠사슬 어깨덮개]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036539, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161379] = {
				"|cffa335ee|Hitem:161379::::::::120:262::::::|h[폭풍의 부리]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				952507, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169303] = {
				"|cff0070dd|Hitem:169303::::::::120:72::::::|h[굳은 결의의 팔보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132521, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[129082] = {
				"|cff0070dd|Hitem:129082::::::::99:73::::::|h[발리야카의 낡은 손등싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1113073, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[141051] = {
				"|cffffffff|Hitem:141051::::::::98:73::::::|h[각인 기법: 삼지창]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				11, -- [6]
			},
			[159185] = {
				"|cff1eff00|Hitem:159185::::::::120:577::::::|h[여우굴 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162659] = {
				"|cff9d9d9d|Hitem:162659::::::::120:262::::::|h[낡은 철퇴]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133476, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158821] = {
				"|cff9d9d9d|Hitem:158821::::::::120:262::::::|h[쪼개진 가면]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133792, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173406] = {
				"|cff0070dd|Hitem:173406::::::::120:577::::::|h[검은 제국 쇠사슬 허리띠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036530, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161380] = {
				"|cffa335ee|Hitem:161380::::::::120:577::::::|h[드러스트 룬 고드름]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				252270, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159491] = {
				"|cff1eff00|Hitem:159491::::::::120:262::::::|h[전쟁항구 단궁]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGED", -- [3]
				1723082, -- [4]
				2, -- [5]
				2, -- [6]
			},
			[153704] = {
				"|cff1eff00|Hitem:153704::::::::120:577::::::|h[비리듐]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2003603, -- [4]
				7, -- [5]
				4, -- [6]
			},
			[173887] = {
				"|cffa335ee|Hitem:173887::::::::120:577::::::|h[하리의 자식]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				3229545, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[161019] = {
				"|cff0070dd|Hitem:161019::::::::120:262::::::|h[죽은 독수리 허리줄]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1762573, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162660] = {
				"|cff9d9d9d|Hitem:162660::::::::120:262::::::|h[빛나는 방패]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				454049, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173911] = {
				"|cff9d9d9d|Hitem:173911::::::::120:577::::::|h[부러진 산성가시]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133720, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161125] = {
				"|cff0070dd|Hitem:161125::::::::120:73::::::|h[카자화된 바나나]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				133979, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161381] = {
				"|cffa335ee|Hitem:161381::::::::120:577::::::|h[영구적인 서리가 박힌 심장]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1390944, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159590] = {
				"|cff1eff00|Hitem:159590::::::::120:262::::::|h[함선좌초자 칼날]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729265, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[153705] = {
				"|cff1eff00|Hitem:153705::::::::120:577::::::|h[남정석]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2003594, -- [4]
				7, -- [5]
				4, -- [6]
			},
			[158754] = {
				"|cff9d9d9d|Hitem:158754::::::::120:262::::::|h[명궁의 깃]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132929, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173913] = {
				"|cff9d9d9d|Hitem:173913::::::::120:577::::::|h[마력 깃든 기이한 비늘]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134309, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162661] = {
				"|cff9d9d9d|Hitem:162661::::::::120:262::::::|h[닳아해진 해골]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133730, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169294] = {
				"|cff1eff00|Hitem:169294::::::::120:577::::::|h[불굴의 영혼]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				458722, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173408] = {
				"|cff0070dd|Hitem:173408::::::::120:577::::::|h[검은 제국 가죽 장화]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978242, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165476] = {
				"|cff0070dd|Hitem:165476::::::::120:73::::::|h[죽음추적자의 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2349376, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169419] = {
				"|cff1eff00|Hitem:169419::::::::120:577::::::|h[암초지기 사슬]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2915282, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154834] = {
				"|cff1eff00|Hitem:154834::::::::120:262::::::|h[혈사술 손장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1762577, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[103624] = {
				"|cff0070dd|Hitem:103624::::::::120:73::::::|h[골짜기의 보물]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				647735, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[87615] = {
				"|cff0070dd|Hitem:87615::::::::120:577::::::|h[야크 세척인의 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				604460, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162662] = {
				"|cff9d9d9d|Hitem:162662::::::::120:262::::::|h[글이 새겨진 가면]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133113, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[167012] = {
				"|cff1eff00|Hitem:167012::::::::120:577::::::|h[염수석 곡괭이]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1064765, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173409] = {
				"|cff0070dd|Hitem:173409::::::::120:577::::::|h[검은 제국 가죽 장갑]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978245, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165477] = {
				"|cff0070dd|Hitem:165477::::::::120:73::::::|h[죽음추적자의 어깨보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2349377, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169293] = {
				"|cff0070dd|Hitem:169293::::::::120:577::::::|h[환영 응축물]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1003600, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[129084] = {
				"|cff0070dd|Hitem:129084::::::::99:73::::::|h[칼부리의 둥지 다리보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1116927, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[87616] = {
				"|cff0070dd|Hitem:87616::::::::120:577::::::|h[산악 개척자의 소매장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				604460, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[173393] = {
				"|cff0070dd|Hitem:173393::::::::120:577::::::|h[검은 제국 판금 가슴보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917475, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[154475] = {
				"|cff0070dd|Hitem:154475::::::::120:262::::::|h[염소털 손목띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1698803, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[87614] = {
				"|cff0070dd|Hitem:87614::::::::120:577::::::|h[카파 채집인의 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				646760, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[173410] = {
				"|cff0070dd|Hitem:173410::::::::120:577::::::|h[검은 제국 가죽 투구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978246, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165478] = {
				"|cff0070dd|Hitem:165478::::::::120:73::::::|h[죽음추적자의 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2349371, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159593] = {
				"|cff1eff00|Hitem:159593::::::::120:262::::::|h[파도술사 커틀라스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729265, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[163943] = {
				"|cffa335ee|Hitem:163943::::::::120:577::::::|h[넬레모어의 무늬새김 다리보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				457940, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[67410] = {
				"|cff9d9d9d|Hitem:67410::::::::120:73::::::|h[불행을 가져오는 돌]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135239, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158773] = {
				"|cff9d9d9d|Hitem:158773::::::::120:72::::::|h[꿈틀거리는 끈적이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463568, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162664] = {
				"|cff9d9d9d|Hitem:162664::::::::120:262::::::|h[움푹 파인 흉갑]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132738, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169317] = {
				"|cffa335ee|Hitem:169317::::::::120:577::::::|h[속박꾼의 귀속석]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				973909, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[173411] = {
				"|cff0070dd|Hitem:173411::::::::120:577::::::|h[검은 제국 가죽 다리보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978247, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165479] = {
				"|cff0070dd|Hitem:165479::::::::120:73::::::|h[죽음추적자의 손목띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2349370, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[106440] = {
				"|cff1eff00|Hitem:106440::::::::93:73::::::|h[수도자 장식끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				937854, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163944] = {
				"|cffa335ee|Hitem:163944::::::::120:577::::::|h[와타의 이중매듭 장식끈]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				514333, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[87617] = {
				"|cff0070dd|Hitem:87617::::::::120:577::::::|h[고요한 산꼭대기의 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				609747, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168650] = {
				"|cffffffff|Hitem:168650::::::::120:577::::::|h[바위비늘]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2032177, -- [4]
				7, -- [5]
				6, -- [6]
			},
			[166759] = {
				"|cff0070dd|Hitem:166759::::::::120:73::::::|h[어둠숲 파수꾼의 외투]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2351529, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[87624] = {
				"|cff0070dd|Hitem:87624::::::::120:73::::::|h[야운골 안개주술사의 아뮬렛]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				645513, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169318] = {
				"|cffa335ee|Hitem:169318::::::::120:577::::::|h[전격아귀의 송곳니]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				1526597, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165480] = {
				"|cff0070dd|Hitem:165480::::::::120:73::::::|h[역병경비병의 멜빵]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2357687, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159595] = {
				"|cff1eff00|Hitem:159595::::::::120:577::::::|h[표백된 해골 커틀라스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1724052, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[153710] = {
				"|cff1eff00|Hitem:153710::::::::120:577::::::|h[치명적인 태양돌]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1990980, -- [4]
				3, -- [5]
				5, -- [6]
			},
			[170185] = {
				"|cff0070dd|Hitem:170185::::::::120:577::::::|h[온전한 나가 해골]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133719, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[87623] = {
				"|cff0070dd|Hitem:87623::::::::120:73::::::|h[아주 날카로운 껍질 목장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				645262, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[162666] = {
				"|cff9d9d9d|Hitem:162666::::::::120:262::::::|h[찢어진 가방]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133656, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169944] = {
				"|cff0070dd|Hitem:169944::::::::120:73::::::|h[꼬마 페즈 모자]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				446121, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173413] = {
				"|cff0070dd|Hitem:173413::::::::120:577::::::|h[검은 제국 가죽 허리띠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978241, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165481] = {
				"|cff0070dd|Hitem:165481::::::::120:73::::::|h[역병경비병의 발등덮개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				2357684, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[94159] = {
				"|cff1eff00|Hitem:94159::::::::90:73::::::|h[잔달라 보급품이 든 작은 자루]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133642, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[129086] = {
				"|cff0070dd|Hitem:129086::::::::102:73::::::|h[브롤고스의 목장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1117697, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[116469] = {
				"|cff1eff00|Hitem:116469::::::::93:73::::::|h[동상 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				926274, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[154832] = {
				"|cff1eff00|Hitem:154832::::::::120:262::::::|h[혈사술 장식끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1762573, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162667] = {
				"|cff9d9d9d|Hitem:162667::::::::120:73::::::|h[파락키 유골단지]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134514, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[140406] = {
				"|cff0070dd|Hitem:140406::::::::104:73::::::|h[설치된 비전 폭발물]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1391782, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[173414] = {
				"|cff0070dd|Hitem:173414::::::::120:577::::::|h[검은 제국 천 로브]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048006, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165482] = {
				"|cff0070dd|Hitem:165482::::::::120:73::::::|h[역병경비병의 손아귀]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2357688, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161387] = {
				"|cffa335ee|Hitem:161387::::::::120:262::::::|h[울부짖는 공포의 다리보호구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				2059678, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170088] = {
				"|cffa335ee|Hitem:170088::::::::120:577::::::|h[울매스의 영혼추적자]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_RANGED", -- [3]
				2924349, -- [4]
				2, -- [5]
				2, -- [6]
			},
			[173403] = {
				"|cff0070dd|Hitem:173403::::::::120:577::::::|h[검은 제국 쇠사슬 투구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036536, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161040] = {
				"|cff0070dd|Hitem:161040::::::::120:73::::::|h[메마른 사막 디딤장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166762] = {
				"|cff0070dd|Hitem:166762::::::::120:73::::::|h[역병인도자의 외투]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2451537, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[165483] = {
				"|cff0070dd|Hitem:165483::::::::120:73::::::|h[역병경비병의 보호모]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2357689, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[173415] = {
				"|cff0070dd|Hitem:173415::::::::120:577::::::|h[검은 제국 천 장화]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048003, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161389] = {
				"|cffa335ee|Hitem:161389::::::::120:262::::::|h[걸신들린 죽음의 허리끈]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				2059672, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[116677] = {
				"|cff1eff00|Hitem:116677::::::::92:73::::::|h[얼음노래꾼 아뮬렛]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_NECK", -- [3]
				348284, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[163948] = {
				"|cffa335ee|Hitem:163948::::::::120:577::::::|h[모아스의 거친사슬 건틀릿]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				422802, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[162619] = {
				"|cff0070dd|Hitem:162619::::::::120:262::::::|h[뼈 수집가의 흉골갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1690121, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161044] = {
				"|cff0070dd|Hitem:161044::::::::120:577::::::|h[납작파도 투사의 철갑허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166763] = {
				"|cff0070dd|Hitem:166763::::::::120:73::::::|h[죽음추적자의 망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2349372, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158831] = {
				"|cff9d9d9d|Hitem:158831::::::::120:577::::::|h[바짝 마른 벌집]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500973, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173416] = {
				"|cff0070dd|Hitem:173416::::::::120:577::::::|h[검은 제국 천 장갑]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048007, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165484] = {
				"|cff0070dd|Hitem:165484::::::::120:73::::::|h[역병경비병의 다리보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2357690, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165458] = {
				"|cff0070dd|Hitem:165458::::::::120:73::::::|h[감시경비병의 전투장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2316874, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170090] = {
				"|cffa335ee|Hitem:170090::::::::120:577::::::|h[무자비한 쪽집게]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2997789, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[153702] = {
				"|cff1eff00|Hitem:153702::::::::120:73::::::|h[쿠빌라인]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2003614, -- [4]
				7, -- [5]
				4, -- [6]
			},
			[160985] = {
				"|cff0070dd|Hitem:160985::::::::120:73::::::|h[꿀꺽아귀의 반지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				803866, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[166764] = {
				"|cff0070dd|Hitem:166764::::::::120:73::::::|h[역병경비병의 망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2357686, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161391] = {
				"|cffa335ee|Hitem:161391::::::::120:262::::::|h[죽음비틀괴물의 어깨덧대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2021687, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[173417] = {
				"|cff0070dd|Hitem:173417::::::::120:577::::::|h[검은 제국 천 투구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048008, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165485] = {
				"|cff0070dd|Hitem:165485::::::::120:73::::::|h[역병경비병의 어깨보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2357691, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[106443] = {
				"|cff1eff00|Hitem:106443::::::::92:73::::::|h[수도자 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				937861, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170091] = {
				"|cffa335ee|Hitem:170091::::::::120:577::::::|h[결의술사의 미늘창]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2735992, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[102543] = {
				"|cff1eff00|Hitem:102543::::::::120:73::::::|h[숙성된 모구샨 치즈]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133949, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[159264] = {
				"|cff1eff00|Hitem:159264::::::::120:262::::::|h[어스름 단망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1726328, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[162671] = {
				"|cff9d9d9d|Hitem:162671::::::::120:262::::::|h[부러진 석궁]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135535, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155598] = {
				"|cff9d9d9d|Hitem:155598::::::::120:262::::::|h[분리된 턱뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237393, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173418] = {
				"|cff0070dd|Hitem:173418::::::::120:577::::::|h[검은 제국 천 다리보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048009, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161392] = {
				"|cffa335ee|Hitem:161392::::::::120:262::::::|h[영원한 공포의 손목띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				2021680, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[155381] = {
				"|cff0070dd|Hitem:155381::::::::120:262::::::|h[바다가름 선장의 사파이어 반지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1048292, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[163951] = {
				"|cffa335ee|Hitem:163951::::::::120:577::::::|h[성인군자 사령관의 허리띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				529876, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161393] = {
				"|cffa335ee|Hitem:161393::::::::120:262::::::|h[단단한 죽음의 다리보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				1991837, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163952] = {
				"|cffa335ee|Hitem:163952::::::::120:577::::::|h[오프레스쿠의 화려한 손길]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				367889, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[162672] = {
				"|cff9d9d9d|Hitem:162672::::::::120:577::::::|h[의술사의 부적 묵주]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1535057, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158834] = {
				"|cff9d9d9d|Hitem:158834::::::::120:262::::::|h[윈치 고리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132998, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173419] = {
				"|cff0070dd|Hitem:173419::::::::120:577::::::|h[검은 제국 천 어깨덮개]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048010, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165487] = {
				"|cff0070dd|Hitem:165487::::::::120:73::::::|h[역병경비병의 팔보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2357685, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159602] = {
				"|cff1eff00|Hitem:159602::::::::120:262::::::|h[골 오시그 마법봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1697864, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[170093] = {
				"|cffa335ee|Hitem:170093::::::::120:577::::::|h[티르마르의 대검]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2835966, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[161041] = {
				"|cff0070dd|Hitem:161041::::::::120:73::::::|h[거트립의 유린장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169253] = {
				"|cffffffff|Hitem:169253::::::::120:262::::::|h[조개뿔]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1498844, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[162673] = {
				"|cff9d9d9d|Hitem:162673::::::::120:262::::::|h[매듭장식 뱃머리 밧줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1119938, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165489] = {
				"|cff0070dd|Hitem:165489::::::::120:73::::::|h[죽음경비병의 발덮개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				2393939, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[173420] = {
				"|cff0070dd|Hitem:173420::::::::120:577::::::|h[검은 제국 천 허리띠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048002, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165488] = {
				"|cff0070dd|Hitem:165488::::::::120:73::::::|h[죽음경비병의 가슴갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2393943, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169433] = {
				"|cff1eff00|Hitem:169433::::::::120:577::::::|h[파도분쇄 큰망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2967512, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170094] = {
				"|cffa335ee|Hitem:170094::::::::120:577::::::|h[사원 수호자의 사브르]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				3004118, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[168303] = {
				"|cffffffff|Hitem:168303::::::::120:577::::::|h[질긴 옆구리살]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				3007465, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[173395] = {
				"|cff0070dd|Hitem:173395::::::::120:577::::::|h[검은 제국 판금 장갑]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917476, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165623] = {
				"|cff0070dd|Hitem:165623::::::::120:73::::::|h[파수꾼의 곡궁]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGED", -- [3]
				2263236, -- [4]
				2, -- [5]
				2, -- [6]
			},
			[158836] = {
				"|cff9d9d9d|Hitem:158836::::::::120:577::::::|h[날카로운 독침]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237142, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170095] = {
				"|cffa335ee|Hitem:170095::::::::120:577::::::|h[달의 여사제의 지휘봉]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2735968, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[161395] = {
				"|cffa335ee|Hitem:161395::::::::120:262::::::|h[늪괴물 영혼 발보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				1991831, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[167792] = {
				"|cff1eff00|Hitem:167792::::::::120:577::::::|h[물감이 든 병: 지옥 박하 녹색]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				413575, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163954] = {
				"|cffa335ee|Hitem:163954::::::::120:577::::::|h[오스웨인의 냉정한 수호 방패]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHIELD", -- [3]
				510886, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[165449] = {
				"|cff0070dd|Hitem:165449::::::::120:73::::::|h[칼도레이 궁수의 경갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				2373961, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[173935] = {
				"|cff9d9d9d|Hitem:173935::::::::120:577::::::|h[닉닉의 매끈피부 비수]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				135637, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[166482] = {
				"|cff0070dd|Hitem:166482::::::::120:73::::::|h[죽음경비병의 대검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2400064, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[163087] = {
				"|cff9d9d9d|Hitem:163087::::::::120:262::::::|h[핏빛 오렌지가 든 가방]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				915544, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173422] = {
				"|cff0070dd|Hitem:173422::::::::120:577::::::|h[검은 제국 판금 팔보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2917473, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161396] = {
				"|cffa335ee|Hitem:161396::::::::120:262::::::|h[내세의 석화된 가면]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HEAD", -- [3]
				2054629, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[167793] = {
				"|cff1eff00|Hitem:167793::::::::120:577::::::|h[물감이 든 병: 지나치게 진한 주황색]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				413575, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170096] = {
				"|cff9d9d9d|Hitem:170096::::::::120:577::::::|h[흠뻑 젖은 명가 그림]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134944, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170181] = {
				"|cff1eff00|Hitem:170181::::::::120:577::::::|h[해일 파수꾼]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237584, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[163074] = {
				"|cff9d9d9d|Hitem:163074::::::::120:73::::::|h[희멀겋고 딱딱한 탄알]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134122, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[150909] = {
				"|cff0070dd|Hitem:150909::::::::120:262::::::|h[곰보버섯 감줄]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				337687, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158838] = {
				"|cff9d9d9d|Hitem:158838::::::::120:577::::::|h[섬유질이 풍부한 오물]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134438, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173423] = {
				"|cff0070dd|Hitem:173423::::::::120:577::::::|h[검은 제국 천 팔보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3048004, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[136833] = {
				"|cffffffff|Hitem:136833::::::::102:73::::::|h[신탁의 수정구]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134334, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[106446] = {
				"|cff1eff00|Hitem:106446::::::::96:73::::::|h[수도자 어깨덧대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				973931, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170097] = {
				"|cff9d9d9d|Hitem:170097::::::::120:577::::::|h[버려진 쿠엘도레이 고서]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133735, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[129219] = {
				"|cff0070dd|Hitem:129219::::::::106:73::::::|h[약탈자의 룬싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1113071, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161033] = {
				"|cff0070dd|Hitem:161033::::::::120:73::::::|h[충격의 도약 다리보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1690124, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[158583] = {
				"|cff0070dd|Hitem:158583::::::::120:262::::::|h[가시매듭 큰망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1733694, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[152698] = {
				"|cffffffff|Hitem:152698::::::::120:262::::::|h[오염돌 스튜]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387641, -- [4]
				0, -- [5]
				5, -- [6]
			},
			[173424] = {
				"|cff0070dd|Hitem:173424::::::::120:577::::::|h[검은 제국 가죽 팔보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978243, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161398] = {
				"|cffa335ee|Hitem:161398::::::::120:262::::::|h[갈퀴에 마모된 청금석 완갑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				2054626, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[173936] = {
				"|cff9d9d9d|Hitem:173936::::::::120:577::::::|h[두까까 우낏 육척봉]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				135145, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[170098] = {
				"|cff9d9d9d|Hitem:170098::::::::120:577::::::|h[녹슨 가지장식 귀걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133348, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[166260] = {
				"|cffffffff|Hitem:166260::::::::120:262::::::|h[도면: 모네라이트로 굳힌 발굽보호대]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				4, -- [6]
			},
			[154828] = {
				"|cff1eff00|Hitem:154828::::::::120:262::::::|h[잘라마르 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1690123, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[174451] = {
				"|cffffffff|Hitem:174451::::::::120:262::::::|h[태양왕의 칙령]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1020391, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158840] = {
				"|cff9d9d9d|Hitem:158840::::::::120:72::::::|h[벌레잡이 혓바닥]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237408, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[173425] = {
				"|cff0070dd|Hitem:173425::::::::120:577::::::|h[검은 제국 쇠사슬 팔보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036532, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165493] = {
				"|cff0070dd|Hitem:165493::::::::120:73::::::|h[죽음경비병의 경갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2393950, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[173937] = {
				"|cffffffff|Hitem:173937::::::::120:577::::::|h[잘린 눈]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1100023, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170099] = {
				"|cff9d9d9d|Hitem:170099::::::::120:577::::::|h[부식된 품위있는 열쇠]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134240, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160120] = {
				"|cff1eff00|Hitem:160120::::::::120:262::::::|h[공포뿔 주름장식 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168645] = {
				"|cffffffff|Hitem:168645::::::::120:577::::::|h[촉촉한 살코기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				3007464, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[163085] = {
				"|cff9d9d9d|Hitem:163085::::::::120:577::::::|h[양파 머리띠]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				651595, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159609] = {
				"|cff1eff00|Hitem:159609::::::::120:577::::::|h[황금 함대 마법봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1694362, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[169332] = {
				"|cff0070dd|Hitem:169332::::::::120:577::::::|h[수상한 무기물 해수]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132774, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[165494] = {
				"|cff0070dd|Hitem:165494::::::::120:73::::::|h[죽음경비병의 견갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2393952, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163703] = {
				"|cff0070dd|Hitem:163703::::::::120:73::::::|h[크로그가 갉아먹은 다리뼈]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				133727, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[163959] = {
				"|cffa335ee|Hitem:163959::::::::120:577::::::|h[씽의 자동회전 단도]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1966587, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[160121] = {
				"|cff1eff00|Hitem:160121::::::::120:262::::::|h[공포뿔 주름장식 철갑허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163961] = {
				"|cffa335ee|Hitem:163961::::::::120:73::::::|h[켈라다의 분별]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1063302, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[161397] = {
				"|cffa335ee|Hitem:161397::::::::120:262::::::|h[영혼판자 완갑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WRIST", -- [3]
				2054626, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[132231] = {
				"|cff9d9d9d|Hitem:132231::::::::106:73::::::|h[닳은 고리 발톱]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132141, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169333] = {
				"|cff0070dd|Hitem:169333::::::::120:577::::::|h[수상한 화산 바위]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132847, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[165495] = {
				"|cff0070dd|Hitem:165495::::::::120:73::::::|h[죽음경비병의 판금허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2393938, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[106448] = {
				"|cff1eff00|Hitem:106448::::::::93:73::::::|h[그론링 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				929914, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163960] = {
				"|cffa335ee|Hitem:163960::::::::120:262::::::|h[불타는 진실의 철퇴]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1113523, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[160122] = {
				"|cff1eff00|Hitem:160122::::::::114:73::::::|h[공포뿔 주름장식 보호모]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1672319, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[162681] = {
				"|cff9d9d9d|Hitem:162681::::::::120:262::::::|h[구부러진 낫]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1060561, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168822] = {
				"|cff1eff00|Hitem:168822::::::::120:262::::::|h[빈약한 젤리]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				3066347, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[165628] = {
				"|cff0070dd|Hitem:165628::::::::120:73::::::|h[파수꾼의 가지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2143644, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[169334] = {
				"|cff0070dd|Hitem:169334::::::::120:577::::::|h[수상한 해양 퇴적물]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				628267, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[165496] = {
				"|cff0070dd|Hitem:165496::::::::120:73::::::|h[죽음경비병의 완갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2393940, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154476] = {
				"|cff0070dd|Hitem:154476::::::::120:262::::::|h[꿀 바른 완갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1727709, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[174196] = {
				"|cffffffff|Hitem:174196::::::::120:262::::::|h[고대 광기의 고서]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134544, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160123] = {
				"|cff1eff00|Hitem:160123::::::::120:577::::::|h[공포뿔 주름장식 다리갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1672320, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154315] = {
				"|cff0070dd|Hitem:154315::::::::120:262::::::|h[녹슨 무쇠발톱]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1730356, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[168823] = {
				"|cffa335ee|Hitem:168823::::::::120:577::::::|h[녹슨 메카거미]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2620863, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[87642] = {
				"|cffa335ee|Hitem:87642::::::::83:73::::::|h[파멸의 암흑지팡이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				622115, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[163940] = {
				"|cffa335ee|Hitem:163940::::::::120:577::::::|h[빛나는 초경량 장식끈]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				414282, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169591] = {
				"|cff1eff00|Hitem:169591::::::::120:262::::::|h[금이 간 수식 실린더]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237445, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[106449] = {
				"|cff1eff00|Hitem:106449::::::::94:73::::::|h[그론링 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				929916, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163962] = {
				"|cffa335ee|Hitem:163962::::::::120:577::::::|h[알리레자의 참수검]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1115730, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[160124] = {
				"|cff1eff00|Hitem:160124::::::::114:73::::::|h[공포뿔 주름장식 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1672321, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[165454] = {
				"|cff0070dd|Hitem:165454::::::::120:73::::::|h[칼도레이 궁수의 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2373960, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168824] = {
				"|cff0070dd|Hitem:168824::::::::120:262::::::|h[바다 시뮬레이터]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2923993, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[106487] = {
				"|cff1eff00|Hitem:106487::::::::96:73::::::|h[뾰족덩굴숲 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				929921, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159598] = {
				"|cff1eff00|Hitem:159598::::::::120:73::::::|h[황금 함대 장검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1788661, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[116466] = {
				"|cff1eff00|Hitem:116466::::::::92:73::::::|h[얼음노래꾼 홀]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				930039, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[169848] = {
				"|cff0070dd|Hitem:169848::::::::120:262::::::|h[미니 아제로스 묶음 상품: 본도의 야적장]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134143, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163963] = {
				"|cffa335ee|Hitem:163963::::::::120:577::::::|h[실리리온의 고기 방망이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1084300, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[160125] = {
				"|cff1eff00|Hitem:160125::::::::120:577::::::|h[공포뿔 주름장식 디딤장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[162684] = {
				"|cff9d9d9d|Hitem:162684::::::::120:262::::::|h[글이 새겨진 갑판 밧줄걸이 막대]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135544, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168825] = {
				"|cff0070dd|Hitem:168825::::::::120:577::::::|h[풍부한 젤리]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2066005, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159514] = {
				"|cff1eff00|Hitem:159514::::::::120:262::::::|h[강늪지 발톱주먹]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1692686, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[63348] = {
				"|cff9d9d9d|Hitem:63348::::::::120:73::::::|h[고블린 신사의 잡지]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133747, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169593] = {
				"|cff1eff00|Hitem:169593::::::::120:577::::::|h[대량의 기록 조각]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				574567, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[106450] = {
				"|cff1eff00|Hitem:106450::::::::94:73::::::|h[그론링 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				929918, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165444] = {
				"|cff0070dd|Hitem:165444::::::::120:73::::::|h[어둠숲 파수꾼의 짧은바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2351533, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160126] = {
				"|cff1eff00|Hitem:160126::::::::120:262::::::|h[공포뿔 주름장식 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1672315, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[165474] = {
				"|cff0070dd|Hitem:165474::::::::120:73::::::|h[죽음추적자의 손장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2349374, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[162685] = {
				"|cff9d9d9d|Hitem:162685::::::::120:73::::::|h[넘치는 로아 공물]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				461809, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165466] = {
				"|cff0070dd|Hitem:165466::::::::120:73::::::|h[역병인도자의 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2450990, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[167790] = {
				"|cff1eff00|Hitem:167790::::::::120:262::::::|h[물감이 든 병: 화염구 적색]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				413575, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169594] = {
				"|cff1eff00|Hitem:169594::::::::120:577::::::|h[녹으로 뒤덮인 원반]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132999, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169850] = {
				"|cff0070dd|Hitem:169850::::::::120:262::::::|h[미니 아제로스 묶음 상품: 메카곤]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134142, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165462] = {
				"|cff0070dd|Hitem:165462::::::::120:73::::::|h[감시경비병의 견갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2451599, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160127] = {
				"|cff1eff00|Hitem:160127::::::::120:577::::::|h[테러닥스가죽 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1672316, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[165438] = {
				"|cff0070dd|Hitem:165438::::::::120:73::::::|h[달사제의 장식띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2444241, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[142543] = {
				"|cff0070dd|Hitem:142543::::::::105:73::::::|h[마을 차원문 두루마리]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1529349, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[166765] = {
				"|cff0070dd|Hitem:166765::::::::120:73::::::|h[죽음경비병의 큰망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2393941, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[155608] = {
				"|cff9d9d9d|Hitem:155608::::::::120:262::::::|h[더럽혀진 뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				442733, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169595] = {
				"|cff1eff00|Hitem:169595::::::::120:577::::::|h[그을린 자료 원반]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133862, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[136785] = {
				"|cffffffff|Hitem:136785::::::::120:73::::::|h[그늘늪지 귀중품]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				348282, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163966] = {
				"|cffa335ee|Hitem:163966::::::::120:577::::::|h[미기 양의 커다란 탑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				615328, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160128] = {
				"|cff1eff00|Hitem:160128::::::::120:577::::::|h[브루토사우루스가죽 팔보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1674412, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[121739] = {
				"|cff0070dd|Hitem:121739::::::::104:73::::::|h[펠리누스 마누스]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1130509, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168828] = {
				"|cffa335ee|Hitem:168828::::::::120:73::::::|h[로열젤리]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				3066348, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158849] = {
				"|cff9d9d9d|Hitem:158849::::::::120:262::::::|h[톱니 턱뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1729493, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165472] = {
				"|cff0070dd|Hitem:165472::::::::120:73::::::|h[죽음추적자의 가슴보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2349373, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165455] = {
				"|cff0070dd|Hitem:165455::::::::120:73::::::|h[칼도레이 궁수의 완갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2373962, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169409] = {
				"|cff1eff00|Hitem:169409::::::::120:577::::::|h[미끈껍질 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2902644, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163967] = {
				"|cffa335ee|Hitem:163967::::::::120:262::::::|h[슈터프의 측정창]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1097922, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[160129] = {
				"|cff1eff00|Hitem:160129::::::::120:577::::::|h[브루토사우루스가죽 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1674411, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158338] = {
				"|cff0070dd|Hitem:158338::::::::120:262::::::|h[날쌘여행 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154500] = {
				"|cff0070dd|Hitem:154500::::::::120:72::::::|h[달나무 가지 지팡이]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1721516, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[158850] = {
				"|cff9d9d9d|Hitem:158850::::::::120:577::::::|h[흩날리는 깃털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132925, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165463] = {
				"|cff0070dd|Hitem:165463::::::::120:73::::::|h[감시경비병의 사슬 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2451595, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166758] = {
				"|cff0070dd|Hitem:166758::::::::120:73::::::|h[달사제의 망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2444247, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[118734] = {
				"|cff0070dd|Hitem:118734::::::::93:73::::::|h[스니블 바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				937861, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168062] = {
				"|cff0070dd|Hitem:168062::::::::120:577::::::|h[도면: 녹슨나사 축음기]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160130] = {
				"|cff1eff00|Hitem:160130::::::::120:577::::::|h[브루토사우루스가죽 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165492] = {
				"|cff0070dd|Hitem:165492::::::::120:73::::::|h[역병인도자의 로브]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_ROBE", -- [3]
				2450989, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158740] = {
				"|cff9d9d9d|Hitem:158740::::::::120:262::::::|h[진주빛 앞니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518104, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158851] = {
				"|cff9d9d9d|Hitem:158851::::::::120:262::::::|h[병 속의 돌풍]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463545, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170087] = {
				"|cff9d9d9d|Hitem:170087::::::::120:577::::::|h[오색 \"식초\"]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132798, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163678] = {
				"|cff0070dd|Hitem:163678::::::::120:262::::::|h[핑쿠숀의 관통장창]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661331, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[158597] = {
				"|cff0070dd|Hitem:158597::::::::120:73::::::|h[은껍질 수호방패]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723691, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[168063] = {
				"|cff0070dd|Hitem:168063::::::::120:262::::::|h[도면: 녹슨나사 맥주 냉장고]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160131] = {
				"|cff1eff00|Hitem:160131::::::::120:262::::::|h[브루토사우루스가죽 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161032] = {
				"|cff0070dd|Hitem:161032::::::::119:73::::::|h[첨탑충전 고리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169152] = {
				"|cffffffff|Hitem:169152::::::::120:577::::::|h[빈 벌집]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				525024, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[155636] = {
				"|cff9d9d9d|Hitem:155636::::::::120:577::::::|h[점성 잉크]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				252178, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[162682] = {
				"|cff9d9d9d|Hitem:162682::::::::120:262::::::|h[빛바랜 장검]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135274, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161411] = {
				"|cffa335ee|Hitem:161411::::::::120:262::::::|h[티제인의 나무등뼈]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				134439, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[106453] = {
				"|cff1eff00|Hitem:106453::::::::93:73::::::|h[그론링 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				929920, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[158810] = {
				"|cff9d9d9d|Hitem:158810::::::::120:262::::::|h[웅웅거리는 이슬]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463570, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160132] = {
				"|cff1eff00|Hitem:160132::::::::120:577::::::|h[브루토사우루스가죽 얼굴보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1674415, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[131730] = {
				"|cff0070dd|Hitem:131730::::::::104:73::::::|h[어둠호랑이 가죽 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1115101, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168832] = {
				"|cffa335ee|Hitem:168832::::::::120:577::::::|h[전류 발진기]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1405815, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158853] = {
				"|cff9d9d9d|Hitem:158853::::::::120:73::::::|h[앙상한 해골판금]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133732, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165460] = {
				"|cff0070dd|Hitem:165460::::::::120:73::::::|h[달사제의 예복]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_ROBE", -- [3]
				2444249, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161412] = {
				"|cffa335ee|Hitem:161412::::::::120:262::::::|h[영혼결속 부두 옹이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_TRINKET", -- [3]
				237468, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165457] = {
				"|cff0070dd|Hitem:165457::::::::120:73::::::|h[감시경비병의 전쟁장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				2316868, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[130122] = {
				"|cff0070dd|Hitem:130122::::::::120:73::::::|h[그렐다의 불로장생 펜던트]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				632854, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160133] = {
				"|cff1eff00|Hitem:160133::::::::120:262::::::|h[브루토사우루스가죽 조끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1674413, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163945] = {
				"|cffa335ee|Hitem:163945::::::::120:577::::::|h[미스트라의 멋진 긴장갑]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				795962, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158598] = {
				"|cff0070dd|Hitem:158598::::::::120:262::::::|h[들끓는 현신의 고리]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1379208, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[167042] = {
				"|cff0070dd|Hitem:167042::::::::120:262::::::|h[도면: 고철 덫]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[159172] = {
				"|cff1eff00|Hitem:159172::::::::120:262::::::|h[자유지대 웃옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1733695, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160963] = {
				"|cff0070dd|Hitem:160963::::::::120:262::::::|h[핏빛 밀림 창]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1722660, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[106454] = {
				"|cff1eff00|Hitem:106454::::::::94:73::::::|h[그론링 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				929921, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165475] = {
				"|cff0070dd|Hitem:165475::::::::120:73::::::|h[죽음추적자의 깃장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2349375, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160134] = {
				"|cff1eff00|Hitem:160134::::::::120:262::::::|h[브루토사우루스가죽 어깨덧대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1674417, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159189] = {
				"|cff1eff00|Hitem:159189::::::::120:262::::::|h[여우굴 아미스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1698809, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[116499] = {
				"|cff1eff00|Hitem:116499::::::::96:73::::::|h[덩굴에 휩싸인 철퇴]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				925571, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[158855] = {
				"|cff9d9d9d|Hitem:158855::::::::116:73::::::|h[불길한 해골 우상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				136008, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154839] = {
				"|cff1eff00|Hitem:154839::::::::120:262::::::|h[혈사술 완장]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[155273] = {
				"|cff0070dd|Hitem:155273::::::::120:262::::::|h[상어이빨 손도끼]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[169858] = {
				"|cffffffff|Hitem:169858::::::::120:73::::::|h[\"붕붕\" 총]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				135617, -- [4]
				0, -- [5]
				0, -- [6]
			},
			[170114] = {
				"|cff1eff00|Hitem:170114::::::::120:577::::::|h[갈고리 철퇴]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2735968, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[160135] = {
				"|cff1eff00|Hitem:160135::::::::114:73::::::|h[브루토사우루스가죽 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1674410, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159604] = {
				"|cff1eff00|Hitem:159604::::::::120:262::::::|h[찬비늘 막대봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1697864, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[161048] = {
				"|cff0070dd|Hitem:161048::::::::114:73::::::|h[야만 파도소환사 팔보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158856] = {
				"|cff9d9d9d|Hitem:158856::::::::120:262::::::|h[거대한 개구리 다리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237396, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169347] = {
				"|cff0070dd|Hitem:169347::::::::120:577::::::|h[메카곤의 심판]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133866, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[163718] = {
				"|cff9d9d9d|Hitem:163718::::::::120:262::::::|h[블랙볼의 금지된 뱃노래]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500866, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[106455] = {
				"|cff1eff00|Hitem:106455::::::::92:73::::::|h[그론링 조끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				929917, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170115] = {
				"|cff1eff00|Hitem:170115::::::::120:577::::::|h[거대한 녹빛 발톱]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2997789, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[160136] = {
				"|cff1eff00|Hitem:160136::::::::120:577::::::|h[황금 도시 인장 반지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391713, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[158345] = {
				"|cff0070dd|Hitem:158345::::::::120:262::::::|h[한파의 견갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1726336, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[116500] = {
				"|cff1eff00|Hitem:116500::::::::93:73::::::|h[성장술사 홀]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				930040, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[158857] = {
				"|cff9d9d9d|Hitem:158857::::::::120:262::::::|h[타락하지 않은 버들]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135645, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[138839] = {
				"|cff9d9d9d|Hitem:138839::::::::98:73::::::|h[용맹한 자의 명예]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				952541, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[165450] = {
				"|cff0070dd|Hitem:165450::::::::120:73::::::|h[칼도레이 궁수의 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2373964, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169860] = {
				"|cff0070dd|Hitem:169860::::::::120:262::::::|h[작고 말쑥한 모자]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133100, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[170116] = {
				"|cff1eff00|Hitem:170116::::::::120:577::::::|h[어둠 깃든 절단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2829897, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[160137] = {
				"|cff1eff00|Hitem:160137::::::::114:73::::::|h[라바사우루스비늘 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[129163] = {
				"|cff0070dd|Hitem:129163::::::::106:73::::::|h[잃어버린 거인의 힘]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				133749, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[165456] = {
				"|cff0070dd|Hitem:165456::::::::120:73::::::|h[감시경비병의 가슴갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2316872, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[87649] = {
				"|cffa335ee|Hitem:87649::::::::120:577::::::|h[웅덩이 휘젓개]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				615480, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[163953] = {
				"|cffa335ee|Hitem:163953::::::::120:577::::::|h[줄라의 쾌활한 외투]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2054623, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[132749] = {
				"|cffffffff|Hitem:132749::::::::99:73::::::|h[군단 차원문 파편]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				961621, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161217] = {
				"|cff0070dd|Hitem:161217::::::::120:73::::::|h[오염된 피 완갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170117] = {
				"|cff1eff00|Hitem:170117::::::::120:577::::::|h[파도결속사의 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				2829934, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[160138] = {
				"|cff1eff00|Hitem:160138::::::::120:577::::::|h[라바사우루스비늘 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154820] = {
				"|cff1eff00|Hitem:154820::::::::120:262::::::|h[고름뿌리 웃옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1674413, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[165491] = {
				"|cff0070dd|Hitem:165491::::::::120:73::::::|h[죽음경비병의 투구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2393948, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158859] = {
				"|cff9d9d9d|Hitem:158859::::::::120:262::::::|h[톱니 송곳니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518091, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169350] = {
				"|cff1eff00|Hitem:169350::::::::120:577::::::|h[반짝이는 금강껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2027870, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160449] = {
				"|cff0070dd|Hitem:160449::::::::120:262::::::|h[유령 복수자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1712022, -- [4]
				2, -- [5]
				9, -- [6]
			},
			[141032] = {
				"|cffffffff|Hitem:141032::::::::106:73::::::|h[각인 기법: 얼어붙은 껍질]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				11, -- [6]
			},
			[170118] = {
				"|cff1eff00|Hitem:170118::::::::120:577::::::|h[백인대장의 쇼트소드]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				3004118, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[168327] = {
				"|cffa335ee|Hitem:168327::::::::120:262::::::|h[사슬 작열코일]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1405814, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[155843] = {
				"|cff9d9d9d|Hitem:155843::::::::120:577::::::|h[부서질 듯한 의식용 목걸이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1535082, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159198] = {
				"|cff1eff00|Hitem:159198::::::::120:262::::::|h[소금물 작업장 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1727709, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158860] = {
				"|cff9d9d9d|Hitem:158860::::::::120:262::::::|h[숫돌 어금니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518089, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169351] = {
				"|cff1eff00|Hitem:169351::::::::120:577::::::|h[모래집게 둥지추적자]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2027879, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[159196] = {
				"|cff1eff00|Hitem:159196::::::::120:262::::::|h[소금물 작업장 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1727714, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[106457] = {
				"|cff1eff00|Hitem:106457::::::::93:73::::::|h[바위등뼈 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				947377, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170119] = {
				"|cff1eff00|Hitem:170119::::::::120:577::::::|h[미끈껍질 전투검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2904097, -- [4]
				2, -- [5]
				9, -- [6]
			},
			[160140] = {
				"|cff1eff00|Hitem:160140::::::::120:577::::::|h[라바사우루스비늘 성큼장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159169] = {
				"|cff0070dd|Hitem:159169::::::::120:262::::::|h[피투성이 곰가죽 바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1733698, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[93960] = {
				"|cff9d9d9d|Hitem:93960::::::::120:73::::::|h[보석 박힌 데빌사우루스 알]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132836, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158861] = {
				"|cff9d9d9d|Hitem:158861::::::::120:577::::::|h[질긴 눈자루]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135503, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169352] = {
				"|cff0070dd|Hitem:169352::::::::120:577::::::|h[진줏빛 반짝껍질]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027919, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169426] = {
				"|cff1eff00|Hitem:169426::::::::120:577::::::|h[파도분쇄 경갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2966770, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158783] = {
				"|cff9d9d9d|Hitem:158783::::::::120:262::::::|h[하얀 비단 깃털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132914, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170120] = {
				"|cff1eff00|Hitem:170120::::::::120:577::::::|h[시녀의 긴지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2921481, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[160141] = {
				"|cff1eff00|Hitem:160141::::::::114:73::::::|h[라바사우루스비늘 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1690123, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159193] = {
				"|cff1eff00|Hitem:159193::::::::120:262::::::|h[소금물 작업장 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1727707, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[155842] = {
				"|cff9d9d9d|Hitem:155842::::::::120:577::::::|h[\"보존된\" 음식]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132934, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158862] = {
				"|cff9d9d9d|Hitem:158862::::::::120:262::::::|h[고대 무덤 티끌]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133852, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[165473] = {
				"|cff0070dd|Hitem:165473::::::::120:73::::::|h[죽음추적자의 발보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				2349369, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[106458] = {
				"|cff1eff00|Hitem:106458::::::::96:73::::::|h[바위등뼈 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				947373, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[116693] = {
				"|cff1eff00|Hitem:116693::::::::93:73::::::|h[얼음노래꾼 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1035455, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169403] = {
				"|cff1eff00|Hitem:169403::::::::120:577::::::|h[깊은바다 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2973322, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160142] = {
				"|cff1eff00|Hitem:160142::::::::114:73::::::|h[라바사우루스비늘 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1690124, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159839] = {
				"|cffffffff|Hitem:159839::::::::120:262::::::|h[거미줄]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237430, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160143] = {
				"|cff1eff00|Hitem:160143::::::::120:262::::::|h[라바사우루스비늘 어깨보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1690125, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[158863] = {
				"|cff9d9d9d|Hitem:158863::::::::120:577::::::|h[키틴질 외골격]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1499546, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[166760] = {
				"|cff0070dd|Hitem:166760::::::::120:73::::::|h[칼도레이 궁수의 큰망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2373976, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[174473] = {
				"|cff0070dd|Hitem:174473::::::::120:577::::::|h[커염둥이]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2958748, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[155841] = {
				"|cff9d9d9d|Hitem:155841::::::::120:577::::::|h[손상된 조각상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134896, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[141034] = {
				"|cff9d9d9d|Hitem:141034::::::::98:73::::::|h[까맣게 탄 각인 기법]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132386, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[137626] = {
				"|cffffffff|Hitem:137626::::::::99:73::::::|h[지옥쇄도]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237414, -- [4]
				15, -- [5]
				1, -- [6]
			},
			[109061] = {
				"|cff0070dd|Hitem:109061::::::::93:73::::::|h[쿠탈그의 무자비한 손장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				132944, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169402] = {
				"|cff1eff00|Hitem:169402::::::::120:577::::::|h[깊은바다 아미스]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2973331, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154770] = {
				"|cff9d9d9d|Hitem:154770::::::::120:73::::::|h[갈라진 생가죽 허리띠]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WAIST", -- [3]
				132493, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169355] = {
				"|cff1eff00|Hitem:169355::::::::120:577::::::|h[딱딱가시 바늘게]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1508493, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169611] = {
				"|cff1eff00|Hitem:169611::::::::120:577::::::|h[조제법: 진모래말미꽃]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[116694] = {
				"|cff1eff00|Hitem:116694::::::::92:73::::::|h[얼음노래꾼 수정]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				929894, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[116507] = {
				"|cff1eff00|Hitem:116507::::::::96:73::::::|h[성장술사 마법봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				938930, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[160144] = {
				"|cff1eff00|Hitem:160144::::::::120:577::::::|h[라바사우루스비늘 흉갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1690121, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159840] = {
				"|cffa335ee|Hitem:159840::::::::120:262::::::|h[티부의 이글거리는 직검]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				135323, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[169613] = {
				"|cffffffff|Hitem:169613::::::::120:577::::::|h[도안: 오스미나이트 융기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[154771] = {
				"|cff9d9d9d|Hitem:154771::::::::120:72::::::|h[갈라진 생가죽 장화]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_FEET", -- [3]
				132539, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169356] = {
				"|cff0070dd|Hitem:169356::::::::120:262::::::|h[암흑동굴 악몽게]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1508492, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169612] = {
				"|cffffffff|Hitem:169612::::::::120:577::::::|h[도안: 오스미나이트 광맥]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				0, -- [6]
			},
			[139529] = {
				"|cffffffff|Hitem:139529::::::::106:73::::::|h[열기가 느껴지는 요청서]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134937, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[157842] = {
				"|cff9d9d9d|Hitem:157842::::::::120:262::::::|h[녹슨 장비]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134064, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160145] = {
				"|cff1eff00|Hitem:160145::::::::120:577::::::|h[사우리드깃털 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1762573, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[87600] = {
				"|cff0070dd|Hitem:87600::::::::91:73::::::|h[늪노래 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				646762, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163939] = {
				"|cffa335ee|Hitem:163939::::::::120:577::::::|h[말루소프의 안정적인 통바지]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				1017828, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154772] = {
				"|cff9d9d9d|Hitem:154772::::::::120:262::::::|h[갈라진 생가죽 장갑]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HAND", -- [3]
				132952, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[162663] = {
				"|cff9d9d9d|Hitem:162663::::::::120:262::::::|h[부러진 창머리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135125, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155284] = {
				"|cff0070dd|Hitem:155284::::::::120:262::::::|h[싸늘한 언덕 강타자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1695564, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[116695] = {
				"|cff1eff00|Hitem:116695::::::::93:73::::::|h[얼음노래꾼 반지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				515955, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161213] = {
				"|cff9d9d9d|Hitem:161213::::::::120:262::::::|h[현자의 영지 성가집]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				354719, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160146] = {
				"|cff1eff00|Hitem:160146::::::::120:262::::::|h[사우리드깃털 벼슬]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1762578, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154816] = {
				"|cff1eff00|Hitem:154816::::::::120:262::::::|h[고름뿌리 성큼장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1674411, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159497] = {
				"|cff1eff00|Hitem:159497::::::::120:262::::::|h[심연지기 발화총]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1773651, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[158867] = {
				"|cff9d9d9d|Hitem:158867::::::::120:262::::::|h[바늘 같은 부리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133707, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163958] = {
				"|cffa335ee|Hitem:163958::::::::120:577::::::|h[프리지의 거품퐁퐁 단도]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				968649, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[163031] = {
				"|cff9d9d9d|Hitem:163031::::::::120:262::::::|h[불안정한 다이너마이트 상자]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132766, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163938] = {
				"|cffa335ee|Hitem:163938::::::::120:577::::::|h[칼리브의 발길질 장화]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				462524, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[157844] = {
				"|cff9d9d9d|Hitem:157844::::::::120:577::::::|h[무지갯빛 입자]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132872, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160147] = {
				"|cff1eff00|Hitem:160147::::::::120:577::::::|h[사우리드깃털 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1762577, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[113571] = {
				"|cff0070dd|Hitem:113571::::::::98:73::::::|h[어둠살이의 장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				929915, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161028] = {
				"|cff0070dd|Hitem:161028::::::::120:262::::::|h[맹독 악어 가죽바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158868] = {
				"|cff9d9d9d|Hitem:158868::::::::120:577::::::|h[금빛 장식]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				458253, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169359] = {
				"|cff0070dd|Hitem:169359::::::::120:577::::::|h[날라아다의 후손]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027953, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[161212] = {
				"|cff9d9d9d|Hitem:161212::::::::120:577::::::|h[파도예언자의 별자리표]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1519351, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[159206] = {
				"|cff1eff00|Hitem:159206::::::::120:262::::::|h[뾰족털 어깨덧대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1733699, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169435] = {
				"|cff1eff00|Hitem:169435::::::::120:577::::::|h[깊은바다 외투]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2973333, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160148] = {
				"|cff1eff00|Hitem:160148::::::::120:577::::::|h[사우리드깃털 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169230] = {
				"|cffffffff|Hitem:169230::::::::120:577::::::|h[반사의 철판]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133022, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158870] = {
				"|cff9d9d9d|Hitem:158870::::::::120:262::::::|h[털북숭이 털]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134352, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[134305] = {
				"|cff1eff00|Hitem:134305::::::::101:73::::::|h[마나고문자 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1134726, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[87651] = {
				"|cffa335ee|Hitem:87651::::::::89:73::::::|h[길나그네 대지팡이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				533889, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[154844] = {
				"|cff1eff00|Hitem:154844::::::::120:577::::::|h[콜레인 경갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1727713, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169872] = {
				"|cff0070dd|Hitem:169872::::::::120:262::::::|h[무쇠파도 금고 열쇠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				136058, -- [4]
				13, -- [5]
				0, -- [6]
			},
			[174222] = {
				"|cff0070dd|Hitem:174222::::::::120:72::::::|h[형언할 수 없는 혈문도]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				538490, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[124117] = {
				"|cffffffff|Hitem:124117::::::::101:73::::::|h[정강이 살코기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387655, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[163699] = {
				"|cffffffff|Hitem:163699::::::::120:577::::::|h[열처리한 꿀 아뮬렛]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				632830, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161211] = {
				"|cff9d9d9d|Hitem:161211::::::::120:577::::::|h[병 안의 배]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1126431, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154776] = {
				"|cff9d9d9d|Hitem:154776::::::::120:262::::::|h[갈라진 생가죽 조끼]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_CHEST", -- [3]
				132724, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169361] = {
				"|cff0070dd|Hitem:169361::::::::120:577::::::|h[단도이빨 광포어]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2564610, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169873] = {
				"|cff0070dd|Hitem:169873::::::::120:262::::::|h[기계 보급품 열쇠]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				348541, -- [4]
				13, -- [5]
				0, -- [6]
			},
			[116697] = {
				"|cff1eff00|Hitem:116697::::::::96:73::::::|h[달빛속삭임 수정]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				929894, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[167786] = {
				"|cffffffff|Hitem:167786::::::::120:577::::::|h[싹틔우는 씨앗]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				464030, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160150] = {
				"|cff1eff00|Hitem:160150::::::::120:577::::::|h[사우리드깃털 발보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1762574, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[124118] = {
				"|cffffffff|Hitem:124118::::::::105:73::::::|h[기름진 곰 스테이크]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387648, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[138396] = {
				"|cff0070dd|Hitem:138396::::::::109:73::::::|h[강력한 사슬 발보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1116922, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154777] = {
				"|cff9d9d9d|Hitem:154777::::::::120:577::::::|h[갈라진 생가죽 손목보호구]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WRIST", -- [3]
				132607, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163947] = {
				"|cffa335ee|Hitem:163947::::::::120:577::::::|h[디누사의 억센 다리싸개]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_LEGS", -- [3]
				422806, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[106405] = {
				"|cff1eff00|Hitem:106405::::::::96:73::::::|h[얼음주둥이 어깨보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1006305, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[139527] = {
				"|cffffffff|Hitem:139527::::::::101:73::::::|h[피에 젖은 호소문]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133675, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[174224] = {
				"|cff0070dd|Hitem:174224::::::::120:72::::::|h[잔혹의 대검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				368868, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[160151] = {
				"|cff1eff00|Hitem:160151::::::::120:577::::::|h[사우리드깃털 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1762580, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161210] = {
				"|cff9d9d9d|Hitem:161210::::::::120:262::::::|h[집에서 만든 어린이용 인형]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716867, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154813] = {
				"|cff1eff00|Hitem:154813::::::::120:262::::::|h[토르가껍질 판금소매]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1672315, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158872] = {
				"|cff9d9d9d|Hitem:158872::::::::120:577::::::|h[불안정한 정수]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132867, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169363] = {
				"|cff0070dd|Hitem:169363::::::::120:577::::::|h[자수정 연갑달팽이]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2530493, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[155543] = {
				"|cff0070dd|Hitem:155543::::::::120:262::::::|h[투스카르 고래잡이의 작살]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661331, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[106463] = {
				"|cff1eff00|Hitem:106463::::::::96:73::::::|h[바위등뼈 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				925625, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[141577] = {
				"|cffa335ee|Hitem:141577::::::::102:73::::::|h[영주 크레이텐의 주먹]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HAND", -- [3]
				1316218, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168340] = {
				"|cffa335ee|Hitem:168340::::::::120:577::::::|h[나가 의식술사의 어깨덧옷]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2906601, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163942] = {
				"|cffa335ee|Hitem:163942::::::::120:262::::::|h[제멋대로인 요정의 끌신]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				1627511, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[166805] = {
				"|cff1eff00|Hitem:166805::::::::120:577::::::|h[피에 젖은 초대장]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				133675, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154779] = {
				"|cff9d9d9d|Hitem:154779::::::::120:577::::::|h[파열된 판금 디딤장화]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_FEET", -- [3]
				132589, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159192] = {
				"|cff1eff00|Hitem:159192::::::::120:262::::::|h[소금물 작업장 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1727711, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[163946] = {
				"|cffa335ee|Hitem:163946::::::::120:577::::::|h[가영의 온화한 발걸음]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				132556, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161045] = {
				"|cff0070dd|Hitem:161045::::::::120:73::::::|h[두루마리속박 태풍 끌신]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1762574, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154774] = {
				"|cff9d9d9d|Hitem:154774::::::::120:262::::::|h[갈라진 생가죽 바지]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_LEGS", -- [3]
				134582, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160153] = {
				"|cff1eff00|Hitem:160153::::::::120:262::::::|h[폭풍제련사 가슴갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1672317, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159220] = {
				"|cff1eff00|Hitem:159220::::::::120:262::::::|h[현자의 영지 예복]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				1698805, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158874] = {
				"|cff9d9d9d|Hitem:158874::::::::120:262::::::|h[부글거리는 증기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132837, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154780] = {
				"|cff9d9d9d|Hitem:154780::::::::120:72::::::|h[파열된 판금 견갑]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				135044, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[159756] = {
				"|cff9d9d9d|Hitem:159756::::::::120:577::::::|h[고갈된 아제라이트]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237007, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158363] = {
				"|cff0070dd|Hitem:158363::::::::120:262::::::|h[거미털 머리장식]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1698807, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[116699] = {
				"|cff1eff00|Hitem:116699::::::::94:73::::::|h[성장술사 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1035498, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[174227] = {
				"|cff0070dd|Hitem:174227::::::::120:72::::::|h[꿈틀대는 촉수]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				530806, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[160154] = {
				"|cff1eff00|Hitem:160154::::::::120:262::::::|h[폭풍제련사 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166551] = {
				"|cff0070dd|Hitem:166551::::::::120:73::::::|h[죽음경비병의 어깨철갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2393952, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[124119] = {
				"|cffffffff|Hitem:124119::::::::105:73::::::|h[누린내가 나는 커다란 갈비]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387642, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[169110] = {
				"|cffa335ee|Hitem:169110::::::::120:577::::::|h[젤리 자석]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1500972, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[169366] = {
				"|cff0070dd|Hitem:169366::::::::120:577::::::|h[꾸물이]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2763647, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[163097] = {
				"|cff9d9d9d|Hitem:163097::::::::120:577::::::|h[조각한 토끼 입상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716879, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169241] = {
				"|cffffffff|Hitem:169241::::::::120:262::::::|h[가문의 장신구]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133299, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[124120] = {
				"|cffffffff|Hitem:124120::::::::99:73::::::|h[지맥 피]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387657, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[160155] = {
				"|cff1eff00|Hitem:160155::::::::120:577::::::|h[폭풍제련사 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166552] = {
				"|cff0070dd|Hitem:166552::::::::120:73::::::|h[역병경비병의 어깨덮개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2357691, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[160952] = {
				"|cff0070dd|Hitem:160952::::::::114:73::::::|h[비수이빨의 앞니]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1686940, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[154782] = {
				"|cff9d9d9d|Hitem:154782::::::::120:577::::::|h[파열된 판금 보호모]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HEAD", -- [3]
				133071, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[124121] = {
				"|cffffffff|Hitem:124121::::::::104:73::::::|h[들새 알]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387668, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[174769] = {
				"|cffa335ee|Hitem:174769::::::::120:72::::::|h[악독한 일벌레]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2914896, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[106465] = {
				"|cff1eff00|Hitem:106465::::::::93:73::::::|h[채찍꼬리 손목띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				940656, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160149] = {
				"|cff1eff00|Hitem:160149::::::::120:262::::::|h[사우리드깃털 의복]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				1762576, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160156] = {
				"|cff1eff00|Hitem:160156::::::::120:262::::::|h[폭풍제련사 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1672319, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166553] = {
				"|cff0070dd|Hitem:166553::::::::120:73::::::|h[죽음추적자의 어깨덧대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2349377, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[106466] = {
				"|cff1eff00|Hitem:106466::::::::94:73::::::|h[채찍꼬리 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				940655, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160924] = {
				"|cff9d9d9d|Hitem:160924::::::::120:262::::::|h[오래된 새긴자국 검]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPON", -- [3]
				135643, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[169368] = {
				"|cff0070dd|Hitem:169368::::::::120:577::::::|h[폭풍격노]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				236154, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[161036] = {
				"|cff0070dd|Hitem:161036::::::::120:577::::::|h[모래로 연마한 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1672315, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160926] = {
				"|cff9d9d9d|Hitem:160926::::::::120:577::::::|h[부서진 철곤봉]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				133476, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[130134] = {
				"|cff0070dd|Hitem:130134::::::::106:73::::::|h[솜 덧댄 사슬 저격수 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1116927, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[160157] = {
				"|cff1eff00|Hitem:160157::::::::120:577::::::|h[폭풍제련사 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1672320, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166554] = {
				"|cff0070dd|Hitem:166554::::::::120:73::::::|h[역병인도자의 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2450992, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160925] = {
				"|cff9d9d9d|Hitem:160925::::::::120:262::::::|h[단단한 커틀라스]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPON", -- [3]
				135328, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[154784] = {
				"|cff9d9d9d|Hitem:154784::::::::120:577::::::|h[파열된 판금 흉갑]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_CHEST", -- [3]
				132746, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169369] = {
				"|cff0070dd|Hitem:169369::::::::120:577::::::|h[모래성 정령]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				796636, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169139] = {
				"|cff9d9d9d|Hitem:169139::::::::120:262::::::|h[막힌 거미줄 직조기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133027, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163740] = {
				"|cff0070dd|Hitem:163740::::::::120:262::::::|h[드러스트 의식용 나이프]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				940537, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[131900] = {
				"|cff0070dd|Hitem:131900::::::::105:73::::::|h[위풍당당한 늙은뿔 순록 발굽]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132368, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160158] = {
				"|cff1eff00|Hitem:160158::::::::120:577::::::|h[폭풍제련사 견갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1672321, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154273] = {
				"|cff0070dd|Hitem:154273::::::::120:262::::::|h[바위막이 가슴보호갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1727710, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161047] = {
				"|cff0070dd|Hitem:161047::::::::120:577::::::|h[암흑 바람 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154785] = {
				"|cff9d9d9d|Hitem:154785::::::::120:73::::::|h[파열된 판금 허리띠]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WAIST", -- [3]
				132495, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169370] = {
				"|cff0070dd|Hitem:169370::::::::120:577::::::|h[비늘떼 히드라]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				463493, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[106403] = {
				"|cff1eff00|Hitem:106403::::::::93:73::::::|h[얼음주둥이 두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				940659, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160980] = {
				"|cff0070dd|Hitem:160980::::::::120:577::::::|h[하늘조각사 전투검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1712022, -- [4]
				2, -- [5]
				9, -- [6]
			},
			[130135] = {
				"|cff0070dd|Hitem:130135::::::::101:73::::::|h[마나배회자 다리보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1115107, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160159] = {
				"|cff1eff00|Hitem:160159::::::::120:577::::::|h[폭풍제련사 발덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168603] = {
				"|cffa335ee|Hitem:168603::::::::120:577::::::|h[안식 없는 영혼의 망토]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2912996, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169168] = {
				"|cff0070dd|Hitem:169168::::::::120:577::::::|h[도면: 초록색 분무로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154786] = {
				"|cff9d9d9d|Hitem:154786::::::::120:577::::::|h[실밥이 풀린 천 손목싸개]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WRIST", -- [3]
				132609, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169371] = {
				"|cff0070dd|Hitem:169371::::::::120:577::::::|h[머르글]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3004140, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[94158] = {
				"|cff0070dd|Hitem:94158::::::::90:73::::::|h[잔달라 보급품이 든 큰 자루]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133665, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163742] = {
				"|cff0070dd|Hitem:163742::::::::120:577::::::|h[심장파멸 흑마법서]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2101967, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[175001] = {
				"|cffffffff|Hitem:175001::::::::120:72::::::|h[아퀴르 그물]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237430, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160160] = {
				"|cff1eff00|Hitem:160160::::::::120:577::::::|h[폭풍제련사 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1672315, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166557] = {
				"|cff0070dd|Hitem:166557::::::::120:73::::::|h[어둠숲 파수꾼의 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2351534, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[172954] = {
				"|cffffffff|Hitem:172954::::::::120:577::::::|h[필멸의 메아리]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				656551, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160928] = {
				"|cff9d9d9d|Hitem:160928::::::::120:262::::::|h[오래된 대검]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				135349, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[169372] = {
				"|cff0070dd|Hitem:169372::::::::120:577::::::|h[어린 죽음지느러미 멀록]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				970832, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[155299] = {
				"|cff0070dd|Hitem:155299::::::::120:73::::::|h[자매 마사의 영혼갈취자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1697864, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[163743] = {
				"|cff0070dd|Hitem:163743::::::::120:577::::::|h[드러스트 영혼갈무리]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				896907, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160950] = {
				"|cff0070dd|Hitem:160950::::::::120:262::::::|h[무딘 나즈마니 거대도끼]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1694560, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[160161] = {
				"|cff1eff00|Hitem:160161::::::::120:577::::::|h[부정한 하늘망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1729479, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163090] = {
				"|cff9d9d9d|Hitem:163090::::::::120:577::::::|h[경화 연기잡초 상자]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134186, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[133827] = {
				"|cffffffff|Hitem:133827::::::::106:73::::::|h[조리법: 곰 육회]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387620, -- [4]
				9, -- [5]
				5, -- [6]
			},
			[162976] = {
				"|cff9d9d9d|Hitem:162976::::::::120:577::::::|h[추방자의 버려진 물품]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				348526, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169373] = {
				"|cff0070dd|Hitem:169373::::::::120:577::::::|h[염수석 해초정령]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				960692, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160182] = {
				"|cff1eff00|Hitem:160182::::::::120:262::::::|h[하늘소환사 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154787] = {
				"|cff9d9d9d|Hitem:154787::::::::120:577::::::|h[실밥이 풀린 천 셔츠]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_ROBE", -- [3]
				135012, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[116480] = {
				"|cff1eff00|Hitem:116480::::::::96:73::::::|h[달빛광휘 너클]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				930038, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[160162] = {
				"|cff1eff00|Hitem:160162::::::::120:577::::::|h[모래정찰병 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1674412, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[134375] = {
				"|cff1eff00|Hitem:134375::::::::101:73::::::|h[지옥박쥐 가죽 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1130505, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169393] = {
				"|cff0070dd|Hitem:169393::::::::120:262::::::|h[기계거미 발발로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2493081, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160930] = {
				"|cff9d9d9d|Hitem:160930::::::::120:577::::::|h[따개비 붙은 거대도끼]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				135424, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[169374] = {
				"|cff0070dd|Hitem:169374::::::::120:577::::::|h[피어나는 해초정령]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				960692, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[106418] = {
				"|cff1eff00|Hitem:106418::::::::93:73::::::|h[서리고리 경갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				929915, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169886] = {
				"|cff0070dd|Hitem:169886::::::::120:577::::::|h[분무로봇 0D]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2735924, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160931] = {
				"|cff9d9d9d|Hitem:160931::::::::120:73::::::|h[거친 요리용 꼬챙이]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				135128, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[168351] = {
				"|cffa335ee|Hitem:168351::::::::120:577::::::|h[바늘장착 어깨보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2913001, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154789] = {
				"|cff9d9d9d|Hitem:154789::::::::120:577::::::|h[실밥이 풀린 천 바지]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_LEGS", -- [3]
				134581, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169407] = {
				"|cff1eff00|Hitem:169407::::::::120:577::::::|h[미끈껍질반장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2902642, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[162978] = {
				"|cff9d9d9d|Hitem:162978::::::::120:577::::::|h[혈마법 의식용 접시]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133748, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169375] = {
				"|cff0070dd|Hitem:169375::::::::120:577::::::|h[산호 덩굴손]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027890, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160984] = {
				"|cff0070dd|Hitem:160984::::::::114:73::::::|h[적응의 공룡비늘 망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1729479, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159475] = {
				"|cff1eff00|Hitem:159475::::::::120:577::::::|h[함선좌초자 도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[162980] = {
				"|cff9d9d9d|Hitem:162980::::::::120:262::::::|h[금빛 항해실 타래]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				348562, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160164] = {
				"|cff1eff00|Hitem:160164::::::::120:577::::::|h[모래정찰병 가죽바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[166561] = {
				"|cff0070dd|Hitem:166561::::::::120:73::::::|h[죽음경비병의 투구모자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2393948, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161204] = {
				"|cff9d9d9d|Hitem:161204::::::::120:262::::::|h[기름 낀 유리 안구]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				970832, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154791] = {
				"|cff9d9d9d|Hitem:154791::::::::120:577::::::|h[실밥이 풀린 천 수도두건]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HEAD", -- [3]
				133153, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169376] = {
				"|cff0070dd|Hitem:169376::::::::120:577::::::|h[새끼 뱀장어]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133898, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[161444] = {
				"|cff0070dd|Hitem:161444::::::::120:262::::::|h[얼어붙은 갈퀴깃털 어깨덧옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1698809, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163084] = {
				"|cff9d9d9d|Hitem:163084::::::::120:262::::::|h[금도금 커틀라스]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135396, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[106425] = {
				"|cff1eff00|Hitem:106425::::::::93:73::::::|h[서리판금 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				947373, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160165] = {
				"|cff1eff00|Hitem:160165::::::::120:577::::::|h[모래정찰병 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[166562] = {
				"|cff0070dd|Hitem:166562::::::::120:73::::::|h[역병경비병의 투구모자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2357689, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154792] = {
				"|cff9d9d9d|Hitem:154792::::::::120:262::::::|h[실밥이 풀린 천 장식끈]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WAIST", -- [3]
				132511, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160933] = {
				"|cff9d9d9d|Hitem:160933::::::::120:262::::::|h[쪼개진 장궁]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_RANGED", -- [3]
				135490, -- [4]
				2, -- [5]
				2, -- [6]
			},
			[160932] = {
				"|cff9d9d9d|Hitem:160932::::::::120:73::::::|h[흰개미로 오염된 지팡이]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				135139, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[138418] = {
				"|cff0070dd|Hitem:138418::::::::106:73::::::|h[태풍 손장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1116925, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[155560] = {
				"|cff0070dd|Hitem:155560::::::::120:262::::::|h[게으른 제빵사의 반지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391759, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160935] = {
				"|cff9d9d9d|Hitem:160935::::::::120:577::::::|h[역발하는 나팔총]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				135616, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[160166] = {
				"|cff1eff00|Hitem:160166::::::::120:577::::::|h[모래정찰병 면갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1674415, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[166563] = {
				"|cff0070dd|Hitem:166563::::::::120:73::::::|h[죽음추적자의 복면]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2349375, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169124] = {
				"|cff9d9d9d|Hitem:169124::::::::120:577::::::|h[장식용 뱅글톱니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				2437246, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154793] = {
				"|cff9d9d9d|Hitem:154793::::::::120:577::::::|h[실밥이 풀린 천 아미스]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				135040, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161205] = {
				"|cff9d9d9d|Hitem:161205::::::::120:262::::::|h[나무 말 조각]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716869, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169135] = {
				"|cff9d9d9d|Hitem:169135::::::::120:577::::::|h[왜곡된 충격 흡수기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134518, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154794] = {
				"|cff9d9d9d|Hitem:154794::::::::120:577::::::|h[바스러지는 사슬 손목보호구]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WRIST", -- [3]
				132602, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168099] = {
				"|cffffffff|Hitem:168099::::::::120:577::::::|h[깊은산호 주머니]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				960695, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[160167] = {
				"|cff1eff00|Hitem:160167::::::::120:577::::::|h[모래정찰병 튜닉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1674413, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[166564] = {
				"|cff0070dd|Hitem:166564::::::::120:73::::::|h[역병인도자의 투구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2450991, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[174764] = {
				"|cff1eff00|Hitem:174764::::::::120:577::::::|h[톨비르 유물 조각]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				442739, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169123] = {
				"|cff9d9d9d|Hitem:169123::::::::120:577::::::|h[기능성 조작전환기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1888317, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169379] = {
				"|cff1eff00|Hitem:169379::::::::120:73::::::|h[포근눈 야금이]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2205588, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[166565] = {
				"|cff0070dd|Hitem:166565::::::::120:73::::::|h[감시경비병의 얼굴보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2316876, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170086] = {
				"|cff9d9d9d|Hitem:170086::::::::120:577::::::|h[산호얼룩 성배]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132789, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170147] = {
				"|cff1eff00|Hitem:170147::::::::120:577::::::|h[페인트 통: 고블린 초록]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				463860, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160168] = {
				"|cff1eff00|Hitem:160168::::::::120:577::::::|h[모래정찰병 어깨가죽]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1674417, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[174753] = {
				"|cffa335ee|Hitem:174753::::::::120:577::::::|h[황무지 노략꾼]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				1929247, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[159260] = {
				"|cff1eff00|Hitem:159260::::::::120:262::::::|h[뾰족털 큰망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1733694, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154795] = {
				"|cff9d9d9d|Hitem:154795::::::::120:262::::::|h[바스러지는 사슬 어깨덮개]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				135033, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154796] = {
				"|cff9d9d9d|Hitem:154796::::::::120:262::::::|h[바스러지는 사슬 발덮개]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_FEET", -- [3]
				132535, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[106423] = {
				"|cff1eff00|Hitem:106423::::::::96:73::::::|h[서리판금 흉갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				947376, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[173986] = {
				"|cffffffff|Hitem:173986::::::::120:72::::::|h[태양왕의 문서]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237450, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169398] = {
				"|cff1eff00|Hitem:169398::::::::120:577::::::|h[깊은바다 끌신]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2973324, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160169] = {
				"|cff1eff00|Hitem:160169::::::::120:577::::::|h[모래정찰병 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1674410, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160170] = {
				"|cff1eff00|Hitem:160170::::::::120:577::::::|h[메마른 짐마차 고리]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391713, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[108907] = {
				"|cff0070dd|Hitem:108907::::::::94:73::::::|h[운명의 버섯]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				134532, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160937] = {
				"|cff9d9d9d|Hitem:160937::::::::120:577::::::|h[화살 박힌 아이기스]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_SHIELD", -- [3]
				134955, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[168366] = {
				"|cffa335ee|Hitem:168366::::::::120:577::::::|h[해일잠복자의 철갑투구]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_HEAD", -- [3]
				2901583, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160938] = {
				"|cff9d9d9d|Hitem:160938::::::::120:262::::::|h[구부러진 천공 칼날]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPON", -- [3]
				132369, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[167846] = {
				"|cff0070dd|Hitem:167846::::::::120:262::::::|h[도면: 기계 간식]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[155572] = {
				"|cff0070dd|Hitem:155572::::::::120:73::::::|h[분노한 설인의 망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1698804, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168358] = {
				"|cffa335ee|Hitem:168358::::::::120:577::::::|h[물속에 잠긴 자의 가슴보호대]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_CHEST", -- [3]
				2909753, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[133816] = {
				"|cffffffff|Hitem:133816::::::::104:73::::::|h[조리법: 지맥구이 갈비]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387620, -- [4]
				9, -- [5]
				5, -- [6]
			},
			[169228] = {
				"|cff1eff00|Hitem:169228::::::::120:577::::::|h[위험한 용기]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237030, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169126] = {
				"|cff9d9d9d|Hitem:169126::::::::120:577::::::|h[과충전 그래픽 톱니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				321487, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169382] = {
				"|cff0070dd|Hitem:169382::::::::120:262::::::|h[잊혀진 악력로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1521022, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[169133] = {
				"|cffa335ee|Hitem:169133::::::::120:262::::::|h[결정화된 젤리]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				134111, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[167847] = {
				"|cff0070dd|Hitem:167847::::::::120:577::::::|h[도면: 안전보증 순간이동기: 메카곤]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154898] = {
				"|cffffffff|Hitem:154898::::::::120:577::::::|h[살이 많은 볼깃살]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066012, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[160171] = {
				"|cff1eff00|Hitem:160171::::::::120:577::::::|h[뼈다귀청소부 허리끈]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[174756] = {
				"|cff1eff00|Hitem:174756::::::::120:72::::::|h[아퀴르 유물 조각]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				441140, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[131775] = {
				"|cff0070dd|Hitem:131775::::::::106:73::::::|h[망치주먹의 장난감 갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				1117700, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154798] = {
				"|cff9d9d9d|Hitem:154798::::::::120:577::::::|h[바스러지는 사슬 갑옷]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_CHEST", -- [3]
				132627, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[160139] = {
				"|cff1eff00|Hitem:160139::::::::120:577::::::|h[라바사우루스비늘 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169128] = {
				"|cff9d9d9d|Hitem:169128::::::::120:577::::::|h[냉각 가열 부품]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				236869, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169167] = {
				"|cff0070dd|Hitem:169167::::::::120:577::::::|h[도면: 주황색 분무로봇]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154810] = {
				"|cff1eff00|Hitem:154810::::::::120:262::::::|h[토르가껍질 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1672320, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[166313] = {
				"|cffffffff|Hitem:166313::::::::120:262::::::|h[도안: 거친 가죽 마갑]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387622, -- [4]
				9, -- [5]
				1, -- [6]
			},
			[169229] = {
				"|cffffffff|Hitem:169229::::::::120:577::::::|h[배기관 향료]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133020, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169132] = {
				"|cff9d9d9d|Hitem:169132::::::::120:577::::::|h[깨진 회전의]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132998, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154799] = {
				"|cff9d9d9d|Hitem:154799::::::::120:577::::::|h[바스러지는 사슬 장갑]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HAND", -- [3]
				132944, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[155055] = {
				"|cff0070dd|Hitem:155055::::::::120:262::::::|h[영혼저주 집행자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				948427, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[169232] = {
				"|cffffffff|Hitem:169232::::::::120:577::::::|h[미작동 폭발통]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1405814, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[108906] = {
				"|cff0070dd|Hitem:108906::::::::94:73::::::|h[포자박쥐의 산성 꼬투리]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FINGER", -- [3]
				529425, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169129] = {
				"|cff9d9d9d|Hitem:169129::::::::120:577::::::|h[사랑스럽게 닳은 랜치]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				2437249, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160173] = {
				"|cff1eff00|Hitem:160173::::::::120:262::::::|h[뼈다귀청소부 손보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[174758] = {
				"|cffffffff|Hitem:174758::::::::120:577::::::|h[공허로 뒤틀린 유물 조각]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				3072269, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[144309] = {
				"|cffffffff|Hitem:144309::::::::106:73::::::|h[주문식: 목걸이 마법부여 - 특화의 징표]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				8, -- [6]
			},
			[154800] = {
				"|cff9d9d9d|Hitem:154800::::::::120:262::::::|h[바스러지는 사슬 코이프]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HEAD", -- [3]
				132767, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159803] = {
				"|cff1eff00|Hitem:159803::::::::120:262::::::|h[찬비늘 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1723673, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[169149] = {
				"|cff9d9d9d|Hitem:169149::::::::120:577::::::|h[닳은 미세-톱니 모양 앞니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1518088, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[155568] = {
				"|cff0070dd|Hitem:155568::::::::120:262::::::|h[돌풍바람 풍경]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				458244, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[133820] = {
				"|cffffffff|Hitem:133820::::::::109:73::::::|h[조리법: 드로그바식 연어]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387620, -- [4]
				9, -- [5]
				5, -- [6]
			},
			[160174] = {
				"|cff1eff00|Hitem:160174::::::::120:262::::::|h[뼈다귀청소부 발등덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[166571] = {
				"|cff0070dd|Hitem:166571::::::::120:73::::::|h[어둠숲 파수꾼의 탈]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2351532, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154801] = {
				"|cff9d9d9d|Hitem:154801::::::::120:577::::::|h[바스러지는 사슬 허리띠]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WAIST", -- [3]
				132498, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169130] = {
				"|cff9d9d9d|Hitem:169130::::::::120:577::::::|h[휘어진 맞물림톱니]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134064, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[161198] = {
				"|cff9d9d9d|Hitem:161198::::::::120:262::::::|h[늙은 선원의 연감]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133736, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154802] = {
				"|cff9d9d9d|Hitem:154802::::::::120:73::::::|h[새김눈 손도끼]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				135421, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[106474] = {
				"|cff1eff00|Hitem:106474::::::::98:73::::::|h[이유운 수도두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				937859, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169138] = {
				"|cff9d9d9d|Hitem:169138::::::::120:262::::::|h[부서진 인성 모듈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134070, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160175] = {
				"|cff1eff00|Hitem:160175::::::::120:577::::::|h[뼈다귀청소부 보호모]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1690123, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[166572] = {
				"|cff0070dd|Hitem:166572::::::::120:73::::::|h[달사제의 면갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				2444253, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160152] = {
				"|cff1eff00|Hitem:160152::::::::120:262::::::|h[사우리드깃털 손목싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160943] = {
				"|cffffffff|Hitem:160943::::::::114:73::::::|h[세콧의 오래된 손]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				446115, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[161199] = {
				"|cff9d9d9d|Hitem:161199::::::::120:262::::::|h[은판 술잔]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132790, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[116471] = {
				"|cff1eff00|Hitem:116471::::::::93:73::::::|h[동상 검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1068836, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[106475] = {
				"|cff1eff00|Hitem:106475::::::::96:73::::::|h[이유운 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				937858, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[138419] = {
				"|cff0070dd|Hitem:138419::::::::106:73::::::|h[결속사의 속박]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1115103, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160176] = {
				"|cff1eff00|Hitem:160176::::::::120:577::::::|h[뼈다귀청소부 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1690124, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[166573] = {
				"|cff0070dd|Hitem:166573::::::::120:73::::::|h[역병인도자의 의복]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_ROBE", -- [3]
				2450989, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[144312] = {
				"|cffffffff|Hitem:144312::::::::105:73::::::|h[주문식: 목걸이 마법부여 - 유연의 징표]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				8, -- [6]
			},
			[154803] = {
				"|cff9d9d9d|Hitem:154803::::::::120:577::::::|h[마모된 큰망치]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				133053, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[161200] = {
				"|cff9d9d9d|Hitem:161200::::::::120:262::::::|h[눈물방울 진주]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237370, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160172] = {
				"|cff1eff00|Hitem:160172::::::::120:577::::::|h[뼈다귀청소부 손목보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169127] = {
				"|cff9d9d9d|Hitem:169127::::::::120:577::::::|h[맛있는 냄새가 나는 기름]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135447, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154840] = {
				"|cff1eff00|Hitem:154840::::::::120:577::::::|h[콜레인 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1727710, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160177] = {
				"|cff1eff00|Hitem:160177::::::::120:577::::::|h[뼈다귀청소부 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1690125, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[166574] = {
				"|cff0070dd|Hitem:166574::::::::120:73::::::|h[죽음경비병의 가슴보호갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2393943, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[132184] = {
				"|cff9d9d9d|Hitem:132184::::::::99:73::::::|h[온전하고 반짝이는 비늘]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				443382, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[154804] = {
				"|cff9d9d9d|Hitem:154804::::::::120:73::::::|h[이가 빠진 시미터]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				132321, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[161201] = {
				"|cff9d9d9d|Hitem:161201::::::::120:262::::::|h[인어의 망원경]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				458243, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169125] = {
				"|cff9d9d9d|Hitem:169125::::::::120:577::::::|h[음파 나사못]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134069, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[106476] = {
				"|cff1eff00|Hitem:106476::::::::96:73::::::|h[이유운 다리보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				937861, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163111] = {
				"|cff9d9d9d|Hitem:163111::::::::120:262::::::|h[검은돌 고양이 동상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133236, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160178] = {
				"|cff1eff00|Hitem:160178::::::::120:262::::::|h[뼈다귀청소부 속갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1690121, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[166575] = {
				"|cff0070dd|Hitem:166575::::::::120:73::::::|h[역병경비병의 쇠사슬갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2357687, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163096] = {
				"|cff9d9d9d|Hitem:163096::::::::120:262::::::|h[납유리 손거울]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				794852, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154805] = {
				"|cff9d9d9d|Hitem:154805::::::::120:577::::::|h[썩은나무 육척봉]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPONMAINHAND", -- [3]
				135201, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[161202] = {
				"|cff9d9d9d|Hitem:161202::::::::120:262::::::|h[잘 닦인 놋쇠 육분의]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716858, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169122] = {
				"|cff9d9d9d|Hitem:169122::::::::120:577::::::|h[지브롤티안 몽키스패너]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134520, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160936] = {
				"|cff9d9d9d|Hitem:160936::::::::120:73::::::|h[고갈된 비전 홀]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				135469, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[167077] = {
				"|cff1eff00|Hitem:167077::::::::120:577::::::|h[탐지돌]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				528693, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[160179] = {
				"|cff1eff00|Hitem:160179::::::::120:577::::::|h[하늘소환사 장식띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1762573, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[166576] = {
				"|cff0070dd|Hitem:166576::::::::120:73::::::|h[죽음추적자의 웃옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2349373, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[144315] = {
				"|cffffffff|Hitem:144315::::::::102:73::::::|h[주문식: 목걸이 마법부여 - 쾌속의 징표]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1387621, -- [4]
				9, -- [5]
				8, -- [6]
			},
			[154806] = {
				"|cff1eff00|Hitem:154806::::::::120:262::::::|h[토르가껍질 가슴보호갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1672317, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161203] = {
				"|cff9d9d9d|Hitem:161203::::::::120:577::::::|h[뱃노래 악보]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1506451, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160934] = {
				"|cff9d9d9d|Hitem:160934::::::::120:262::::::|h[진흙 범벅 석궁]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				135531, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[167836] = {
				"|cff0070dd|Hitem:167836::::::::120:577::::::|h[도면: 송사리 통조림]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160163] = {
				"|cff1eff00|Hitem:160163::::::::120:577::::::|h[모래정찰병 발등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1674411, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160180] = {
				"|cff1eff00|Hitem:160180::::::::120:577::::::|h[하늘소환사 수도두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1762578, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[166577] = {
				"|cff0070dd|Hitem:166577::::::::120:73::::::|h[달사제의 의복]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2444249, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[153713] = {
				"|cff1eff00|Hitem:153713::::::::120:577::::::|h[강력한 쿠빌라인]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1990981, -- [4]
				3, -- [5]
				6, -- [6]
			},
			[154807] = {
				"|cff1eff00|Hitem:154807::::::::120:262::::::|h[토르가껍질 분쇄장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169392] = {
				"|cff0070dd|Hitem:169392::::::::120:262::::::|h[뼈도독]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2027842, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[162979] = {
				"|cff9d9d9d|Hitem:162979::::::::120:262::::::|h[그랄이 아낀 아스트롤라베]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				254118, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154790] = {
				"|cff9d9d9d|Hitem:154790::::::::120:72::::::|h[실밥이 풀린 천 손등싸개]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HAND", -- [3]
				132961, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[159140] = {
				"|cff9d9d9d|Hitem:159140::::::::120:577::::::|h[생기 없는 점토]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134111, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160181] = {
				"|cff1eff00|Hitem:160181::::::::120:577::::::|h[하늘소환사 손등싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1762577, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[166578] = {
				"|cff0070dd|Hitem:166578::::::::120:73::::::|h[감시경비병의 가슴보호갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2316872, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[134312] = {
				"|cff1eff00|Hitem:134312::::::::101:73::::::|h[지맥 흉터가 남은 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1122333, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154808] = {
				"|cff1eff00|Hitem:154808::::::::120:262::::::|h[토르가껍질 철갑허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[116457] = {
				"|cff1eff00|Hitem:116457::::::::96:73::::::|h[동상 도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				921386, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[160929] = {
				"|cff9d9d9d|Hitem:160929::::::::120:262::::::|h[깨진 대포 망치]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				133049, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[106478] = {
				"|cff1eff00|Hitem:106478::::::::96:73::::::|h[이유운 덧신]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				937855, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[163092] = {
				"|cff9d9d9d|Hitem:163092::::::::120:262::::::|h[수놓인 매사냥 두건]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237038, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[168370] = {
				"|cffa335ee|Hitem:168370::::::::120:577::::::|h[고물더미 동그랑쇠 열쇠]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2902998, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[166579] = {
				"|cff0070dd|Hitem:166579::::::::120:73::::::|h[칼도레이 궁수의 갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2373963, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[116463] = {
				"|cff1eff00|Hitem:116463::::::::93:73::::::|h[동상 너클]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				929536, -- [4]
				2, -- [5]
				13, -- [6]
			},
			[154809] = {
				"|cff1eff00|Hitem:154809::::::::120:262::::::|h[토르가껍질 보호모]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1672319, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161206] = {
				"|cff9d9d9d|Hitem:161206::::::::120:577::::::|h[빛바랜 보물 지도]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237384, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[166555] = {
				"|cff0070dd|Hitem:166555::::::::120:73::::::|h[감시경비병의 어깨철갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2451599, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158078] = {
				"|cff9d9d9d|Hitem:158078::::::::120:262::::::|h[금이 간 대군주의 홀]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WEAPON", -- [3]
				454053, -- [4]
				2, -- [5]
				4, -- [6]
			},
			[106419] = {
				"|cff1eff00|Hitem:106419::::::::98:73::::::|h[서리고리 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				929919, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[160183] = {
				"|cff1eff00|Hitem:160183::::::::120:577::::::|h[하늘소환사 로브]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_ROBE", -- [3]
				1762576, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[166580] = {
				"|cff0070dd|Hitem:166580::::::::120:73::::::|h[어둠숲 파수꾼의 웃옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CHEST", -- [3]
				2351530, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[106441] = {
				"|cff1eff00|Hitem:106441::::::::98:73::::::|h[수도자 수도두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				937859, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[160951] = {
				"|cff0070dd|Hitem:160951::::::::120:73::::::|h[늘푸른 정찰병의 활]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGED", -- [3]
				1723082, -- [4]
				2, -- [5]
				2, -- [6]
			},
			[161207] = {
				"|cff9d9d9d|Hitem:161207::::::::120:262::::::|h[제독의 흑럼주]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134758, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170092] = {
				"|cffa335ee|Hitem:170092::::::::120:577::::::|h[황천춤꾼의 손칼]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WEAPON", -- [3]
				2829897, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[106479] = {
				"|cff1eff00|Hitem:106479::::::::98:73::::::|h[이유운 어깨덧대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				973931, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154783] = {
				"|cff9d9d9d|Hitem:154783::::::::120:577::::::|h[파열된 판금 건틀릿]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HAND", -- [3]
				132962, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160184] = {
				"|cff1eff00|Hitem:160184::::::::120:577::::::|h[하늘소환사 덧신]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1762574, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[121192] = {
				"|cff1eff00|Hitem:121192::::::::120:73::::::|h[골짜기 나그네의 둥근고리]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391720, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[116460] = {
				"|cff1eff00|Hitem:116460::::::::93:73::::::|h[동상 석궁]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				920736, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[154811] = {
				"|cff1eff00|Hitem:154811::::::::120:262::::::|h[토르가껍질 어깨보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1672321, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161208] = {
				"|cff9d9d9d|Hitem:161208::::::::120:262::::::|h[해적의 코담배갑]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132596, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[116498] = {
				"|cff1eff00|Hitem:116498::::::::96:73::::::|h[덩굴에 휩싸인 총]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				940808, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[159222] = {
				"|cff1eff00|Hitem:159222::::::::120:262::::::|h[현자의 영지 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1698809, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154781] = {
				"|cff9d9d9d|Hitem:154781::::::::120:577::::::|h[파열된 판금 다리보호구]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_LEGS", -- [3]
				134583, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160185] = {
				"|cff1eff00|Hitem:160185::::::::120:577::::::|h[하늘소환사 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1762580, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[129109] = {
				"|cff0070dd|Hitem:129109::::::::106:73::::::|h[봉돌 줄]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1113069, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158650] = {
				"|cff0070dd|Hitem:158650::::::::120:262::::::|h[바다스컬지 대날검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1722409, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[154812] = {
				"|cff1eff00|Hitem:154812::::::::120:262::::::|h[토르가껍질 전쟁장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1672314, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[161209] = {
				"|cff9d9d9d|Hitem:161209::::::::120:262::::::|h[서약단 꿈갈무리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716836, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[116462] = {
				"|cff1eff00|Hitem:116462::::::::98:73::::::|h[얼음노래꾼 마법단검]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				926765, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[106480] = {
				"|cff1eff00|Hitem:106480::::::::98:73::::::|h[이유운 손목싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				937856, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154778] = {
				"|cff9d9d9d|Hitem:154778::::::::120:262::::::|h[파열된 판금 완갑]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_WRIST", -- [3]
				132606, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160186] = {
				"|cff1eff00|Hitem:160186::::::::120:577::::::|h[하늘소환사 소매장식]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[158839] = {
				"|cff9d9d9d|Hitem:158839::::::::120:577::::::|h[두꺼운 집게발]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1508493, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170089] = {
				"|cffa335ee|Hitem:170089::::::::120:577::::::|h[리아라의 뾰족지팡이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2921481, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[134343] = {
				"|cff1eff00|Hitem:134343::::::::101:73::::::|h[마나폭발 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1137681, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159163] = {
				"|cff1eff00|Hitem:159163::::::::120:262::::::|h[애쉬베인 무역회사 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1727714, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[169654] = {
				"|cff0070dd|Hitem:169654::::::::120:577::::::|h[나선형 설인 뿔]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				237396, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163955] = {
				"|cffa335ee|Hitem:163955::::::::120:577::::::|h[늑대의 검 카연]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				841309, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[166761] = {
				"|cff0070dd|Hitem:166761::::::::120:73::::::|h[감시병비병의 외투]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2317401, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[167059] = {
				"|cff1eff00|Hitem:167059::::::::120:577::::::|h[미끼]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				350570, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[115507] = {
				"|cff0070dd|Hitem:115507::::::::93:73::::::|h[고갈된 수정 조각]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				132784, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160969] = {
				"|cff0070dd|Hitem:160969::::::::120:73::::::|h[되살아난 강령술사의 칼날]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1724052, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[154814] = {
				"|cff1eff00|Hitem:154814::::::::120:262::::::|h[늪 추적자의 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2055323, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169399] = {
				"|cff1eff00|Hitem:169399::::::::120:577::::::|h[깊은바다 장갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2973328, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[106391] = {
				"|cff1eff00|Hitem:106391::::::::93:73::::::|h[칼날첨탑 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				947377, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[168081] = {
				"|cffffffff|Hitem:168081::::::::120:577::::::|h[염수석 곡괭이]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1064765, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170167] = {
				"|cff1eff00|Hitem:170167::::::::120:577::::::|h[뱀장어 살토막]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				134032, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[163030] = {
				"|cff9d9d9d|Hitem:163030::::::::120:262::::::|h[녹슨 채광용 곡괭이]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1060565, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[132183] = {
				"|cff9d9d9d|Hitem:132183::::::::99:73::::::|h[날카로운 이빨]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133296, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[87599] = {
				"|cff0070dd|Hitem:87599::::::::91:73::::::|h[사육자의 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				609749, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154815] = {
				"|cff1eff00|Hitem:154815::::::::120:577::::::|h[고름뿌리 손목띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1674412, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169400] = {
				"|cff1eff00|Hitem:169400::::::::120:577::::::|h[깊은바다 덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2973329, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[141587] = {
				"|cffa335ee|Hitem:141587::::::::99:73::::::|h[여왕 이세이리의 펜던트]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_NECK", -- [3]
				1360007, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[116679] = {
				"|cff1eff00|Hitem:116679::::::::93:73::::::|h[성장술사 아뮬렛]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_NECK", -- [3]
				648546, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[159605] = {
				"|cff1eff00|Hitem:159605::::::::120:262::::::|h[강철문장 지휘봉]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1697864, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[169429] = {
				"|cff1eff00|Hitem:169429::::::::120:577::::::|h[파도분쇄 손목보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2973479, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[158750] = {
				"|cff9d9d9d|Hitem:158750::::::::115:73::::::|h[뼈파괴자 부리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133708, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154773] = {
				"|cff9d9d9d|Hitem:154773::::::::120:577::::::|h[갈라진 생가죽 두건]|h|r", -- [1]
				0, -- [2]
				"INVTYPE_HEAD", -- [3]
				133101, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169145] = {
				"|cff9d9d9d|Hitem:169145::::::::120:577::::::|h[녹슨 정밀 포착기]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133863, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169401] = {
				"|cff1eff00|Hitem:169401::::::::120:577::::::|h[깊은바다 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2973330, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169657] = {
				"|cff0070dd|Hitem:169657::::::::120:262::::::|h[벌집도둑의 젤리 보관함]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2066005, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[158866] = {
				"|cff9d9d9d|Hitem:158866::::::::120:262::::::|h[기름진 지방 덩어리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				970839, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163969] = {
				"|cffa335ee|Hitem:163969::::::::120:577::::::|h[아밀튼의 총알투척기]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				985703, -- [4]
				2, -- [5]
				3, -- [6]
			},
			[124115] = {
				"|cffffffff|Hitem:124115::::::::99:73::::::|h[폭풍비늘]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1377087, -- [4]
				7, -- [5]
				6, -- [6]
			},
			[158864] = {
				"|cff9d9d9d|Hitem:158864::::::::120:262::::::|h[끈적거리는 거미줄]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				237431, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[158865] = {
				"|cff9d9d9d|Hitem:158865::::::::120:73::::::|h[섬뜩한 점액]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				603530, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154817] = {
				"|cff1eff00|Hitem:154817::::::::120:577::::::|h[고름뿌리 짧은바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1674416, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159167] = {
				"|cff1eff00|Hitem:159167::::::::120:73::::::|h[자유지대 팔보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1733693, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169658] = {
				"|cff0070dd|Hitem:169658::::::::120:577::::::|h[찬탈자의 향낭]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				134343, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[169434] = {
				"|cff1eff00|Hitem:169434::::::::120:577::::::|h[미끈껍질 망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				2902640, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170170] = {
				"|cff1eff00|Hitem:170170::::::::120:577::::::|h[발효된 돌연변이 물고기]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				350650, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[137185] = {
				"|cffffffff|Hitem:137185::::::::99:73::::::|h[지배의 룬]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1093191, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160447] = {
				"|cff0070dd|Hitem:160447::::::::120:262::::::|h[영혼기둥 등불]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HOLDABLE", -- [3]
				1723696, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[163680] = {
				"|cff0070dd|Hitem:163680::::::::120:262::::::|h[역병이빨의 발걸음]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1698802, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154818] = {
				"|cff1eff00|Hitem:154818::::::::120:577::::::|h[고름뿌리 손아귀]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[155074] = {
				"|cff0070dd|Hitem:155074::::::::120:262::::::|h[희생 집행자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1729266, -- [4]
				2, -- [5]
				7, -- [6]
			},
			[169659] = {
				"|cff0070dd|Hitem:169659::::::::120:577::::::|h[늙은 나샤의 발]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1509620, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[106483] = {
				"|cff1eff00|Hitem:106483::::::::96:73::::::|h[뾰족덩굴숲 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				929918, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170171] = {
				"|cff1eff00|Hitem:170171::::::::120:577::::::|h[대왕게 다리]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1508493, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154848] = {
				"|cff1eff00|Hitem:154848::::::::120:262::::::|h[심장파멸 큰망토]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1698804, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[124113] = {
				"|cffffffff|Hitem:124113::::::::102:73::::::|h[돌껍질 가죽]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				1377086, -- [4]
				7, -- [5]
				6, -- [6]
			},
			[106392] = {
				"|cff1eff00|Hitem:106392::::::::94:73::::::|h[칼날첨탑 요대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				947373, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154819] = {
				"|cff1eff00|Hitem:154819::::::::120:577::::::|h[고름뿌리 투구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1674415, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169404] = {
				"|cff1eff00|Hitem:169404::::::::120:577::::::|h[깊은바다 소매장식]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2973325, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168802] = {
				"|cff1eff00|Hitem:168802::::::::120:577::::::|h[나즈자타 전투 훈장]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1594746, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[155362] = {
				"|cff0070dd|Hitem:155362::::::::120:262::::::|h[버들야수 절단창]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1661331, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[170172] = {
				"|cff1eff00|Hitem:170172::::::::120:577::::::|h[밝은가시 껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1499541, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[129101] = {
				"|cff0070dd|Hitem:129101::::::::108:73::::::|h[우두머리의 앞발]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_TRINKET", -- [3]
				132936, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[131791] = {
				"|cff0070dd|Hitem:131791::::::::105:73::::::|h[지옥숨결 피노래꾼 로브]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_ROBE", -- [3]
				1113076, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[166846] = {
				"|cff1eff00|Hitem:166846::::::::120:262::::::|h[예비 부품]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				2915723, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160961] = {
				"|cff0070dd|Hitem:160961::::::::120:73::::::|h[전쟁어미의 난타기]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				926211, -- [4]
				2, -- [5]
				5, -- [6]
			},
			[169405] = {
				"|cff1eff00|Hitem:169405::::::::120:577::::::|h[미끈껍질 조끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				2902641, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163956] = {
				"|cffa335ee|Hitem:163956::::::::120:262::::::|h[트레이야의 빛나는 기둥지팡이]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1617802, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[154845] = {
				"|cff1eff00|Hitem:154845::::::::120:262::::::|h[콜레인 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1727714, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[155844] = {
				"|cff9d9d9d|Hitem:155844::::::::120:577::::::|h[불안정한 자철광]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				135253, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[137677] = {
				"|cffffffff|Hitem:137677::::::::99:73::::::|h[지옥 피]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				576311, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[87596] = {
				"|cff0070dd|Hitem:87596::::::::91:73::::::|h[머드머그의 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				646762, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[165614] = {
				"|cff0070dd|Hitem:165614::::::::120:73::::::|h[연금술사 주문지팡이]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2139104, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[154821] = {
				"|cff1eff00|Hitem:154821::::::::120:262::::::|h[고름뿌리 어깨덧대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1674417, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[169406] = {
				"|cff1eff00|Hitem:169406::::::::120:577::::::|h[미끈껍질 장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2902638, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[163717] = {
				"|cff9d9d9d|Hitem:163717::::::::120:577::::::|h[조세푸스의 금지된 뱃노래]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1500866, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[167871] = {
				"|cff0070dd|Hitem:167871::::::::120:577::::::|h[도면: G99.99 땅상어]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170174] = {
				"|cff1eff00|Hitem:170174::::::::120:577::::::|h[거름 수액괴물]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1500942, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[165461] = {
				"|cff0070dd|Hitem:165461::::::::120:73::::::|h[감시경비병의 다리갑옷]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				2451597, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160451] = {
				"|cff0070dd|Hitem:160451::::::::120:577::::::|h[바텐더 꼬챙이]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				132797, -- [4]
				2, -- [5]
				15, -- [6]
			},
			[163934] = {
				"|cffa335ee|Hitem:163934::::::::120:262::::::|h[비틀린 기분의 반지]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FINGER", -- [3]
				1011901, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[154822] = {
				"|cff1eff00|Hitem:154822::::::::120:262::::::|h[고름뿌리 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1674410, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161219] = {
				"|cff0070dd|Hitem:161219::::::::116:73::::::|h[수컷 랩터 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[139524] = {
				"|cffffffff|Hitem:139524::::::::104:73::::::|h[구겨진 편지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237245, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170112] = {
				"|cff1eff00|Hitem:170112::::::::120:577::::::|h[파도분쇄 장창]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2735992, -- [4]
				2, -- [5]
				6, -- [6]
			},
			[155271] = {
				"|cff0070dd|Hitem:155271::::::::120:262::::::|h[원숭이의 앞발 절단 도끼]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1698637, -- [4]
				2, -- [5]
				0, -- [6]
			},
			[131809] = {
				"|cff1eff00|Hitem:131809::::::::105:73::::::|h[번뜩이는 로크 깃털]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				132925, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[160452] = {
				"|cff0070dd|Hitem:160452::::::::120:262::::::|h[염소의 가방]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_BAG", -- [3]
				133646, -- [4]
				1, -- [5]
				0, -- [6]
			},
			[165471] = {
				"|cff0070dd|Hitem:165471::::::::120:73::::::|h[역병인도자의 팔보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2450988, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154823] = {
				"|cff1eff00|Hitem:154823::::::::120:262::::::|h[새김 뼈 반지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FINGER", -- [3]
				1391713, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169408] = {
				"|cff1eff00|Hitem:169408::::::::120:577::::::|h[미끈껍질삼각모자]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2902643, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160119] = {
				"|cff1eff00|Hitem:160119::::::::120:577::::::|h[공포뿔 주름장식 가슴보호구]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1672317, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[139522] = {
				"|cffffffff|Hitem:139522::::::::98:73::::::|h[피투성이 쪽지]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				133678, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[170176] = {
				"|cff1eff00|Hitem:170176::::::::120:577::::::|h[심해 가오리 날개]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1547467, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[165464] = {
				"|cff0070dd|Hitem:165464::::::::120:73::::::|h[감시경비병의 손목보호구]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				2316870, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[160453] = {
				"|cffffffff|Hitem:160453::::::::114:73::::::|h[약탈당한 폭풍 은괴]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				237047, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[165446] = {
				"|cff0070dd|Hitem:165446::::::::120:73::::::|h[어둠숲 파수꾼의 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2351526, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[154824] = {
				"|cff1eff00|Hitem:154824::::::::120:262::::::|h[잘라마르 사슬띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				1690118, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[161221] = {
				"|cff0070dd|Hitem:161221::::::::120:73::::::|h[밀림의 왕 진흙투척자]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1674414, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[161042] = {
				"|cff0070dd|Hitem:161042::::::::120:73::::::|h[고타카의 강타장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1672318, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[165490] = {
				"|cff0070dd|Hitem:165490::::::::120:73::::::|h[죽음경비병의 건틀릿]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				2393946, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170177] = {
				"|cff1eff00|Hitem:170177::::::::120:577::::::|h[노출된 생선]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				237301, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[137681] = {
				"|cffffffff|Hitem:137681::::::::105:73::::::|h[도면: 핏빛토템 안장 담요]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134939, -- [4]
				9, -- [5]
				2, -- [6]
			},
			[162683] = {
				"|cff9d9d9d|Hitem:162683::::::::120:577::::::|h[고풍스러운 공룡술 조각상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				134465, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[154664] = {
				"|cff0070dd|Hitem:154664::::::::120:73::::::|h[사자시야 징조검]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1722409, -- [4]
				2, -- [5]
				8, -- [6]
			},
			[154825] = {
				"|cff1eff00|Hitem:154825::::::::120:262::::::|h[잘라마르 완갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				1690120, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169410] = {
				"|cff1eff00|Hitem:169410::::::::120:577::::::|h[미끈껍질 어깨덧옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2902645, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[129090] = {
				"|cff0070dd|Hitem:129090::::::::103:73::::::|h[보선의 산으로 얼룩진 망토]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_CLOAK", -- [3]
				1325258, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[155593] = {
				"|cff9d9d9d|Hitem:155593::::::::120:262::::::|h[뒤집힌 복장뼈]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133727, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170178] = {
				"|cff1eff00|Hitem:170178::::::::120:577::::::|h[으뜸 지느러미]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1547460, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[158756] = {
				"|cff9d9d9d|Hitem:158756::::::::120:262::::::|h[회전형 마개]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				132997, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160455] = {
				"|cff0070dd|Hitem:160455::::::::120:73::::::|h[앵무새조련사 장식띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1698801, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161037] = {
				"|cff0070dd|Hitem:161037::::::::120:73::::::|h[모래에 마모된 요대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1672313, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[154826] = {
				"|cff1eff00|Hitem:154826::::::::120:577::::::|h[잘라마르 건틀릿]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				1690122, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169411] = {
				"|cff1eff00|Hitem:169411::::::::120:577::::::|h[미끈껍질 허리띠]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WAIST", -- [3]
				2902637, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158844] = {
				"|cff9d9d9d|Hitem:158844::::::::120:577::::::|h[반짝먼지]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463877, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[163782] = {
				"|cffffffff|Hitem:163782::::::::120:262::::::|h[저주받은 허벅지 고기]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134005, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[170179] = {
				"|cff0070dd|Hitem:170179::::::::120:577::::::|h[치악룡 분비선]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				237414, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[163028] = {
				"|cff9d9d9d|Hitem:163028::::::::120:73::::::|h[장인이 조각한 초대 트롤 동상]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				516666, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[160456] = {
				"|cff0070dd|Hitem:160456::::::::120:262::::::|h[표백된 까마귀깃털 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1698806, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[168248] = {
				"|cff0070dd|Hitem:168248::::::::120:262::::::|h[도면: 머머리-371]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154827] = {
				"|cff1eff00|Hitem:154827::::::::120:577::::::|h[잘라마르 경갑]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				1690119, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169412] = {
				"|cff1eff00|Hitem:169412::::::::120:577::::::|h[미끈껍질 팔보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2902639, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[127037] = {
				"|cffffffff|Hitem:127037::::::::101:73::::::|h[룬 무늬 장선]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				134479, -- [4]
				7, -- [5]
				5, -- [6]
			},
			[163679] = {
				"|cff0070dd|Hitem:163679::::::::120:262::::::|h[세베루스의 손목띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1698803, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[170180] = {
				"|cff1eff00|Hitem:170180::::::::120:577::::::|h[서슬껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				839982, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159608] = {
				"|cff1eff00|Hitem:159608::::::::120:577::::::|h[전쟁항구 사술사]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1694362, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[160457] = {
				"|cff0070dd|Hitem:160457::::::::120:73::::::|h[용암 얼룩이 진 무릎바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1698808, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[106447] = {
				"|cff1eff00|Hitem:106447::::::::98:73::::::|h[수도자 손목싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				937856, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[142546] = {
				"|cff0070dd|Hitem:142546::::::::105:73::::::|h[관성의 작은 부적]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1529345, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[169413] = {
				"|cff1eff00|Hitem:169413::::::::120:577::::::|h[암초지기 갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				2915286, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163095] = {
				"|cff9d9d9d|Hitem:163095::::::::120:73::::::|h[금빛 트롤 광전사]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1716868, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169925] = {
				"|cffa335ee|Hitem:169925::::::::120:577::::::|h[뱀비늘 물튀김단화]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2906594, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[129133] = {
				"|cff0070dd|Hitem:129133::::::::106:73::::::|h[망치의 머리]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HEAD", -- [3]
				1116926, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[159349] = {
				"|cff0070dd|Hitem:159349::::::::120:262::::::|h[용거북 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1726333, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[160458] = {
				"|cff0070dd|Hitem:160458::::::::120:262::::::|h[깃털처럼 가벼운 고대 끌신]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1698802, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[161018] = {
				"|cff0070dd|Hitem:161018::::::::120:73::::::|h[날개 달린 공포 손목싸개]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1762575, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[154829] = {
				"|cff1eff00|Hitem:154829::::::::120:262::::::|h[잘라마르 다리보호대]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1690124, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169414] = {
				"|cff1eff00|Hitem:169414::::::::120:577::::::|h[암초지기 성큼장화]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_FEET", -- [3]
				2915283, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[163029] = {
				"|cff9d9d9d|Hitem:163029::::::::120:73::::::|h[잘못 놓인 장례용 공물]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				463484, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[169926] = {
				"|cffa335ee|Hitem:169926::::::::120:577::::::|h[살아나는 수호병의 허리띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				2912993, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[170182] = {
				"|cff0070dd|Hitem:170182::::::::120:577::::::|h[전기비늘 보호막]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				237456, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[87625] = {
				"|cff0070dd|Hitem:87625::::::::120:73::::::|h[응결된 안개 아뮬렛]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_NECK", -- [3]
				632848, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160459] = {
				"|cff0070dd|Hitem:160459::::::::120:577::::::|h[양봉가의 벌침방지 허리띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1698801, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[165486] = {
				"|cff0070dd|Hitem:165486::::::::120:73::::::|h[역병경비병의 요대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				2357683, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154830] = {
				"|cff1eff00|Hitem:154830::::::::120:262::::::|h[잘라마르 어깨덮개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				1690125, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169415] = {
				"|cff1eff00|Hitem:169415::::::::120:577::::::|h[암초지기 손싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HAND", -- [3]
				2915287, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154897] = {
				"|cffffffff|Hitem:154897::::::::120:577::::::|h[힘줄 굵은 허릿살]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				2066020, -- [4]
				7, -- [5]
				8, -- [6]
			},
			[169927] = {
				"|cffa335ee|Hitem:169927::::::::120:577::::::|h[심연소환사의 죔쇠띠]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_WAIST", -- [3]
				2909745, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[170183] = {
				"|cff1eff00|Hitem:170183::::::::120:577::::::|h[암초지기 껍질]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				959845, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[166345] = {
				"|cff1eff00|Hitem:166345::::::::120:577::::::|h[잔달라 랩터 알]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				236997, -- [4]
				15, -- [5]
				2, -- [6]
			},
			[160460] = {
				"|cff0070dd|Hitem:160460::::::::120:262::::::|h[두꺼운 공룡가죽 장갑]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_HAND", -- [3]
				1733696, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168804] = {
				"|cff0070dd|Hitem:168804::::::::120:577::::::|h[동력이 공급된 물고기 조달 균형대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				2909707, -- [4]
				2, -- [5]
				20, -- [6]
			},
			[154831] = {
				"|cff1eff00|Hitem:154831::::::::120:262::::::|h[잘라마르 쇠사슬갑옷]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_CHEST", -- [3]
				1690121, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169416] = {
				"|cff1eff00|Hitem:169416::::::::120:577::::::|h[암초지기 코이프]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				2915288, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[173401] = {
				"|cff0070dd|Hitem:173401::::::::120:577::::::|h[검은 제국 쇠사슬 장화]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				3036531, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[169928] = {
				"|cffa335ee|Hitem:169928::::::::120:577::::::|h[웨케마라의 전쟁장화]|h|r", -- [1]
				4, -- [2]
				"INVTYPE_FEET", -- [3]
				2901579, -- [4]
				4, -- [5]
				4, -- [6]
			},
			[170184] = {
				"|cff0070dd|Hitem:170184::::::::120:577::::::|h[고대 암초지기 껍질]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				615629, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[160973] = {
				"|cff0070dd|Hitem:160973::::::::120:72::::::|h[저주받은 엄니마법봉]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1694362, -- [4]
				2, -- [5]
				19, -- [6]
			},
			[160461] = {
				"|cff0070dd|Hitem:160461::::::::120:262::::::|h[두꺼운 공룡가죽 바지]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_LEGS", -- [3]
				1733698, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[158744] = {
				"|cff9d9d9d|Hitem:158744::::::::120:73::::::|h[유령 장막]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				343641, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[171208] = {
				"|cffffffff|Hitem:171208::::::::120:577::::::|h[태양손길 아뮬렛]|h|r", -- [1]
				1, -- [2]
				"", -- [3]
				514924, -- [4]
				5, -- [5]
				0, -- [6]
			},
			[169417] = {
				"|cff1eff00|Hitem:169417::::::::120:577::::::|h[암초지기 바지]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				2915289, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169673] = {
				"|cff1eff00|Hitem:169673::::::::120:577::::::|h[파란 페인트 채운 주머니]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1567722, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[165453] = {
				"|cff0070dd|Hitem:165453::::::::120:73::::::|h[칼도레이 궁수의 어깨보호대]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2373967, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[168138] = {
				"|cff0070dd|Hitem:168138::::::::120:577::::::|h[앞선 자의 영혼]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				878157, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[173412] = {
				"|cff0070dd|Hitem:173412::::::::120:577::::::|h[검은 제국 가죽 어깨덮개]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978248, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[160462] = {
				"|cff0070dd|Hitem:160462::::::::120:73::::::|h[효기 바구니 고정띠]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WRIST", -- [3]
				1733693, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[160466] = {
				"|cff0070dd|Hitem:160466::::::::120:72::::::|h[사우로리스크 무리어미 장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1726330, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[154833] = {
				"|cff1eff00|Hitem:154833::::::::120:262::::::|h[혈사술 두건]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_HEAD", -- [3]
				1762578, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169418] = {
				"|cff1eff00|Hitem:169418::::::::120:577::::::|h[암초지기 어깨받이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHOULDER", -- [3]
				2915290, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[169674] = {
				"|cff1eff00|Hitem:169674::::::::120:577::::::|h[초록 페인트 채운 주머니]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1567722, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[155601] = {
				"|cff9d9d9d|Hitem:155601::::::::120:262::::::|h[날카로운 곤충 다리]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				133571, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170186] = {
				"|cff1eff00|Hitem:170186::::::::120:577::::::|h[심연 진주]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				463858, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[173407] = {
				"|cff0070dd|Hitem:173407::::::::120:577::::::|h[검은 제국 가죽 가슴보호구]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2978244, -- [4]
				4, -- [5]
				0, -- [6]
			},
			[161027] = {
				"|cff0070dd|Hitem:161027::::::::120:262::::::|h[맹독 둥지어미 장식끈]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_WAIST", -- [3]
				1674410, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[159493] = {
				"|cff1eff00|Hitem:159493::::::::120:73::::::|h[옹이나무 석궁]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_RANGEDRIGHT", -- [3]
				1695549, -- [4]
				2, -- [5]
				18, -- [6]
			},
			[169163] = {
				"|cffa335ee|Hitem:169163::::::::120:577::::::|h[조용한 글라이더]|h|r", -- [1]
				4, -- [2]
				"", -- [3]
				2620777, -- [4]
				15, -- [5]
				5, -- [6]
			},
			[116470] = {
				"|cff1eff00|Hitem:116470::::::::94:73::::::|h[동상 지팡이]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				922707, -- [4]
				2, -- [5]
				10, -- [6]
			},
			[169675] = {
				"|cff1eff00|Hitem:169675::::::::120:577::::::|h[주황 페인트 채운 주머니]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				1567722, -- [4]
				0, -- [5]
				8, -- [6]
			},
			[163790] = {
				"|cff1eff00|Hitem:163790::::::::120:262::::::|h[으스스한 주문]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				134937, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[170187] = {
				"|cff0070dd|Hitem:170187::::::::120:577::::::|h[그늘비늘]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				1526603, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159488] = {
				"|cff1eff00|Hitem:159488::::::::120:262::::::|h[젬란 가로날도끼]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_2HWEAPON", -- [3]
				1694560, -- [4]
				2, -- [5]
				1, -- [6]
			},
			[160464] = {
				"|cff0070dd|Hitem:160464::::::::120:262::::::|h[공포 언덕 늑대장화]|h|r", -- [1]
				3, -- [2]
				"INVTYPE_FEET", -- [3]
				1733692, -- [4]
				4, -- [5]
				2, -- [6]
			},
			[168908] = {
				"|cff0070dd|Hitem:168908::::::::120:577::::::|h[도안: 모험가를 위한 실험용 증강상자]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				2915721, -- [4]
				12, -- [5]
				0, -- [6]
			},
			[154835] = {
				"|cff1eff00|Hitem:154835::::::::120:262::::::|h[혈사술 다리싸개]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_LEGS", -- [3]
				1762579, -- [4]
				4, -- [5]
				1, -- [6]
			},
			[169420] = {
				"|cff1eff00|Hitem:169420::::::::120:577::::::|h[암초지기 고리]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WRIST", -- [3]
				2915284, -- [4]
				4, -- [5]
				3, -- [6]
			},
			[175141] = {
				"|cff1eff00|Hitem:175141::::::::120:262::::::|h[만물을 보는 왼쪽 눈]|h|r", -- [1]
				2, -- [2]
				"", -- [3]
				236407, -- [4]
				15, -- [5]
				1, -- [6]
			},
			[155603] = {
				"|cff9d9d9d|Hitem:155603::::::::120:577::::::|h[부슬부슬한 물고기 비늘]|h|r", -- [1]
				0, -- [2]
				"", -- [3]
				1526611, -- [4]
				15, -- [5]
				0, -- [6]
			},
			[170188] = {
				"|cff0070dd|Hitem:170188::::::::120:577::::::|h[따개비가 붙은 물건 자루]|h|r", -- [1]
				3, -- [2]
				"", -- [3]
				133662, -- [4]
				15, -- [5]
				4, -- [6]
			},
			[159812] = {
				"|cff1eff00|Hitem:159812::::::::120:262::::::|h[조칼리 방패]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_SHIELD", -- [3]
				1729566, -- [4]
				4, -- [5]
				6, -- [6]
			},
			[159506] = {
				"|cff1eff00|Hitem:159506::::::::120:262::::::|h[로아의 축복을 받은 초승달 글레이브]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1733930, -- [4]
				2, -- [5]
				9, -- [6]
			},
			[159517] = {
				"|cff1eff00|Hitem:159517::::::::120:262::::::|h[조칼리 발톱주먹]|h|r", -- [1]
				2, -- [2]
				"INVTYPE_WEAPON", -- [3]
				1692686, -- [4]
				2, -- [5]
				13, -- [6]
			},
		},
		["rares_loot"] = {
			[131404] = {
				158078, -- [1]
			},
			[273905] = {
				161201, -- [1]
				161202, -- [2]
			},
			[147708] = {
				158865, -- [1]
			},
			[154154] = {
				169943, -- [1]
				172502, -- [2]
				168825, -- [3]
				172503, -- [4]
				169858, -- [5]
				168828, -- [6]
				172504, -- [7]
				169944, -- [8]
				172500, -- [9]
				169152, -- [10]
				169133, -- [11]
				172501, -- [12]
				169860, -- [13]
				172493, -- [14]
				169110, -- [15]
			},
			[155059] = {
				155629, -- [1]
				154898, -- [2]
				169654, -- [3]
				158859, -- [4]
				168822, -- [5]
				159200, -- [6]
				168825, -- [7]
			},
			[291211] = {
				161203, -- [1]
			},
			[153313] = {
				155636, -- [1]
			},
			[162172] = {
			},
			[155838] = {
				170201, -- [1]
				170120, -- [2]
			},
			[153314] = {
				154790, -- [1]
			},
			[124548] = {
				159799, -- [1]
			},
			[325663] = {
				169124, -- [1]
			},
			[155172] = {
				169656, -- [1]
				155601, -- [2]
			},
			[153315] = {
				170194, -- [1]
			},
			[144997] = {
				160938, -- [1]
				160933, -- [2]
				160934, -- [3]
			},
			[155173] = {
				169658, -- [1]
				158775, -- [2]
				159264, -- [3]
				158831, -- [4]
			},
			[293884] = {
				163089, -- [1]
			},
			[152681] = {
				158874, -- [1]
			},
			[325984] = {
				171208, -- [1]
			},
			[138299] = {
				155605, -- [1]
			},
			[93371] = {
				121138, -- [1]
			},
			[126907] = {
				159476, -- [1]
			},
			[152397] = {
				158745, -- [1]
			},
			[297825] = {
				163091, -- [1]
			},
			[316780] = {
				167513, -- [1]
			},
			[273918] = {
				163852, -- [1]
				161204, -- [2]
				161200, -- [3]
				161205, -- [4]
				161198, -- [5]
			},
			[150191] = {
				155631, -- [1]
				158757, -- [2]
			},
			[291254] = {
				163092, -- [1]
			},
			[155176] = {
				155629, -- [1]
				169659, -- [2]
				154898, -- [3]
			},
			[97793] = {
				132184, -- [1]
				121101, -- [2]
			},
			[291223] = {
				163113, -- [1]
			},
			[291224] = {
				161205, -- [1]
			},
			[77140] = {
				107528, -- [1]
			},
			[297892] = {
				161203, -- [1]
			},
			[326404] = {
				170096, -- [1]
				170087, -- [2]
				169215, -- [3]
				170512, -- [4]
			},
			[131984] = {
				158857, -- [1]
			},
			[297893] = {
				163088, -- [1]
			},
			[140938] = {
				159511, -- [1]
			},
			[75434] = {
				106870, -- [1]
			},
			[145161] = {
				160933, -- [1]
				159549, -- [2]
				160136, -- [3]
			},
			[291227] = {
				161209, -- [1]
			},
			[162141] = {
			},
			[279378] = {
				163852, -- [1]
			},
			[294174] = {
				161211, -- [1]
				161201, -- [2]
			},
			[279379] = {
				162978, -- [1]
				162633, -- [2]
			},
			[325664] = {
				169850, -- [1]
				168832, -- [2]
			},
			[138288] = {
				159493, -- [1]
			},
			[81406] = {
				106869, -- [1]
			},
			[291229] = {
				163088, -- [1]
			},
			[153296] = {
				160935, -- [1]
				160926, -- [2]
			},
			[325660] = {
				169122, -- [1]
				169850, -- [2]
			},
			[153302] = {
				154785, -- [1]
			},
			[151719] = {
				155636, -- [1]
			},
			[139205] = {
				158756, -- [1]
			},
			[145020] = {
				159514, -- [1]
				154802, -- [2]
			},
			[145112] = {
				160129, -- [1]
				160924, -- [2]
			},
			[152291] = {
				158760, -- [1]
			},
			[291263] = {
				161203, -- [1]
			},
			[293962] = {
				161204, -- [1]
			},
			[275071] = {
				163096, -- [1]
			},
			[303170] = {
				161208, -- [1]
				163084, -- [2]
			},
			[291264] = {
				161203, -- [1]
			},
			[325662] = {
				167790, -- [1]
			},
			[291201] = {
				163096, -- [1]
			},
			[334223] = {
			},
			[291265] = {
				161198, -- [1]
				161211, -- [2]
			},
			[293964] = {
				161201, -- [1]
			},
			[148451] = {
				157842, -- [1]
			},
			[279042] = {
				161211, -- [1]
				161205, -- [2]
			},
			[74206] = {
				106870, -- [1]
			},
			[155055] = {
				169657, -- [1]
				168822, -- [2]
				160934, -- [3]
				168825, -- [4]
			},
			[157167] = {
				154794, -- [1]
			},
			[153309] = {
				170174, -- [1]
				170170, -- [2]
			},
			[291267] = {
				161205, -- [1]
				163092, -- [2]
			},
			[273900] = {
				163852, -- [1]
				163091, -- [2]
				161198, -- [3]
			},
			[291204] = {
				163096, -- [1]
			},
			[326415] = {
				170097, -- [1]
			},
			[148563] = {
				154770, -- [1]
			},
			[298920] = {
				163092, -- [1]
			},
			[275076] = {
				163091, -- [1]
				161207, -- [2]
			},
			[153310] = {
				170193, -- [1]
			},
			[284469] = {
				161207, -- [1]
				161212, -- [2]
			},
			[326410] = {
				170087, -- [1]
				170097, -- [2]
			},
			[326409] = {
				170098, -- [1]
			},
			[148446] = {
				154791, -- [1]
			},
			[291257] = {
				161204, -- [1]
			},
			[145278] = {
				160122, -- [1]
			},
			[137665] = {
				158857, -- [1]
			},
			[110562] = {
				132231, -- [1]
			},
			[284413] = {
				162633, -- [1]
				163852, -- [2]
			},
			[126142] = {
				154823, -- [1]
			},
			[153303] = {
				154805, -- [1]
			},
		},
		["rare_names"] = {
			["koKR"] = {
				[85767] = "저주받은 선구자",
				[139766] = "전직 항해사 더블린",
				[136183] = "파게",
				[157170] = "수행사제 타스푸",
				[158706] = "타락한 부패",
				[88071] = "전략가 안코르",
				[139767] = "\"망원경\" 마리",
				[88583] = "숲 감시자 얄",
				[157171] = "돌군주 헤이시",
				[126462] = "포즈루크",
				[98309] = "해바람",
				[139768] = "해적단원 단",
				[90887] = "핏빛의 돌그",
				[88072] = "대마법사 테카르",
				[139769] = "이등항해사 바나비",
				[152566] = "아네모나르",
				[125951] = "흑요석 죽음수호자",
				[134651] = "의술사 하브라두",
				[152567] = "물풀버들",
				[140794] = "흉터갈퀴",
				[99846] = "분노하는 대지",
				[152568] = "우르두우",
				[140795] = "싸늘한 모래빙빙",
				[126208] = "바르가",
				[63240] = "어둠의 주인 사이도우",
				[110340] = "묘닉스",
				[98311] = "가옳아옳",
				[136189] = "이끼왕",
				[107269] = "심문관 티보스",
				[121090] = "실성한 쉬바라",
				[88586] = "모가마고",
				[109317] = "룰프 본스냅퍼",
				[154106] = "퀴드",
				[85771] = "고위 흑마술사 카스",
				[90122] = "육중한 조우그",
				[140798] = "바위까악",
				[79629] = "천둥발 크리고",
				[92682] = "지옥어귀 약탈자",
				[140799] = "급류추적자",
				[50828] = "보노보스",
				[110342] = "랍사흐",
				[147966] = "아만",
				[78606] = "창백한 생선탐식자",
				[121092] = "변형된 주시자",
				[80398] = "케라브노스",
				[109575] = "목마른 발라카르",
				[101641] = "미타나",
				[134147] = "괴물윙윙",
				[116230] = "이국적인 무희",
				[129027] = "골로나르",
				[129283] = "대왕 모래게",
				[153088] = "반짝이는 메카거미",
				[138244] = "장미나무 방어병",
				[147970] = "아옳마르",
				[91661] = "빈예티",
				[92429] = "무리군주 익스코르",
				[92685] = "대장 브르벳",
				[92941] = "고라보쉬",
				[154115] = "야수어미 그룰라",
				[50062] = "애오낙스",
				[85264] = "롤코르",
				[85520] = "무리잎새",
				[110346] = "시든꽃잎 아오드",
				[140296] = "사향 축축털",
				[157188] = "무덤 과부거미",
				[145415] = "대장 고로크",
				[145927] = "별비명꾼 엘라나",
				[91663] = "말썽이",
				[140297] = "노크아라크",
				[145928] = "스카비스 나이트스토커",
				[140298] = "흉포한 골쿤",
				[78867] = "질식자",
				[124680] = "줄조로스",
				[140299] = "유령송곳니",
				[149513] = "크로즈 블러드레이지",
				[50831] = "할퀴",
				[50959] = "카르킨",
				[140300] = "파쇄찢개",
				[149514] = "험악뿔",
				[91921] = "고룡벌레",
				[140301] = "흉터발",
				[145932] = "셀레스트라 브라이트문",
				[139278] = "란쟈",
				[103183] = "로크나쉬",
				[149516] = "깜장발",
				[88083] = "영혼술사 나일라나",
				[149517] = "아가테 웜우드",
				[50832] = "울부짖는 자",
				[139280] = "날쌘돌이 시디안",
				[107023] = "니소그",
				[101649] = "서리조각",
				[86549] = "강철엄니",
				[124684] = "고문관의 눈",
				[92180] = "시어세이",
				[129803] = "채찍덩굴",
				[109584] = "피오르둔",
				[154640] = "최고사령관 트렘블레이드",
				[151569] = "깊은물 아귀괴수",
				[90901] = "무리군주 야옹부엉",
				[78872] = "클리킥스",
				[154641] = "대장군 볼라스",
				[139285] = "맹독의 부들비늘",
				[125453] = "어미 가시도치",
				[93205] = "쏜드락스",
				[77081] = "란티코어",
				[94485] = "악취나는 폴로우스",
				[139287] = "톱이빨",
				[92694] = "피범벅발톱",
				[129805] = "비숄",
				[122639] = "고대의 르갈",
				[139289] = "표류자 텐튤로스",
				[152086] = "얼굴 없는 중재자",
				[92951] = "사냥개조련사 엘리",
				[126223] = "비술사 칼송곳니",
				[142361] = "역병깃털",
				[139290] = "소라게 메종",
				[70429] = "감염된 플레시록",
				[58769] = "무쇠턱",
				[140828] = "아침이슬",
				[83483] = "부싯돌가죽",
				[132127] = "여우굴 하늘공포",
				[140829] = "가을바람",
				[77085] = "어둠의 발산물",
				[154650] = "끓어오르는 고대의 공포",
				[78621] = "분노의 회오리바람",
				[115732] = "믿음직스러운 요르빌드",
				[154651] = "부패한 고대의 공포",
				[121107] = "여군주 엘드라스",
				[50836] = "잽싼 익익",
				[122899] = "데스 메탈 기사",
				[110870] = "연금술사 폴드런",
				[148510] = "드록사르 모가르",
				[108823] = "하프단",
				[133155] = "그나아트",
				[89884] = "선장잡이 플로그",
				[139298] = "핑쿠숀",
				[139810] = "투자회사 중간 관리자",
				[107544] = "니소그",
				[99610] = "가르브룰그",
				[87837] = "뼈파괴자",
				[147489] = "선장 그린세일즈",
				[139811] = "투자회사 부선임",
				[58771] = "퀴드",
				[139812] = "투자회사 생산자",
				[140836] = "밝은불길",
				[133158] = "무리어미 키말",
				[134694] = "추방자 모르파니",
				[92189] = "상상의 공포",
				[139813] = "선임 생산자 직시",
				[110361] = "비명의 전령",
				[139814] = "합병 전문가 허즐",
				[127765] = "암컷 사우로리스크",
				[138279] = "아드하라 화이트",
				[155171] = "벌집파괴벌",
				[135720] = "달빛 깃든 암사냥호랑이",
				[140327] = "여왕 돌엄니",
				[109594] = "폭풍깃털",
				[101660] = "분노의 부패자",
				[130581] = "모래눈이",
				[155172] = "들창 벌사냥꾼",
				[135721] = "아샤네",
				[155173] = "벌꿀등 강탈자",
				[108827] = "무덤의 한기 피욜랙",
				[140329] = "시체유린자 바일릭스",
				[133163] = "티아카완",
				[110363] = "썩은눈",
				[139818] = "보안 장교 더크",
				[160805] = "끈끈한 방울",
				[140842] = "엡",
				[124440] = "감독관 이베다",
				[135724] = "수풀추적자",
				[140331] = "깊은굴 복병",
				[85026] = "영혼왜곡사 토렉",
				[110364] = "창백한 공포날개",
				[139820] = "부사장 핏지 제트젬",
				[86562] = "광기 어린 마드가드",
				[140844] = "제피스",
				[124185] = "골라칸",
				[139821] = "부사장 프랭키 G.",
				[140333] = "강철껍질",
				[130584] = "가시박이",
				[127001] = "저주받은 그워그너그",
				[103199] = "라고울",
				[160810] = "선구자 일코시크",
				[97057] = "감독관 브루타그",
				[50840] = "상사 내너스",
				[138288] = "심연의 유령",
				[155180] = "옵스큐론",
				[135217] = "북녘골의 맥시밀리언",
				[70440] = "모나라",
				[134706] = "죽음뚜껑",
				[92451] = "저주받은 바릭스",
				[97058] = "백작 네파리우스",
				[113694] = "파샤",
				[77095] = "길추적자 드라가",
				[150575] = "우레바위",
				[134707] = "여군주 세이린",
				[140338] = "군집 경비병 진칼로",
				[99362] = "칡괴수",
				[150576] = "고철 부품",
				[104481] = "알라와쉬테",
				[140339] = "계곡의 공포",
				[97059] = "왕 보라스",
				[63510] = "우론",
				[152113] = "고철모이왕",
				[86566] = "배신자 다즈고",
				[87846] = "구덩이 학살자",
				[92197] = "렐고르",
				[84263] = "자갈니",
				[140341] = "구름박박이",
				[92965] = "어둠그늘",
				[101411] = "대게 고움",
				[162352] = "암흑 의식술사 자칸의 영혼",
				[140854] = "흐름물",
				[111649] = "대사 디브윈",
				[79145] = "칼날흉터 야가",
				[139319] = "폐수범벅",
				[125214] = "크럽스",
				[140343] = "칼날날개",
				[140855] = "낙수령",
				[135225] = "풍차의 가이른",
				[140344] = "하늘 독사",
				[144951] = "창백털 포식자",
				[92199] = "우르속의 형상",
				[140345] = "폭풍비명",
				[140857] = "비취섬광",
				[150583] = "바위물풀 비틀괴물",
				[122912] = "사령관 사스레나엘",
				[140858] = "화염족속",
				[111651] = "디그렌",
				[138299] = "피아귀",
				[92200] = "우르솔의 형상",
				[50331] = "고칸",
				[144954] = "피의 탐식자",
				[130079] = "와가 스날터스크",
				[134717] = "엄브라릭스",
				[86058] = "개리슨 포드",
				[143931] = "하늘빛나래",
				[140860] = "벼랑주자",
				[139325] = "Void Essence Kill Credit",
				[140861] = "흙떨이",
				[153658] = "소멸자 쉬즈나라스",
				[93993] = "만족을 모르는 먹보",
				[86571] = "증오의 두르프",
				[140862] = "포세이큰 역병 수레",
				[111653] = "미아수",
				[116004] = "비행 조련사 볼나스",
				[103975] = "제이드 다크헤이븐",
				[50332] = "코르다 토로스",
				[160826] = "둥지경비병 나즈루제크",
				[140863] = "루비바람 악동",
				[109606] = "발리토스",
				[77614] = "광포한 골렘",
				[139328] = "호랑트론",
				[140864] = "낄낄발작",
				[121124] = "아포크론",
				[130338] = "먼지송곳니",
				[87597] = "폭격수 구고크",
				[50333] = "황소 론",
				[134213] = "집행자 블랙웰",
				[78128] = "그론추적자 다원",
				[86574] = "발명가 블라모",
				[133190] = "비수이빨",
				[138309] = "끄적이",
				[92205] = "가장 어두운 공포",
				[140357] = "맹독절단자",
				[140358] = "비탄부름",
				[82992] = "지옥불꽃 악녀",
				[49822] = "비취송곳니",
				[139335] = "호랑트론",
				[50334] = "파괴자 닥",
				[140359] = "천둥매 포식자",
				[97069] = "격노군주 레코스",
				[154180] = "어스름길잡이 야르가",
				[110378] = "냉혈의 드루곤",
				[139336] = "호랑트론",
				[140360] = "태양등",
				[144967] = "빈예티",
				[87344] = "고르탁 스틸그립",
				[91695] = "대흑마법사 네더쿠르스",
				[138825] = "인가토라 블러드드링커",
				[140361] = "흉조의 검은그림자",
				[129830] = "거수 딸각발톱",
				[97326] = "날치기 하틀리",
				[162372] = "흑사자 사이러스의 영혼",
				[138826] = "용감한 레이크니르",
				[151623] = "고철왕",
				[140362] = "반짝날개",
				[99886] = "잠잠해진 대지",
				[138827] = "강한 보달프",
				[151624] = "태엽돌이 거인",
				[72245] = "제스쿠아",
				[138828] = "용맹한 베르힐드",
				[151625] = "고철왕",
				[123689] = "흉측한 탈레스트라",
				[138829] = "교활한 잉겔",
				[92465] = "검은송곳니",
				[129832] = "따개비게",
				[89650] = "폭풍인도자 발리야카",
				[138830] = "별의 인도를 받는 트로바스트",
				[151627] = "고쳐줘 씨",
				[148044] = "오윈 그라독",
				[160841] = "비대한 블로불",
				[86835] = "젤가나크",
				[154187] = "온전한 물방울",
				[128553] = "아제르토르",
				[138831] = "홀벌드 오션사이드",
				[50336] = "요릭 샤프아이",
				[139344] = "드라카니 죽음부패자",
				[78134] = "길잡이 자로그",
				[148558] = "바위분노",
				[91187] = "모래젓개",
				[87348] = "흰 서리",
				[83509] = "선혈꽃잎",
				[134738] = "되살아난 자 하카비",
				[139345] = "죽음전령 쿨루",
				[71992] = "달송곳니",
				[132179] = "사나운 증기정령",
				[139346] = "영혼예언자 갈라니",
				[140370] = "시체포식자",
				[82742] = "에나브라",
				[82998] = "죄악의 여제",
				[142418] = "물결치는 거수",
				[139347] = "광전사 골라",
				[140371] = "알지기 니식크",
				[129835] = "뿔꼬챙이",
				[93236] = "어둠갈퀴",
				[97587] = "광기 어린 마법사",
				[126508] = "스케틱",
				[139348] = "서리방패 바가",
				[140372] = "둥지 수호자 크쉭스",
				[124717] = "집행자 바알",
				[139349] = "무덤소환사 무자",
				[121134] = "공작 시티지",
				[140373] = "여왕 모래껍질",
				[129836] = "주문을 뒤트는 모에퍼스",
				[139350] = "아나하 위더브레스",
				[140374] = "둥지 수호자 익스닐",
				[157266] = "집어삼키는 아귀 카이슬",
				[87351] = "어미 고렌",
				[151124] = "메카곤식 종결자",
				[139351] = "어둠예언자 안고로",
				[50338] = "밤의 포악자 코르나스",
				[157267] = "탈출한 돌연변이",
				[126254] = "부관 자카아르",
				[142423] = "감독관 크릭스",
				[134745] = "하늘조각사 크라킷",
				[139352] = "죽음소환사 마줄리",
				[87352] = "겁쟁이 지블렛",
				[139353] = "죽지 못하는 용사",
				[138842] = "공명생성자 타킬",
				[139354] = "뼈절단자 부툰",
				[160341] = "새끼 시궁창 악어",
				[90936] = "피사냥꾼 줄크",
				[138843] = "날개지도자 스라키크",
				[139355] = "서리검사 구란",
				[50339] = "술리크쇼르",
				[132701] = "티제인",
				[109620] = "속삭이는 자",
				[73277] = "낙엽치유사",
				[138844] = "황제의 칼날 야비크",
				[139356] = "호랑트론",
				[144987] = "어둠사냥꾼 무툼바",
				[138845] = "사령관 조바크",
				[138846] = "호박석날개 정신노래꾼",
				[139358] = "접대원",
				[136799] = "절벽파괴자",
				[138847] = "전투 치유사 카바즈",
				[139359] = "호랑트론",
				[139871] = "혈길잡이 킬틱스",
				[62881] = "영혼절단자 가오훈",
				[137824] = "전깃불이",
				[73279] = "영원아귀",
				[138848] = "칼춤꾼 졸라크",
				[98361] = "피투성이 까마귀",
				[139872] = "수호자 자카르",
				[136801] = "측량사 꼬질소금",
				[137825] = "눈사태",
				[138849] = "둥지군주 빅스익크",
				[139873] = "파멸끼긱",
				[140385] = "보석껍질 무리지기",
				[136802] = "석탄깨물",
				[142433] = "포즈루크",
				[139874] = "공포습격",
				[140386] = "토파즈 딱정벌레",
				[87357] = "발코르",
				[142434] = "루아이",
				[50085] = "대군주 가리분노",
				[50341] = "보르긴 다크피스트",
				[140387] = "보석 박힌 여왕",
				[136804] = "자갈척추",
				[72769] = "비취불꽃의 영혼",
				[50981] = "루크호크",
				[90173] = "비전 사냥개",
				[139876] = "밤흡혈거미",
				[140388] = "루비 청소부",
				[136805] = "바위댕강",
				[99899] = "흉포한 고래상어",
				[139877] = "알지기 카하스즈",
				[117303] = "말리피쿠스",
				[136806] = "돌마법사 바르그",
				[73282] = "갈니아",
				[139878] = "늙은 아칼아잔",
				[140390] = "마노 담즙포식자",
				[144997] = "구린 스톤바인더",
				[83008] = "걸신들린 하쿤",
				[142438] = "베노마루스",
				[134760] = "암흑예언자 졸라",
				[140391] = "에메랄드 심연수색자",
				[136808] = "모래거죽",
				[89407] = "고룡혓바닥 강탈자",
				[85568] = "눈사태",
				[77634] = "탈라도란튤라",
				[139880] = "무리순찰자 탈나딕스",
				[152677] = "승천자 네베트",
				[136809] = "바위포식자 돌턱",
				[111674] = "잿불날개",
				[142440] = "요구르사",
				[79938] = "그림자껍질",
				[139881] = "무리감시자 탈림라",
				[160868] = "유린날개 니르베라쉬",
				[139882] = "무리감시자 아눕아칼",
				[83522] = "둥지 여왕 스크리카",
				[134764] = "따닥이껍질",
				[139883] = "예언자 바키즈아샤",
				[157287] = "도카니 절멸자",
				[147562] = "박격포 대장 잽프릿츠",
				[127288] = "사냥개조련사 케락스",
				[152681] = "왕자 타이포너스",
				[136813] = "금광킁킁",
				[87362] = "기비",
				[134766] = "파도뱉기게",
				[139885] = "예언자 녹스티르",
				[125497] = "감독관 이소르나",
				[136814] = "넝마꼬리",
				[134767] = "죽음발톱 알어미",
				[90434] = "세락사스",
				[140398] = "제리타르즈",
				[157290] = "비취 감시자",
				[134768] = "냉혹한 모래집게",
				[50344] = "놀락스",
				[125498] = "감독관 이모르나",
				[136816] = "감독관 스놀글",
				[97345] = "굶주린 크로슈크",
				[85572] = "그르브르글",
				[134769] = "톱니 발톱",
				[127290] = "머그",
				[136817] = "감독관 강철주둥이",
				[124475] = "휘청거리는 복병",
				[79686] = "은빛잎새 고대정령",
				[139889] = "보러스아라크",
				[132211] = "악취부리",
				[136818] = "감독관 화염핥기",
				[138866] = "맥",
				[78151] = "전문사냥꾼 쿠앙",
				[82758] = "위엄깃털",
				[83526] = "루클라",
				[104513] = "디필리아",
				[135796] = "선장 리드피스트",
				[160878] = "불경한 자 부그자키",
				[153200] = "부글앗뜨",
				[50985] = "두드림주먹",
				[110656] = "비전술사 리란드레",
				[90437] = "작스조르",
				[95044] = "공포주먹",
				[154225] = "녹슨 왕자",
				[84807] = "두르카스 스틸마",
				[97348] = "아베샤",
				[138870] = "믹",
				[90438] = "여군주 오란",
				[141942] = "무쇠주먹 몰로크",
				[154739] = "부식성 기계수액",
				[138871] = "어니",
				[112705] = "아크로노스",
				[148597] = "강철 주술사 그림비어드",
				[97093] = "샤라 펠브레스",
				[77642] = "업화술사 진드라",
				[153205] = "보석사 거미",
				[124479] = "물집아귀",
				[139385] = "긴송곳니",
				[152182] = "녹슨깃털",
				[153206] = "늙은 왕엄니",
				[151159] = "OOX-날쌘발/MG",
				[139386] = "뱀혓바닥",
				[116034] = "젖소왕",
				[120641] = "스컬굴로스",
				[104517] = "마와트아키",
				[129343] = "졸로탈의 화신",
				[84810] = "피범벅 칼로스",
				[73293] = "휘지그",
				[139388] = "제스에즈",
				[152697] = "울매스",
				[83019] = "구그톨",
				[134782] = "살해부리",
				[112708] = "그림토템 용사",
				[80204] = "지옥껍질",
				[109125] = "야생의 카소우",
				[140925] = "의사 마르틴스",
				[139390] = "비늘경비병 사리스즈",
				[90442] = "여주인 타브라",
				[82764] = "가르루아",
				[116036] = "제왕 구름날개",
				[79693] = "은빛잎새 고대정령",
				[139391] = "암흑파도 암살자",
				[125250] = "고대 턱파괴자",
				[93002] = "마그위아",
				[89675] = "지휘관 오르그모크",
				[122947] = "여군주 일센드라",
				[128578] = "주조스걸",
				[136834] = "무두장이 바주울루",
				[126019] = "지나치게 자란 아귀마귀",
				[138370] = "호르코",
				[85837] = "조각아귀",
				[98890] = "잠탱이",
				[136835] = "킨토가 비스트베인",
				[104521] = "알테리아",
				[50349] = "영혼도둑 캉",
				[136836] = "암흑파괴자 우르줄라",
				[50733] = "스키티크",
				[77648] = "불꽃의 대모 타르가",
				[151681] = "투척꾼 짤딸꼬리",
				[131718] = "덤불날개",
				[136837] = "맹독술사 앤트수",
				[128580] = "칼날턱",
				[112712] = "금박 수호자",
				[132743] = "화염비늘 파도돌격병",
				[109641] = "일급 비전골렘",
				[138374] = "모래털이",
				[134791] = "영롱한 엉금게",
				[78161] = "하이페리우스",
				[136839] = "므로건",
				[138375] = "스무스",
				[104523] = "샬라스아만",
				[50350] = "모르긴 크랙팡",
				[136840] = "조가",
				[105547] = "로우렌",
				[50990] = "천둥발굽 나크",
				[134793] = "반짝가시",
				[151685] = "군내털 굴어미",
				[140424] = "낫뿔이",
				[132746] = "서리미늘 무리어미",
				[107595] = "음침한 부패곰",
				[116041] = "보물 고블린",
				[91727] = "집행관 라일로스",
				[138889] = "선견자 우불드",
				[104524] = "오르마그로그",
				[96590] = "망치주먹 구르보그",
				[140425] = "매운발",
				[97102] = "람파그",
				[138890] = "영혼수색자 다르걸프",
				[151687] = "비명쟁이",
				[140426] = "달수염",
				[140938] = "두껍이",
				[107596] = "음침한 부패곰",
				[120393] = "공성전문가 보라안",
				[134796] = "가시집게 왕게",
				[139403] = "침략자 아라사즈",
				[50351] = "존다르",
				[140427] = "산악발굽 무리아비",
				[93264] = "대장 그록마르",
				[77140] = "아마우콰",
				[142475] = "매혹적인 카자",
				[134797] = "해변 그늘게",
				[139404] = "고위 사제 마사스",
				[140428] = "협곡도약자",
				[95056] = "파멸바퀴",
				[128584] = "버그수스",
				[134798] = "심연 엉금게",
				[139405] = "파도인도자 세제스안",
				[140429] = "재빠른 급류폴짝이",
				[153226] = "강철 노래꾼 프레자",
				[134799] = "심연집게",
				[139406] = "핏빛비늘 하산",
				[136335] = "격노한 크롤러스크",
				[103247] = "울타녹스",
				[108366] = "기억 저편의 히포그리프",
				[139407] = "송곳니공포",
				[50352] = "쿠나스",
				[136336] = "스콜폭스",
				[80725] = "유황손아귀",
				[93778] = "빛나는 꽃",
				[134801] = "깨진 껍질 거북",
				[122955] = "대사 테릭",
				[145039] = "눈추적자",
				[134802] = "칼날등껍질 거북",
				[108879] = "휴몽그리스",
				[136338] = "시로카르",
				[136850] = "무쇠가죽 듈란",
				[139410] = "조용한 칼날의 비스즈",
				[132244] = "키보쿠",
				[136851] = "누루 엠버브레이드",
				[83542] = "숀 화이트시",
				[134804] = "영겁의 룬껍질거북",
				[54320] = "반탈로스",
				[80471] = "제나디안",
				[72537] = "나뭇잎예언자 쿠리",
				[85078] = "공허약탈자 우르네이",
				[134293] = "아제라이트가 주입된 화산바위",
				[134805] = "떠도는 거대 거북",
				[139412] = "가샤스즈",
				[135829] = "먼지바람",
				[136341] = "밀림그물 사냥꾼",
				[136853] = "소머리 전쟁수염",
				[138389] = "스마샤",
				[134806] = "피절단거북",
				[139413] = "진창매복 오아시스예언자",
				[135830] = "강풍분노",
				[140437] = "느린 올로",
				[136854] = "바룬 플린트후프",
				[149651] = "깜장발",
				[134807] = "고대 가시갑옷",
				[139414] = "늪 사제 바스즈",
				[78169] = "구름예언자 데이버",
				[140438] = "늙은 긴이빨",
				[136855] = "녹아내린 보르도",
				[149652] = "아가테 웜우드",
				[138391] = "투척자 노르코",
				[54321] = "솔릭스",
				[50354] = "하바크",
				[140439] = "사향몸통 무리지도자",
				[136856] = "잿불뿔",
				[149653] = "육식 덩굴손",
				[138392] = "보노",
				[139416] = "볼샤스",
				[140440] = "뿔난 핏빛털",
				[136857] = "무리두목 운돌",
				[95318] = "페렉스",
				[138393] = "깨물끼끼",
				[139417] = "저주박은 부패나무",
				[135834] = "썩은구름",
				[136346] = "선장 스테프 \"골수\" 쿠인",
				[136858] = "잔리",
				[149655] = "크로즈 블러드레이지",
				[139418] = "부패한 자",
				[136859] = "붉은머리",
				[149656] = "험악뿔",
				[139419] = "대점쟁이 아사이자",
				[50355] = "카흐티르",
				[132253] = "지아라크",
				[136860] = "추적자 부카",
				[50739] = "가르로크",
				[139420] = "늪 수호자 바스자쉬",
				[135837] = "소용돌이 부관",
				[70238] = "깜박이지 않는 눈",
				[136861] = "황혼추적자 쿨리",
				[149658] = "그림자발톱",
				[139421] = "이끼비늘 게카즈",
				[108885] = "아이기르 파도파괴자",
				[160920] = "역병의 칼티크",
				[136862] = "올고",
				[109653] = "거대한 마블럽",
				[135839] = "늪가스",
				[136863] = "위대한 모타",
				[149660] = "깜장발",
				[100184] = "선원의 악몽",
				[54323] = "키릭스",
				[50356] = "칼날의 크롤",
				[148637] = "어둠사냥꾼 볼트리스",
				[136864] = "공포의 우구우",
				[149661] = "크로즈 블러드레이지",
				[130897] = "대장 레이저스파인",
				[136865] = "모래약탈자 우잔",
				[91227] = "핏빛 달의 잔재",
				[99929] = "바다떠돌이",
				[135842] = "군주 프루자안",
				[140449] = "뭉툭몸통",
				[97370] = "장군 볼로스",
				[135843] = "군주 무달",
				[140450] = "눈먼 두누",
				[149664] = "오웰 스티븐슨",
				[54324] = "화염발이",
				[92508] = "어스름갈퀴",
				[140451] = "애정어린 새끼어미",
				[149665] = "비늘마귀",
				[130643] = "뒤틀린 레잔의 자식",
				[77664] = "아르코",
				[135845] = "군주 카메트",
				[140452] = "잠자는 창뿔",
				[134822] = "우두머리 돌장갑",
				[140453] = "나무털 무리지도자",
				[101467] = "거북신",
				[130644] = "칼니악어",
				[134823] = "깨지지 않는 수정가시",
				[139430] = "영원한 사냥개 잘리즈",
				[70243] = "대의식술사 켈라다",
				[139431] = "무덤 수호자",
				[50358] = "고장난 선리버 피조물",
				[160930] = "주입된 호박석 수액",
				[136872] = "우프 브레인배셔",
				[139432] = "루시",
				[136873] = "타액사수",
				[154277] = "Test Creature",
				[83553] = "인샤타르",
				[155301] = "타이드스코른 검투사",
				[88672] = "사냥꾼 발라",
				[136874] = "봉크",
				[93279] = "용서받지 못한 크리스카르",
				[97630] = "영혼곯이",
				[122456] = "공허아귀",
				[151719] = "심연의 목소리",
				[148648] = "무리주인 스위프트애로우",
				[140970] = "바위파열자",
				[91232] = "지휘관 크라그고스",
				[120665] = "군사령관 질리어스",
				[135852] = "아크타르",
				[136876] = "공포의 어윽",
				[117850] = "매혹의 시몬",
				[122457] = "암흑소환사",
				[136877] = "바바 구파",
				[116059] = "제왕 구름날개",
				[142508] = "나뭇가지군주 알드루스",
				[72294] = "잿불아귀",
				[136878] = "머리상모",
				[139438] = "영혼인도자 토간",
				[111197] = "아낙스",
				[136879] = "용암포식자 마부투",
				[116316] = "지룩스",
				[139439] = "황혼결속자 주운",
				[84836] = "발톱파괴자",
				[77926] = "불세로스",
				[111454] = "베스트릭스",
				[146607] = "옴거 둠보우",
				[143536] = "대장군 볼라스",
				[72808] = "차보카",
				[137906] = "주입된 기반암",
				[139442] = "척추파쇄자 주칸",
				[148144] = "크로즈 블러드레이지",
				[70249] = "집중하는 눈",
				[140978] = "파멸땅굴",
				[133812] = "잔시브",
				[139443] = "척추술사 쿤타이",
				[117086] = "잿불불꽃",
				[117342] = "지옥사냥개",
				[93028] = "드리스 바일",
				[139444] = "강령군주 지안",
				[110944] = "수호자 토르엘",
				[107105] = "무리어미 리작스",
				[107617] = "늙은 불곰",
				[146611] = "튼튼팔 존",
				[139445] = "투마트",
				[92517] = "고요한 크렐",
				[136886] = "깃발운반자 코랄",
				[97380] = "댓개비",
				[132280] = "꽉꽉이",
				[136887] = "바늘갈기",
				[152756] = "단도이빨 공포광치",
				[93030] = "무쇠가지",
				[97381] = "빽빽이",
				[97637] = "투견 바락스",
				[69996] = "하늘발톱 쿠라이",
				[152757] = "아테크라문",
				[136889] = "칼날소환사 투크",
				[117089] = "심문관 칠베인",
				[136890] = "무쇠 오르카스",
				[138938] = "바다파괴자 스콜로스",
				[69997] = "프로제니투스",
				[140474] = "심연의 신봉자",
				[136891] = "흉터 입은 엄니분쇄자",
				[117090] = "화염조각사 조로군",
				[140987] = "탐욕의 살점융해자",
				[130143] = "가시뭉치",
				[90217] = "퇴위된 노르만티스",
				[69998] = "고다",
				[140988] = "강철파쇄",
				[83819] = "벽돌집",
				[117091] = "지옥아귀 잿불마귀",
				[97384] = "세가세디",
				[98408] = "지옥 감독관 머드럼프",
				[69999] = "괴물신 라무크",
				[103271] = "크락사",
				[146109] = "밤빛깔 돌진엘크",
				[138431] = "해일여제 나줄라",
				[79725] = "대장 아이언비어드",
				[50364] = "학살자 날라크",
				[152764] = "산화된 갈취짐승",
				[140991] = "골수천공",
				[130401] = "바시커르",
				[138432] = "해일여제 네사",
				[110438] = "공성전문가 에이드린",
				[155836] = "사술사 니타라",
				[139968] = "타락한 파도돌고래",
				[136385] = "아주레토스",
				[140992] = "시체파열자",
				[91243] = "토가르 고어피스트",
				[146111] = "20 점짜리",
				[138433] = "해일여제 베사나",
				[72048] = "해골엄니",
				[146112] = "검은털 거수",
				[155838] = "여주술사 바지나",
				[70001] = "척추파쇄자 우루",
				[111463] = "부르빈켈",
				[103785] = "배불리 먹은 곰",
				[108136] = "근육덩어리",
				[72049] = "학포식자",
				[140995] = "폐허추적자",
				[97387] = "마나 흡입자",
				[146114] = "쇄도의 바람",
				[138436] = "군주 갈퀴지느러미",
				[138948] = "우까까꾸",
				[155840] = "전쟁군주 잘자르",
				[70002] = "루반",
				[107113] = "보르탁스",
				[140996] = "심연천공",
				[138437] = "침략자 스제리스",
				[155841] = "그림자술사 아티사",
				[117095] = "공포칼날 파멸자",
				[140997] = "추방자 세베루스",
				[97388] = "줄로락스",
				[138438] = "파도약탈자 강철송곳니",
				[70003] = "몰소르",
				[148676] = "짐마차 지휘관 베로니카",
				[103787] = "베이컨리스크",
				[138439] = "뱀여왕 발라",
				[155331] = "아제라이트 거수",
				[96621] = "토로크의 아들 멜로크",
				[76914] = "서리엄니",
				[138440] = "여군주 아사나",
				[155332] = "빛나는 아제라이트보석 수정등",
				[143559] = "최고사령관 트렘블레이드",
				[136393] = "혈날개 뼈다귀청소부",
				[138441] = "심연의 여가수",
				[124775] = "사령관 엔닥시스",
				[143560] = "작전사령관 가브리엘",
				[80242] = "한기송곳니",
				[109163] = "선장 다르건",
				[97390] = "도둑질하는 건달",
				[138442] = "파도돌격병",
				[139466] = "코발트 바위경비병",
				[138443] = "비늘경비병 불레스",
				[120681] = "지옥 절멸자",
				[139467] = "화강암주먹 킨수",
				[126056] = "토템 제작자 자쉬가",
				[138444] = "장군 베스파라크",
				[139468] = "척추절단자 쿠콘",
				[139980] = "파도울음 타자",
				[74613] = "무리어미 리그아크",
				[138445] = "공작 스줄",
				[139469] = "천둥의 주산",
				[160968] = "비취 거대괴수",
				[109677] = "수석 회계사 자브릴",
				[138446] = "심해소환사 젤리사",
				[139470] = "용 조련사 시쇼",
				[138447] = "여전사 살라리아",
				[92274] = "고통의 여왕 셀로라",
				[160970] = "대지파괴자 부클라즈",
				[76918] = "원시술사 멀오그",
				[106351] = "기술병 로테어",
				[139472] = "바위군주 킨쇼",
				[106863] = "되살아난 바다수염",
				[78710] = "승리의 카라조스",
				[133842] = "전쟁삼엽충 카키티스",
				[87668] = "관찰자 오루모",
				[139473] = "바위 기계공 누신",
				[88436] = "수호자 파르토스",
				[133843] = "일등항해사 낭만부리",
				[139474] = "대지소환사 코르신",
				[157390] = "현실포식자 로요로크",
				[138963] = "둥지 어미 아카다",
				[139475] = "비취형성 뼈다귀싸움꾼",
				[84854] = "미끄러운 진흙괴물",
				[163534] = "애완동물 훈련용 허수아비",
				[127084] = "사령관 텍스라즈",
				[139988] = "모래송곳니",
				[153297] = "REUSE",
				[146131] = "잠복자 바르토크",
				[120686] = "일리스틴드리아",
				[117103] = "지옥소환사 젤타이",
				[153298] = "REUSE",
				[127341] = "영원히 타오르는 파멸인도자",
				[78713] = "갈조마르",
				[112497] = "순백의 마이아",
				[152788] = "태양의 분노 우아트카",
				[88951] = "추악발톱",
				[97653] = "타우르슨",
				[98421] = "코트르 본디르",
				[153301] = "쉬라케스 별길잡이",
				[148695] = "의사 라제인",
				[145112] = "자그 브로큰아이",
				[110451] = "악몽 수정",
				[86137] = "태양발톱",
				[78715] = "학살의 여제 시크티스",
				[111731] = "카르탁스",
				[54338] = "안트리스",
				[58817] = "라오페의 영혼",
				[50883] = "질주발굽",
				[136413] = "지배자 사이라원",
				[153305] = "잔지르 야만전사",
				[146139] = "금빛가시",
				[146651] = "운무사 니엔",
				[112756] = "소랄루스",
				[132319] = "증오송곳니 어미",
				[129904] = "어미 솜꼬리토끼",
				[146140] = "가시도저",
				[139486] = "하늘틈새",
				[152795] = "모래집게 돌딱지",
				[153307] = "풀려난 비전마귀",
				[79485] = "갈퀴사제 조르크라",
				[112757] = "마법학자 바일사",
				[153308] = "아즈샤라의 격분",
				[154332] = "공허지기 말케스",
				[127090] = "제독 렐바르",
				[107127] = "브롤고스",
				[153309] = "천둥의 화살 알자나",
				[146143] = "칼가시",
				[112758] = "감사관 에시엘",
				[153310] = "얼음의 창 칼리나",
				[153311] = "뱀갈퀴 아잔즈",
				[103801] = "아르스파엘",
				[134884] = "라그나",
				[112759] = "아즈자타르",
				[132837] = "해변거인",
				[70530] = "라샤",
				[112760] = "의지파괴자 볼샥스",
				[152290] = "한깊가오리",
				[141029] = "발로뻥",
				[152291] = "심해가오리",
				[153315] = "엘다나르",
				[138984] = "흉터비늘",
				[122999] = "가르조스",
				[148198] = "정찰대장 그리즐놉",
				[70276] = "폭풍예언자 노쿠",
				[138473] = "스티지아",
				[138985] = "늙은 굶그옳",
				[85121] = "여군주 템테사",
				[154342] = "포획꾼 기계거미",
				[138474] = "엄브랄리온",
				[138986] = "수색자 보글",
				[82050] = "바라샤",
				[133356] = "템페스트리아",
				[138475] = "타이런티온",
				[138987] = "흙지느러미 대점쟁이",
				[136428] = "어둠의 기록가",
				[125816] = "하늘의 여왕",
				[58949] = "도살자 바이진",
				[51015] = "미끈거죽",
				[138988] = "뽀글눈알",
				[127096] = "모두를 보는 자 자나리안",
				[91009] = "퓨트레타르",
				[95872] = "해골모자",
				[138989] = "짭짤지느러미",
				[93057] = "그란노크",
				[138990] = "눈먼 우르글",
				[138479] = "흑요석 대군주",
				[138991] = "겔겔이",
				[104831] = "자브릭스",
				[129657] = "여왕의 검 자아마르",
				[141039] = "얼음 낫",
				[134897] = "경멸받은 다그러스",
				[69768] = "잔달라 전투정찰병",
				[136945] = "코르버스",
				[138481] = "크로미투스",
				[138993] = "걸락",
				[138482] = "연금술사 칼루리악",
				[138994] = "팀버피스트",
				[90244] = "아르카벨루스",
				[135923] = "가즈란의 사냥개",
				[107136] = "사냥개조련사 스트록시스",
				[138483] = "흑요석 괴물",
				[138995] = "씨앗지기 운간",
				[135924] = "타오르는 격노",
				[141043] = "잔인한 자칼라",
				[138484] = "흑요석 예언자",
				[138996] = "대지예언자 주와",
				[82311] = "불타는 차르",
				[149746] = "녹슨 메카거미",
				[83591] = "투라아카",
				[134902] = "그림자술사 거미",
				[135926] = "이글심장",
				[129660] = "고대 방어구",
				[138486] = "알루리악",
				[134903] = "흡혈 공포 거미",
				[138487] = "흑요석 날개 분리병",
				[138999] = "늙은 오르돌",
				[147701] = "참수자 목소",
				[84872] = "복수심에 불타는 오스키라",
				[109954] = "마법학자 패드리스",
				[134905] = "그늘그물 사냥거미",
				[135929] = "화염남작 블레이즈할로우",
				[135930] = "라바로크",
				[90248] = "퇴위된 노르만티스",
				[135931] = "잿빛돌",
				[103045] = "역병아귀",
				[82826] = "광분로봇 T-300 시리즈 마크 II",
				[134908] = "붉은송곳니",
				[135932] = "볼카나르",
				[125824] = "카자두움",
				[133373] = "되살아난 작스텝",
				[134909] = "딸깍거리는 물레그물 거미",
				[90505] = "시포누스",
				[91529] = "길마르 아이언피스트",
				[134910] = "흐린빛그물 거미",
				[135934] = "군주 인신디바르",
				[80524] = "감독관 블러드메인",
				[84875] = "고대 불지옥",
				[109957] = "망치 이셀",
				[97928] = "길든 산호등",
				[134911] = "어둠굴 과부거미",
				[147708] = "애스리쿠스 나라신",
				[135935] = "군주 마그마르",
				[127873] = "수컷 강탈랩터",
				[137983] = "부제독 헤인스워스",
				[100232] = "라이엘 돈드리프터",
				[108678] = "샤르토스",
				[135936] = "군주 아마르잔",
				[149245] = "호드 대장",
				[109702] = "심해집게",
				[126338] = "분노군주 야레즈",
				[110726] = "카드래우스",
				[141056] = "파도 군주 마쿠나",
				[140545] = "여왕거미 플레어네이",
				[141057] = "파도 군주 보르샤스즈",
				[81038] = "푸른 화염의 겔고르",
				[94347] = "공포기수 코르티스",
				[135939] = "덩굴예언자 라타",
				[140546] = "여왕거미 빌틸락",
				[141058] = "파도 군주 스주니스",
				[124548] = "벳지",
				[124804] = "선택자 테렉",
				[84110] = "코르살 소울고져",
				[129411] = "추방자 주나쉬",
				[140547] = "여왕거미 신드릭스",
				[141059] = "무식한 음산도끼눈",
				[146178] = "하늘가시",
				[126852] = "사냥꾼 크라보스",
				[90253] = "퇴위된 노르만티스",
				[123269] = "쿡",
				[140548] = "잿불송곳니 복병",
				[115847] = "아리아드네",
				[150786] = "기계식 거미전차",
				[140549] = "용암그물 포식자",
				[138502] = "나로비악 고룡술사",
				[98188] = "인내하는 자 에길",
				[123270] = "주방장 그루",
				[140550] = "화염딸깍이",
				[127877] = "긴송곳니",
				[138503] = "황혼의 감독관",
				[157443] = "태산 실린",
				[50766] = "셀레나",
				[138504] = "장군 다카리온",
				[139016] = "가시가죽",
				[63691] = "후오슈앙",
				[142088] = "휘리릭날개",
				[138505] = "진화한 무리감독관",
				[120712] = "라리시아",
				[88208] = "구덩이 야수",
				[148231] = "공성파괴자 볼가르",
				[140553] = "여왕거미 슈자스즈",
				[138506] = "진홍비늘",
				[139018] = "잠든 산",
				[139530] = "대지세공 공성파괴자",
				[148744] = "양조달인 린",
				[145161] = "공성 기술자 크래클블룸",
				[138507] = "전쟁군주 울트리스",
				[139019] = "분노등짝",
				[140555] = "화염 투견",
				[132877] = "축축비늘",
				[109708] = "하급 그렐 우두머리",
				[130439] = "애쉬메인",
				[138508] = "불굴의 소용돌이",
				[139020] = "난폭한 으르렁심연",
				[140556] = "연기사냥개",
				[138509] = "역술사 울루라",
				[139021] = "피추적꾼",
				[100495] = "엄습하는 어둠",
				[140557] = "안면절단자",
				[132879] = "수정 거인",
				[146188] = "불길의 통솔자",
				[138510] = "황혼의 파멸소환사",
				[139022] = "수호자 쏜퍼",
				[140558] = "지옥불 공포",
				[138511] = "청금비늘",
				[120715] = "라가유트",
				[140559] = "화산개",
				[50768] = "컬니스 워터스트라이더",
				[138512] = "토리시오나",
				[139024] = "밤깃털",
				[140560] = "불꽃추적자",
				[127882] = "수집가 빅스",
				[115853] = "파멸덩굴손",
				[91795] = "폭풍날개 어미",
				[120716] = "공포예언자 세릴리스",
				[138514] = "아티오나",
				[77719] = "미명날개",
				[139538] = "벽파괴자 하비크",
				[82326] = "바룬",
				[95123] = "노파 그렐다",
				[138515] = "엔달리온",
				[120717] = "여군주 도미닉스",
				[139539] = "여제의 망치 타보크",
				[148753] = "프팅고",
				[93076] = "대장 아이언비어드",
				[50769] = "추방자 자이",
				[130443] = "둥지어미 크락시",
				[138516] = "황혼의 진화론자",
				[126860] = "창백한 카아라",
				[135958] = "공작석",
				[84887] = "벳시 붐바스켓",
				[134935] = "어미 비쉬스",
				[135959] = "우레정령 진동발",
				[103827] = "왕 모르갈라쉬",
				[134936] = "킬틸락",
				[135448] = "악취가 나는 골탄",
				[135960] = "군주 자그러크",
				[105619] = "사이릴린",
				[126862] = "피에 굶주린 바루우트",
				[127118] = "세계분열자 스쿠울",
				[90519] = "야생의 불꽃 신드랄",
				[160532] = "암흑에 물든 쇼스",
				[148759] = "폭풍소환사 모르카",
				[126095] = "빌리스",
				[98198] = "루크두그",
				[132892] = "방정나뭇잎",
				[107924] = "어둠마귀 고문관",
				[84378] = "학살자 아크옥스",
				[84890] = "구린꽃",
				[126864] = "머핀 도둑 피즐",
				[127376] = "수석 연금술사 먼큘러스",
				[90777] = "대사제 이크잔",
				[91289] = "케일린 페일둠",
				[140061] = "회색털 소굴어미",
				[72606] = "바위발굽",
				[154394] = "타락자 베스칸",
				[126865] = "감시자 타노스",
				[140062] = "공포철퇴",
				[136991] = "혈사냥꾼 다잘아이",
				[103575] = "산호초 군주 라즈히스",
				[107926] = "도살자 한느발",
				[139039] = "심연사냥꾼 에소",
				[117140] = "무리방랑자 살레단",
				[50772] = "에셜론",
				[138016] = "다록크",
				[139040] = "심연 점쟁이 우나니",
				[140064] = "피에 젖은 회색털",
				[141088] = "돌풍",
				[142112] = "한파의 코르그레쉬",
				[91803] = "파스니르",
				[134946] = "거대한 수렵거미",
				[96410] = "위풍당당한 늙은뿔 순록",
				[140065] = "사향가죽",
				[84893] = "피엄니",
				[122004] = "엄브라진",
				[126867] = "맹독꼬리 하늘지느러미",
				[147744] = "호박집게",
				[140066] = "도끼발톱",
				[157470] = "령 포식자 라아스",
				[134948] = "수풀 추적거미",
				[148257] = "죽음경비대장 다니엘",
				[134949] = "점판땅거미",
				[151841] = "전령 버그톡",
				[157472] = "광기의 허울 아프롬",
				[139045] = "예언자 주치",
				[148259] = "죽음경비대장 딜라일라",
				[157473] = "의지약탈자 이프림",
				[126101] = "황혼거죽 암호랑이",
				[126869] = "대장 파루크",
				[140070] = "추적자 핏내음",
				[94877] = "힘세고 강한 브로그룰",
				[140071] = "늙은 외송곳니",
				[122519] = "드레그마르 룬브랜드",
				[147750] = "대포 장인 굿윈",
				[140072] = "약탈자 공포걸음",
				[157476] = "살덩이 탐식자 슈그슐",
				[147751] = "산산파편",
				[140073] = "광기아귀",
				[122520] = "얼음주먹",
				[147240] = "히드라스",
				[140074] = "뾰족니",
				[86689] = "스니블",
				[147241] = "싸이클라러스",
				[140075] = "카누스",
				[93088] = "흉포발톱",
				[122521] = "해골도살자",
				[139564] = "낭만부리",
				[152361] = "떼아비 악독비늘",
				[79524] = "최면개구리",
				[151850] = "사령관 딜리크",
				[121242] = "꿀꺽아귀",
				[148779] = "빛벼림 기갑전투복",
				[153898] = "바다군주 아쿠아투스",
				[122522] = "얼음파괴자",
				[102303] = "사령관 스트라스마르",
				[127129] = "그로즈고어",
				[151852] = "감시자 리후",
				[140079] = "밀림비명꾼",
				[132913] = "군도 거인",
				[50776] = "날라쉬 베르단티스",
				[118172] = "군주 히드로니쿠스",
				[82085] = "바시오크",
				[140080] = "머리분쇄자",
				[141616] = "우레의 거수",
				[151854] = "죽음의수색꾼 로소크",
				[140081] = "왕 루까",
				[140593] = "잠 못 드는 공포",
				[109727] = "분쇄자 도르바쉬",
				[122524] = "피발굽",
				[140082] = "기브",
				[141618] = "물결치는 거수",
				[103841] = "그림자깃",
				[124572] = "화염술사 볼라알",
				[128923] = "샤키",
				[140083] = "천둥발 쿨라",
				[109728] = "거인",
				[154416] = "히스카리",
				[140084] = "박살주먹",
				[107169] = "호룩스",
				[141620] = "요동치는 거수",
				[129180] = "전쟁인도자 호지크",
				[72362] = "공허현자 쿠탈그",
				[109729] = "격노",
				[118175] = "폭풍의 정령",
				[126621] = "뼈돌풍",
				[148276] = "파도결속자 마카",
				[107170] = "조룩스",
				[127901] = "헨리 브레이크워터",
				[138039] = "어둠 순찰자 클리아",
				[75434] = "어미 바람송곳니 늑대",
				[50138] = "카로마",
				[129181] = "바텐더 빌",
				[84392] = "라고르 드리프트스토커",
				[132921] = "해일여제 세르아",
				[118176] = "천둥충격",
				[111010] = "사에퍼",
				[137529] = "배신당한 자 아르본",
				[75435] = "이그드렐",
				[112802] = "마르투라",
				[140089] = "늙은 황혼발굽",
				[72364] = "용암먹보 고르그악",
				[129950] = "발톱새",
				[90024] = "하사관 모르그락",
				[155958] = "타샤라",
				[140090] = "아나타쉬",
				[148792] = "하늘선장 써모스파크",
				[131389] = "테레스",
				[135996] = "군주 콜슬레이트",
				[90281] = "대사제 이크잔",
				[140092] = "긴걸음사슴",
				[140093] = "솔먹이 새끼어미",
				[77741] = "라칸",
				[135999] = "헬리오도르",
				[147261] = "그라노크",
				[136000] = "베릴러스",
				[152892] = "녹슨 메카거미",
				[50780] = "산 타이드헌터",
				[109990] = "잊혀진 닐라트리아",
				[127906] = "황혼전령 타루울",
				[162619] = "공허의 망령",
				[128674] = "탐욕의 거트거트",
				[128930] = "로흔코르",
				[151870] = "모래성",
				[140097] = "거대 먼지배",
				[129954] = "가즈랄카",
				[126115] = "벤오른",
				[136003] = "그레블러스",
				[127651] = "꼭집게",
				[138563] = "부닥스",
				[140099] = "시끄러운 천둥주둥이",
				[138564] = "크슈운",
				[139588] = "막을 수 없는 고르쿨",
				[94636] = "음험한 칼라지우스",
				[119718] = "임프 어미 브루바",
				[79024] = "전투대장 블러그톨",
				[158528] = "고위 경비병 레쉬프",
				[138565] = "미리스",
				[139589] = "황천술사 욱크",
				[140101] = "늪뒹굴이",
				[84911] = "데미도스",
				[146244] = "찌르는 마귀",
				[138566] = "닐소즈",
				[126885] = "엄브랄리스",
				[140102] = "칼니멧돼지",
				[70323] = "크락카논",
				[86959] = "카로쉬 블랙윈드",
				[146245] = "파닥날개",
				[142662] = "흙점쟁이 플린트대거",
				[139591] = "혓바닥천지 오론",
				[92590] = "후크",
				[84912] = "가시가름쇠",
				[50782] = "사르낙",
				[109994] = "폭풍발톱",
				[138568] = "정복사 슈크슈군",
				[139592] = "역술사 고로",
				[146247] = "백색죽음",
				[138569] = "선구자 보르직스",
				[151878] = "태양왕 나흐코텝",
				[136010] = "바위얼굴 대지파괴자",
				[138570] = "전령 라자퀴",
				[126887] = "아탁쏜",
				[139594] = "투사 고르",
				[136011] = "피바위",
				[127911] = "공허칼날 제다아트",
				[83634] = "정찰병 포크하르",
				[128935] = "말라킬리",
				[139595] = "고위 경비병 마카그",
				[136012] = "요지부동 산덩치",
				[145226] = "스트로프니르",
				[50783] = "살리인 전투정찰병",
				[138572] = "장군 우보쉬",
				[139596] = "점쟁이 고르도",
				[78260] = "대왕 수액괴물",
				[138573] = "장군 누가스",
				[139597] = "용암주먹 오그고그",
				[140109] = "무장한 죽음갈퀴",
				[145228] = "발리아",
				[138574] = "장군 에르줄",
				[126889] = "비운의 소롤리스",
				[139598] = "척추파쇄자 바하하",
				[140110] = "히드라러크",
				[145229] = "스로프니르",
				[138575] = "장군 슐아콸",
				[116652] = "보물 고블린",
				[139599] = "검투사 오르투그",
				[140111] = "독창 스칼딕스",
				[148813] = "토마스 반더그리프",
				[129961] = "아탈줄 괴수",
				[102064] = "토렌티우스",
				[98225] = "파스니르",
				[139600] = "화산 같은 마루크",
				[140112] = "바위채찍",
				[90803] = "지옥불정령 군주",
				[137553] = "장군 크라탁스",
				[128426] = "거트립",
				[157525] = "고동치는 무더기",
				[139601] = "고위주술사 모르그",
				[140113] = "맹독채찍",
				[135844] = "군주 수마르",
				[145232] = "스쿨리",
				[163356] = "[DNT] Vignette",
				[133971] = "드루켄구",
				[126635] = "혈사제 자크라르",
				[161407] = "불안정한 방울",
				[139602] = "막을 수 없는 스커르",
				[140114] = "챙강발톱",
				[82614] = "몰트노마",
				[162370] = "아마게딜로",
				[147507] = "하늘조각사 크라킷",
				[154447] = "수사 멜러",
				[79543] = "쉬르지르",
				[153303] = "공허칼날 카사르",
				[128610] = "슐 나그루스의 아귀",
				[84406] = "만드라코",
				[144722] = "토고스 크루얼암",
				[97203] = "텐파크 플레임토템",
				[147955] = "대지보주",
				[155274] = "타이드스코른 용사",
				[157469] = "지능강탈자 조스럼",
				[160872] = "파괴자 크록스타자르",
				[155703] = "거대한 자 안쿠리",
				[120675] = "안티나",
				[156709] = "타락한 강탈자",
				[151609] = "태양 예언자 에파포스",
				[161467] = "차원문 수호자 진타샬",
				[160876] = "격노한 호박석 정령",
				[135497] = "버섯",
				[160874] = "일꾼지기 아크세트",
				[50830] = "스프리긴",
				[80312] = "약탈자 그루투쉬",
				[76473] = "어미 아라네애",
				[158491] = "매사냥꾼 아메노피스",
				[152110] = "타락자",
				[94313] = "다니엘 \"폭탄광\" 보릭",
				[126637] = "칸다크",
				[160825] = "호박석구체자 에쉬리",
				[159318] = "암흑방랑자 야쉬그스",
				[78265] = "거대한 뼈발톱 미늘벌레",
				[82616] = "성큼턱",
				[148651] = "비대해진 고대정령",
				[70000] = "천리안 알타빔",
				[160867] = "크지트코보크",
				[146773] = "일등항해사 말론",
				[139593] = "문맹탈출 버크",
				[80057] = "영혼송곳니",
				[157995] = "상아 파괴자",
				[160893] = "대장 보를레크",
				[141143] = "수녀 앱신테",
				[156299] = "속을 알 수 없는 알크후즈",
				[93622] = "모티퍼러스",
				[117094] = "영혼지킴이 말로러스",
				[157291] = "첩보단장 훌라크",
				[81001] = "노크 카로쉬",
				[145020] = "돌리자이트",
				[82617] = "시체탐식자 회색엄니",
				[149334] = "지층 아제라이트",
				[82536] = "고리박스",
				[83385] = "공허현자 카룰그",
				[128686] = "덫사냥꾼 카미드",
				[116657] = "분노한 바다 거인",
				[134298] = "아제라이트가 주입된 정령",
				[92599] = "피추적자 우두머리",
				[140273] = "룬발굽 소굴지기",
				[89016] = "라빈드라스",
				[149847] = "광기 어린 트로그",
				[164331] = "[DNT] Vignette",
				[152657] = "해골이빨 타트",
				[50750] = "애티스",
				[134296] = "루실레",
				[82362] = "모르바 소울트위스터",
				[82618] = "토르고로스",
				[149336] = "현무암 아제라이트",
				[103605] = "장막수색꾼",
				[136892] = "야만주둥이",
				[142682] = "마른나무껍질 잘라스",
				[154333] = "공허지기 말케스",
				[161033] = "어둠아귀",
				[140123] = "무기달인 할루",
				[152557] = "도전장교",
				[149337] = "응축된 아제라이트",
				[50787] = "비늘의 아르네스",
				[134294] = "격노한 물의 정령",
				[106165] = "악몽 감시관소환 안 됨",
				[126896] = "혼돈의 전령",
				[151897] = "태양 여사제 누비트",
				[84833] = "상그리카스",
				[135838] = "오염바람",
				[149338] = "불안정한 아제라이트",
				[154604] = "군주 아즈퀴라이",
				[72045] = "첼론",
				[83643] = "말로크 스톤선더",
				[157176] = "망각한 자",
				[58768] = "따닥송곳니",
				[152556] = "수렁 귀신뱀",
				[92763] = "이름 없는 왕",
				[149339] = "스며든 아제라이트",
				[152624] = "왕 가쿨라",
				[155176] = "늙은 나샤",
				[151308] = "뽀각 스컬배쉬",
				[150342] = "대지파괴자 걸록",
				[127291] = "감시자 에이발",
				[78269] = "옹이턱",
				[132448] = "양초지기 서리수염",
				[82876] = "최고사령관 트렘블레이드",
				[152359] = "떼어미 진흙추적꾼",
				[152555] = "원로생명체 날라아다",
				[142686] = "뒤뚱발이",
				[92090] = "공포의 대상 쉬아마",
				[109648] = "의술사 아옳옳옳",
				[153313] = "정신지배자 비즈올고",
				[152682] = "왕자 보르트란",
				[129969] = "혈마녀 이신나",
				[153300] = "강철의 조코",
				[153928] = "바다군주 디스퍼시우스",
				[82268] = "암흑스승 고비드",
				[126898] = "사부울",
				[152397] = "오로누",
				[151680] = "주홍이빨",
				[132450] = "구린장화",
				[137057] = "장로 구르타니",
				[136323] = "송곳니소환사 조레스",
				[91579] = "파멸의 군주 카즈로크",
				[142688] = "다벨 몬트로즈",
				[147435] = "텔라르 문스트라이크",
				[127300] = "공허 감시자 발수란",
				[152414] = "장로 우누",
				[93371] = "모르드빅비오른",
				[137058] = "사술사 마고다",
				[162140] = "스킥스트라즈",
				[158557] = "기만자 액티스",
				[76380] = "고룸",
				[126899] = "제드힌 우승자 보루스크",
				[151296] = "OOX-복수자/MG",
				[152415] = "눈이 먼 알가",
				[111434] = "바다왕 티드로스",
				[82878] = "작전사령관 가브리엘",
				[162141] = "주이시즈",
				[107960] = "알루바논",
				[142690] = "싱어",
				[152553] = "심홍비늘",
				[153228] = "장비 검수자 코그스타",
				[92604] = "용사 엘로디",
				[127844] = "걸신들린 예티",
				[137060] = "모래술사 무나",
				[162142] = "큐호",
				[105657] = "노트가른",
				[104522] = "셀레니",
				[126900] = "교관 타라흐나",
				[85250] = "석화된 화석나무",
				[148322] = "블링키 기즈모스파크",
				[144644] = "수렁 바다달팽이",
				[137061] = "바람조련사 술루즈",
				[141668] = "미즈라엘의 메아리",
				[78733] = "전쟁마법사 바르골",
				[142692] = "학살자 니마르",
				[152552] = "샤시라",
				[152040] = "정찰대장 모스웬",
				[152729] = "달의 여사제 리아라",
				[151688] = "멜론파괴꾼",
				[137062] = "혈사냥꾼 아칼",
				[151672] = "메카란툴라",
				[140979] = "큰송곳니",
				[153299] = "뼈파괴자 스준",
				[73666] = "화염의 대제사장",
				[153312] = "심연예언자 킥스줄",
				[148456] = "진타고",
				[152323] = "왕 가쿨라",
				[82880] = "작전사령관 카쉬 스톰포지",
				[152736] = "수호자 탄닌",
				[154467] = "족장 멕멕",
				[154701] = "게걸스러운 기계포식자",
				[153302] = "빙하 마법사 지엘라",
				[111939] = "라이사니스 셰이드소울",
				[92606] = "실리사",
				[54322] = "데스틸락",
				[109498] = "잰더",
				[157157] = "빛나는 무미나",
				[151202] = "부정한 현신",
				[154153] = "집행자 KX-T57",
				[142435] = "역병깃털",
				[149341] = "유리화된 아제라이트",
				[152416] = "선지자 오마킬",
				[152569] = "광기 어린 트로그",
				[157466] = "충성스러운 안디",
				[162147] = "시체 청소부",
				[107327] = "흉악뿔",
				[152712] = "유리비늘",
				[151690] = "그슬이빨",
				[121016] = "아퀘욱스",
				[136042] = "군주 아쿠아노스",
				[117136] = "파멸인도자 자르토즈",
				[149351] = "망간광",
				[145041] = "날렵꼬리 추적자",
				[133995] = "데인저펄",
				[152794] = "자수정 돌돌껍질",
				[77763] = "저격수 키지",
				[137704] = "대모 모라나",
				[136043] = "염수정령",
				[157468] = "티시폰",
				[82882] = "장군 에이브드",
				[137579] = "속박 풀린 아제라이트",
				[72775] = "부포",
				[152548] = "비늘 여군주 그라티낙스",
				[116666] = "심연의 잿불",
				[147941] = "파도현자 클라리사",
				[136044] = "맹독팽창",
				[144946] = "숲군주 이부스",
				[109500] = "자크",
				[50791] = "벼리는 자 실트리스",
				[73157] = "바위 이끼",
				[142684] = "코보르크",
				[147664] = "짐카가",
				[144955] = "피폭식자 잘지",
				[136045] = "분쇄파도",
				[148842] = "공성트론",
				[86978] = "눈길",
				[87234] = "브루타그 그림블레이드",
				[148092] = "날레이스 페더시커",
				[140774] = "얼어붙은 돌군주",
				[147998] = "공허지배자 이븐셰이드",
				[135933] = "군주 가즈란",
				[92609] = "사냥꾼 잭",
				[98200] = "구크",
				[109501] = "다크풀",
				[146110] = "차오름달",
				[73158] = "에메랄드 학",
				[140435] = "희끗털",
				[90050] = "수정수염",
				[109113] = "침식된 낙하바위",
				[136047] = "얼음심장",
				[146113] = "천둥발굽",
				[149356] = "격노한 아제라이트보석 수정등",
				[157153] = "하리",
				[148451] = "자동공성로봇 9000",
				[148103] = "공병 오데트",
				[116668] = "영혼구속자 모르텍",
				[151916] = "제그라 샤프액스",
				[136048] = "군주 메르큐리어스",
				[149659] = "오웰 스티븐슨",
				[145077] = "공포날개",
				[50734] = "추적자 리시크",
				[82883] = "장군 녹틴",
				[149510] = "오웰 스티븐슨",
				[98241] = "리라스 문페더",
				[151917] = "타르알 본스피터",
				[136049] = "알게논",
				[86724] = "은둔자 창백가죽",
				[149358] = "거대한 아제라이트보석 수정등",
				[145063] = "폭풍부리",
				[134002] = "지하군주 제르직스",
				[146979] = "오르민 로켓밥",
				[151883] = "아나우아",
				[151918] = "북녘의 라즈카",
				[136050] = "핏빛기류",
				[149355] = "변종 아제라이트보석 수정등",
				[149359] = "아제라이트 거수",
				[152431] = "카넵티",
				[73160] = "무쇠가죽 강철뿔",
				[82755] = "야생의 붉은발톱",
				[126907] = "전쟁북장이 주룰라",
				[86213] = "아쿠아릴",
				[136051] = "파도머스",
				[140658] = "뾰족털",
				[149360] = "덩치 큰 아제라이트",
				[139000] = "늙은 유르",
				[116158] = "탑의 무희",
				[128699] = "피불룩이",
				[83990] = "태양 확대경",
				[160623] = "굶주린 독기",
				[140147] = "위대한 우르수",
				[140659] = "분노쿵쿵",
				[109504] = "분노아귀",
				[149873] = "스탠리",
				[73161] = "거대거북 분노등딱지",
				[159087] = "타락한 뼈갈이",
				[77768] = "원소술사 우트라",
				[145040] = "영리한 로린",
				[140148] = "광란의 회색털",
				[140660] = "거대뿔",
				[103223] = "헤르타 그림도티르",
				[145466] = "분쇄트론-2000",
				[116159] = "교활한 추종자",
				[145268] = "그림자발톱",
				[116671] = "잿불이",
				[144957] = "샬라이",
				[92613] = "여사제 리자",
				[140661] = "골짜기천둥",
				[93125] = "글럽글록",
				[77513] = "비탄에 잠긴 한기발굽",
				[144956] = "섬뜩이빨",
				[142709] = "야수기수 카마",
				[149663] = "그림자발톱",
				[148674] = "역병 전문가 허버트",
				[84926] = "불타는 힘",
				[140662] = "늙은 거대털",
				[145269] = "반짝가시",
				[87239] = "크랄 데드아이",
				[148147] = "오웰 스티븐슨",
				[149353] = "빛나는 아제라이트보석 수정등",
				[81406] = "바하메이",
				[145076] = "인르",
				[147758] = "오누",
				[140663] = "산의 제왕 그럼",
				[141175] = "노래 여군주 다달리아",
				[126142] = "바지아타",
				[73163] = "황실 비단뱀",
				[140769] = "황금광맥",
				[126910] = "사령관 제스가",
				[149147] = "알 도둑 느찰라",
				[149352] = "영롱한 아제라이트보석 수정등",
				[149354] = "기괴한 아제라이트보석 수정등",
				[145271] = "험악뿔",
				[162163] = "대사제 이태스시스",
				[83401] = "황천의 전령",
				[146675] = "하트포드 스턴바흐",
				[148155] = "머크럭",
				[124927] = "준티",
				[148343] = "공룡사냥꾼 와일드비어드",
				[149662] = "험악뿔",
				[145272] = "깜장발",
				[132578] = "크로쉐익스",
				[144952] = "고리송곳니",
				[138618] = "폭주 골렘",
				[86268] = "알칼리",
				[80190] = "그루크",
				[82877] = "대장군 볼라스",
				[86729] = "광포발굽",
				[50388] = "토릭에디스",
				[154076] = "복수심에 불타는 대지",
				[78144] = "거인사냥꾼 킴라",
				[73281] = "공포의 유령선 바주비어스호",
				[147321] = "맹독턱",
				[93372] = "분노한 대지하수인",
				[140155] = "광포한 썩은발톱",
				[135648] = "평원거죽 호랑이",
				[139017] = "거친갈기",
				[72909] = "무리인도자 구치",
				[90057] = "칼부리",
				[134112] = "대모 크리스티안",
				[126912] = "파멸의 스크리그",
				[98503] = "정복자 그릃븛굴",
				[140156] = "썩은아귀",
				[139471] = "육체파괴자 부간",
				[109195] = "영혼술사 할도라",
				[148717] = "심문관 에릭",
				[150394] = "무장한 금고봇",
				[142716] = "인간수집가 로그",
				[92574] = "내장을 가르는 쓰로마",
				[136304] = "여가수 나흐진",
				[140157] = "새끼포식자 썩은발톱",
				[101063] = "왕 포르갈라쉬",
				[82620] = "고라말의 아들",
				[85451] = "말고쉬 섀도우키퍼",
				[73166] = "괴물 가시집게",
				[142301] = "베노마루스",
				[126913] = "최후의 슬리쏜",
				[140160] = "분노의 끓는가죽",
				[140158] = "담즙에 젖은 썩은발톱",
				[148860] = "그리즈왈드",
				[140672] = "지저분한 먼지가죽",
				[120003] = "전쟁군주 다르자",
				[125479] = "타르 살포자",
				[146813] = "회색빛의 군터",
				[139135] = "심연의 아옳옳",
				[58474] = "피돌기",
				[140159] = "고름투성이 공포으르렁",
				[140671] = "난폭한 야생발톱",
				[145278] = "공룡술사 자쿠루",
				[162170] = "전쟁마법사 제쉬로",
				[73167] = "후오론",
				[75071] = "대모 옴라",
				[149886] = "스탠리",
				[151933] = "고장난 야수로봇",
				[70096] = "전쟁신 도카",
				[86732] = "벨그루",
				[63977] = "바이락시스",
				[162171] = "대장 듄워커",
				[139529] = "무클라이",
				[149343] = "광란이 주입된 아제라이트",
				[121029] = "무리어미 닉스",
				[151934] = "포획꾼 기계거미",
				[140161] = "모래구덩이꾼",
				[140673] = "분노으르렁",
				[140163] = "전쟁인도자 예나즈",
				[162172] = "아퀴르 전쟁마법사",
				[110024] = "타락자 말드레스",
				[77519] = "거인잡이",
				[135043] = "흉포한 톱니이빨",
				[69841] = "잔달라 전쟁인도자",
				[140162] = "증오의 와그작독침",
				[140674] = "깊은울음",
				[127939] = "영원의 토라스케",
				[162173] = "보잘것없는 알크록스",
				[154495] = "느조스의 의지",
				[128707] = "서리바위",
				[135044] = "게걸스러운 분쇄아귀 악어",
				[160126] = "배후자 이그소스",
				[152448] = "오색 반짝껍질",
				[161150] = "하급 호박석 정령",
				[135045] = "척추똑딱",
				[69842] = "잔달라 전쟁인도자",
				[73169] = "오르도의 자쿠르",
				[159103] = "배후자 쉬로글스",
				[77776] = "떠도는 구원자",
				[160127] = "암흑예언자 샤스굴",
				[135645] = "우두머리 무리어미",
				[140676] = "거대한 돌부리",
				[63978] = "크리촌",
				[139387] = "냉혈한 나사",
				[111021] = "수액 면상",
				[138629] = "성직자 드조사",
				[135046] = "엉금악어",
				[147222] = "놀탐식자",
				[129476] = "불어오른 크롤러스크",
				[146942] = "최고사령관 퓨리",
				[94413] = "망치 이셀",
				[138630] = "성직자 이자드",
				[73170] = "감시자 오수",
				[142725] = "끔찍한 원혼",
				[147332] = "바위결속자 스라베스",
				[69843] = "짜오초",
				[151940] = "트로그 삼촌",
				[121073] = "광기 어린 서큐버스",
				[139227] = "간수 운다리우스",
				[135644] = "여명추적자",
				[158594] = "파멸의 예언자 바시리스",
				[138631] = "길잡이 콰딤",
				[128965] = "구속된 우로쿠",
				[147845] = "사령관 드랄드",
				[137025] = "무리어미",
				[73171] = "검은 불꽃의 용사",
				[145286] = "모테가 블러드쉴드",
				[145287] = "센진의 준조",
				[158595] = "생각강탈자 보스",
				[102092] = "전쟁군주 바틸라쉬",
				[124722] = "준장 칼호운",
				[94414] = "키라니스 더스크위스퍼",
				[140168] = "늙은 가슴쾅",
				[140680] = "광포한 냉동뿔 웬디고",
				[91087] = "제텔엘",
				[149654] = "반짝가시",
				[83409] = "오피스",
				[138633] = "수사 마트",
				[139145] = "블랙쏜",
				[147928] = "대지파편",
				[140169] = "난폭한 모그카",
				[140681] = "게걸스러운 구루두",
				[149383] = "지즈 것섕크",
				[138634] = "예언자 라피사",
				[158597] = "고위집행관 요스림",
				[163204] = "[DNT] Vignette",
				[147260] = "컨플라그로스",
				[86582] = "모르고 케인",
				[140170] = "늙은 모카",
				[140682] = "빙하주먹",
				[100302] = "퍽",
				[115914] = "육중한 토름",
				[108715] = "늙은 얼리",
				[138635] = "사령관 후산",
				[50159] = "삼바스",
				[147849] = "비취섬광",
				[140171] = "안개털",
				[140683] = "부수는 자 어둠털",
				[148534] = "영원한 자 이브존",
				[144915] = "화염감시자 바이턴 다크플레어",
				[73173] = "소작술사 우르두르",
				[138636] = "왕자 아바리",
				[85970] = "학살발톱",
				[90164] = "전쟁인도자 목스나",
				[111052] = "은빛 뱀",
				[140684] = "분쇄쿵쿵",
				[82899] = "고대의 검귀",
				[95440] = "트렘블레이드",
				[96208] = "쥬베이토스",
				[138637] = "헤페트",
				[100303] = "제노비아",
				[148308] = "에릭 콰이엇피스트",
				[84435] = "핀치 아저씨",
				[140685] = "늙은뿔",
				[145292] = "알시안 비스트레스",
				[134106] = "벌목손아귀 파수병",
				[73174] = "화염의 대제사장",
				[138638] = "드자르",
				[131984] = "두 마음의 피조물",
				[149141] = "방화기 마크 V",
				[102863] = "우걱턱",
				[144855] = "연금술사 제로드",
				[86520] = "난폭발굽",
				[149241] = "얼라이언스 대장",
				[99792] = "엘프 학살자",
				[138639] = "아센누",
				[108494] = "영혼마귀 다게르마",
				[147853] = "벽파괴자 하비크",
				[92626] = "죽음경비병 아담스",
				[148563] = "혹한의 공작 부인 폴른송",
				[148264] = "공룡술사 다징고",
				[138640] = "토러스",
				[73175] = "잿불폭포",
				[77526] = "정찰병 고어시커",
				[139152] = "칼라 스머크",
				[147854] = "칼춤꾼 졸라크",
				[105899] = "격노의 오글록",
				[69769] = "잔달라 전쟁인도자",
				[148642] = "짐마차 우두머리",
				[120012] = "드레사노스",
				[149349] = "석회화된 아제라이트",
				[147957] = "아제크리살리스",
				[96210] = "칼날의 크롤",
				[140975] = "어린위장",
				[92627] = "렌드락",
				[148787] = "알라쉬아니르",
				[140369] = "지하수색자",
				[50086] = "비열한 타르부스",
				[62880] = "무쇠주먹 고차오",
				[77527] = "으깨주먹",
				[50359] = "어골락스",
				[139666] = "토템 신봉자 올그를",
				[111055] = "기괴한 역병 쥐",
				[139667] = "예언자 그를글록",
				[136819] = "감독관 쥐꼬리",
				[120013] = "공포의 추적자",
				[147857] = "대포전문가 아를린",
				[77561] = "글룸 박사",
				[152464] = "어둠동굴 공포",
				[121037] = "그로시르",
				[125388] = "배신당한 자 바가스",
				[147858] = "배 없는 지미",
				[129995] = "에밀리 메이빌",
				[152465] = "바늘가시",
				[139044] = "물결치유사 아샤",
				[142739] = "기사대장 알드린",
				[77784] = "로마그 죠크러셔",
				[139668] = "파도결속사 고르글",
				[140180] = "난폭핏물",
				[140692] = "피구렁이",
				[91093] = "지옥가시덩굴",
				[130508] = "무리어미 라조라",
				[133527] = "흉터 입은 쥬바",
				[147860] = "토러스",
				[92117] = "피부리",
				[139669] = "주술사 가르믈",
				[140181] = "험준엄니",
				[140693] = "쉬익카라스",
				[84951] = "꿀꺽이빨",
				[122062] = "카뮬 클라우드송",
				[105938] = "지옥날개",
				[77529] = "소각술사 야즈히라",
				[140694] = "탐욕의 우걱턱",
				[139670] = "모옳곡",
				[140182] = "밀림지진 나뭇잎납작이",
				[86743] = "데콜한",
				[131262] = "무리 우두머리 아세냐",
				[139672] = "쫑알지느러미",
				[148154] = "아가테 웜우드",
				[138647] = "히아나 포그브링어",
				[128973] = "성질 나쁜 워가블",
				[139671] = "상어학살자 머글룩",
				[140183] = "늙은 똥가죽",
				[140695] = "백색 공포의 송곳니",
				[103154] = "하티",
				[154005] = "검은 주먹 헤이미르",
				[93654] = "스컬브락스",
				[138648] = "수의작공 시그리드",
				[126926] = "맹독턱",
				[123087] = "알아바스",
				[72156] = "포식자 보로크",
				[140696] = "공포의 나주",
				[161683] = "안탁샬",
				[74971] = "화염격노 거인",
				[68317] = "메이비스 함즈",
				[138649] = "벌프 스톰쇼어",
				[128974] = "여왕 츠시키크",
				[139673] = "이빨많록",
				[92631] = "어둠 순찰자 제스",
				[101077] = "세칸",
				[138513] = "바이란티온",
				[162196] = "흑요석 파멸자",
				[147864] = "쉬익카라스",
				[89816] = "무쇠 지느러미 골자",
				[139674] = "심연비늘",
				[118993] = "공포눈",
				[140100] = "전쟁주둥이",
				[139322] = "휘트니 \"철발톱\" 람세이",
				[50789] = "예언자 네소스",
				[154007] = "옥텔 드래곤블러드",
				[107431] = "무기화한 로봇토끼",
				[138651] = "실베리아 리프콜러",
				[143314] = "숲의 파멸자",
				[139675] = "심연수색자",
				[124362] = "쥬에",
				[68318] = "달란 나이트브레이커",
				[50992] = "고로크",
				[162198] = "흑요석 파멸자",
				[139676] = "파도예언자 옮르그",
				[150937] = "바다모래톱",
				[123189] = "전쟁인도자 모그라",
				[147866] = "피의 탐식자",
				[86577] = "홀그",
				[108881] = "거북",
				[107477] = "기계다람쥐",
				[100223] = "브리쿨 대지창조자 영혼",
				[143313] = "포타킬로",
				[138653] = "부패하는 선체의 호스비르",
				[145308] = "선임하사 스틸팽",
				[139677] = "심연소환사",
				[92633] = "암살자 휴위",
				[68319] = "디샤 피어워든",
				[157593] = "살덩어리의 융합체",
				[93401] = "약탈자 우르게브",
				[87600] = "평화주의자 잘루크",
				[146844] = "계악자 올프크리그",
				[71864] = "스페럴크",
				[139678] = "여울방랑자",
				[74206] = "살육아귀",
				[147869] = "수의작공 시그리드",
				[111573] = "굶주리는 코수모스",
				[120019] = "희미한 자 률",
				[134048] = "부쿠바",
				[146845] = "톱니의 자레드",
				[142436] = "분노부리",
				[139679] = "앓그를",
				[92634] = "연금술사 페레즈",
				[68320] = "그늘의 우분티",
				[136875] = "무역상 우두",
				[90429] = "임프소환사 발레사",
				[141615] = "불타는 거수",
				[147870] = "파도저주 여군주",
				[123282] = "전쟁군주 모고쉬",
				[139680] = "어두컴컴 사냥꾼",
				[123347] = "대지술사 말란",
				[140982] = "얼음파괴자",
				[140392] = "천굴 공포딱정벌레",
				[120020] = "에르두발",
				[150430] = "너두호그",
				[146847] = "소환사 라니엘라",
				[100224] = "브리쿨 대지여전사 영혼",
				[139681] = "싸늘지느러미",
				[109015] = "라제르타",
				[68321] = "카르 워메이커",
				[73172] = "바위군주 가이란",
				[133539] = "로쿠노",
				[126419] = "나로우아",
				[146848] = "으스스한 융합체",
				[84746] = "사로잡힌 고르보쉬 바위구체자",
				[147872] = "여왕거미 빌틸락",
				[106532] = "심문관 볼리틱스",
				[161181] = "[DNT] Vignette Marker",
				[91100] = "브로고조그",
				[145825] = "짐마차 우두머리",
				[99802] = "아르스파엘",
				[146849] = "영혼의 대가 로웨나",
				[50805] = "옴니스 그린록",
				[147873] = "여왕거미 신드릭스",
				[92636] = "밤의 유령",
				[68322] = "무에르타",
				[50816] = "루운 고스트포우",
				[158111] = "도전장교",
				[109692] = "리데론",
				[146850] = "거장 울리치",
				[98178] = "아랫바위",
				[135589] = "괴저 흉물",
				[108541] = "공포의 해적",
				[127700] = "편대 사령관 비샥스",
				[82058] = "깊은뿌리",
				[120022] = "심연아귀",
				[134794] = "어둠잠복",
				[85001] = "정예근위병 밀그라",
				[149512] = "그림자발톱",
				[121046] = "수사 배다틴",
				[132007] = "광포폭풍",
				[91098] = "지옥불꽃",
				[139411] = "우글송곳니",
				[82676] = "에나브라",
				[148428] = "담즙발",
				[146852] = "노예사냥꾼 콘라드",
				[98268] = "타르벤",
				[54318] = "안카",
				[135719] = "그늘길잡이",
				[134912] = "보라색 땅거미",
				[82912] = "회색아귀",
				[128893] = "빈예티",
				[146853] = "파헤쳐진 케폴키스",
				[83680] = "척후병 듀레사",
				[139321] = "브래단 화이트월",
				[147877] = "거장 울리치",
				[92423] = "테리시아",
				[80372] = "에키드나",
				[86410] = "실드로스",
				[50806] = "애꾸눈 몰도",
				[110367] = "엘디스",
				[146854] = "스텔라 다크포우",
				[142683] = "루울 원스톤",
				[147878] = "파헤쳐진 케폴키스",
				[148390] = "제시벨 문쉴드",
				[123001] = "암흑의 물 정령",
				[108251] = "덩어리불의 지배자 셀리아",
				[124375] = "속이 꽉 찬 사우로리스크",
				[116185] = "수행원 관리자",
				[146855] = "아키나",
				[134932] = "썩은그물 무리여왕",
				[116953] = "타락한 뼈파괴자",
				[134821] = "썩은응시 돌바실리스크",
				[84431] = "교활한 그렐드록",
				[82988] = "쿨로쉬 둠팽",
				[89865] = "파도를 가르는 자 아옳옳옳",
				[103214] = "만족할 줄 모르는 하르케스",
				[134571] = "하늘소환사 테스크리스",
				[77795] = "울림의 메아리",
				[147880] = "영혼수색자 다르걸프",
				[105632] = "여왕 슈말리스",
				[127703] = "파멸술사 수프락스",
				[141226] = "망치의 헤이골",
				[139815] = "부사장 랙스 블라스템",
				[121049] = "재앙의 기사대장",
				[138667] = "파멸의 흉물",
				[140098] = "흉포한 흉터가죽",
				[147881] = "선견자 우불드",
				[148393] = "고대 수호정령",
				[153000] = "불꽃여왕 전파거미",
				[107266] = "사령관 소락스",
				[121112] = "흐릿한 여명",
				[142251] = "요구르사",
				[127776] = "비늘발톱 무리어미",
				[90081] = "암흑의 소환사 렌드크라",
				[138824] = "할피드 아이언아이",
				[100230] = "\"명사수\" 아르니",
				[127704] = "영혼치유사 비덱스",
				[96647] = "야수살육자 얼노크",
				[126868] = "또렷한 의식의 투레크",
				[158632] = "타락한 살덩이괴물",
				[83683] = "만드라고라스터",
				[132076] = "토테스",
				[152007] = "살해톱",
				[115226] = "라베니안",
				[140981] = "이빨 가는 공포",
				[80868] = "먹보",
				[97504] = "망령발톱",
				[158633] = "느조스의 시선",
				[100231] = "다르고크 썬더루인",
				[92887] = "무쇠주둥이",
				[139694] = "냉혹껍질",
				[111069] = "사에퍼",
				[127705] = "대모 로줄라",
				[82778] = "광적인 옹이발굽",
				[154490] = "포식자 라이즈스",
				[83428] = "바람소환사 코라스트",
				[91874] = "칼날돌풍",
				[160708] = "우편 우적이",
				[84196] = "거미줄에 뒤덮인 병사",
				[119629] = "군주 헬누라스",
				[121108] = "파멸의 거대마귀",
				[75492] = "맹독그늘",
				[50808] = "걷는 자 우로비",
				[85029] = "어둠예언자 니르",
				[138477] = "갈퀴수호병 브리키스",
				[139809] = "투자회사 인수 전문가",
				[133042] = "하늘 치안대장 가브리엘",
				[126815] = "영혼이 뒤틀린 흉물",
				[127706] = "현자 레지라",
				[107487] = "별사슴",
				[137649] = "살충기 마크 II",
				[79334] = "노로쉬",
				[108255] = "비전술의 여제 쿠라",
				[134795] = "장막의 은둔자 게",
				[139697] = "고위주술사 클락시카르",
				[77715] = "망치이빨",
				[80614] = "칼춤꾼 에이릭스",
				[133043] = "대장군 볼라스",
				[138863] = "자매 마사",
				[126427] = "나뭇가지군주 알드루스",
				[91788] = "껍질아귀",
				[73704] = "구린수염",
				[139698] = "점쟁이 클래터크로",
				[106526] = "여군주 리반타스",
				[142437] = "두개골절단자",
				[133044] = "최고사령관 트렘블레이드",
				[108256] = "서리바람의 지배자 퀸엘",
				[84838] = "독의 대가 볼터스크",
				[155055] = "벌집도둑 거르그",
				[125820] = "임프 어미 라글라스",
				[91871] = "파괴자 아르고쉬",
				[136046] = "군주 어비시안",
				[117470] = "시바쉬",
				[137140] = "큰덩치 돌진자",
				[108010] = "화약장인 마크린",
				[116395] = "밤샘 풍수사",
				[81639] = "가시왕 필리",
				[139188] = "무쇠가죽",
				[139700] = "바닷물비늘 바다 주술사",
				[92703] = "지옥어귀 약탈자",
				[161199] = "금고지기 자즈라",
				[95204] = "곤봉꾼 아웁돕",
				[121088] = "뒤틀린 공허군주",
				[92657] = "피눈물 공포전사",
				[100067] = "히드라논",
				[139189] = "고대의 벌목발톱",
				[139701] = "바닷물비늘 수련 점쟁이",
				[92645] = "밤의 유령",
				[109281] = "말리산드라",
				[109318] = "룬의 현자 시그비드",
				[90094] = "항만관리자 코라크",
				[146884] = "전쟁군주 혤슈카르트",
				[126040] = "푸실라",
				[139190] = "재빠른 가지도약꾼",
				[63695] = "불태우는 자 바오라이",
				[83603] = "사냥꾼 블랙투스",
				[111329] = "대모 하가사",
				[82920] = "군주 코리낙",
				[155059] = "젤리먹보 요라그",
				[139027] = "초승달 점쟁이",
				[146869] = "맹독의 자이룸",
				[139191] = "덤불랑이",
				[156083] = "핏빛 송곳니",
				[132088] = "선장 윈터세일",
				[96997] = "케스라조르",
				[141239] = "피범벅 오스카",
				[138485] = "실험가 누조리악",
				[110562] = "바하가르",
				[146870] = "역술사 오나재",
				[90087] = "강철 대장 아르가",
				[138997] = "광기의 그르렁채찍",
				[140436] = "킁킁발굽",
				[88210] = "적출자 크루드",
				[135722] = "황혼 배회자",
				[111057] = "쥐들의 왕",
				[152001] = "뼈다귀청소부",
				[146871] = "여군주 나스나야",
				[140389] = "굴지기 키닉스",
				[121056] = "기괴한 공포수호병",
				[92647] = "지옥기술자 다모르카",
				[107657] = "비전술사 샬이만",
				[77620] = "크로 플레쉬렌더",
				[139025] = "달빛노래",
				[70430] = "공포의 바위",
				[146872] = "추방당한 카초타",
				[90088] = "오르마크 블러드볼트",
				[139043] = "물결잡이 오초",
				[136340] = "유물사냥꾼 하자아크",
				[140797] = "시체수확자",
				[82922] = "파괴자 조티어",
				[71665] = "거인학살자 쿨",
				[139023] = "야생의 피아귀",
				[146873] = "흉악한 폭풍우 정령",
				[155583] = "고철집게발",
				[147897] = "음험한 소고스",
				[138650] = "파도잠식 용사",
				[144826] = "인간탐식자",
				[138652] = "파도저주 여군주",
				[50811] = "나스라 스팟하이드",
				[126432] = "요동치는 거수",
				[146874] = "바람소환사 마리아",
				[90089] = "그롭톡 스컬브레이커",
				[70126] = "윌리 와일더",
				[82411] = "어둠발톱",
				[144827] = "늪트림꾼",
				[91113] = "파도 거수",
				[146875] = "흉포한 발리모크",
				[69664] = "뭄타",
				[83691] = "판토라",
				[98276] = "펜리",
				[146880] = "수수께끼의 골브란",
				[140800] = "살해약탈 구름날개",
				[139884] = "예언자 둠라",
				[130016] = "에밀리 메이빌",
				[140454] = "늙은 땋은머리",
				[131520] = "고약한 컬렛",
				[98024] = "알먹보 루굿",
				[87019] = "걸신들린 거인",
				[151995] = "감독관 히크텐",
				[86750] = "칠흑발톱",
				[144829] = "천둥꺼비",
				[91114] = "파도 거수",
				[122606] = "하늘빛나래",
				[142741] = "파멸기수 헬그림",
				[139695] = "잽잽집게",
				[88043] = "소크레타르의 화신",
				[71919] = "시큼한 주곤",
				[138307] = "와장창면상",
				[144830] = "포식자 야자",
				[131687] = "탐바노",
				[125232] = "대장 무칼라",
				[118244] = "번개발",
				[134904] = "밤배회거미",
				[126946] = "심문관 베스로즈",
				[133531] = "주바",
				[134924] = "Taloc IGC",
				[144831] = "거대 쟁기발개구리",
				[91115] = "파도 거수",
				[137665] = "영혼 골리앗",
				[138998] = "두껍가죽",
				[87788] = "둘그 스파인크러셔",
				[98199] = "푸그",
				[90139] = "심문관 에른스텐보크",
				[82207] = "오색날개",
				[146876] = "야만적인 마치투",
				[140088] = "돌진사슴 돌뿔",
				[82975] = "덥석니",
				[151686] = "도둑 약삭발이",
				[126691] = "티라노사우루스 렉스",
				[134754] = "효기",
				[120583] = "탄오탈리온",
				[139389] = "강철비늘 볼샤시스",
				[144833] = "찰싹혀",
				[140332] = "깔짝파개",
				[92140] = "무성한 만드라고라",
				[154559] = "심연군주 지리즈",
				[146881] = "예언자 브린불프",
				[96235] = "제미르콜",
				[139042] = "창의 달인 카샤이",
				[138851] = "영혼 사냥꾼",
				[135723] = "달발톱",
				[139194] = "부패아귀",
				[90782] = "라스더",
				[84925] = "병참장교 허샤크",
				[146882] = "거대한 황폐사냥개",
				[98283] = "드라쿰",
				[110824] = "파도집게",
				[82415] = "신리",
				[157120] = "송곳니갈취자 오르사",
				[139026] = "월식소환사",
				[108822] = "여사냥꾼 에스트리드",
				[85907] = "벨소라",
				[146883] = "사냥개조련사 앵그볼드",
				[139205] = "P4-N73R4",
				[97933] = "게 기수 우옳옳",
				[140063] = "식인 박살아귀",
				[110486] = "전문사냥꾼 헉로스",
				[137158] = "속박된 번개 정령",
				[126181] = "어둠의 라무트",
				[117093] = "지옥소환사 자르토크",
				[130788] = "타기라",
				[98284] = "곤다르",
				[71721] = "협곡 얼음어미",
				[148403] = "차원문 수호자 로미르",
				[135925] = "화염불꽃",
				[134088] = "자이발란 포식자",
				[91374] = "포들링군주 와카왐",
				[150468] = "보르코스",
				[146885] = "구린절규",
				[135997] = "군주 지르콘",
				[123464] = "자매 서브버시아",
				[138675] = "포식한 멧돼지",
				[92751] = "상아 파수꾼",
				[93166] = "실성한 팁톡",
				[97517] = "공포수렁",
				[156078] = "학자 레흘레스",
				[146886] = "악취나는 흐롤슈칼트",
				[98285] = "스매셤 그랩",
				[117141] = "말그라조스",
				[158636] = "대집행관",
				[80370] = "렐니아",
				[50363] = "크락시크",
				[94113] = "룩크마즈",
				[140974] = "왕꿀꺽이",
				[146887] = "썩은 자 게른",
				[126866] = "감시자 쿠로",
				[121051] = "불안정한 심연불정령",
				[84465] = "껑충 고렌",
				[134950] = "공포의 송곳니",
				[136990] = "저주받은 안칼리",
				[84904] = "오라그로",
				[93679] = "정복자 가테나크",
				[126169] = "밀림의 왕 룬투",
				[139210] = "맹독대두",
				[86257] = "바스텐",
				[127820] = "정찰병 스크라스니스",
				[84775] = "부서진 테스카",
				[82930] = "암흑불길 공포인도자",
				[119103] = "칠흑의 집행자",
				[139041] = "정령사 루슈",
				[149335] = "격동의 아제라이트",
				[139211] = "영원만개",
				[127289] = "사우로리스크 조련사 머그",
				[80371] = "티폰",
				[139038] = "카이후",
				[93168] = "지옥바위",
				[50815] = "스카르",
				[92040] = "펜리",
				[130791] = "쿠트인",
				[139212] = "포도채찍",
				[86258] = "눌트라",
				[148146] = "인간사냥꾼 줄아키",
				[90888] = "드리브눌",
				[87026] = "기계 약탈자",
				[92552] = "벨고르크",
				[50749] = "역병의 칼티크",
				[119000] = "공포수염",
				[139213] = "열매쿵",
				[101596] = "그슬린깃털",
				[132047] = "강화된 선체파괴자",
				[140697] = "썩은 독뱀",
				[100516] = "굶주린 릴린",
				[122090] = "약탈자 사라샤스",
				[111007] = "란드릴",
				[103203] = "바다 부랑자",
				[122838] = "흑마술사 보룬",
				[86259] = "발스틸",
				[106990] = "쓴소금물 족장",
				[86771] = "잔혹한 가그로그",
				[87027] = "어둠의 거한",
				[123293] = "제왕 모래 게",
				[139817] = "선임기술자 제지",
				[142419] = "우레의 거수",
				[104484] = "선박파괴자 올로크",
				[140330] = "해골딸깍이",
				[96212] = "코르다 토로스",
				[105739] = "사나아르",
				[139819] = "부사장 젠니 뉴콤",
				[63101] = "장군 테무자",
				[156451] = "암흑예언자 툴그쉬",
				[120021] = "물풀주먹",
				[143311] = "사악독버섯",
				[97449] = "뾰족털 망치발",
				[50340] = "독기 어린 가른",
				[88494] = "군단 선봉대원",
				[91780] = "어미 딸깍이",
				[137681] = "왕 딸깍똑딱",
				[131410] = "거대 맹독비늘",
				[84856] = "역병포자",
				[139217] = "늙은 막핀나무",
				[121068] = "불안정한 임프",
				[137059] = "머리사냥꾼 가하",
				[136838] = "야만전사 즈고르도",
				[122911] = "사령관 베카야",
				[126187] = "시체인도자 얄카르",
				[138654] = "누더기 돛의 베스타르",
				[84955] = "포자먹보 지아스카",
				[139218] = "생명지기 올바리우스",
				[97209] = "에라키스",
				[132052] = "볼짐",
				[157134] = "네 바람의 이샤크",
				[127333] = "미늘가시 여왕",
				[51059] = "블랙후프",
				[108016] = "강령마법사 톨드레다르",
				[91892] = "영주 무자비한 이르글로브",
				[139219] = "나시라 모닝프로스트",
				[131717] = "생명갈취자 자욜린",
				[140851] = "크라그",
				[59369] = "의사 테올렌 크라스티노브",
				[122958] = "물집아귀",
				[50817] = "방랑자 아혼",
				[154576] = "아퀴르 괴수",
				[154006] = "예언자 리타스",
				[139220] = "바이야 크리스탈블룸",
				[110832] = "고르그로스",
				[92591] = "싱커",
				[86774] = "아오겍손",
				[147862] = "아센누",
				[75482] = "벨로스",
				[124397] = "칼드락사",
				[95988] = "덩어리",
				[143316] = "해골모자",
				[147923] = "기사대장 조시프",
				[134947] = "뻣뻣가시 무리여왕",
				[140757] = "포즈루크",
				[85555] = "나기드나",
				[109054] = "샬안",
				[154578] = "아퀴르 갈퀴손",
				[89846] = "대장 볼로렌",
				[110577] = "흉측한 오레스",
				[147924] = "대지조각",
				[148037] = "아실 듀파이어",
				[131476] = "자유스",
				[95221] = "광기의 헨릭",
				[157279] = "폭풍포효",
				[89906] = "빈예티",
				[138308] = "우끼아끼",
				[129005] = "왕 쿠바",
				[148075] = "야수 조련사 왓킨스",
				[148477] = "야수군주 드라카라",
				[82486] = "탐험가 노잔드",
				[92977] = "강철 사냥개조련사",
				[148253] = "죽음경비대장 데세카",
				[93686] = "꿰뚫는 자 지니키",
				[146238] = "검은쐐기",
				[77626] = "무리어미 하미",
				[151948] = "긍지아비 센부",
				[140248] = "재빠른 달추적자",
				[140760] = "대지생명 거인",
				[155531] = "감염된 사막유랑단 대장",
				[118192] = "노르고르",
				[124399] = "감염된 공포뿔",
				[148550] = "짐마차 우두머리",
				[108531] = "공포의 유령선 크라자토아호",
				[80122] = "가즈올다",
				[140249] = "점판가죽",
				[116008] = "카르준",
				[124580] = "동굴 거북",
				[120998] = "플루르로크르",
				[128951] = "네즈아라",
				[147958] = "대지활성 굴절체",
				[139226] = "자매 아나나",
				[135643] = "렌키리",
				[130138] = "네버모어",
				[58778] = "애타",
				[138632] = "수호자 아수다",
				[145465] = "기술자 볼트홀드",
				[91640] = "빈예티",
				[50051] = "유령게",
				[92152] = "하얀물 태풍",
				[92408] = "영생의 잔지스",
				[124582] = "협곡사냥꾼",
				[140763] = "설언덕 거인",
				[92725] = "피머리의 아들",
				[154072] = "만족할 줄 모르는 보그레스",
				[134109] = "지배당한 히드라",
				[122609] = "자비녹스",
				[148031] = "그렌 토른퍼",
				[86266] = "베놀라식스",
				[140252] = "우박 피조물",
				[140764] = "용암 거인",
				[140675] = "무리어미 무고",
				[116166] = "구르그의 눈",
				[146816] = "바튼 브릭햄 경",
				[149887] = "스탠리",
				[139229] = "알루나 리프시스터",
				[135646] = "분쇄의 피얼룩 호랑이",
				[148862] = "질리 운더렌치",
				[140765] = "요동치는 거수",
				[147061] = "그럽",
				[149344] = "광란이 주입된 아제라이트",
				[126449] = "모래토쟁이",
				[89850] = "예언자",
				[97589] = "썩은 알",
				[135647] = "이투아키",
				[138567] = "응징자 샤스호스",
				[157146] = "부패탐식자",
				[137183] = "꿀 발린 뱀장어",
				[160631] = "굶주린 독기",
				[128497] = "궤변론자 바지아니",
				[100864] = "코라카르",
				[139231] = "짓밟는 마이어우드",
				[108790] = "무리어미 이르바",
				[145934] = "미치광이 아이반",
				[131404] = "현장감독 스크립스",
				[117096] = "물약의 달인 글룹",
				[50820] = "율 와일드포우",
				[77310] = "미친 \"왕\" 스포리온",
				[134625] = "전쟁어미 포로",
				[148723] = "저격수 매독",
				[135649] = "질풍발톱",
				[148446] = "늑대우두머리 스크로그",
				[140768] = "태산파괴자 구우루",
				[87356] = "고대의 브록",
				[135994] = "군주 아미타이트",
				[50347] = "암흑의 인도자 카르",
				[149657] = "맛간깃털",
				[139233] = "걸리버",
				[92411] = "대군주 마그루스",
				[152542] = "비늘 여군주 조디아",
				[117493] = "그림토템 전사",
				[151684] = "턱파괴자",
				[97593] = "발톱비명 민타",
				[126451] = "아작집게",
				[116912] = "모아그 투사",
				[138387] = "망골",
				[146246] = "독벌 오빅스",
				[132068] = "바쉬무",
				[132580] = "신크릭스",
				[82942] = "여군주 뎀라쉬",
				[84417] = "무타펜",
				[97220] = "아루",
				[148739] = "마법학자 크리스탈린",
				[139235] = "거북턱",
				[121077] = "희미한 지옥사냥꾼",
				[72193] = "카르카노스",
				[126908] = "다중인격의 줄탄",
				[145250] = "맛간깃털",
				[50821] = "아이리 스카이미러",
				[82374] = "라이보쉬",
				[132182] = "회계 감사관 돌프",
				[98299] = "탐욕스러운 보다쉬",
				[92611] = "잠복꾼 단도엄니",
				[152545] = "비늘 여군주 바이나라",
				[134800] = "강화된 무쇠턱거북",
				[149346] = "퍼진 아제라이트",
				[79104] = "얼어붙은 우글로크",
				[131233] = "레이즈",
				[78150] = "야수조각사 사라모르",
				[84805] = "바위눈길",
				[104698] = "콜레리안",
				[117239] = "브루탈루스",
				[140773] = "깊은바다 파도잡이",
				[145242] = "비늘마귀",
				[136841] = "추악한 쑤준",
				[138388] = "컹",
				[145062] = "쉬샤린",
				[82247] = "나스 던블린",
				[120899] = "쿨크라잔",
				[120713] = "와글루르",
				[132584] = "자르셰지",
				[141286] = "밀렵꾼 제인",
				[139415] = "뱀비늘",
				[146134] = "날쌘돌이",
				[131704] = "코아티",
				[96323] = "아라크니스",
				[108794] = "장막수색꾼의 그림자",
				[54533] = "왕자 라크마",
				[79692] = "은빛잎새 고대정령",
				[153314] = "알드란티스",
				[50822] = "변화하는 구름의 아이란",
				[85504] = "마귀버섯",
				[51078] = "퍼디난드",
				[54319] = "마그리아",
				[147942] = "황혼의 예언자 그래미",
				[109630] = "이몰리안",
				[139875] = "동굴 과부거미",
				[151689] = "도약꾼 할퀴발톱",
				[131735] = "현자 이데지",
				[142312] = "두개골절단자",
				[83713] = "티타루스",
				[93001] = "뒤틀린 스지레크",
				[96072] = "두르구스",
				[155333] = "고동치는 아제라이트 정동석",
				[140777] = "보석파편 거인",
				[148295] = "부패한 이부스",
				[126199] = "브락스툴",
				[104519] = "콜레리안",
				[136893] = "지면진동자 아간",
				[154968] = "무장한 금고봇",
				[150191] = "아바리우스",
				[140266] = "고대의 부서진뿔",
				[107846] = "검을들고덤비게",
				[148494] = "모래결속사 소디르",
				[154087] = "무한의 즈로룸",
				[95053] = "죽음갈퀴",
				[92495] = "영혼절개자",
				[152570] = "광기 어린 트로그",
				[139755] = "일등항해사 맥넬리",
				[140267] = "거대뿔 우와누",
				[50823] = "포악 군",
				[95054] = "복수",
				[137708] = "돌 골렘",
				[154600] = "깨어난 자 텐그",
				[134637] = "인간사냥꾼 리자",
				[77828] = "울림의 메아리",
				[139756] = "자객 쉴라",
				[140268] = "숲지기 아노",
				[157160] = "사냥개군주 렌",
				[151845] = "부관 느오트",
				[154089] = "야수살육자 루딘",
				[91649] = "여왕벌 즈살라",
				[134638] = "전쟁군주 조딕스",
				[112636] = "사악한 지맥질주마",
				[139757] = "확인사살 존슨",
				[140269] = "울루테일",
				[132591] = "미치광이 오그모트",
				[151702] = "파올 폰드웨이더",
				[154148] = "해일여제 레스신드라",
				[152360] = "우두머리 맹독이빨",
				[85763] = "저주받은 칼날발톱",
				[153296] = "폭풍혓바닥 샬란알리",
				[139758] = "총알둘 애니",
				[140270] = "야생사슴",
				[157162] = "레이 룬",
				[151862] = "영혼방랑자 페살",
				[148679] = "비전술사 퀸트릴",
				[155811] = "사령관 민제라",
				[136888] = "흙예언자 바룰",
				[112637] = "악마의 태양질주마",
				[139759] = "반란자 잘리아",
				[140271] = "절단뿔",
				[153304] = "운다나 프로스트바브",
				[115537] = "로르탈륨",
				[152671] = "웨케마라",
				[97793] = "불꽃비늘",
				[154949] = "잔지르 야만전사",
				[136852] = "가마솥지기 오도",
				[139760] = "선임 항해사 프랭클린",
				[140272] = "숲성큼걸이",
				[157164] = "광신도 테켐",
				[145391] = "짐마차 우두머리",
				[140091] = "눈송이발굽",
				[158284] = "크래글 워블톱",
				[147951] = "알칼리니우스",
				[108543] = "공포의 선장 테돈",
				[139761] = "부두주임 오루어크",
				[88580] = "화마 그라쉬",
				[158531] = "타락한 네페르세트 경비병",
				[145392] = "대사 게인스",
				[105728] = "낫의 달인 실라만",
				[142321] = "분노부리",
				[134643] = "전사 블옳를옳",
				[80235] = "구룬",
				[139762] = "청소부 페이스",
				[156654] = "파멸예언자 숄소스",
				[90884] = "투척자 빌코르",
				[161463] = "심연소환사 벨셴",
				[161451] = "배후자 야사스",
				[124412] = "사냥개몰이꾼 오록스",
				[160906] = "스카이버",
				[86579] = "검귀 로고르",
				[139763] = "대포전문가 아를린",
				[156655] = "학살자 코르자란",
				[157167] = "용사 센마트",
				[131252] = "메리아나이",
				[160922] = "쐐기병 저살라",
				[126460] = "오염된 수호자",
				[85766] = "저주받은 뾰족발톱",
				[127581] = "다면의 포식자",
				[139764] = "커틀라스꾼 제임",
				[132086] = "검은 눈의 바트",
				[90885] = "추적자 로곤드",
				[145395] = "카트리아나",
				[157183] = "응고된 령",
				[156820] = "도드",
				[148025] = "사령관 랄에쉬",
				[154192] = "날카로운 눈의 감시자",
				[139765] = "배 없는 지미",
				[88582] = "날쌘 칠흑색 칼날발톱",
				[154328] = "온전한 물방울",
				[87666] = "무그라",
				[72970] = "골가나르",
				[163357] = "[DNT] Vignette",
				[136410] = "테드 슈메이커",
			},
		},
		["dbversion"] = {
			{
				["locale"] = "koKR",
				["version"] = 8,
			}, -- [1]
		},
		["recentlySeen"] = {
		},
		["containers_reseteable"] = {
			[291264] = true,
			[284413] = true,
			[291257] = true,
			[291265] = true,
			[291211] = true,
			[291266] = true,
			[275076] = true,
			[291204] = true,
			[284469] = true,
			[279378] = true,
			[291227] = true,
			[291267] = true,
			[291213] = true,
			[279379] = true,
			[291229] = true,
			[291201] = true,
			[291224] = true,
			[291222] = true,
			[273918] = true,
			[273955] = true,
			[273956] = true,
			[291223] = true,
			[291254] = true,
			[275071] = true,
			[282722] = true,
			[291255] = true,
			[291263] = true,
			[273900] = true,
			[291217] = true,
			[275074] = true,
			[273905] = true,
		},
		["rares_found"] = {
			[149356] = {
				["mapID"] = 981,
				["artID"] = 981,
				["coordY"] = 0.3396188616752625,
				["coordX"] = 0.5591546893119812,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569425959,
			},
			[152553] = {
				["mapID"] = 1355,
				["coordY"] = 0.332854688167572,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3227439522743225,
				["artID"] = 1186,
				["foundTime"] = 1577376737,
			},
			[152681] = {
				["mapID"] = 1355,
				["coordY"] = 0.8794395923614502,
				["foundTime"] = 1577375647,
				["coordX"] = 0.4304642081260681,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[138487] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569931913,
				["coordX"] = 0.4859040975570679,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4102242588996887,
			},
			[273905] = {
				["mapID"] = 895,
				["coordY"] = 0.2835392951965332,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3722277283668518,
				["artID"] = 920,
				["foundTime"] = 1572129871,
			},
			[138871] = {
				["mapID"] = 896,
				["artID"] = 921,
				["foundTime"] = 1570553330,
				["coordX"] = 0.24200001,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.218,
			},
			[135930] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3136339783668518,
				["coordX"] = 0.6644870638847351,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572646873,
			},
			[152682] = {
				["mapID"] = 1355,
				["coordY"] = 0.7552899718284607,
				["foundTime"] = 1569675212,
				["coordX"] = 0.4299296736717224,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[133373] = {
				["mapID"] = 863,
				["coordY"] = 0.5189148783683777,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4517753124237061,
				["artID"] = 888,
				["foundTime"] = 1573360873,
			},
			[135931] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582731,
				["coordX"] = 0.483020007610321,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.595107913017273,
			},
			[127939] = {
				["mapID"] = 862,
				["coordY"] = 0.652100145816803,
				["foundTime"] = 1579711127,
				["coordX"] = 0.4660052955150604,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[152555] = {
				["mapID"] = 1355,
				["coordY"] = 0.7544835209846497,
				["foundTime"] = 1564802876,
				["coordX"] = 0.5207043886184692,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[151916] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.5367255210876465,
				["coordX"] = 0.7640135288238525,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567343526,
			},
			[149359] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.550769567489624,
				["coordX"] = 0.4259355068206787,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925980,
			},
			[156648] = {
				["mapID"] = 1527,
				["coordY"] = 0.4710197746753693,
				["foundTime"] = 1579284161,
				["coordX"] = 0.6137528419494629,
				["artID"] = 1343,
				["atlasName"] = "VignetteEvent",
			},
			[139385] = {
				["mapID"] = 942,
				["coordY"] = 0.5123838186264038,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5281391143798828,
				["artID"] = 967,
				["foundTime"] = 1573732989,
			},
			[151917] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568818537,
				["coordX"] = 0.7680164575576782,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5073871612548828,
			},
			[139769] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565799092,
				["coordX"] = 0.466456413269043,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4459150433540344,
			},
			[293349] = {
				["mapID"] = 942,
				["coordY"] = 0.6368243098258972,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5820598006248474,
				["artID"] = 967,
				["foundTime"] = 1577448929,
			},
			[136189] = {
				["mapID"] = 942,
				["coordY"] = 0.7978469133377075,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5178033709526062,
				["artID"] = 967,
				["foundTime"] = 1573732412,
			},
			[139386] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568810280,
				["coordX"] = 0.4560864567756653,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8058711290359497,
			},
			[237722] = {
				["mapID"] = 582,
				["coordY"] = 0.3151673078536987,
				["foundTime"] = 1572528724,
				["coordX"] = 0.3716474175453186,
				["artID"] = 627,
				["atlasName"] = "VignetteLoot",
			},
			[151918] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568817195,
				["coordX"] = 0.6965210437774658,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.65742027759552,
			},
			[129283] = {
				["mapID"] = 864,
				["coordY"] = 0.8488221764564514,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3743495643138886,
				["artID"] = 889,
				["foundTime"] = 1569020043,
			},
			[237723] = {
				["mapID"] = 582,
				["coordY"] = 0.3151673078536987,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3716474175453186,
				["artID"] = 627,
				["foundTime"] = 1568378845,
			},
			[147188] = {
				["mapID"] = 1336,
				["coordY"] = 0.7419161796569824,
				["atlasName"] = "VignetteKillElite",
				["coordX"] = 0.3240886926651001,
				["artID"] = 1170,
				["foundTime"] = 1572646077,
			},
			[91113] = {
				["mapID"] = 630,
				["coordY"] = 0.620258092880249,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6130495071411133,
				["artID"] = 653,
				["foundTime"] = 1568374442,
			},
			[273917] = {
				["mapID"] = 895,
				["coordY"] = 0.4783213436603546,
				["foundTime"] = 1578490768,
				["coordX"] = 0.8235633373260498,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[110870] = {
				["mapID"] = 680,
				["coordY"] = 0.5657593011856079,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4225218296051025,
				["artID"] = 704,
				["foundTime"] = 1568374801,
			},
			[147061] = {
				["mapID"] = 895,
				["coordY"] = 0.3492601811885834,
				["foundTime"] = 1578490645,
				["coordX"] = 0.8445457816123962,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[145271] = {
				["mapID"] = 1203,
				["artID"] = 1165,
				["foundTime"] = 1563445651,
				["coordX"] = 0.58707594871521,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5088509321212769,
			},
			[139389] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568810337,
				["coordX"] = 0.5562317371368408,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5627810955047607,
			},
			[273919] = {
				["mapID"] = 895,
				["coordY"] = 0.5710616707801819,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7001351714134216,
				["artID"] = 920,
				["foundTime"] = 1570813739,
			},
			[147957] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569765117,
				["coordX"] = 0.5568065047264099,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3735055923461914,
			},
			[153200] = {
				["mapID"] = 1462,
				["coordY"] = 0.5056332945823669,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5124651789665222,
				["artID"] = 1276,
				["foundTime"] = 1569080908,
			},
			[128965] = {
				["mapID"] = 863,
				["coordY"] = 0.4877086877822876,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.442639172077179,
				["artID"] = 888,
				["foundTime"] = 1570112072,
			},
			[134147] = {
				["mapID"] = 942,
				["coordY"] = 0.7459104061126709,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6598094701766968,
				["artID"] = 967,
				["foundTime"] = 1570369386,
			},
			[139390] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1567431885,
				["coordX"] = 0.5117604732513428,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7909072041511536,
			},
			[50832] = {
				["mapID"] = 388,
				["coordY"] = 0.7460626363754272,
				["foundTime"] = 1572529115,
				["coordX"] = 0.6761540770530701,
				["artID"] = 400,
				["atlasName"] = "VignetteKill",
			},
			[131718] = {
				["mapID"] = 862,
				["coordY"] = 0.3229322731494904,
				["foundTime"] = 1568576409,
				["coordX"] = 0.667450487613678,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[139135] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.370189428329468,
				["coordX"] = 0.488860905170441,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1568575754,
			},
			[154225] = {
				["mapID"] = 1462,
				["coordY"] = 0.5838,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5721,
				["artID"] = 1276,
				["foundTime"] = 1564244742,
			},
			[135939] = {
				["mapID"] = 942,
				["coordY"] = 0.6806183457374573,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4961374998092651,
				["artID"] = 967,
				["foundTime"] = 1570032797,
			},
			[284410] = {
				["mapID"] = 864,
				["coordY"] = 0.3372947871685028,
				["foundTime"] = 1573996325,
				["coordX"] = 0.6277510523796082,
				["artID"] = 889,
				["atlasName"] = "VignetteLoot",
			},
			[136323] = {
				["mapID"] = 864,
				["coordY"] = 0.3457550704479218,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5364658236503601,
				["artID"] = 889,
				["foundTime"] = 1567604165,
			},
			[284411] = {
				["mapID"] = 864,
				["coordY"] = 0.3019782900810242,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5290380716323853,
				["artID"] = 889,
				["foundTime"] = 1567604224,
			},
			[135045] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1568812856,
				["coordX"] = 0.3172670006752014,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6389461755752563,
			},
			[284412] = {
				["mapID"] = 864,
				["coordY"] = 0.2608975470066071,
				["foundTime"] = 1573996368,
				["coordX"] = 0.640636146068573,
				["artID"] = 889,
				["atlasName"] = "VignetteLoot",
			},
			[279042] = {
				["mapID"] = 942,
				["coordY"] = 0.8387717008590698,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5859931111335754,
				["artID"] = 967,
				["foundTime"] = 1577801164,
			},
			[284413] = {
				["mapID"] = 864,
				["coordY"] = 0.4316296279430389,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3565104901790619,
				["artID"] = 889,
				["foundTime"] = 1570814634,
			},
			[145020] = {
				["mapID"] = 942,
				["coordY"] = 0.4621987044811249,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4690589606761932,
				["artID"] = 967,
				["foundTime"] = 1577800275,
			},
			[140161] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.6525408029556274,
				["coordX"] = 0.526144802570343,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572646703,
			},
			[279299] = {
				["mapID"] = 863,
				["coordY"] = 0.8297224044799805,
				["foundTime"] = 1570200692,
				["coordX"] = 0.4621938765048981,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[154739] = {
				["mapID"] = 1462,
				["coordY"] = 0.5345146059989929,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6917940974235535,
				["artID"] = 1276,
				["foundTime"] = 1569081946,
			},
			[284415] = {
				["mapID"] = 864,
				["coordY"] = 0.4536804854869843,
				["foundTime"] = 1570816878,
				["coordX"] = 0.4637280106544495,
				["artID"] = 889,
				["atlasName"] = "VignetteLoot",
			},
			[153205] = {
				["mapID"] = 1462,
				["coordY"] = 0.6982120275497437,
				["foundTime"] = 1566576436,
				["coordX"] = 0.5719438195228577,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[284416] = {
				["mapID"] = 864,
				["coordY"] = 0.462308943271637,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3034027516841888,
				["artID"] = 889,
				["foundTime"] = 1568836137,
			},
			[128584] = {
				["mapID"] = 863,
				["coordY"] = 0.3373443484306335,
				["foundTime"] = 1573360946,
				["coordX"] = 0.4674688279628754,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[284417] = {
				["mapID"] = 864,
				["coordY"] = 0.6145329475402832,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3184630870819092,
				["artID"] = 889,
				["foundTime"] = 1570815211,
			},
			[132746] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.8372640609741211,
				["coordX"] = 0.6247435808181763,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572645494,
			},
			[145278] = {
				["mapID"] = 942,
				["coordY"] = 0.5818721652030945,
				["foundTime"] = 1572060736,
				["coordX"] = 0.3470779359340668,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[152567] = {
				["mapID"] = 1355,
				["coordY"] = 0.695204496383667,
				["foundTime"] = 1569087978,
				["coordX"] = 0.5017485618591309,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[293881] = {
				["mapID"] = 895,
				["coordY"] = 0.7550604343414307,
				["foundTime"] = 1566736914,
				["coordX"] = 0.9049660563468933,
				["artID"] = 920,
				["atlasName"] = "VignetteLootElite",
			},
			[147708] = {
				["mapID"] = 62,
				["coordY"] = 0.243276059627533,
				["foundTime"] = 1570207262,
				["coordX"] = 0.5847851037979126,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[138629] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1569931397,
				["coordX"] = 0.3170222043991089,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8103410005569458,
			},
			[284419] = {
				["mapID"] = 864,
				["coordY"] = 0.7644393444061279,
				["foundTime"] = 1569670667,
				["coordX"] = 0.4780066013336182,
				["artID"] = 889,
				["atlasName"] = "VignetteLoot",
			},
			[136839] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4126340746879578,
				["coordX"] = 0.5659633874893188,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567943780,
			},
			[141059] = {
				["mapID"] = 942,
				["coordY"] = 0.7389867901802063,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6170793771743774,
				["artID"] = 967,
				["foundTime"] = 1577456121,
			},
			[150394] = {
				["mapID"] = 1462,
				["coordY"] = 0.4545035362243652,
				["foundTime"] = 1566391646,
				["coordX"] = 0.5490601062774658,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[138502] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.8132179379463196,
				["coordX"] = 0.668412446975708,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571836193,
			},
			[138630] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1567867490,
				["coordX"] = 0.4923985600471497,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5526394844055176,
			},
			[284421] = {
				["mapID"] = 864,
				["coordY"] = 0.5509148240089417,
				["foundTime"] = 1570816901,
				["coordX"] = 0.575355052947998,
				["artID"] = 889,
				["atlasName"] = "VignetteLoot",
			},
			[134794] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.419087827205658,
				["coordX"] = 0.5781365036964417,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925180,
			},
			[148477] = {
				["mapID"] = 864,
				["coordY"] = 0.4243108332157135,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3464818596839905,
				["artID"] = 889,
				["foundTime"] = 1569673513,
			},
			[152697] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3812071681022644,
				["coordX"] = 0.8351465463638306,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564073893,
			},
			[138631] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1569422525,
				["coordX"] = 0.5528743863105774,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.437132716178894,
			},
			[154104] = {
				["mapID"] = 1530,
				["coordY"] = 0.6638021469116211,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.4095381200313568,
				["artID"] = 1342,
				["foundTime"] = 1579531147,
			},
			[125453] = {
				["mapID"] = 896,
				["coordY"] = 0.427338033914566,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6657809019088745,
				["artID"] = 921,
				["foundTime"] = 1572898216,
			},
			[138504] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.5475974082946777,
				["coordX"] = 0.7199010848999023,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924043,
			},
			[134796] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1567342491,
				["coordX"] = 0.7315021753311157,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6003314256668091,
			},
			[138505] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["foundTime"] = 1571836648,
				["coordX"] = 0.3352446556091309,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6178420782089233,
			},
			[138633] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1569931466,
				["coordX"] = 0.6010329723358154,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4031738638877869,
			},
			[154106] = {
				["mapID"] = 1530,
				["coordY"] = 0.4600565135478973,
				["foundTime"] = 1579714256,
				["coordX"] = 0.9020876884460449,
				["artID"] = 1342,
				["atlasName"] = "VignetteKill",
			},
			[132879] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.535889744758606,
				["coordX"] = 0.4237756729125977,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569763982,
			},
			[93677] = {
				["mapID"] = 641,
				["coordY"] = 0.8749706745147705,
				["foundTime"] = 1568290553,
				["coordX"] = 0.5273743271827698,
				["artID"] = 664,
				["atlasName"] = "VignetteEvent",
			},
			[327650] = {
				["mapID"] = 1355,
				["coordY"] = 0.4607007503509522,
				["atlasName"] = "VignetteLootElite",
				["coordX"] = 0.4785045981407166,
				["artID"] = 1186,
				["foundTime"] = 1569025917,
			},
			[144644] = {
				["mapID"] = 1355,
				["coordY"] = 0.3409859538078308,
				["foundTime"] = 1574946744,
				["coordX"] = 0.3543007373809815,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[151933] = {
				["mapID"] = 1462,
				["coordY"] = 0.421489804983139,
				["foundTime"] = 1569686153,
				["coordX"] = 0.606634795665741,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[127820] = {
				["mapID"] = 863,
				["coordY"] = 0.3878504037857056,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5913995504379272,
				["artID"] = 888,
				["foundTime"] = 1579715078,
			},
			[93166] = {
				["mapID"] = 634,
				["coordY"] = 0.4986329972743988,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4671667814254761,
				["artID"] = 657,
				["foundTime"] = 1568386199,
			},
			[319212] = {
				["mapID"] = 62,
				["coordY"] = 0.4095378220081329,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3998992145061493,
				["artID"] = 1176,
				["foundTime"] = 1569599225,
			},
			[138507] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569419505,
				["coordX"] = 0.6612585783004761,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7940090894699097,
			},
			[138635] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.5891540050506592,
				["coordX"] = 0.5669326186180115,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567943523,
			},
			[142088] = {
				["mapID"] = 942,
				["coordY"] = 0.425345778465271,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4745121002197266,
				["artID"] = 967,
				["foundTime"] = 1577799051,
			},
			[89650] = {
				["mapID"] = 630,
				["coordY"] = 0.3445216119289398,
				["foundTime"] = 1568289824,
				["coordX"] = 0.4746468663215637,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[138508] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564581966,
				["coordX"] = 0.5956070423126221,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4537070393562317,
			},
			[138636] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.3367382884025574,
				["coordX"] = 0.583147406578064,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569931523,
			},
			[140938] = {
				["mapID"] = 942,
				["coordY"] = 0.328283965587616,
				["foundTime"] = 1571400019,
				["coordX"] = 0.6293017864227295,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[145286] = {
				["mapID"] = 1161,
				["coordY"] = 0.4125689566135407,
				["foundTime"] = 1568644500,
				["coordX"] = 0.7714257836341858,
				["artID"] = 1138,
				["atlasName"] = "VignetteKill",
			},
			[54320] = {
				["mapID"] = 198,
				["artID"] = 227,
				["coordY"] = 0.612,
				["coordX"] = 0.258,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1574592267,
			},
			[151680] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920346,
				["coordX"] = 0.2978854179382324,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4073823094367981,
			},
			[126095] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568810276,
				["coordX"] = 0.6112380623817444,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4455658197402954,
			},
			[131476] = {
				["mapID"] = 862,
				["coordY"] = 0.5423378348350525,
				["foundTime"] = 1569761821,
				["coordX"] = 0.4799821376800537,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[82362] = {
				["mapID"] = 539,
				["coordY"] = 0.704363226890564,
				["foundTime"] = 1568211080,
				["coordX"] = 0.3858969509601593,
				["artID"] = 556,
				["atlasName"] = "VignetteKill",
			},
			[82426] = {
				["mapID"] = 539,
				["coordY"] = 0.4025859534740448,
				["foundTime"] = 1568034046,
				["coordX"] = 0.4289679527282715,
				["artID"] = 556,
				["atlasName"] = "VignetteEvent",
			},
			[115226] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.4448662400245667,
				["coordX"] = 0.5779024362564087,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569931862,
			},
			[151681] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.5952246189117432,
				["coordX"] = 0.4011715054512024,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565926121,
			},
			[138510] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3227379322052002,
				["coordX"] = 0.6731036901473999,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007544,
			},
			[128973] = {
				["mapID"] = 896,
				["coordY"] = 0.2155257016420364,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6488416790962219,
				["artID"] = 921,
				["foundTime"] = 1577419753,
			},
			[139278] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.635641515254974,
				["coordX"] = 0.68305903673172,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569936428,
			},
			[140429] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4089969396591187,
				["coordX"] = 0.486330509185791,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567004172,
			},
			[138511] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1569420643,
				["coordX"] = 0.4935778379440308,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.293592095375061,
			},
			[140685] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["foundTime"] = 1569418994,
				["coordX"] = 0.654045581817627,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3642922639846802,
			},
			[252448] = {
				["mapID"] = 680,
				["coordY"] = 0.1918597966432571,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4196332395076752,
				["artID"] = 704,
				["foundTime"] = 1568374853,
			},
			[111007] = {
				["mapID"] = 680,
				["coordY"] = 0.7898325324058533,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4964746832847595,
				["artID"] = 704,
				["foundTime"] = 1568374772,
			},
			[130508] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.448254376649857,
				["coordX"] = 0.835436940193176,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1568575996,
			},
			[279325] = {
				["mapID"] = 863,
				["coordY"] = 0.5762358903884888,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6144613027572632,
				["artID"] = 888,
				["foundTime"] = 1572653891,
			},
			[140558] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.6662293076515198,
				["coordX"] = 0.528430700302124,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570624653,
			},
			[273955] = {
				["mapID"] = 895,
				["coordY"] = 0.3067688643932343,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5217528343200684,
				["artID"] = 920,
				["foundTime"] = 1578312298,
			},
			[129805] = {
				["mapID"] = 896,
				["coordY"] = 0.3006249666213989,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5054298043251038,
				["artID"] = 921,
				["foundTime"] = 1570707996,
			},
			[134804] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1565919653,
				["coordX"] = 0.7010776400566101,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7466039657592773,
			},
			[152323] = {
				["mapID"] = 1355,
				["coordY"] = 0.2900329828262329,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2944130301475525,
				["artID"] = 1186,
				["foundTime"] = 1566138119,
			},
			[128974] = {
				["mapID"] = 863,
				["coordY"] = 0.6770389676094055,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5771782994270325,
				["artID"] = 888,
				["foundTime"] = 1570200774,
			},
			[139280] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.131802096962929,
				["coordX"] = 0.667342483997345,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565915671,
			},
			[69768] = {
				["mapID"] = 379,
				["coordY"] = 0.6471238136291504,
				["foundTime"] = 1579363270,
				["coordX"] = 0.687126636505127,
				["artID"] = 391,
				["atlasName"] = "VignetteKill",
			},
			[140559] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.4523815512657166,
				["coordX"] = 0.6541941165924072,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564240925,
			},
			[151940] = {
				["mapID"] = 1462,
				["coordY"] = 0.2214440107345581,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5796273946762085,
				["artID"] = 1276,
				["foundTime"] = 1569683613,
			},
			[134294] = {
				["mapID"] = 863,
				["coordY"] = 0.6089728474617004,
				["foundTime"] = 1570111872,
				["coordX"] = 0.8169736266136169,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[90804] = {
				["mapID"] = 630,
				["coordY"] = 0.5037305355072021,
				["foundTime"] = 1568289574,
				["coordX"] = 0.3531843721866608,
				["artID"] = 653,
				["atlasName"] = "VignetteEvent",
			},
			[133527] = {
				["mapID"] = 863,
				["coordY"] = 0.3411683142185211,
				["foundTime"] = 1570025929,
				["coordX"] = 0.2756856083869934,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[134806] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.7610135078430176,
				["coordX"] = 0.7113698720932007,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569422217,
			},
			[145292] = {
				["mapID"] = 1161,
				["coordY"] = 0.4123324453830719,
				["foundTime"] = 1568644500,
				["coordX"] = 0.7720505595207214,
				["artID"] = 1138,
				["atlasName"] = "VignetteKill",
			},
			[97326] = {
				["mapID"] = 650,
				["coordY"] = 0.482337236404419,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5107390284538269,
				["artID"] = 674,
				["foundTime"] = 1568377231,
			},
			[139410] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564583243,
				["coordX"] = 0.5867190361022949,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.442463219165802,
			},
			[139538] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569423256,
				["coordX"] = 0.6243754625320435,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8262673616409302,
			},
			[159103] = {
				["mapID"] = 1570,
				["coordY"] = 0.5948824882507324,
				["foundTime"] = 1579617721,
				["coordX"] = 0.8701679706573486,
				["artID"] = 1363,
				["atlasName"] = "VignetteKill",
			},
			[145932] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.4264104962348938,
				["coordX"] = 0.6043267250061035,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565925320,
			},
			[136853] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1568818284,
				["coordX"] = 0.5463791489601135,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8117984533309937,
			},
			[135958] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569930693,
				["coordX"] = 0.5734056234359741,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.502063512802124,
			},
			[81406] = {
				["mapID"] = 539,
				["coordY"] = 0.06629262864589691,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2941061556339264,
				["artID"] = 556,
				["foundTime"] = 1568124168,
			},
			[284448] = {
				["mapID"] = 942,
				["coordY"] = 0.3906724750995636,
				["foundTime"] = 1573733653,
				["coordX"] = 0.599142849445343,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[151687] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920488,
				["coordX"] = 0.6183640956878662,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4767789840698242,
			},
			[138516] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.8274484276771545,
				["coordX"] = 0.6082821488380432,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569425750,
			},
			[89846] = {
				["mapID"] = 630,
				["coordY"] = 0.4394021332263947,
				["foundTime"] = 1568298387,
				["coordX"] = 0.5345421433448792,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[136854] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1568818343,
				["coordX"] = 0.5541123151779175,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7761676907539368,
			},
			[135959] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.4354857206344605,
				["coordX"] = 0.6970322132110596,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565919747,
			},
			[110562] = {
				["mapID"] = 641,
				["coordY"] = 0.8878257870674133,
				["foundTime"] = 1568291068,
				["coordX"] = 0.4558531939983368,
				["artID"] = 664,
				["atlasName"] = "VignetteKill",
			},
			[282660] = {
				["mapID"] = 863,
				["coordY"] = 0.5768159031867981,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.3808612823486328,
				["artID"] = 888,
				["foundTime"] = 1573363639,
			},
			[154118] = {
				["mapID"] = 1530,
				["coordY"] = 0.6781296730041504,
				["foundTime"] = 1579280459,
				["coordX"] = 0.6042100787162781,
				["artID"] = 1342,
				["atlasName"] = "VignetteEvent",
			},
			[140180] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.5964587330818176,
				["coordX"] = 0.5950369834899902,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570628216,
			},
			[139285] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1563536451,
				["coordX"] = 0.551244556903839,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.324088424444199,
			},
			[152712] = {
				["mapID"] = 1355,
				["coordY"] = 0.8254230618476868,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3740364909172058,
				["artID"] = 1186,
				["foundTime"] = 1570977749,
			},
			[140692] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568812451,
				["coordX"] = 0.4280242919921875,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6559599041938782,
			},
			[145040] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.5687674283981323,
				["coordX"] = 0.5637578964233398,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567943530,
			},
			[89016] = {
				["mapID"] = 630,
				["coordY"] = 0.4181382358074188,
				["foundTime"] = 1568289607,
				["coordX"] = 0.4100285172462463,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[284454] = {
				["mapID"] = 1165,
				["coordY"] = 0.8866457939147949,
				["foundTime"] = 1572263212,
				["coordX"] = 0.5930131673812866,
				["artID"] = 1143,
				["atlasName"] = "VignetteLoot",
			},
			[139414] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564921748,
				["coordX"] = 0.6118149757385254,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4477077722549439,
			},
			[138647] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1568645550,
				["coordX"] = 0.4907298088073731,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5653666853904724,
			},
			[97584] = {
				["mapID"] = 650,
				["coordY"] = 0.4063010513782501,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.545431911945343,
				["artID"] = 674,
				["foundTime"] = 1568375573,
			},
			[280619] = {
				["mapID"] = 942,
				["coordY"] = 0.4723159372806549,
				["foundTime"] = 1573732970,
				["coordX"] = 0.4285467863082886,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[294174] = {
				["mapID"] = 942,
				["coordY"] = 0.3069271445274353,
				["foundTime"] = 1570031952,
				["coordX"] = 0.4600470960140228,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[139287] = {
				["mapID"] = 1161,
				["coordY"] = 0.4238300025463104,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7994891405105591,
				["artID"] = 1138,
				["foundTime"] = 1572663749,
			},
			[136346] = {
				["mapID"] = 864,
				["coordY"] = 0.243161216378212,
				["foundTime"] = 1572065169,
				["coordX"] = 0.412490576505661,
				["artID"] = 889,
				["atlasName"] = "VignetteKill",
			},
			[153226] = {
				["mapID"] = 1462,
				["coordY"] = 0.7737317681312561,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2545179724693298,
				["artID"] = 1276,
				["foundTime"] = 1569683640,
			},
			[151308] = {
				["mapID"] = 1462,
				["coordY"] = 0.3358480930328369,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5309227108955383,
				["artID"] = 1276,
				["foundTime"] = 1569685384,
			},
			[132127] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.221902117133141,
				["coordX"] = 0.601013600826263,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1566485454,
			},
			[139416] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1571837698,
				["coordX"] = 0.5777726769447327,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8486171364784241,
			},
			[139672] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.4747206568717957,
				["coordX"] = 0.4121946096420288,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571753887,
			},
			[144915] = {
				["mapID"] = 942,
				["coordY"] = 0.4908104836940765,
				["foundTime"] = 1571236824,
				["coordX"] = 0.4972397089004517,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[281646] = {
				["mapID"] = 942,
				["coordY"] = 0.7114048004150391,
				["foundTime"] = 1570198797,
				["coordX"] = 0.6655718088150024,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[121242] = {
				["mapID"] = 863,
				["coordY"] = 0.5747234225273132,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6877394318580627,
				["artID"] = 888,
				["foundTime"] = 1570110832,
			},
			[124375] = {
				["mapID"] = 863,
				["coordY"] = 0.6520676612854004,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6210723519325256,
				["artID"] = 888,
				["foundTime"] = 1570200829,
			},
			[139289] = {
				["mapID"] = 895,
				["coordY"] = 0.5153875946998596,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5531342625617981,
				["artID"] = 920,
				["foundTime"] = 1571398110,
			},
			[140440] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568646364,
				["coordX"] = 0.3754523992538452,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6952056884765625,
			},
			[281903] = {
				["mapID"] = 862,
				["coordY"] = 0.7361626029014587,
				["foundTime"] = 1574244978,
				["coordX"] = 0.4273635745048523,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[326404] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1569083538,
				["coordX"] = 0.7952965497970581,
				["atlasName"] = "VignetteLoot",
				["coordY"] = 0.2716021537780762,
			},
			[153228] = {
				["mapID"] = 1462,
				["coordY"] = 0.5493391156196594,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6723161935806274,
				["artID"] = 1276,
				["foundTime"] = 1569686613,
			},
			[281904] = {
				["mapID"] = 862,
				["coordY"] = 0.379704624414444,
				["foundTime"] = 1566650787,
				["coordX"] = 0.4216816127300263,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[287531] = {
				["mapID"] = 942,
				["coordY"] = 0.6378964781761169,
				["foundTime"] = 1577456109,
				["coordX"] = 0.6154956817626953,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[139418] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3235605955123901,
				["coordX"] = 0.5149439573287964,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571835725,
			},
			[281905] = {
				["mapID"] = 862,
				["coordY"] = 0.3763481378555298,
				["foundTime"] = 1568577267,
				["coordX"] = 0.7841234803199768,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[140697] = {
				["mapID"] = 1034,
				["artID"] = 1015,
				["foundTime"] = 1567866062,
				["coordX"] = 0.6574256420135498,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6219828128814697,
			},
			[326406] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1575166435,
				["coordX"] = 0.5632744431495667,
				["atlasName"] = "VignetteLoot",
				["coordY"] = 0.3378702998161316,
			},
			[135838] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568812291,
				["coordX"] = 0.5111336708068848,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7724469900131226,
			},
			[93622] = {
				["mapID"] = 630,
				["coordY"] = 0.4467275440692902,
				["foundTime"] = 1568289710,
				["coordX"] = 0.4062276482582092,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[326407] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.4977533221244812,
				["coordX"] = 0.5283011198043823,
				["atlasName"] = "VignetteLoot",
				["foundTime"] = 1564913248,
			},
			[107113] = {
				["mapID"] = 630,
				["coordY"] = 0.4320957958698273,
				["foundTime"] = 1568289590,
				["coordX"] = 0.3728079199790955,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[89850] = {
				["mapID"] = 630,
				["coordY"] = 0.5516137480735779,
				["foundTime"] = 1568374499,
				["coordX"] = 0.5968800187110901,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[110438] = {
				["mapID"] = 680,
				["coordY"] = 0.215299129486084,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3724152743816376,
				["artID"] = 704,
				["foundTime"] = 1568374860,
			},
			[136990] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.4114857912063599,
				["coordX"] = 0.6961304545402527,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571836132,
			},
			[92152] = {
				["mapID"] = 634,
				["coordY"] = 0.5174220204353333,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3649635314941406,
				["artID"] = 657,
				["foundTime"] = 1568387386,
			},
			[281397] = {
				["mapID"] = 895,
				["coordY"] = 0.5814225077629089,
				["foundTime"] = 1565927837,
				["coordX"] = 0.724904477596283,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[139420] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564921815,
				["coordX"] = 0.5969768166542053,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4893783926963806,
			},
			[326410] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1572032188,
				["coordX"] = 0.50616055727005,
				["atlasName"] = "VignetteLoot",
				["coordY"] = 0.4995437860488892,
			},
			[136863] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1567342746,
				["coordX"] = 0.5993069410324097,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8428320288658142,
			},
			[136991] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1567866609,
				["coordX"] = 0.3294551372528076,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8499531745910645,
			},
			[152464] = {
				["mapID"] = 1355,
				["coordY"] = 0.07354062795639038,
				["foundTime"] = 1575111471,
				["coordX"] = 0.4078888893127441,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[151569] = {
				["mapID"] = 1462,
				["coordY"] = 0.4291911423206329,
				["foundTime"] = 1569082575,
				["coordX"] = 0.3528560996055603,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[279609] = {
				["mapID"] = 862,
				["coordY"] = 0.8687533140182495,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.517133891582489,
				["artID"] = 887,
				["foundTime"] = 1569604813,
			},
			[133539] = {
				["mapID"] = 863,
				["coordY"] = 0.4507228136062622,
				["foundTime"] = 1570111898,
				["coordX"] = 0.7772201895713806,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[284469] = {
				["mapID"] = 895,
				["coordY"] = 0.3861140906810761,
				["foundTime"] = 1579353081,
				["coordX"] = 0.7224424481391907,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[136864] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1569764387,
				["coordX"] = 0.6368635892868042,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6900957822799683,
			},
			[147222] = {
				["mapID"] = 49,
				["coordY"] = 0.7096279263496399,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2435671389102936,
				["artID"] = 54,
				["foundTime"] = 1575096608,
			},
			[152465] = {
				["mapID"] = 1355,
				["coordY"] = 0.07710593938827515,
				["foundTime"] = 1577626420,
				["coordX"] = 0.5703926086425781,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[50808] = {
				["mapID"] = 371,
				["coordY"] = 0.7169138789176941,
				["foundTime"] = 1567947551,
				["coordX"] = 0.5737815499305725,
				["artID"] = 383,
				["atlasName"] = "VignetteKill",
			},
			[136865] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1567866680,
				["coordX"] = 0.2367957830429077,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7396372556686401,
			},
			[326415] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.7441,
				["coordX"] = 0.3871,
				["atlasName"] = "VignetteLoot",
				["foundTime"] = 1564908523,
			},
			[149653] = {
				["mapID"] = 1355,
				["coordY"] = 0.4171630144119263,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.547032356262207,
				["artID"] = 1186,
				["foundTime"] = 1577377136,
			},
			[111463] = {
				["mapID"] = 634,
				["artID"] = 657,
				["foundTime"] = 1567868872,
				["coordX"] = 0.734,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.84,
			},
			[132007] = {
				["mapID"] = 942,
				["coordY"] = 0.5435811877250671,
				["foundTime"] = 1570369596,
				["coordX"] = 0.7144935727119446,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[149654] = {
				["mapID"] = 62,
				["coordY"] = 0.1963830888271332,
				["foundTime"] = 1569089655,
				["coordX"] = 0.4350595772266388,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[326418] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1569511924,
				["coordX"] = 0.3796876668930054,
				["atlasName"] = "VignetteLoot",
				["coordY"] = 0.6059074997901917,
			},
			[97653] = {
				["mapID"] = 650,
				["coordY"] = 0.5127764940261841,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.5370946526527405,
				["artID"] = 674,
				["foundTime"] = 1568376486,
			},
			[140064] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3144945502281189,
				["coordX"] = 0.6793252825737,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571835604,
			},
			[149655] = {
				["mapID"] = 62,
				["coordY"] = 0.3241119384765625,
				["foundTime"] = 1570207218,
				["coordX"] = 0.5063717365264893,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[139809] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564582244,
				["coordX"] = 0.3981276154518127,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5952268242835999,
			},
			[141088] = {
				["mapID"] = 942,
				["coordY"] = 0.759826123714447,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.570468544960022,
				["artID"] = 967,
				["foundTime"] = 1577801101,
			},
			[145308] = {
				["mapID"] = 895,
				["coordY"] = 0.4250621497631073,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8601298332214355,
				["artID"] = 920,
				["foundTime"] = 1570702133,
			},
			[90173] = {
				["mapID"] = 630,
				["coordY"] = 0.5343262553215027,
				["foundTime"] = 1568297437,
				["coordX"] = 0.4782509207725525,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[151702] = {
				["mapID"] = 1462,
				["coordY"] = 0.6805565357208252,
				["foundTime"] = 1569683996,
				["coordX"] = 0.230964869260788,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[127129] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.2063771337270737,
				["coordX"] = 0.5034276247024536,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572898688,
			},
			[139810] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1569764534,
				["coordX"] = 0.6221923828125,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5678040385246277,
			},
			[134823] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4133331775665283,
				["coordX"] = 0.5637351870536804,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567005041,
			},
			[140450] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1567005846,
				["coordX"] = 0.4336100816726685,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5733608603477478,
			},
			[146844] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4563124179840088,
				["coordX"] = 0.3839726448059082,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571836684,
			},
			[279366] = {
				["mapID"] = 863,
				["coordY"] = 0.2679369747638702,
				["foundTime"] = 1570028177,
				["coordX"] = 0.3919752538204193,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[50138] = {
				["mapID"] = 241,
				["artID"] = 252,
				["coordY"] = 0.744,
				["coordX"] = 0.492,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1566132822,
			},
			[93371] = {
				["mapID"] = 634,
				["coordY"] = 0.4993655383586884,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7249486446380615,
				["artID"] = 657,
				["foundTime"] = 1568377937,
			},
			[150937] = {
				["mapID"] = 1462,
				["coordY"] = 0.8028293251991272,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.1940868645906448,
				["artID"] = 1276,
				["foundTime"] = 1569684123,
			},
			[139812] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1569931821,
				["coordX"] = 0.5750276446342468,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7118301391601562,
			},
			[325659] = {
				["mapID"] = 1462,
				["coordY"] = 0.5327059030532837,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5211336612701416,
				["artID"] = 1276,
				["foundTime"] = 1569684774,
			},
			[106990] = {
				["mapID"] = 630,
				["coordY"] = 0.5690937042236328,
				["foundTime"] = 1568374098,
				["coordX"] = 0.656529426574707,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[325660] = {
				["mapID"] = 1462,
				["coordY"] = 0.7142783999443054,
				["foundTime"] = 1569683263,
				["coordX"] = 0.2059285789728165,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[140836] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1568818189,
				["coordX"] = 0.5232545137405396,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6626853942871094,
			},
			[325661] = {
				["mapID"] = 1462,
				["coordY"] = 0.5328653454780579,
				["foundTime"] = 1572526276,
				["coordX"] = 0.7359024882316589,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[148253] = {
				["mapID"] = 862,
				["coordY"] = 0.5623018741607666,
				["foundTime"] = 1570206449,
				["coordX"] = 0.787909209728241,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[138279] = {
				["mapID"] = 895,
				["coordY"] = 0.4340527355670929,
				["foundTime"] = 1568237131,
				["coordX"] = 0.8546528816223145,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[139430] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565799596,
				["coordX"] = 0.4724639654159546,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3261980414390564,
			},
			[243009] = {
				["mapID"] = 630,
				["coordY"] = 0.4001505374908447,
				["foundTime"] = 1568287070,
				["coordX"] = 0.6512895822525024,
				["artID"] = 653,
				["atlasName"] = "VignetteEvent",
			},
			[139814] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1569424247,
				["coordX"] = 0.573119580745697,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6057994365692139,
			},
			[325663] = {
				["mapID"] = 1462,
				["coordY"] = 0.5738828778266907,
				["foundTime"] = 1566741949,
				["coordX"] = 0.5665207505226135,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[148510] = {
				["mapID"] = 864,
				["coordY"] = 0.6235734820365906,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3678158819675446,
				["artID"] = 889,
				["foundTime"] = 1573363054,
			},
			[139431] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1572646813,
				["coordX"] = 0.615311861038208,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4813365936279297,
			},
			[325665] = {
				["mapID"] = 1462,
				["coordY"] = 0.2826369106769562,
				["foundTime"] = 1572526262,
				["coordX"] = 0.8568623065948486,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[277329] = {
				["mapID"] = 896,
				["coordY"] = 0.3648057878017426,
				["foundTime"] = 1577419262,
				["coordX"] = 0.4195208847522736,
				["artID"] = 921,
				["atlasName"] = "VignetteEvent",
			},
			[325666] = {
				["mapID"] = 1462,
				["coordY"] = 0.7759378552436829,
				["foundTime"] = 1566390761,
				["coordX"] = 0.6675953269004822,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[146849] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1569849582,
				["coordX"] = 0.6668627262115479,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4395135045051575,
			},
			[125214] = {
				["mapID"] = 863,
				["coordY"] = 0.3593465685844421,
				["foundTime"] = 1570111922,
				["coordX"] = 0.757058322429657,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[325667] = {
				["mapID"] = 1462,
				["coordY"] = 0.6597946286201477,
				["foundTime"] = 1566574886,
				["coordX"] = 0.7648739814758301,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[154394] = {
				["mapID"] = 1530,
				["coordY"] = 0.4167832136154175,
				["foundTime"] = 1579709497,
				["coordX"] = 0.8667539954185486,
				["artID"] = 1342,
				["atlasName"] = "VignetteKill",
			},
			[146845] = {
				["mapID"] = 981,
				["artID"] = 981,
				["coordY"] = 0.443051815032959,
				["coordX"] = 0.7504346370697021,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572645352,
			},
			[325668] = {
				["mapID"] = 1462,
				["coordY"] = 0.7695606350898743,
				["foundTime"] = 1569683266,
				["coordX"] = 0.205322340130806,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[126621] = {
				["mapID"] = 896,
				["coordY"] = 0.5097635984420776,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6669610142707825,
				["artID"] = 921,
				["foundTime"] = 1577419009,
			},
			[146850] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569420744,
				["coordX"] = 0.5981878042221069,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5513783693313599,
			},
			[279378] = {
				["mapID"] = 863,
				["coordY"] = 0.3695122599601746,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7215051054954529,
				["artID"] = 888,
				["foundTime"] = 1570200927,
			},
			[136876] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1564922721,
				["coordX"] = 0.657328188419342,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6265261769294739,
			},
			[148257] = {
				["mapID"] = 862,
				["coordY"] = 0.5629572868347168,
				["foundTime"] = 1570206459,
				["coordX"] = 0.7877076864242554,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[163204] = {
				["mapID"] = 1527,
				["coordY"] = 0.5705471038818359,
				["foundTime"] = 1579620084,
				["coordX"] = 0.2776930332183838,
				["artID"] = 1343,
				["atlasName"] = "VignetteEvent",
			},
			[279379] = {
				["mapID"] = 863,
				["coordY"] = 0.2159627825021744,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5429264307022095,
				["artID"] = 888,
				["foundTime"] = 1570111957,
			},
			[130138] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.454817533493042,
				["coordX"] = 0.5994223356246948,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1577419103,
			},
			[50811] = {
				["mapID"] = 376,
				["coordY"] = 0.1785528659820557,
				["foundTime"] = 1579466609,
				["coordX"] = 0.8839069604873657,
				["artID"] = 388,
				["atlasName"] = "VignetteKill",
			},
			[138667] = {
				["mapID"] = 896,
				["coordY"] = 0.1110316142439842,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3600378632545471,
				["artID"] = 921,
				["foundTime"] = 1577186912,
			},
			[139818] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1569425237,
				["coordX"] = 0.5703206062316895,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6048926711082458,
			},
			[293852] = {
				["mapID"] = 895,
				["coordY"] = 0.460786372423172,
				["foundTime"] = 1573846987,
				["coordX"] = 0.5499342083930969,
				["artID"] = 920,
				["atlasName"] = "VignetteLootElite",
			},
			[132913] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1572646611,
				["coordX"] = 0.4165741801261902,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3827662467956543,
			},
			[162172] = {
				["mapID"] = 1527,
				["coordY"] = 0.2987438142299652,
				["foundTime"] = 1579618104,
				["coordX"] = 0.3199795186519623,
				["artID"] = 1343,
				["atlasName"] = "VignetteKill",
			},
			[138618] = {
				["mapID"] = 896,
				["coordY"] = 0.3051560819149017,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2357774078845978,
				["artID"] = 921,
				["foundTime"] = 1573360232,
			},
			[164331] = {
				["mapID"] = 1530,
				["coordY"] = 0.3997679054737091,
				["foundTime"] = 1579639191,
				["coordX"] = 0.7423943877220154,
				["artID"] = 1342,
				["atlasName"] = "VignetteEvent",
			},
			[163337] = {
				["mapID"] = 1527,
				["coordY"] = 0.2066219300031662,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.3653130233287811,
				["artID"] = 1343,
				["foundTime"] = 1579552809,
			},
			[146852] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.4822253584861755,
				["coordX"] = 0.6036513447761536,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569424329,
			},
			[277336] = {
				["mapID"] = 1165,
				["coordY"] = 0.08313080668449402,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4469476342201233,
				["artID"] = 1143,
				["foundTime"] = 1569603116,
			},
			[140970] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1569932410,
				["coordX"] = 0.5299839973449707,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4899251461029053,
			},
			[127901] = {
				["mapID"] = 896,
				["coordY"] = 0.5540385842323303,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5935744047164917,
				["artID"] = 921,
				["foundTime"] = 1573359342,
			},
			[141226] = {
				["mapID"] = 942,
				["coordY"] = 0.77767014503479,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.351095587015152,
				["artID"] = 967,
				["foundTime"] = 1577424334,
			},
			[154095] = {
				["mapID"] = 1530,
				["coordY"] = 0.6703577637672424,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.4233199954032898,
				["artID"] = 1342,
				["foundTime"] = 1579531238,
			},
			[131252] = {
				["mapID"] = 895,
				["coordY"] = 0.1687140464782715,
				["foundTime"] = 1564914812,
				["coordX"] = 0.4313379228115082,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[129180] = {
				["mapID"] = 864,
				["coordY"] = 0.4604599177837372,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3706750869750977,
				["artID"] = 889,
				["foundTime"] = 1573361888,
			},
			[146853] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.6058095693588257,
				["coordX"] = 0.5575790405273438,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570628172,
			},
			[273902] = {
				["mapID"] = 895,
				["coordY"] = 0.8050503134727478,
				["foundTime"] = 1572064889,
				["coordX"] = 0.7803499102592468,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[293962] = {
				["mapID"] = 895,
				["coordY"] = 0.331906259059906,
				["foundTime"] = 1564914429,
				["coordX"] = 0.5602756142616272,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[157170] = {
				["mapID"] = 1527,
				["coordY"] = 0.2563655972480774,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6450706720352173,
				["artID"] = 1343,
				["foundTime"] = 1579361253,
			},
			[164361] = {
				["mapID"] = 1527,
				["coordY"] = 0.4586372673511505,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.7159016728401184,
				["artID"] = 1343,
				["foundTime"] = 1579361906,
			},
			[293884] = {
				["mapID"] = 895,
				["coordY"] = 0.3759433329105377,
				["atlasName"] = "VignetteLootElite",
				["coordX"] = 0.489785760641098,
				["artID"] = 920,
				["foundTime"] = 1570551224,
			},
			[152736] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3539354205131531,
				["coordX"] = 0.837614893913269,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1577377572,
			},
			[50769] = {
				["mapID"] = 379,
				["coordY"] = 0.7624598741531372,
				["foundTime"] = 1579278186,
				["coordX"] = 0.7337870597839355,
				["artID"] = 391,
				["atlasName"] = "VignetteKill",
			},
			[157167] = {
				["mapID"] = 1527,
				["coordY"] = 0.5221226215362549,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7541301250457764,
				["artID"] = 1343,
				["foundTime"] = 1579362103,
			},
			[151202] = {
				["mapID"] = 1462,
				["coordY"] = 0.5161255598068237,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6563528180122375,
				["artID"] = 1276,
				["foundTime"] = 1569685800,
			},
			[293964] = {
				["mapID"] = 895,
				["coordY"] = 0.6274539828300476,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6177815198898315,
				["artID"] = 920,
				["foundTime"] = 1570813902,
			},
			[151684] = {
				["mapID"] = 1462,
				["coordY"] = 0.4447919726371765,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.771460771560669,
				["artID"] = 1276,
				["foundTime"] = 1568641688,
			},
			[142251] = {
				["mapID"] = 943,
				["artID"] = 968,
				["coordY"] = 0.282260119915009,
				["coordX"] = 0.442937970161438,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563547968,
			},
			[154495] = {
				["mapID"] = 1530,
				["coordY"] = 0.6225057244300842,
				["foundTime"] = 1579283603,
				["coordX"] = 0.5295419692993164,
				["artID"] = 1342,
				["atlasName"] = "VignetteKill",
			},
			[293965] = {
				["mapID"] = 895,
				["coordY"] = 0.2133042067289352,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7265006899833679,
				["artID"] = 920,
				["foundTime"] = 1579714154,
			},
			[129181] = {
				["mapID"] = 895,
				["coordY"] = 0.8287777900695801,
				["foundTime"] = 1572064884,
				["coordX"] = 0.7609888911247253,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[131984] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1573732277,
				["coordX"] = 0.703424513339996,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.124857723712921,
			},
			[149147] = {
				["mapID"] = 862,
				["coordY"] = 0.3673205971717835,
				["foundTime"] = 1573364893,
				["coordX"] = 0.695693850517273,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[133812] = {
				["mapID"] = 863,
				["coordY"] = 0.7132976055145264,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.387824296951294,
				["artID"] = 888,
				["foundTime"] = 1573995870,
			},
			[140168] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.6579194664955139,
				["coordX"] = 0.5303711891174316,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569931991,
			},
			[134293] = {
				["mapID"] = 863,
				["coordY"] = 0.2699517905712128,
				["foundTime"] = 1570025964,
				["coordX"] = 0.3313024640083313,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[138288] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.4630273580551148,
				["coordX"] = 0.6968731880187988,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565927405,
			},
			[139439] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1572645484,
				["coordX"] = 0.5705645084381104,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6733417510986328,
			},
			[147751] = {
				["mapID"] = 62,
				["coordY"] = 0.2940788269042969,
				["foundTime"] = 1569089683,
				["coordX"] = 0.4348946809768677,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[139695] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.6207869052886963,
				["coordX"] = 0.6392873525619507,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564241713,
			},
			[124548] = {
				["mapID"] = 896,
				["artID"] = 921,
				["foundTime"] = 1568710293,
				["coordX"] = 0.5846678018569946,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3317910134792328,
			},
			[152227] = {
				["mapID"] = 1527,
				["coordY"] = 0.2982923090457916,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.6449587345123291,
				["artID"] = 1343,
				["foundTime"] = 1579191504,
			},
			[147240] = {
				["mapID"] = 62,
				["coordY"] = 0.3213121592998505,
				["foundTime"] = 1570207237,
				["coordX"] = 0.5243692398071289,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[139413] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3009872436523438,
				["coordX"] = 0.5408317446708679,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571837681,
			},
			[325626] = {
				["mapID"] = 1527,
				["coordY"] = 0.4294252693653107,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6746701598167419,
				["artID"] = 1343,
				["foundTime"] = 1579361906,
			},
			[140453] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4579221606254578,
				["coordX"] = 0.3808060884475708,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569422050,
			},
			[50159] = {
				["mapID"] = 241,
				["artID"] = 252,
				["coordY"] = 0.53,
				["coordX"] = 0.382,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1577378037,
			},
			[287320] = {
				["mapID"] = 864,
				["coordY"] = 0.2614915668964386,
				["foundTime"] = 1570025423,
				["coordX"] = 0.4450576603412628,
				["artID"] = 889,
				["atlasName"] = "VignetteLoot",
			},
			[140547] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.6487029790878296,
				["coordX"] = 0.5223678350448608,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570628318,
			},
			[140975] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["coordY"] = 0.4742436408996582,
				["coordX"] = 0.6811608076095581,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569423124,
			},
			[148264] = {
				["mapID"] = 862,
				["coordY"] = 0.3730973303318024,
				["foundTime"] = 1570205971,
				["coordX"] = 0.670683741569519,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[127001] = {
				["mapID"] = 863,
				["coordY"] = 0.8599702715873718,
				["foundTime"] = 1570111103,
				["coordX"] = 0.3380497097969055,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[139041] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.6819263696670532,
				["coordX"] = 0.3940279483795166,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572645478,
			},
			[132280] = {
				["mapID"] = 895,
				["coordY"] = 0.8283413648605347,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8091084957122803,
				["artID"] = 920,
				["foundTime"] = 1569939413,
			},
			[138509] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1571837184,
				["coordX"] = 0.4979709386825562,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8433774709701538,
			},
			[147562] = {
				["mapID"] = 942,
				["coordY"] = 0.4652308225631714,
				["foundTime"] = 1567540746,
				["coordX"] = 0.4303671419620514,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[122004] = {
				["mapID"] = 862,
				["coordY"] = 0.3239408433437347,
				["foundTime"] = 1570030552,
				["coordX"] = 0.7141416072845459,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[149352] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569765112,
				["coordX"] = 0.5773607492446899,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3992758393287659,
			},
			[129950] = {
				["mapID"] = 896,
				["coordY"] = 0.4062059819698334,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3193835616111755,
				["artID"] = 921,
				["foundTime"] = 1573847544,
			},
			[129995] = {
				["mapID"] = 896,
				["coordY"] = 0.4009649455547333,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.634058952331543,
				["artID"] = 921,
				["foundTime"] = 1570024723,
			},
			[134298] = {
				["mapID"] = 863,
				["coordY"] = 0.8107480406761169,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5411631464958191,
				["artID"] = 888,
				["foundTime"] = 1570296547,
			},
			[139442] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1567431842,
				["coordX"] = 0.5728213787078857,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3737393617630005,
			},
			[287324] = {
				["mapID"] = 864,
				["coordY"] = 0.6463976502418518,
				["foundTime"] = 1569270951,
				["coordX"] = 0.5774049758911133,
				["artID"] = 889,
				["atlasName"] = "VignetteLoot",
			},
			[161181] = {
				["mapID"] = 1530,
				["coordY"] = 0.5162886381149292,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.7643964886665344,
				["artID"] = 1342,
				["foundTime"] = 1579714825,
			},
			[154148] = {
				["mapID"] = 1355,
				["coordY"] = 0.244073748588562,
				["foundTime"] = 1570630722,
				["coordX"] = 0.6637352705001831,
				["artID"] = 1186,
				["atlasName"] = "VignetteEvent",
			},
			[282721] = {
				["mapID"] = 863,
				["coordY"] = 0.5294104218482971,
				["foundTime"] = 1570110751,
				["coordX"] = 0.677067220211029,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[148259] = {
				["mapID"] = 862,
				["coordY"] = 0.5624605417251587,
				["foundTime"] = 1570206442,
				["coordX"] = 0.7883018255233765,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[278793] = {
				["mapID"] = 862,
				["coordY"] = 0.2835460007190704,
				["foundTime"] = 1570030567,
				["coordX"] = 0.7150080800056458,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[288604] = {
				["mapID"] = 862,
				["coordY"] = 0.5188829302787781,
				["foundTime"] = 1572264857,
				["coordX"] = 0.7637903690338135,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[155811] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1575166359,
				["coordX"] = 0.3344057202339172,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3012655973434448,
			},
			[155172] = {
				["mapID"] = 942,
				["coordY"] = 0.2158566415309906,
				["foundTime"] = 1571920336,
				["coordX"] = 0.6285213232040405,
				["artID"] = 967,
				["atlasName"] = "VignetteEvent",
			},
			[148456] = {
				["mapID"] = 864,
				["coordY"] = 0.7161595225334167,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3329837322235107,
				["artID"] = 889,
				["foundTime"] = 1573363387,
			},
			[163356] = {
				["mapID"] = 1527,
				["coordY"] = 0.4381363987922669,
				["foundTime"] = 1579621112,
				["coordX"] = 0.3160574436187744,
				["artID"] = 1343,
				["atlasName"] = "VignetteEvent",
			},
			[140978] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4599134922027588,
				["coordX"] = 0.3717272877693176,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565926377,
			},
			[156451] = {
				["mapID"] = 1570,
				["coordY"] = 0.6522283554077148,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.9137915372848511,
				["artID"] = 1363,
				["foundTime"] = 1579467360,
			},
			[339756] = {
				["mapID"] = 1530,
				["coordY"] = 0.5717616677284241,
				["foundTime"] = 1579279870,
				["coordX"] = 0.4638642966747284,
				["artID"] = 1342,
				["atlasName"] = "VignetteEvent",
			},
			[130079] = {
				["mapID"] = 942,
				["coordY"] = 0.7476725578308105,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4202911853790283,
				["artID"] = 967,
				["foundTime"] = 1571142520,
			},
			[139444] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1568818245,
				["coordX"] = 0.4481260776519775,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6019729375839233,
			},
			[135924] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1567344104,
				["coordX"] = 0.6793426871299744,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6504858732223511,
			},
			[135796] = {
				["mapID"] = 896,
				["coordY"] = 0.141814798116684,
				["foundTime"] = 1572064553,
				["coordX"] = 0.2808245122432709,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[155173] = {
				["mapID"] = 942,
				["coordY"] = 0.6987200379371643,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.6687302589416504,
				["artID"] = 967,
				["foundTime"] = 1572134081,
			},
			[140979] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1569422545,
				["coordX"] = 0.5582382082939148,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4171536564826965,
			},
			[152360] = {
				["mapID"] = 1355,
				["coordY"] = 0.5054889917373657,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6553360223770142,
				["artID"] = 1186,
				["foundTime"] = 1575112508,
			},
			[163357] = {
				["mapID"] = 1527,
				["coordY"] = 0.4306272268295288,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.451382577419281,
				["artID"] = 1343,
				["foundTime"] = 1579620772,
			},
			[324413] = {
				["mapID"] = 1527,
				["coordY"] = 0.509798526763916,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.849989116191864,
				["artID"] = 1343,
				["foundTime"] = 1579366672,
			},
			[131389] = {
				["mapID"] = 895,
				["coordY"] = 0.5036491751670837,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6365872621536255,
				["artID"] = 920,
				["foundTime"] = 1577801685,
			},
			[339247] = {
				["mapID"] = 1527,
				["coordY"] = 0.3157914578914642,
				["foundTime"] = 1579621064,
				["coordX"] = 0.3541105687618256,
				["artID"] = 1343,
				["atlasName"] = "VignetteLoot",
			},
			[126926] = {
				["mapID"] = 863,
				["coordY"] = 0.5074923038482666,
				["foundTime"] = 1570111362,
				["coordX"] = 0.2952761352062225,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[128578] = {
				["mapID"] = 863,
				["artID"] = 888,
				["foundTime"] = 1573361135,
				["coordX"] = 0.3958415389060974,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4979309737682343,
			},
			[136888] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1567866505,
				["coordX"] = 0.4987193942070007,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4182979464530945,
			},
			[339248] = {
				["mapID"] = 1527,
				["coordY"] = 0.4014920592308044,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3877929449081421,
				["artID"] = 1343,
				["foundTime"] = 1579621249,
			},
			[140341] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1572645944,
				["coordX"] = 0.6349585056304932,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.576948881149292,
			},
			[50750] = {
				["mapID"] = 371,
				["coordY"] = 0.5078285336494446,
				["foundTime"] = 1579278132,
				["coordX"] = 0.335535854101181,
				["artID"] = 383,
				["atlasName"] = "VignetteKill",
			},
			[146607] = {
				["mapID"] = 896,
				["coordY"] = 0.3305632770061493,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3180270195007324,
				["artID"] = 921,
				["foundTime"] = 1570975615,
			},
			[325664] = {
				["mapID"] = 1462,
				["coordY"] = 0.2626125812530518,
				["foundTime"] = 1569685736,
				["coordX"] = 0.6410514116287231,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[327229] = {
				["mapID"] = 1530,
				["coordY"] = 0.6668639779090881,
				["foundTime"] = 1579639504,
				["coordX"] = 0.4936759769916534,
				["artID"] = 1342,
				["atlasName"] = "VignetteEvent",
			},
			[77140] = {
				["mapID"] = 539,
				["artID"] = 556,
				["foundTime"] = 1568035386,
				["coordX"] = 0.3664463460445404,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3598529994487763,
			},
			[153314] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1566932365,
				["coordX"] = 0.5235252380371094,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.255308985710144,
			},
			[128610] = {
				["mapID"] = 863,
				["coordY"] = 0.6720285415649414,
				["foundTime"] = 1577416367,
				["coordX"] = 0.4989306628704071,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[138634] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.3334884643554688,
				["coordX"] = 0.4774917960166931,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572644900,
			},
			[139319] = {
				["mapID"] = 942,
				["coordY"] = 0.284284234046936,
				["foundTime"] = 1571144433,
				["coordX"] = 0.4183684289455414,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[107127] = {
				["mapID"] = 630,
				["coordY"] = 0.4574044644832611,
				["foundTime"] = 1568298372,
				["coordX"] = 0.5514870285987854,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[127651] = {
				["mapID"] = 896,
				["coordY"] = 0.6010057926177979,
				["foundTime"] = 1572064819,
				["coordX"] = 0.7315068244934082,
				["artID"] = 921,
				["atlasName"] = "VignetteEvent",
			},
			[154153] = {
				["mapID"] = 1462,
				["coordY"] = 0.5517680644989014,
				["foundTime"] = 1566742568,
				["coordX"] = 0.553820788860321,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[140854] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3760369420051575,
				["coordX"] = 0.4742763638496399,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571835487,
			},
			[140982] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.327782928943634,
				["coordX"] = 0.6705145239830017,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570624631,
			},
			[128930] = {
				["mapID"] = 863,
				["coordY"] = 0.5487031936645508,
				["foundTime"] = 1573360780,
				["coordX"] = 0.5259196162223816,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[139419] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565919792,
				["coordX"] = 0.5685067176818848,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6901346445083618,
			},
			[140343] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.5573345422744751,
				["coordX"] = 0.7609050273895264,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567343520,
			},
			[97793] = {
				["mapID"] = 650,
				["artID"] = 674,
				["coordY"] = 0.58,
				["coordX"] = 0.412,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1568380221,
			},
			[139321] = {
				["mapID"] = 896,
				["coordY"] = 0.595876932144165,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2763534486293793,
				["artID"] = 921,
				["foundTime"] = 1577419475,
			},
			[131520] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1570021565,
				["coordX"] = 0.4783838987350464,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.2223443388938904,
			},
			[163361] = {
				["mapID"] = 1527,
				["coordY"] = 0.2929791212081909,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.344004213809967,
				["artID"] = 1343,
				["foundTime"] = 1579531802,
			},
			[148144] = {
				["mapID"] = 1203,
				["coordY"] = 0.509800374507904,
				["foundTime"] = 1567428646,
				["coordX"] = 0.588461697101593,
				["artID"] = 1165,
				["atlasName"] = "VignetteKill",
			},
			[86732] = {
				["mapID"] = 550,
				["artID"] = 567,
				["coordY"] = 0.122,
				["coordX"] = 0.61,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1579187720,
			},
			[141239] = {
				["mapID"] = 942,
				["coordY"] = 0.6324954628944397,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4226929247379303,
				["artID"] = 967,
				["foundTime"] = 1572061516,
			},
			[140344] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["coordY"] = 0.4387097358703613,
				["coordX"] = 0.3583653569221497,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569425177,
			},
			[153313] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.2334645390510559,
				["coordX"] = 0.4183965921401978,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564909124,
			},
			[127652] = {
				["mapID"] = 896,
				["coordY"] = 0.6046963930130005,
				["foundTime"] = 1572898386,
				["coordX"] = 0.728598952293396,
				["artID"] = 921,
				["atlasName"] = "VignetteEvent",
			},
			[134793] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1569422423,
				["coordX"] = 0.5561772584915161,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8034618496894836,
			},
			[279260] = {
				["mapID"] = 863,
				["coordY"] = 0.8560956120491028,
				["foundTime"] = 1573995792,
				["coordX"] = 0.3563618659973145,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[150191] = {
				["mapID"] = 1355,
				["coordY"] = 0.112368106842041,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.3690873980522156,
				["artID"] = 1186,
				["foundTime"] = 1572059215,
			},
			[90057] = {
				["mapID"] = 630,
				["coordY"] = 0.3169914782047272,
				["foundTime"] = 1568289850,
				["coordX"] = 0.5113784074783325,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[139322] = {
				["mapID"] = 896,
				["coordY"] = 0.6410086154937744,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2950240671634674,
				["artID"] = 921,
				["foundTime"] = 1573855953,
			},
			[160805] = {
				["mapID"] = 1570,
				["coordY"] = 0.6446199417114258,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.9084359407424927,
				["artID"] = 1363,
				["foundTime"] = 1579530821,
			},
			[50783] = {
				["mapID"] = 376,
				["coordY"] = 0.5427923202514648,
				["foundTime"] = 1567951093,
				["coordX"] = 0.696047842502594,
				["artID"] = 388,
				["atlasName"] = "VignetteKill",
			},
			[50815] = {
				["mapID"] = 338,
				["artID"] = 350,
				["coordY"] = 0.522,
				["coordX"] = 0.33,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1575208492,
			},
			[138675] = {
				["mapID"] = 896,
				["coordY"] = 0.259585976600647,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2799833416938782,
				["artID"] = 921,
				["foundTime"] = 1573347134,
			},
			[130338] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3703657388687134,
				["coordX"] = 0.4418883919715881,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571837951,
			},
			[90505] = {
				["mapID"] = 630,
				["coordY"] = 0.5163683891296387,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6713793277740479,
				["artID"] = 653,
				["foundTime"] = 1568374093,
			},
			[140090] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.6107821464538574,
				["coordX"] = 0.4868760704994202,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571835056,
			},
			[277561] = {
				["mapID"] = 862,
				["coordY"] = 0.6526473760604858,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4949944317340851,
				["artID"] = 887,
				["foundTime"] = 1572263180,
			},
			[154154] = {
				["mapID"] = 942,
				["coordY"] = 0.1739618182182312,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.616348385810852,
				["artID"] = 967,
				["foundTime"] = 1572131119,
			},
			[72537] = {
				["mapID"] = 539,
				["coordY"] = 0.1440145522356033,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3768782019615173,
				["artID"] = 556,
				["foundTime"] = 1568120997,
			},
			[282722] = {
				["mapID"] = 863,
				["coordY"] = 0.4742542207241058,
				["foundTime"] = 1570111337,
				["coordX"] = 0.3085923790931702,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[131704] = {
				["mapID"] = 862,
				["coordY"] = 0.1412995159626007,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6317936778068542,
				["artID"] = 887,
				["foundTime"] = 1569603289,
			},
			[297828] = {
				["mapID"] = 896,
				["coordY"] = 0.199462041258812,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.2574792802333832,
				["artID"] = 921,
				["foundTime"] = 1577415323,
			},
			[139813] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1571837238,
				["coordX"] = 0.5136840343475342,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7440041303634644,
			},
			[135999] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569424634,
				["coordX"] = 0.6910525560379028,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6368619203567505,
			},
			[136335] = {
				["mapID"] = 864,
				["coordY"] = 0.3784506022930145,
				["foundTime"] = 1573996582,
				["coordX"] = 0.6198858618736267,
				["artID"] = 889,
				["atlasName"] = "VignetteKill",
			},
			[139698] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569930755,
				["coordX"] = 0.6116009950637817,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4828022718429565,
			},
			[130439] = {
				["mapID"] = 864,
				["coordY"] = 0.1513983309268951,
				["foundTime"] = 1570025560,
				["coordX"] = 0.5470390915870667,
				["artID"] = 889,
				["atlasName"] = "VignetteKill",
			},
			[148787] = {
				["mapID"] = 62,
				["coordY"] = 0.3080493211746216,
				["foundTime"] = 1570207231,
				["coordX"] = 0.5657761096954346,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[146869] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["foundTime"] = 1571836590,
				["coordX"] = 0.4411600232124329,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7178314328193665,
			},
			[297825] = {
				["mapID"] = 896,
				["coordY"] = 0.3007924258708954,
				["foundTime"] = 1577023837,
				["coordX"] = 0.3371013402938843,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[140987] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["coordY"] = 0.5550318956375122,
				["coordX"] = 0.4504950046539307,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571835102,
			},
			[148276] = {
				["mapID"] = 862,
				["coordY"] = 0.5291576981544495,
				["foundTime"] = 1568577694,
				["coordX"] = 0.8319790959358215,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[139411] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4425232410430908,
				["coordX"] = 0.5710549354553223,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571837699,
			},
			[289647] = {
				["mapID"] = 942,
				["coordY"] = 0.1206164211034775,
				["foundTime"] = 1571747032,
				["coordX"] = 0.6692846417427063,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[153311] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1570540232,
				["coordX"] = 0.33400002,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.30200002,
			},
			[275070] = {
				["mapID"] = 895,
				["coordY"] = 0.165228009223938,
				["foundTime"] = 1573854654,
				["coordX"] = 0.5839362740516663,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[146870] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1567432327,
				["coordX"] = 0.7577398419380188,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6832576990127563,
			},
			[152113] = {
				["mapID"] = 1462,
				["coordY"] = 0.4827,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6839,
				["artID"] = 1276,
				["foundTime"] = 1564585571,
			},
			[148637] = {
				["mapID"] = 863,
				["coordY"] = 0.2250102758407593,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5235918760299683,
				["artID"] = 888,
				["foundTime"] = 1568708171,
			},
			[149659] = {
				["mapID"] = 62,
				["coordY"] = 0.3341478705406189,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3969378173351288,
				["artID"] = 1176,
				["foundTime"] = 1569599273,
			},
			[275071] = {
				["mapID"] = 895,
				["coordY"] = 0.7839559316635132,
				["foundTime"] = 1579353324,
				["coordX"] = 0.8840499520301819,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[136385] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.2379547357559204,
				["coordX"] = 0.6236034035682678,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1573733967,
			},
			[138431] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1571837724,
				["coordX"] = 0.555530309677124,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8332929015159607,
			},
			[277885] = {
				["mapID"] = 863,
				["coordY"] = 0.5498234629631042,
				["foundTime"] = 1570111324,
				["coordX"] = 0.3544997572898865,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[155055] = {
				["mapID"] = 942,
				["coordY"] = 0.3237980604171753,
				["foundTime"] = 1571322082,
				["coordX"] = 0.4767941534519196,
				["artID"] = 967,
				["atlasName"] = "VignetteEvent",
			},
			[287318] = {
				["mapID"] = 864,
				["coordY"] = 0.5846220850944519,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4718587398529053,
				["artID"] = 889,
				["foundTime"] = 1573361494,
			},
			[311902] = {
				["mapID"] = 864,
				["coordY"] = 0.4231607019901276,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4190521240234375,
				["artID"] = 889,
				["foundTime"] = 1567603464,
			},
			[137025] = {
				["mapID"] = 942,
				["coordY"] = 0.6961123943328857,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2946944534778595,
				["artID"] = 967,
				["foundTime"] = 1577424133,
			},
			[152415] = {
				["mapID"] = 1355,
				["coordY"] = 0.4170379638671875,
				["foundTime"] = 1570719934,
				["coordX"] = 0.5242451429367065,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[145465] = {
				["mapID"] = 896,
				["coordY"] = 0.4346466064453125,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2759437561035156,
				["artID"] = 921,
				["foundTime"] = 1569335422,
			},
			[138432] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1565798445,
				["coordX"] = 0.6404674053192139,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7200030088424683,
			},
			[75482] = {
				["mapID"] = 539,
				["coordY"] = 0.2097824662923813,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2175737619400024,
				["artID"] = 556,
				["foundTime"] = 1568123357,
			},
			[146872] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3481332659721375,
				["coordX"] = 0.6403172016143799,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570625079,
			},
			[149358] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569930994,
				["coordX"] = 0.4968898296356201,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4501881003379822,
			},
			[152290] = {
				["mapID"] = 1355,
				["coordY"] = 0.512630820274353,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6455634832382202,
				["artID"] = 1186,
				["foundTime"] = 1563808227,
			},
			[133190] = {
				["mapID"] = 862,
				["coordY"] = 0.3932296335697174,
				["foundTime"] = 1572265314,
				["coordX"] = 0.7416980862617493,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[311903] = {
				["mapID"] = 864,
				["coordY"] = 0.4260530471801758,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4170985817909241,
				["artID"] = 889,
				["foundTime"] = 1573361889,
			},
			[134213] = {
				["mapID"] = 896,
				["coordY"] = 0.1839195936918259,
				["foundTime"] = 1577024135,
				["coordX"] = 0.3088042438030243,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[145466] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.4316760897636414,
				["coordX"] = 0.2761807441711426,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569335413,
			},
			[97215] = {
				["mapID"] = 650,
				["coordY"] = 0.5007427930831909,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.486652672290802,
				["artID"] = 674,
				["foundTime"] = 1568387283,
			},
			[275076] = {
				["mapID"] = 895,
				["coordY"] = 0.2101535052061081,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.444883406162262,
				["artID"] = 920,
				["foundTime"] = 1577415588,
			},
			[148146] = {
				["mapID"] = 896,
				["coordY"] = 0.3576115965843201,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.308999091386795,
				["artID"] = 921,
				["foundTime"] = 1570553039,
			},
			[140991] = {
				["mapID"] = 981,
				["artID"] = 981,
				["coordY"] = 0.5314074754714966,
				["coordX"] = 0.5153030157089233,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572645276,
			},
			[279253] = {
				["mapID"] = 863,
				["coordY"] = 0.361358255147934,
				["foundTime"] = 1570027769,
				["coordX"] = 0.7768657207489014,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[302954] = {
				["mapID"] = 1161,
				["coordY"] = 0.0183513481169939,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.9191371202468872,
				["artID"] = 1138,
				["foundTime"] = 1578490582,
			},
			[152628] = {
				["mapID"] = 1527,
				["coordY"] = 0.5555481910705566,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.841895341873169,
				["artID"] = 1343,
				["foundTime"] = 1579366670,
			},
			[152756] = {
				["mapID"] = 1355,
				["coordY"] = 0.2090555429458618,
				["foundTime"] = 1569013748,
				["coordX"] = 0.4788036346435547,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[128935] = {
				["mapID"] = 863,
				["coordY"] = 0.546390950679779,
				["foundTime"] = 1573360780,
				["coordX"] = 0.5272465944290161,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[147897] = {
				["mapID"] = 62,
				["coordY"] = 0.8532842397689819,
				["foundTime"] = 1569089792,
				["coordX"] = 0.4061335325241089,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[144956] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568812492,
				["coordX"] = 0.4233638048171997,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5144338607788086,
			},
			[144997] = {
				["mapID"] = 942,
				["coordY"] = 0.4603925347328186,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4691177308559418,
				["artID"] = 967,
				["foundTime"] = 1577800274,
			},
			[325973] = {
				["mapID"] = 1527,
				["coordY"] = 0.5922669172286987,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7131128907203674,
				["artID"] = 1343,
				["foundTime"] = 1579191169,
			},
			[140777] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.7295215129852295,
				["coordX"] = 0.5951787233352661,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569849517,
			},
			[135238] = {
				["mapID"] = 1355,
				["coordY"] = 0.4607007503509522,
				["atlasName"] = "VignetteLootElite",
				["coordX"] = 0.4785045981407166,
				["artID"] = 1186,
				["foundTime"] = 1569025869,
			},
			[156849] = {
				["mapID"] = 1527,
				["coordY"] = 0.6852005124092102,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.7135091423988342,
				["artID"] = 1343,
				["foundTime"] = 1579192552,
			},
			[138563] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4222376942634583,
				["coordX"] = 0.2661415338516235,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569932377,
			},
			[155059] = {
				["mapID"] = 942,
				["coordY"] = 0.2159278094768524,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.6285325884819031,
				["artID"] = 967,
				["foundTime"] = 1571920507,
			},
			[144957] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568645874,
				["coordX"] = 0.4953894019126892,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5639976859092712,
			},
			[148154] = {
				["mapID"] = 1203,
				["coordY"] = 0.3520309925079346,
				["foundTime"] = 1567428847,
				["coordX"] = 0.5649635791778564,
				["artID"] = 1165,
				["atlasName"] = "VignetteKill",
			},
			[325974] = {
				["mapID"] = 1527,
				["coordY"] = 0.5187958478927612,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7419959902763367,
				["artID"] = 1343,
				["foundTime"] = 1579366947,
			},
			[138938] = {
				["mapID"] = 942,
				["coordY"] = 0.3832090795040131,
				["foundTime"] = 1569232326,
				["coordX"] = 0.3305681347846985,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[106351] = {
				["mapID"] = 680,
				["coordY"] = 0.1486405581235886,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.336281955242157,
				["artID"] = 704,
				["foundTime"] = 1568374872,
			},
			[136390] = {
				["mapID"] = 864,
				["coordY"] = 0.5359719395637512,
				["foundTime"] = 1570816902,
				["coordX"] = 0.5606528520584106,
				["artID"] = 889,
				["atlasName"] = "VignetteKill",
			},
			[153206] = {
				["mapID"] = 1462,
				["coordY"] = 0.38020458817482,
				["foundTime"] = 1569082051,
				["coordX"] = 0.5574030876159668,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[303170] = {
				["mapID"] = 942,
				["coordY"] = 0.6965036392211914,
				["foundTime"] = 1570032943,
				["coordX"] = 0.3288314044475555,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[147260] = {
				["mapID"] = 62,
				["coordY"] = 0.6203259825706482,
				["foundTime"] = 1569089739,
				["coordX"] = 0.3928767144680023,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[148155] = {
				["mapID"] = 896,
				["coordY"] = 0.375231921672821,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3372327387332916,
				["artID"] = 921,
				["foundTime"] = 1570975684,
			},
			[277896] = {
				["mapID"] = 896,
				["coordY"] = 0.6688476800918579,
				["foundTime"] = 1570195395,
				["coordX"] = 0.6799048781394958,
				["artID"] = 921,
				["atlasName"] = "VignetteEvent",
			},
			[140995] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["foundTime"] = 1569424421,
				["coordX"] = 0.5299419164657593,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.444659411907196,
			},
			[124397] = {
				["mapID"] = 863,
				["coordY"] = 0.1315522193908691,
				["foundTime"] = 1570028002,
				["coordX"] = 0.5290763974189758,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[128699] = {
				["mapID"] = 862,
				["coordY"] = 0.1829797327518463,
				["foundTime"] = 1570296551,
				["coordX"] = 0.5984519124031067,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[131404] = {
				["mapID"] = 942,
				["coordY"] = 0.6591660380363464,
				["foundTime"] = 1577456112,
				["coordX"] = 0.6443019509315491,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[50338] = {
				["mapID"] = 371,
				["coordY"] = 0.762445867061615,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4362932443618774,
				["artID"] = 383,
				["foundTime"] = 1567857345,
			},
			[277715] = {
				["mapID"] = 863,
				["coordY"] = 0.5078296065330505,
				["foundTime"] = 1573364054,
				["coordX"] = 0.4306012988090515,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[146110] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.2483599185943604,
				["coordX"] = 0.5397177934646606,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564240781,
			},
			[146238] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1571837147,
				["coordX"] = 0.4554972052574158,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3929556608200073,
			},
			[139205] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1570801975,
				["coordX"] = 0.643190324306488,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6329596042633057,
			},
			[275074] = {
				["mapID"] = 895,
				["coordY"] = 0.2136168926954269,
				["foundTime"] = 1577799784,
				["coordX"] = 0.670333981513977,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[326409] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.49193,
				["coordX"] = 0.39713,
				["atlasName"] = "VignetteLoot",
				["foundTime"] = 1564908037,
			},
			[126635] = {
				["mapID"] = 863,
				["coordY"] = 0.9137158989906311,
				["foundTime"] = 1570200702,
				["coordX"] = 0.4320735633373261,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[145161] = {
				["mapID"] = 1161,
				["coordY"] = 0.6612594127655029,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3199673295021057,
				["artID"] = 1138,
				["foundTime"] = 1575203762,
			},
			[136857] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1568818103,
				["coordX"] = 0.5748370885848999,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6878184676170349,
			},
			[139817] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568812248,
				["coordX"] = 0.5045427083969116,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.802615761756897,
			},
			[325981] = {
				["mapID"] = 1527,
				["coordY"] = 0.4679897725582123,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7634319067001343,
				["artID"] = 1343,
				["foundTime"] = 1579366647,
			},
			[104513] = {
				["mapID"] = 650,
				["coordY"] = 0.486039936542511,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5665749311447144,
				["artID"] = 674,
				["foundTime"] = 1568387332,
			},
			[140357] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.4217172861099243,
				["coordX"] = 0.4637579917907715,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564925045,
			},
			[94347] = {
				["mapID"] = 634,
				["coordY"] = 0.6360675096511841,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.744911789894104,
				["artID"] = 657,
				["foundTime"] = 1568379447,
			},
			[138568] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.3875377774238586,
				["coordX"] = 0.3579469323158264,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570628098,
			},
			[138473] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920410,
				["coordX"] = 0.5748206377029419,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4265384078025818,
			},
			[325984] = {
				["mapID"] = 1527,
				["coordY"] = 0.305990606546402,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6134695410728455,
				["artID"] = 1343,
				["foundTime"] = 1579366579,
			},
			[140997] = {
				["mapID"] = 942,
				["coordY"] = 0.7328947186470032,
				["foundTime"] = 1570816346,
				["coordX"] = 0.2249222695827484,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[128426] = {
				["mapID"] = 863,
				["coordY"] = 0.4312819242477417,
				["foundTime"] = 1570026101,
				["coordX"] = 0.3276418447494507,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[139417] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1564583254,
				["coordX"] = 0.6067830324172974,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4394235610961914,
			},
			[129961] = {
				["mapID"] = 862,
				["coordY"] = 0.2160585075616837,
				["foundTime"] = 1570030735,
				["coordX"] = 0.8096948862075806,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[97928] = {
				["mapID"] = 650,
				["coordY"] = 0.1077659130096436,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.431803435087204,
				["artID"] = 674,
				["foundTime"] = 1568375783,
			},
			[163120] = {
				["mapID"] = 1527,
				["coordY"] = 0.2983224093914032,
				["foundTime"] = 1579361680,
				["coordX"] = 0.6446269154548645,
				["artID"] = 1343,
				["atlasName"] = "VignetteEvent",
			},
			[291204] = {
				["mapID"] = 896,
				["coordY"] = 0.234693169593811,
				["foundTime"] = 1577419743,
				["coordX"] = 0.5921428799629211,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[148031] = {
				["mapID"] = 62,
				["coordY"] = 0.564441978931427,
				["foundTime"] = 1569089731,
				["coordX"] = 0.4091095328330994,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[146113] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["foundTime"] = 1569424111,
				["coordX"] = 0.383022665977478,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4244574904441834,
			},
			[136011] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568812125,
				["coordX"] = 0.6344512701034546,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5887031555175781,
			},
			[127979] = {
				["mapID"] = 896,
				["coordY"] = 0.6966232061386108,
				["foundTime"] = 1573367742,
				["coordX"] = 0.6306862235069275,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[153658] = {
				["mapID"] = 1355,
				["coordY"] = 0.1677008271217346,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3939948081970215,
				["artID"] = 1186,
				["foundTime"] = 1575111346,
			},
			[138441] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4388901591300964,
				["coordX"] = 0.5867986679077148,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567008085,
			},
			[138569] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.5068192481994629,
				["coordX"] = 0.7541075348854065,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567343556,
			},
			[152569] = {
				["mapID"] = 1462,
				["coordY"] = 0.2093121856451035,
				["foundTime"] = 1569686176,
				["coordX"] = 0.8245280981063843,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[138825] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1564922197,
				["coordX"] = 0.5807844400405884,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8363896012306213,
			},
			[152892] = {
				["mapID"] = 1462,
				["artID"] = 1276,
				["foundTime"] = 1566391316,
				["coordX"] = 0.7069134712219238,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3852438926696777,
			},
			[316780] = {
				["mapID"] = 863,
				["coordY"] = 0.1009971052408218,
				["atlasName"] = "VignetteLootElite",
				["coordX"] = 0.6011815071105957,
				["artID"] = 888,
				["foundTime"] = 1568709498,
			},
			[124399] = {
				["mapID"] = 863,
				["coordY"] = 0.7749007344245911,
				["foundTime"] = 1570112357,
				["coordX"] = 0.2451031804084778,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[140360] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.8168452978134155,
				["coordX"] = 0.3435608744621277,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564925129,
			},
			[138442] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1571837309,
				["coordX"] = 0.7151713371276855,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7212041616439819,
			},
			[126637] = {
				["mapID"] = 862,
				["coordY"] = 0.4876110553741455,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6865893006324768,
				["artID"] = 887,
				["foundTime"] = 1573365036,
			},
			[154968] = {
				["mapID"] = 1462,
				["coordY"] = 0.4979767501354218,
				["foundTime"] = 1566742034,
				["coordX"] = 0.5333603620529175,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[138826] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569764994,
				["coordX"] = 0.5872137546539307,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8386731743812561,
			},
			[145041] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3504912257194519,
				["coordX"] = 0.4584248661994934,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007413,
			},
			[138827] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568812360,
				["coordX"] = 0.4488836526870728,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8468793034553528,
			},
			[126460] = {
				["mapID"] = 863,
				["coordY"] = 0.381827712059021,
				["foundTime"] = 1570111369,
				["coordX"] = 0.3146992921829224,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[140361] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1571837536,
				["coordX"] = 0.5562286376953125,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7488114833831787,
			},
			[138443] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1571835167,
				["coordX"] = 0.629442036151886,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.2442371249198914,
			},
			[94413] = {
				["mapID"] = 634,
				["coordY"] = 0.6046205759048462,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6206340193748474,
				["artID"] = 657,
				["foundTime"] = 1568379357,
			},
			[157525] = {
				["mapID"] = 1530,
				["coordY"] = 0.2178856432437897,
				["foundTime"] = 1579714969,
				["coordX"] = 0.6929396390914917,
				["artID"] = 1342,
				["atlasName"] = "VignetteEvent",
			},
			[241127] = {
				["mapID"] = 641,
				["coordY"] = 0.7761557698249817,
				["foundTime"] = 1572182293,
				["coordX"] = 0.5555793642997742,
				["artID"] = 664,
				["atlasName"] = "VignetteEvent",
			},
			[141029] = {
				["mapID"] = 942,
				["coordY"] = 0.617177426815033,
				["foundTime"] = 1569600018,
				["coordX"] = 0.3130332827568054,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[153305] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563804895,
				["coordX"] = 0.684,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.33400002,
			},
			[151934] = {
				["mapID"] = 1462,
				["coordY"] = 0.4054615199565888,
				["foundTime"] = 1569686439,
				["coordX"] = 0.5290257930755615,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[140362] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1567343216,
				["coordX"] = 0.4079307913780212,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4740597009658814,
			},
			[143559] = {
				["mapID"] = 1161,
				["artID"] = 1138,
				["coordY"] = 0.2607061862945557,
				["coordX"] = 0.563530445098877,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1574591966,
			},
			[148025] = {
				["mapID"] = 62,
				["coordY"] = 0.762427031993866,
				["foundTime"] = 1569089757,
				["coordX"] = 0.3794506192207336,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[241128] = {
				["mapID"] = 641,
				["coordY"] = 0.7761567831039429,
				["foundTime"] = 1568290671,
				["coordX"] = 0.5555793642997742,
				["artID"] = 664,
				["atlasName"] = "VignetteEvent",
			},
			[129835] = {
				["mapID"] = 896,
				["coordY"] = 0.4431462585926056,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5711885094642639,
				["artID"] = 921,
				["foundTime"] = 1570114503,
			},
			[280522] = {
				["mapID"] = 863,
				["coordY"] = 0.4636207818984985,
				["foundTime"] = 1570111889,
				["coordX"] = 0.7789798974990845,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[291211] = {
				["mapID"] = 896,
				["coordY"] = 0.3308037519454956,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4347178936004639,
				["artID"] = 921,
				["foundTime"] = 1577023812,
			},
			[138446] = {
				["mapID"] = 981,
				["artID"] = 981,
				["coordY"] = 0.3744603395462036,
				["coordX"] = 0.6160696744918823,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567944227,
			},
			[132179] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.586164712905884,
				["coordX"] = 0.647706508636475,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571748306,
			},
			[143560] = {
				["mapID"] = 1161,
				["artID"] = 1138,
				["coordY"] = 0.2560635805130005,
				["coordX"] = 0.5644993185997009,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1574591982,
			},
			[126907] = {
				["mapID"] = 863,
				["coordY"] = 0.507702112197876,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4897392988204956,
				["artID"] = 888,
				["foundTime"] = 1573360834,
			},
			[155069] = {
				["mapID"] = 942,
				["coordY"] = 0.6997602581977844,
				["foundTime"] = 1572133809,
				["coordX"] = 0.6632782220840454,
				["artID"] = 967,
				["atlasName"] = "VignetteEvent",
			},
			[281494] = {
				["mapID"] = 942,
				["coordY"] = 0.8410260677337646,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.489747017621994,
				["artID"] = 967,
				["foundTime"] = 1570538158,
			},
			[133842] = {
				["mapID"] = 862,
				["coordY"] = 0.2543765306472778,
				["foundTime"] = 1570030142,
				["coordX"] = 0.439351499080658,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[291213] = {
				["mapID"] = 896,
				["coordY"] = 0.4442796111106873,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6038894653320312,
				["artID"] = 921,
				["foundTime"] = 1577419100,
			},
			[146143] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568645884,
				["coordX"] = 0.4990784525871277,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5577128529548645,
			},
			[98890] = {
				["mapID"] = 650,
				["coordY"] = 0.3177423775196075,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4148254096508026,
				["artID"] = 674,
				["foundTime"] = 1568376345,
			},
			[139469] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4190733432769775,
				["coordX"] = 0.41632080078125,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571837345,
			},
			[129005] = {
				["mapID"] = 863,
				["coordY"] = 0.4283689856529236,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5342261791229248,
				["artID"] = 888,
				["foundTime"] = 1570200152,
			},
			[152001] = {
				["mapID"] = 1462,
				["coordY"] = 0.227863684296608,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6566863059997559,
				["artID"] = 1276,
				["foundTime"] = 1569685476,
			},
			[138830] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.4734777212142944,
				["coordX"] = 0.6072679758071899,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567867412,
			},
			[133843] = {
				["mapID"] = 864,
				["artID"] = 889,
				["foundTime"] = 1572065147,
				["coordX"] = 0.4140159785747528,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.2414686232805252,
			},
			[146247] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564581955,
				["coordX"] = 0.6257898807525635,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4569714665412903,
			},
			[154559] = {
				["mapID"] = 1530,
				["coordY"] = 0.6778900027275085,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.680027425289154,
				["artID"] = 1342,
				["foundTime"] = 1579714690,
			},
			[325662] = {
				["mapID"] = 1462,
				["coordY"] = 0.5320271849632263,
				["foundTime"] = 1569685563,
				["coordX"] = 0.6540651917457581,
				["artID"] = 1276,
				["atlasName"] = "VignetteLoot",
			},
			[155838] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.509932816028595,
				["coordX"] = 0.791060209274292,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1575166527,
			},
			[273956] = {
				["mapID"] = 895,
				["coordY"] = 0.2412500083446503,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.5455029010772705,
				["artID"] = 920,
				["foundTime"] = 1578312289,
			},
			[131262] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.153003871440887,
				["coordX"] = 0.388924062252045,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564904072,
			},
			[138831] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568812326,
				["coordX"] = 0.6020311117172241,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4574467539787293,
			},
			[134296] = {
				["mapID"] = 863,
				["coordY"] = 0.2023287415504456,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6810042858123779,
				["artID"] = 888,
				["foundTime"] = 1572439354,
			},
			[291217] = {
				["mapID"] = 896,
				["coordY"] = 0.5425245761871338,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6519326567649841,
				["artID"] = 921,
				["foundTime"] = 1577414785,
			},
			[155583] = {
				["mapID"] = 1462,
				["coordY"] = 0.7772676348686218,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8229547142982483,
				["artID"] = 1276,
				["foundTime"] = 1566133455,
			},
			[132182] = {
				["mapID"] = 895,
				["coordY"] = 0.7894518971443176,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7491134405136108,
				["artID"] = 920,
				["foundTime"] = 1572065004,
			},
			[139471] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.3180161118507385,
				["coordX"] = 0.4966437816619873,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571838027,
			},
			[137553] = {
				["mapID"] = 864,
				["artID"] = 889,
				["coordY"] = 0.626,
				["coordX"] = 0.606,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569270978,
			},
			[137681] = {
				["mapID"] = 864,
				["coordY"] = 0.4140233993530273,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3827857077121735,
				["artID"] = 889,
				["foundTime"] = 1569016757,
			},
			[98421] = {
				["mapID"] = 634,
				["coordY"] = 0.4681720733642578,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7264209389686584,
				["artID"] = 657,
				["foundTime"] = 1568378401,
			},
			[154944] = {
				["mapID"] = 942,
				["coordY"] = 0.6997591853141785,
				["foundTime"] = 1572134202,
				["coordX"] = 0.6633256673812866,
				["artID"] = 967,
				["atlasName"] = "VignetteLootElite",
			},
			[148295] = {
				["mapID"] = 62,
				["artID"] = 1176,
				["coordY"] = 0.361,
				["coordX"] = 0.412,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569599424,
			},
			[155836] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.6553937792778015,
				["coordX"] = 0.4939302206039429,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564236175,
			},
			[139472] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4218864440917969,
				["coordX"] = 0.6037552356719971,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567008091,
			},
			[148679] = {
				["mapID"] = 863,
				["coordY"] = 0.05067466199398041,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6268712878227234,
				["artID"] = 888,
				["foundTime"] = 1568708416,
			},
			[136834] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4367412328720093,
				["coordX"] = 0.5896376371383667,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571836129,
			},
			[139290] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1567259589,
				["coordX"] = 0.585159420967102,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.494630873203278,
			},
			[96590] = {
				["mapID"] = 650,
				["coordY"] = 0.607332706451416,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5685487985610962,
				["artID"] = 674,
				["foundTime"] = 1568386238,
			},
			[145415] = {
				["mapID"] = 942,
				["coordY"] = 0.4803451001644135,
				["foundTime"] = 1577800307,
				["coordX"] = 0.3738290965557098,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[140112] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.377318799495697,
				["coordX"] = 0.488379180431366,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572646674,
			},
			[126449] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1571837097,
				["coordX"] = 0.580394446849823,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.822287917137146,
			},
			[152182] = {
				["mapID"] = 1462,
				["coordY"] = 0.7917572855949402,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6583449840545654,
				["artID"] = 1276,
				["foundTime"] = 1569686366,
			},
			[155841] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1575166470,
				["coordX"] = 0.734,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.314,
			},
			[291222] = {
				["mapID"] = 896,
				["coordY"] = 0.6191490888595581,
				["foundTime"] = 1573367757,
				["coordX"] = 0.5943509340286255,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[157120] = {
				["mapID"] = 1527,
				["coordY"] = 0.6816902756690979,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7504633665084839,
				["artID"] = 1343,
				["foundTime"] = 1579192523,
			},
			[278436] = {
				["mapID"] = 863,
				["coordY"] = 0.1734681725502014,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.667924702167511,
				["artID"] = 888,
				["foundTime"] = 1572439419,
			},
			[291259] = {
				["mapID"] = 942,
				["coordY"] = 0.5320200324058533,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4094040393829346,
				["artID"] = 967,
				["foundTime"] = 1577800962,
			},
			[334189] = {
				["mapID"] = 1530,
				["coordY"] = 0.4180483222007752,
				["foundTime"] = 1579639752,
				["coordX"] = 0.5388801097869873,
				["artID"] = 1342,
				["atlasName"] = "VignetteLoot",
			},
			[156993] = {
				["mapID"] = 1527,
				["coordY"] = 0.503006100654602,
				["foundTime"] = 1579284584,
				["coordX"] = 0.6651955842971802,
				["artID"] = 1343,
				["atlasName"] = "VignetteEvent",
			},
			[139346] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["coordY"] = 0.3333336710929871,
				["coordX"] = 0.3727111220359802,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569425105,
			},
			[139474] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1569424789,
				["coordX"] = 0.5932462811470032,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3883950114250183,
			},
			[291224] = {
				["mapID"] = 896,
				["coordY"] = 0.1667737811803818,
				["foundTime"] = 1578312305,
				["coordX"] = 0.3334358930587769,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[157266] = {
				["mapID"] = 1530,
				["coordY"] = 0.5918591022491455,
				["foundTime"] = 1579714380,
				["coordX"] = 0.4815217256546021,
				["artID"] = 1342,
				["atlasName"] = "VignetteKill",
			},
			[154180] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.5921164751052856,
				["coordX"] = 0.3799697160720825,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564075747,
			},
			[139529] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1569849658,
				["coordX"] = 0.4560043215751648,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7053842544555664,
			},
			[291225] = {
				["mapID"] = 896,
				["coordY"] = 0.3168163299560547,
				["foundTime"] = 1577415267,
				["coordX"] = 0.2667239606380463,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[139475] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564582186,
				["coordX"] = 0.4208597540855408,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5431439876556396,
			},
			[151623] = {
				["mapID"] = 1462,
				["coordY"] = 0.5012,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7227,
				["artID"] = 1276,
				["foundTime"] = 1569684692,
			},
			[278694] = {
				["mapID"] = 862,
				["coordY"] = 0.2092091739177704,
				["foundTime"] = 1570030688,
				["coordX"] = 0.7639813423156738,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[163132] = {
				["mapID"] = 1527,
				["coordY"] = 0.4796346127986908,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.7608276009559631,
				["artID"] = 1343,
				["foundTime"] = 1579366655,
			},
			[236916] = {
				["mapID"] = 582,
				["coordY"] = 0.3151673078536987,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3716474175453186,
				["artID"] = 602,
				["foundTime"] = 1568243822,
			},
			[293350] = {
				["mapID"] = 942,
				["coordY"] = 0.735307514667511,
				["foundTime"] = 1573732438,
				["coordX"] = 0.4443886578083038,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[138445] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1565916928,
				["coordX"] = 0.4776913523674011,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5790448188781738,
			},
			[291227] = {
				["mapID"] = 896,
				["coordY"] = 0.4028444290161133,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.2459205985069275,
				["artID"] = 921,
				["foundTime"] = 1573854432,
			},
			[92180] = {
				["mapID"] = 641,
				["coordY"] = 0.7825093865394592,
				["foundTime"] = 1568292350,
				["coordX"] = 0.4161238670349121,
				["artID"] = 664,
				["atlasName"] = "VignetteKill",
			},
			[139348] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569425421,
				["coordX"] = 0.6137281656265259,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8566805124282837,
			},
			[136336] = {
				["mapID"] = 864,
				["coordY"] = 0.6507019996643066,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3270649909973145,
				["artID"] = 889,
				["foundTime"] = 1573363336,
			},
			[291228] = {
				["mapID"] = 896,
				["coordY"] = 0.5269994139671326,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.2313000708818436,
				["artID"] = 921,
				["foundTime"] = 1573855659,
			},
			[334223] = {
				["mapID"] = 1530,
				["coordY"] = 0.6853326559066772,
				["foundTime"] = 1579639510,
				["coordX"] = 0.4419025778770447,
				["artID"] = 1342,
				["atlasName"] = "VignetteLoot",
			},
			[134745] = {
				["mapID"] = 864,
				["coordY"] = 0.3645614087581635,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5129411220550537,
				["artID"] = 889,
				["foundTime"] = 1569674383,
			},
			[139988] = {
				["mapID"] = 942,
				["artID"] = 967,
				["coordY"] = 0.6064436435699463,
				["coordX"] = 0.7351427674293518,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572440998,
			},
			[291229] = {
				["mapID"] = 896,
				["coordY"] = 0.6051656007766724,
				["foundTime"] = 1573855659,
				["coordX"] = 0.2431748956441879,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[128497] = {
				["mapID"] = 864,
				["coordY"] = 0.8108786344528198,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3100311458110809,
				["artID"] = 889,
				["foundTime"] = 1569019837,
			},
			[151625] = {
				["mapID"] = 1462,
				["coordY"] = 0.4900919497013092,
				["foundTime"] = 1563800760,
				["coordX"] = 0.7103789448738098,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[92599] = {
				["mapID"] = 634,
				["coordY"] = 0.3871516585350037,
				["foundTime"] = 1568385671,
				["coordX"] = 0.3960913121700287,
				["artID"] = 657,
				["atlasName"] = "VignetteKill",
			},
			[291230] = {
				["mapID"] = 896,
				["coordY"] = 0.5944631099700928,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3766935169696808,
				["artID"] = 921,
				["foundTime"] = 1570972692,
			},
			[151719] = {
				["mapID"] = 1355,
				["coordY"] = 0.3456892371177673,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.671718955039978,
				["artID"] = 1186,
				["foundTime"] = 1569083800,
			},
			[74206] = {
				["mapID"] = 539,
				["coordY"] = 0.4459301829338074,
				["foundTime"] = 1568035199,
				["coordX"] = 0.4078861474990845,
				["artID"] = 556,
				["atlasName"] = "VignetteKill",
			},
			[148428] = {
				["mapID"] = 862,
				["artID"] = 887,
				["foundTime"] = 1568576656,
				["coordX"] = 0.7496148347854614,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4912689924240112,
			},
			[152729] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3394231796264648,
				["coordX"] = 0.8385803699493408,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1577377487,
			},
			[139145] = {
				["mapID"] = 895,
				["coordY"] = 0.7343687415122986,
				["foundTime"] = 1578059781,
				["coordX"] = 0.8525850772857666,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[155840] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.3220067024230957,
				["coordX"] = 0.4742978811264038,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572034761,
			},
			[156869] = {
				["mapID"] = 1527,
				["coordY"] = 0.5754558444023132,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.7820659279823303,
				["artID"] = 1343,
				["foundTime"] = 1579190777,
			},
			[90164] = {
				["mapID"] = 630,
				["coordY"] = 0.5335838198661804,
				["foundTime"] = 1568297437,
				["coordX"] = 0.4776794016361237,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[153300] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.69,
				["coordX"] = 0.42200002,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567257560,
			},
			[145287] = {
				["mapID"] = 1161,
				["coordY"] = 0.4134030044078827,
				["foundTime"] = 1568644492,
				["coordX"] = 0.7717565894126892,
				["artID"] = 1138,
				["atlasName"] = "VignetteKill",
			},
			[144722] = {
				["mapID"] = 895,
				["coordY"] = 0.3759651482105255,
				["foundTime"] = 1570701971,
				["coordX"] = 0.7924480438232422,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[291254] = {
				["mapID"] = 942,
				["coordY"] = 0.4031530022621155,
				["foundTime"] = 1573850938,
				["coordX"] = 0.6120372414588928,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[156614] = {
				["mapID"] = 1527,
				["coordY"] = 0.2270469963550568,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.6444364190101624,
				["artID"] = 1343,
				["foundTime"] = 1579361718,
			},
			[151627] = {
				["mapID"] = 1462,
				["coordY"] = 0.6144568920135498,
				["foundTime"] = 1566391913,
				["coordX"] = 0.6102732419967651,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[90775] = {
				["mapID"] = 630,
				["coordY"] = 0.4002343714237213,
				["foundTime"] = 1568287073,
				["coordX"] = 0.651219367980957,
				["artID"] = 653,
				["atlasName"] = "VignetteEvent",
			},
			[151883] = {
				["mapID"] = 1527,
				["coordY"] = 0.5226050019264221,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7141168117523193,
				["artID"] = 1343,
				["foundTime"] = 1579366649,
			},
			[135643] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.8459722399711609,
				["coordX"] = 0.4123024344444275,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572646879,
			},
			[50883] = {
				["mapID"] = 539,
				["coordY"] = 0.4399527013301849,
				["foundTime"] = 1568035081,
				["coordX"] = 0.4406917691230774,
				["artID"] = 556,
				["atlasName"] = "VignetteKill",
			},
			[95123] = {
				["mapID"] = 641,
				["coordY"] = 0.53433758020401,
				["foundTime"] = 1570208148,
				["coordX"] = 0.6579618453979492,
				["artID"] = 664,
				["atlasName"] = "VignetteKill",
			},
			[137665] = {
				["mapID"] = 896,
				["coordY"] = 0.5394806861877441,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.249056950211525,
				["artID"] = 921,
				["foundTime"] = 1572898803,
			},
			[154578] = {
				["mapID"] = 1527,
				["coordY"] = 0.3876189589500427,
				["foundTime"] = 1579618244,
				["coordX"] = 0.4184028208255768,
				["artID"] = 1343,
				["atlasName"] = "VignetteKill",
			},
			[149847] = {
				["mapID"] = 1462,
				["coordY"] = 0.2093054950237274,
				["foundTime"] = 1565917597,
				["coordX"] = 0.8245287537574768,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[132319] = {
				["mapID"] = 896,
				["coordY"] = 0.3325970470905304,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3505832254886627,
				["artID"] = 921,
				["foundTime"] = 1573854740,
			},
			[290725] = {
				["mapID"] = 862,
				["coordY"] = 0.4719313383102417,
				["foundTime"] = 1570205798,
				["coordX"] = 0.5296496748924255,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[144987] = {
				["mapID"] = 942,
				["coordY"] = 0.5195040106773376,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3644067645072937,
				["artID"] = 967,
				["foundTime"] = 1569599912,
			},
			[327553] = {
				["mapID"] = 1530,
				["coordY"] = 0.3314825296401978,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.7925209403038025,
				["artID"] = 1342,
				["foundTime"] = 1579639829,
			},
			[280751] = {
				["mapID"] = 895,
				["coordY"] = 0.1207813993096352,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4100187420845032,
				["artID"] = 920,
				["foundTime"] = 1577419789,
			},
			[141143] = {
				["mapID"] = 942,
				["coordY"] = 0.5705834627151489,
				["foundTime"] = 1573733736,
				["coordX"] = 0.6157293319702148,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[139353] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["foundTime"] = 1569424310,
				["coordX"] = 0.4802262187004089,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4335066676139832,
			},
			[327554] = {
				["mapID"] = 1530,
				["coordY"] = 0.593210756778717,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.5668133497238159,
				["artID"] = 1342,
				["foundTime"] = 1579714684,
			},
			[72362] = {
				["mapID"] = 539,
				["coordY"] = 0.3507404029369354,
				["foundTime"] = 1568035636,
				["coordX"] = 0.3245202302932739,
				["artID"] = 556,
				["atlasName"] = "VignetteKill",
			},
			[136892] = {
				["mapID"] = 981,
				["artID"] = 981,
				["coordY"] = 0.5247941017150879,
				["coordX"] = 0.677797794342041,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567944039,
			},
			[140760] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.2760408520698547,
				["coordX"] = 0.5592336654663086,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571754011,
			},
			[138842] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569764970,
				["coordX"] = 0.7346713542938232,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6870168447494507,
			},
			[146131] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.45807945728302,
				["coordX"] = 0.3808413743972778,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1568645366,
			},
			[152397] = {
				["mapID"] = 1355,
				["coordY"] = 0.2500696182250977,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7813016176223755,
				["artID"] = 1186,
				["foundTime"] = 1572185690,
			},
			[137180] = {
				["mapID"] = 895,
				["coordY"] = 0.1937957108020783,
				["foundTime"] = 1577798322,
				["coordX"] = 0.6430521011352539,
				["artID"] = 920,
				["atlasName"] = "VignetteEvent",
			},
			[139354] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568818727,
				["coordX"] = 0.7288545370101929,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7233660221099854,
			},
			[148563] = {
				["mapID"] = 896,
				["coordY"] = 0.5074164271354675,
				["foundTime"] = 1573850167,
				["coordX"] = 0.402098536491394,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[135648] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582567,
				["coordX"] = 0.4200963377952576,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8000352382659912,
			},
			[297892] = {
				["mapID"] = 896,
				["coordY"] = 0.2769678831100464,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4421927034854889,
				["artID"] = 921,
				["foundTime"] = 1570708212,
			},
			[138843] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4133331775665283,
				["coordX"] = 0.5637351870536804,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567343034,
			},
			[278456] = {
				["mapID"] = 862,
				["coordY"] = 0.1827677339315414,
				["foundTime"] = 1570112832,
				["coordX"] = 0.5776041746139526,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[145112] = {
				["mapID"] = 895,
				["coordY"] = 0.4307567179203033,
				["foundTime"] = 1576860395,
				["coordX"] = 0.767216682434082,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[151124] = {
				["mapID"] = 1462,
				["coordY"] = 0.5210065245628357,
				["foundTime"] = 1569081533,
				["coordX"] = 0.5691445469856262,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[297891] = {
				["mapID"] = 896,
				["coordY"] = 0.6585321426391602,
				["foundTime"] = 1570554031,
				["coordX"] = 0.632999837398529,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[146773] = {
				["mapID"] = 895,
				["coordY"] = 0.4760339856147766,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8477122187614441,
				["artID"] = 920,
				["foundTime"] = 1578490836,
			},
			[144855] = {
				["mapID"] = 896,
				["coordY"] = 0.4160018265247345,
				["foundTime"] = 1573850497,
				["coordX"] = 0.3526655733585358,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[146134] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569424904,
				["coordX"] = 0.3803480267524719,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6227327585220337,
			},
			[138844] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569419137,
				["coordX"] = 0.4708366394042969,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3777996301651001,
			},
			[132068] = {
				["mapID"] = 895,
				["coordY"] = 0.3035782277584076,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3450413942337036,
				["artID"] = 920,
				["foundTime"] = 1572064514,
			},
			[138846] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1571836787,
				["coordX"] = 0.2498452663421631,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4293901920318604,
			},
			[334215] = {
				["mapID"] = 1530,
				["coordY"] = 0.5159545540809631,
				["foundTime"] = 1579714905,
				["coordX"] = 0.6203892827033997,
				["artID"] = 1342,
				["atlasName"] = "VignetteLoot",
			},
			[154701] = {
				["mapID"] = 1462,
				["coordY"] = 0.5430490970611572,
				["foundTime"] = 1566574925,
				["coordX"] = 0.7003786563873291,
				["artID"] = 1276,
				["atlasName"] = "VignetteKill",
			},
			[134754] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.4948560297489166,
				["coordX"] = 0.2293815016746521,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1572898892,
			},
			[291244] = {
				["mapID"] = 942,
				["coordY"] = 0.5113599300384521,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7071247100830078,
				["artID"] = 967,
				["foundTime"] = 1577456082,
			},
			[50344] = {
				["mapID"] = 388,
				["coordY"] = 0.6349052786827087,
				["foundTime"] = 1572529143,
				["coordX"] = 0.5389165282249451,
				["artID"] = 400,
				["atlasName"] = "VignetteKill",
			},
			[278461] = {
				["mapID"] = 862,
				["coordY"] = 0.2450855821371079,
				["foundTime"] = 1570030229,
				["coordX"] = 0.4599752128124237,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[278713] = {
				["mapID"] = 862,
				["coordY"] = 0.2752240598201752,
				["foundTime"] = 1570030523,
				["coordX"] = 0.6582620143890381,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[154447] = {
				["mapID"] = 1530,
				["coordY"] = 0.4095928370952606,
				["foundTime"] = 1579714906,
				["coordX"] = 0.5710684061050415,
				["artID"] = 1342,
				["atlasName"] = "VignetteKill",
			},
			[137183] = {
				["mapID"] = 895,
				["coordY"] = 0.1963558048009872,
				["foundTime"] = 1566140080,
				["coordX"] = 0.6403713226318359,
				["artID"] = 920,
				["atlasName"] = "VignetteEvent",
			},
			[280504] = {
				["mapID"] = 863,
				["coordY"] = 0.6214287877082825,
				["foundTime"] = 1570111867,
				["coordX"] = 0.7687780261039734,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[298920] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.486,
				["coordX"] = 0.244,
				["atlasName"] = "VignetteLoot",
				["foundTime"] = 1570552939,
			},
			[291246] = {
				["mapID"] = 942,
				["coordY"] = 0.4306470155715942,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6802030205726624,
				["artID"] = 967,
				["foundTime"] = 1573850977,
			},
			[139486] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920199,
				["coordX"] = 0.2100303173065186,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4873050451278687,
			},
			[278459] = {
				["mapID"] = 862,
				["coordY"] = 0.6251455545425415,
				["foundTime"] = 1570367036,
				["coordX"] = 0.4581110179424286,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[153296] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.414139449596405,
				["coordX"] = 0.336714506149292,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564912563,
			},
			[334213] = {
				["mapID"] = 1530,
				["coordY"] = 0.2782274782657623,
				["foundTime"] = 1579714965,
				["coordX"] = 0.6721922755241394,
				["artID"] = 1342,
				["atlasName"] = "VignetteLoot",
			},
			[278460] = {
				["mapID"] = 862,
				["coordY"] = 0.3984197676181793,
				["foundTime"] = 1569762580,
				["coordX"] = 0.4885445833206177,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[160841] = {
				["mapID"] = 1570,
				["coordY"] = 0.6909950971603394,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8790690898895264,
				["artID"] = 1363,
				["foundTime"] = 1579467359,
			},
			[278716] = {
				["mapID"] = 862,
				["coordY"] = 0.6068433523178101,
				["foundTime"] = 1570031070,
				["coordX"] = 0.7259260416030884,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[294317] = {
				["mapID"] = 864,
				["coordY"] = 0.8574492335319519,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4057031273841858,
				["artID"] = 889,
				["foundTime"] = 1569020043,
			},
			[125816] = {
				["mapID"] = 1165,
				["coordY"] = 0.8404674530029297,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5003560781478882,
				["artID"] = 1143,
				["foundTime"] = 1569602964,
			},
			[137824] = {
				["mapID"] = 896,
				["coordY"] = 0.6902610659599304,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2922166585922241,
				["artID"] = 921,
				["foundTime"] = 1570195227,
			},
			[132837] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569424665,
				["coordX"] = 0.6613796949386597,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7904848456382751,
			},
			[137057] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582657,
				["coordX"] = 0.4551339745521545,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7005612850189209,
			},
			[83553] = {
				["mapID"] = 539,
				["coordY"] = 0.4860007762908936,
				["foundTime"] = 1568246362,
				["coordX"] = 0.5744537711143494,
				["artID"] = 556,
				["atlasName"] = "VignetteKill",
			},
			[278462] = {
				["mapID"] = 862,
				["coordY"] = 0.4481673836708069,
				["foundTime"] = 1570206878,
				["coordX"] = 0.6980306506156921,
				["artID"] = 887,
				["atlasName"] = "VignetteLoot",
			},
			[75434] = {
				["mapID"] = 539,
				["artID"] = 556,
				["foundTime"] = 1568034162,
				["coordX"] = 0.426,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.406,
			},
			[334216] = {
				["mapID"] = 1530,
				["coordY"] = 0.5833544135093689,
				["foundTime"] = 1579714319,
				["coordX"] = 0.7844716310501099,
				["artID"] = 1342,
				["atlasName"] = "VignetteLoot",
			},
			[89884] = {
				["mapID"] = 630,
				["coordY"] = 0.5782783627510071,
				["foundTime"] = 1568299144,
				["coordX"] = 0.4520503878593445,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[138848] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.319304883480072,
				["coordX"] = 0.4500525593757629,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571753916,
			},
			[134884] = {
				["mapID"] = 942,
				["artID"] = 967,
				["coordY"] = 0.7418192028999329,
				["coordX"] = 0.4155919849872589,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1577448726,
			},
			[137058] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4404436349868774,
				["coordX"] = 0.5897376537322998,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567943771,
			},
			[147924] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568645836,
				["coordX"] = 0.5324007272720337,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6616841554641724,
			},
			[297893] = {
				["mapID"] = 896,
				["coordY"] = 0.7173320651054382,
				["foundTime"] = 1573855890,
				["coordX"] = 0.3368264436721802,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[154187] = {
				["mapID"] = 1530,
				["coordY"] = 0.4328959286212921,
				["foundTime"] = 1579639682,
				["coordX"] = 0.6057466864585876,
				["artID"] = 1342,
				["atlasName"] = "VignetteEvent",
			},
			[93401] = {
				["mapID"] = 634,
				["coordY"] = 0.5181509256362915,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6487227082252502,
				["artID"] = 657,
				["foundTime"] = 1568378294,
			},
			[101649] = {
				["mapID"] = 650,
				["coordY"] = 0.7440071105957031,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5434674024581909,
				["artID"] = 674,
				["foundTime"] = 1568388801,
			},
			[138849] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1571836717,
				["coordX"] = 0.299350917339325,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4750306606292725,
			},
			[153299] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563553857,
				["coordX"] = 0.638,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.57,
			},
			[273918] = {
				["mapID"] = 895,
				["coordY"] = 0.6002047657966614,
				["foundTime"] = 1579353117,
				["coordX"] = 0.7826629281044006,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[139233] = {
				["mapID"] = 895,
				["coordY"] = 0.5590100288391113,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5784597992897034,
				["artID"] = 920,
				["foundTime"] = 1568750505,
			},
			[124475] = {
				["mapID"] = 863,
				["coordY"] = 0.5585708022117615,
				["foundTime"] = 1570111335,
				["coordX"] = 0.2915255725383759,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[110340] = {
				["mapID"] = 680,
				["coordY"] = 0.3277244865894318,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4093949496746063,
				["artID"] = 704,
				["foundTime"] = 1568374839,
			},
			[334220] = {
				["mapID"] = 1530,
				["coordY"] = 0.6345767378807068,
				["foundTime"] = 1579714754,
				["coordX"] = 0.6073106527328491,
				["artID"] = 1342,
				["atlasName"] = "VignetteLoot",
			},
			[140768] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.5706084966659546,
				["coordX"] = 0.4928805232048035,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569764741,
			},
			[152795] = {
				["mapID"] = 1355,
				["coordY"] = 0.5157637596130371,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5167657136917114,
				["artID"] = 1186,
				["foundTime"] = 1577377075,
			},
			[146139] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568645365,
				["coordX"] = 0.4138584733009338,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4053025841712952,
			},
			[291255] = {
				["mapID"] = 942,
				["coordY"] = 0.3709108233451843,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7623469829559326,
				["artID"] = 967,
				["foundTime"] = 1571408065,
			},
			[149360] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.4328230023384094,
				["coordX"] = 0.5749641060829163,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565919878,
			},
			[138828] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["coordY"] = 0.490866482257843,
				["coordX"] = 0.5160455703735352,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567007737,
			},
			[132244] = {
				["mapID"] = 862,
				["coordY"] = 0.3590457141399384,
				["foundTime"] = 1564235760,
				["coordX"] = 0.7562843561172485,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[277389] = {
				["mapID"] = 896,
				["coordY"] = 0.4696722626686096,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.5206868648529053,
				["artID"] = 921,
				["foundTime"] = 1577419160,
			},
			[140769] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["coordY"] = 0.6850020885467529,
				["coordX"] = 0.5687972903251648,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569419068,
			},
			[291226] = {
				["mapID"] = 896,
				["coordY"] = 0.1299417316913605,
				["foundTime"] = 1572064552,
				["coordX"] = 0.2718364894390106,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[153301] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.39200002,
				["coordX"] = 0.33200002,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564587669,
			},
			[291257] = {
				["mapID"] = 942,
				["coordY"] = 0.6735740900039673,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.7341870069503784,
				["artID"] = 967,
				["foundTime"] = 1573851130,
			},
			[148198] = {
				["mapID"] = 862,
				["coordY"] = 0.4175698757171631,
				["foundTime"] = 1572265048,
				["coordX"] = 0.7737302780151367,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[97345] = {
				["mapID"] = 650,
				["coordY"] = 0.4018551111221314,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4838606715202332,
				["artID"] = 674,
				["foundTime"] = 1568376372,
			},
			[86689] = {
				["mapID"] = 539,
				["coordY"] = 0.4370180368423462,
				["foundTime"] = 1568033869,
				["coordX"] = 0.2748928070068359,
				["artID"] = 556,
				["atlasName"] = "VignetteKill",
			},
			[291258] = {
				["mapID"] = 942,
				["coordY"] = 0.633882999420166,
				["foundTime"] = 1577801035,
				["coordX"] = 0.4876459240913391,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[278437] = {
				["mapID"] = 863,
				["coordY"] = 0.2619989216327667,
				["foundTime"] = 1570028172,
				["coordX"] = 0.4277211129665375,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[134760] = {
				["mapID"] = 862,
				["coordY"] = 0.1023947075009346,
				["foundTime"] = 1570112634,
				["coordX"] = 0.6536888480186462,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[153302] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563720157,
				["coordX"] = 0.42,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.676,
			},
			[137062] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.7029296159744263,
				["coordX"] = 0.630545973777771,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569849763,
			},
			[291223] = {
				["mapID"] = 896,
				["coordY"] = 0.580848753452301,
				["foundTime"] = 1577414750,
				["coordX"] = 0.7160961627960205,
				["artID"] = 921,
				["atlasName"] = "VignetteLoot",
			},
			[140387] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["foundTime"] = 1564582032,
				["coordX"] = 0.5054986476898193,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.376514732837677,
			},
			[150342] = {
				["mapID"] = 1462,
				["coordY"] = 0.2405987530946732,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6408148407936096,
				["artID"] = 1276,
				["foundTime"] = 1566572816,
			},
			[149341] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.5522624254226685,
				["coordX"] = 0.6175167560577393,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569765119,
			},
			[139539] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.6365309953689575,
				["coordX"] = 0.6454522609710693,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569931805,
			},
			[157267] = {
				["mapID"] = 1530,
				["coordY"] = 0.4612535536289215,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.441858172416687,
				["artID"] = 1342,
				["foundTime"] = 1579363779,
			},
			[153303] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.4,
				["coordX"] = 0.33,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564321850,
			},
			[149339] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565919954,
				["coordX"] = 0.3940021395683289,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6101217865943909,
			},
			[132076] = {
				["mapID"] = 895,
				["coordY"] = 0.2064892500638962,
				["foundTime"] = 1570021551,
				["coordX"] = 0.4685119688510895,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[128686] = {
				["mapID"] = 864,
				["coordY"] = 0.5183804035186768,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3506928086280823,
				["artID"] = 889,
				["foundTime"] = 1569673775,
			},
			[109504] = {
				["mapID"] = 630,
				["coordY"] = 0.4872035682201386,
				["foundTime"] = 1568289572,
				["coordX"] = 0.3259701430797577,
				["artID"] = 653,
				["atlasName"] = "VignetteKill",
			},
			[151897] = {
				["mapID"] = 1527,
				["coordY"] = 0.5703880786895752,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8478200435638428,
				["artID"] = 1343,
				["foundTime"] = 1579190607,
			},
			[118175] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1567431576,
				["coordX"] = 0.6275796890258789,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.43513023853302,
			},
			[139980] = {
				["mapID"] = 942,
				["coordY"] = 0.4585151672363281,
				["foundTime"] = 1573733709,
				["coordX"] = 0.5996778607368469,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[153304] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563890396,
				["coordX"] = 0.682,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.33,
			},
			[291263] = {
				["mapID"] = 942,
				["coordY"] = 0.7568139433860779,
				["foundTime"] = 1577448736,
				["coordX"] = 0.438920795917511,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[140092] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["coordY"] = 0.4454596042633057,
				["coordX"] = 0.3675717711448669,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569421498,
			},
			[339856] = {
				["mapID"] = 1530,
				["coordY"] = 0.4540150761604309,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.4132890403270721,
				["artID"] = 1342,
				["foundTime"] = 1579365352,
			},
			[133356] = {
				["mapID"] = 895,
				["artID"] = 920,
				["foundTime"] = 1577801360,
				["coordX"] = 0.609269261360169,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.170171156525612,
			},
			[291264] = {
				["mapID"] = 942,
				["coordY"] = 0.675193190574646,
				["foundTime"] = 1577463084,
				["coordX"] = 0.2806602716445923,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[137704] = {
				["mapID"] = 896,
				["coordY"] = 0.1986713856458664,
				["foundTime"] = 1570199746,
				["coordX"] = 0.3484510183334351,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[136809] = {
				["mapID"] = 1032,
				["artID"] = 1013,
				["coordY"] = 0.6960573196411133,
				["coordX"] = 0.356592059135437,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564242362,
			},
			[154328] = {
				["mapID"] = 1530,
				["coordY"] = 0.5431650876998901,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.7953048944473267,
				["artID"] = 1342,
				["foundTime"] = 1579714319,
			},
			[291265] = {
				["mapID"] = 942,
				["coordY"] = 0.6330350637435913,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.2681853175163269,
				["artID"] = 967,
				["foundTime"] = 1577463091,
			},
			[148446] = {
				["mapID"] = 864,
				["coordY"] = 0.4807709753513336,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4036366939544678,
				["artID"] = 889,
				["foundTime"] = 1569673661,
			},
			[151870] = {
				["mapID"] = 1355,
				["coordY"] = 0.250836968421936,
				["foundTime"] = 1574773079,
				["coordX"] = 0.7527012228965759,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[152794] = {
				["mapID"] = 1355,
				["coordY"] = 0.332738995552063,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6875760555267334,
				["artID"] = 1186,
				["foundTime"] = 1572033777,
			},
			[291266] = {
				["mapID"] = 942,
				["coordY"] = 0.3390703499317169,
				["foundTime"] = 1572134674,
				["coordX"] = 0.3738897740840912,
				["artID"] = 967,
				["atlasName"] = "VignetteLoot",
			},
			[138570] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.7122619152069092,
				["coordX"] = 0.6978752613067627,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567343650,
			},
			[134764] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1564582458,
				["coordX"] = 0.3050875067710877,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.71254563331604,
			},
			[132047] = {
				["mapID"] = 942,
				["coordY"] = 0.5082359910011292,
				["foundTime"] = 1571574318,
				["coordX"] = 0.6987061500549316,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[291267] = {
				["mapID"] = 942,
				["coordY"] = 0.4652769565582275,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6118210554122925,
				["artID"] = 967,
				["foundTime"] = 1573733711,
			},
			[141286] = {
				["mapID"] = 942,
				["coordY"] = 0.6796942949295044,
				["foundTime"] = 1569232457,
				["coordX"] = 0.346519261598587,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[138440] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1571838018,
				["coordX"] = 0.4921901226043701,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6084014773368835,
			},
			[96410] = {
				["mapID"] = 650,
				["coordY"] = 0.3079530000686646,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4643794894218445,
				["artID"] = 674,
				["foundTime"] = 1568375602,
			},
			[291201] = {
				["mapID"] = 896,
				["coordY"] = 0.2537985444068909,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.6507217288017273,
				["artID"] = 921,
				["foundTime"] = 1577419748,
			},
			[134637] = {
				["mapID"] = 862,
				["coordY"] = 0.141478106379509,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6316561102867126,
				["artID"] = 887,
				["foundTime"] = 1569603307,
			},
			[148231] = {
				["mapID"] = 862,
				["coordY"] = 0.352111279964447,
				["foundTime"] = 1572265160,
				["coordX"] = 0.7629314064979553,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[153307] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.406,
				["coordX"] = 0.48599997,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563807754,
			},
			[92590] = {
				["mapID"] = 634,
				["coordY"] = 0.5760433077812195,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4205233752727509,
				["artID"] = 657,
				["foundTime"] = 1568379547,
			},
			[138566] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1568645395,
				["coordX"] = 0.4135072231292725,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4002224802970886,
			},
			[139152] = {
				["mapID"] = 895,
				["coordY"] = 0.8100727796554565,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.7243191003799438,
				["artID"] = 920,
				["foundTime"] = 1570802247,
			},
			[136428] = {
				["mapID"] = 862,
				["coordY"] = 0.7651328444480896,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4412437677383423,
				["artID"] = 887,
				["foundTime"] = 1569602871,
			},
			[137579] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569930839,
				["coordX"] = 0.5320160388946533,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.360906183719635,
			},
			[134638] = {
				["mapID"] = 864,
				["artID"] = 889,
				["coordY"] = 0.5255738496780396,
				["coordX"] = 0.301964282989502,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1568836075,
			},
			[126187] = {
				["mapID"] = 863,
				["coordY"] = 0.5343179106712341,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.413166344165802,
				["artID"] = 888,
				["foundTime"] = 1573361158,
			},
			[140099] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568645887,
				["coordX"] = 0.4793001413345337,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5433651208877563,
			},
			[130143] = {
				["mapID"] = 896,
				["coordY"] = 0.2914918959140778,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.556367039680481,
				["artID"] = 921,
				["foundTime"] = 1569935745,
			},
			[124927] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1567431847,
				["coordX"] = 0.5664255619049072,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3550311923027039,
			},
			[120899] = {
				["mapID"] = 1165,
				["coordY"] = 0.8253210783004761,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5498871207237244,
				["artID"] = 1143,
				["foundTime"] = 1570029768,
			},
			[127333] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.1676111370325089,
				["coordX"] = 0.5910288691520691,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1570113432,
			},
			[126142] = {
				["mapID"] = 863,
				["coordY"] = 0.6053369641304016,
				["foundTime"] = 1573363642,
				["coordX"] = 0.428373396396637,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[137708] = {
				["mapID"] = 896,
				["coordY"] = 0.4309336245059967,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.497077077627182,
				["artID"] = 921,
				["foundTime"] = 1571400845,
			},
			[134767] = {
				["mapID"] = 1034,
				["artID"] = 1015,
				["coordY"] = 0.8382949829101562,
				["coordX"] = 0.4070408940315247,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567942608,
			},
			[153309] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1563892599,
				["coordX"] = 0.41599998,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.246,
			},
			[152414] = {
				["mapID"] = 1355,
				["coordY"] = 0.3285042643547058,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6561412215232849,
				["artID"] = 1186,
				["foundTime"] = 1575726433,
			},
			[152542] = {
				["mapID"] = 1355,
				["coordY"] = 0.4661996364593506,
				["foundTime"] = 1563719920,
				["coordX"] = 0.2861908674240112,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[139968] = {
				["mapID"] = 942,
				["coordY"] = 0.516832709312439,
				["foundTime"] = 1573733234,
				["coordX"] = 0.6617249250411987,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[94877] = {
				["mapID"] = 650,
				["coordY"] = 0.7255194783210754,
				["foundTime"] = 1568387864,
				["coordX"] = 0.5641800761222839,
				["artID"] = 674,
				["atlasName"] = "VignetteKill",
			},
			[141039] = {
				["mapID"] = 942,
				["coordY"] = 0.8374756574630737,
				["foundTime"] = 1577462380,
				["coordX"] = 0.6344079375267029,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[139755] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1569931978,
				["coordX"] = 0.5701279044151306,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4408555030822754,
			},
			[303039] = {
				["mapID"] = 942,
				["coordY"] = 0.6623652577400208,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.3215342462062836,
				["artID"] = 967,
				["foundTime"] = 1577424126,
			},
			[153310] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.122,
				["coordX"] = 0.618,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564237790,
			},
			[136047] = {
				["mapID"] = 981,
				["artID"] = 981,
				["coordY"] = 0.6615415811538696,
				["coordX"] = 0.6935237050056458,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569425313,
			},
			[148451] = {
				["mapID"] = 864,
				["coordY"] = 0.3844084441661835,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3631913661956787,
				["artID"] = 889,
				["foundTime"] = 1565964803,
			},
			[152671] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1578315143,
				["coordX"] = 0.4299968481063843,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.7550837397575378,
			},
			[126056] = {
				["mapID"] = 863,
				["coordY"] = 0.3769486546516419,
				["foundTime"] = 1573361027,
				["coordX"] = 0.494227945804596,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[139298] = {
				["mapID"] = 942,
				["coordY"] = 0.5113450884819031,
				["foundTime"] = 1572060790,
				["coordX"] = 0.3826122879981995,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[140828] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["foundTime"] = 1569768021,
				["coordX"] = 0.3852623701095581,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6876741647720337,
			},
			[134769] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1568645725,
				["coordX"] = 0.6055864095687866,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4626281261444092,
			},
			[134897] = {
				["mapID"] = 942,
				["coordY"] = 0.3983003795146942,
				["foundTime"] = 1571399992,
				["coordX"] = 0.6785996556282043,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[152416] = {
				["mapID"] = 1355,
				["coordY"] = 0.3670188188552856,
				["foundTime"] = 1565921519,
				["coordX"] = 0.6540259122848511,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[128707] = {
				["mapID"] = 896,
				["coordY"] = 0.7183312177658081,
				["foundTime"] = 1573359551,
				["coordX"] = 0.5961676239967346,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[339870] = {
				["mapID"] = 1530,
				["coordY"] = 0.49526047706604,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.813557505607605,
				["artID"] = 1342,
				["foundTime"] = 1579639807,
			},
			[128674] = {
				["mapID"] = 864,
				["coordY"] = 0.4750157296657562,
				["foundTime"] = 1570025813,
				["coordX"] = 0.6402006149291992,
				["artID"] = 889,
				["atlasName"] = "VignetteKill",
			},
			[141175] = {
				["mapID"] = 942,
				["coordY"] = 0.3222707509994507,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.708605170249939,
				["artID"] = 967,
				["foundTime"] = 1571919154,
			},
			[139757] = {
				["mapID"] = 1037,
				["artID"] = 1018,
				["foundTime"] = 1569420242,
				["coordX"] = 0.6555929780006409,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.2643752098083496,
			},
			[138244] = {
				["mapID"] = 896,
				["artID"] = 921,
				["coordY"] = 0.38,
				["coordX"] = 0.412,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569934541,
			},
			[153312] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["foundTime"] = 1564431117,
				["coordX"] = 0.414,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.24,
			},
			[131233] = {
				["mapID"] = 862,
				["coordY"] = 0.7417586445808411,
				["foundTime"] = 1570031340,
				["coordX"] = 0.5867801308631897,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[152545] = {
				["mapID"] = 1355,
				["coordY"] = 0.3703687191009522,
				["foundTime"] = 1574774171,
				["coordX"] = 0.2716850638389587,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[133531] = {
				["mapID"] = 863,
				["coordY"] = 0.5051694512367249,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.3653853833675385,
				["artID"] = 888,
				["foundTime"] = 1573361147,
			},
			[152448] = {
				["mapID"] = 1355,
				["coordY"] = 0.5615756511688232,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4534103870391846,
				["artID"] = 1186,
				["foundTime"] = 1574772407,
			},
			[138299] = {
				["mapID"] = 895,
				["artID"] = 920,
				["coordY"] = 0.33,
				["coordX"] = 0.588,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1571149128,
			},
			[147942] = {
				["mapID"] = 62,
				["coordY"] = 0.8268715739250183,
				["foundTime"] = 1569089788,
				["coordX"] = 0.4060646593570709,
				["artID"] = 1176,
				["atlasName"] = "VignetteKill",
			},
			[138863] = {
				["mapID"] = 896,
				["coordY"] = 0.5711688995361328,
				["foundTime"] = 1577419663,
				["coordX"] = 0.3298172950744629,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[107922] = {
				["mapID"] = 641,
				["coordY"] = 0.7345892190933228,
				["foundTime"] = 1572182313,
				["coordX"] = 0.5854143500328064,
				["artID"] = 664,
				["atlasName"] = "VignetteEvent",
			},
			[82411] = {
				["mapID"] = 539,
				["coordY"] = 0.4182792603969574,
				["foundTime"] = 1568204110,
				["coordX"] = 0.4963102638721466,
				["artID"] = 556,
				["atlasName"] = "VignetteKill",
			},
			[132086] = {
				["mapID"] = 895,
				["coordY"] = 0.6995464563369751,
				["foundTime"] = 1574516895,
				["coordX"] = 0.5620246529579163,
				["artID"] = 920,
				["atlasName"] = "VignetteKill",
			},
			[140398] = {
				["mapID"] = 942,
				["artID"] = 967,
				["coordY"] = 0.5509235858917236,
				["coordX"] = 0.3159112930297852,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1577800410,
			},
			[134717] = {
				["mapID"] = 862,
				["coordY"] = 0.2942405343055725,
				["foundTime"] = 1570205886,
				["coordX"] = 0.4922183752059937,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[155176] = {
				["mapID"] = 942,
				["coordY"] = 0.2159278094768524,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.6285325884819031,
				["artID"] = 967,
				["foundTime"] = 1571143536,
			},
			[137529] = {
				["mapID"] = 896,
				["coordY"] = 0.6919295191764832,
				["foundTime"] = 1570114299,
				["coordX"] = 0.3483815789222717,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[273910] = {
				["mapID"] = 895,
				["coordY"] = 0.3019811511039734,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4308087229728699,
				["artID"] = 920,
				["foundTime"] = 1574949494,
			},
			[152291] = {
				["mapID"] = 1355,
				["coordY"] = 0.4336398243904114,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5293625593185425,
				["artID"] = 1186,
				["foundTime"] = 1577377956,
			},
			[98268] = {
				["mapID"] = 634,
				["coordY"] = 0.4316231906414032,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6144307851791382,
				["artID"] = 657,
				["foundTime"] = 1568377585,
			},
			[140271] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1565920127,
				["coordX"] = 0.2991082668304443,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4942335486412048,
			},
			[136341] = {
				["mapID"] = 864,
				["coordY"] = 0.180103063583374,
				["foundTime"] = 1570025585,
				["coordX"] = 0.6055540442466736,
				["artID"] = 889,
				["atlasName"] = "VignetteKill",
			},
			[138481] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.5227176547050476,
				["coordX"] = 0.4933848381042481,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1565920426,
			},
			[140300] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1570624559,
				["coordX"] = 0.5932462811470032,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.3883950114250183,
			},
			[139760] = {
				["mapID"] = 1337,
				["artID"] = 1171,
				["foundTime"] = 1571836824,
				["coordX"] = 0.3353211879730225,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6173615455627441,
			},
			[125250] = {
				["mapID"] = 863,
				["coordY"] = 0.2947749793529511,
				["foundTime"] = 1572440612,
				["coordX"] = 0.6780533194541931,
				["artID"] = 888,
				["atlasName"] = "VignetteKill",
			},
			[153315] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.251192569732666,
				["coordX"] = 0.5194318294525146,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563463098,
			},
			[149351] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.543757438659668,
				["coordX"] = 0.6155840158462524,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924221,
			},
			[140272] = {
				["mapID"] = 1035,
				["artID"] = 1016,
				["coordY"] = 0.8468402624130249,
				["coordX"] = 0.5730711221694946,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569849964,
			},
			[140339] = {
				["mapID"] = 1034,
				["artID"] = 1015,
				["foundTime"] = 1567866073,
				["coordX"] = 0.6540141105651855,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6311376690864563,
			},
			[152359] = {
				["mapID"] = 1355,
				["coordY"] = 0.5483675003051758,
				["foundTime"] = 1575112176,
				["coordX"] = 0.7164038419723511,
				["artID"] = 1186,
				["atlasName"] = "VignetteKill",
			},
			[282723] = {
				["mapID"] = 863,
				["coordY"] = 0.6980457901954651,
				["foundTime"] = 1573995897,
				["coordX"] = 0.2902392745018005,
				["artID"] = 888,
				["atlasName"] = "VignetteLoot",
			},
			[146847] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569425921,
				["coordX"] = 0.6032053232192993,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.5662344694137573,
			},
			[138866] = {
				["mapID"] = 896,
				["coordY"] = 0.2195319533348084,
				["foundTime"] = 1570022452,
				["coordX"] = 0.2446682453155518,
				["artID"] = 921,
				["atlasName"] = "VignetteKill",
			},
			[135925] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.5963016152381897,
				["coordX"] = 0.5676091909408569,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567005728,
			},
			[154467] = {
				["mapID"] = 1530,
				["coordY"] = 0.6448803544044495,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.8119672536849976,
				["artID"] = 1342,
				["foundTime"] = 1579467208,
			},
			[140273] = {
				["mapID"] = 1034,
				["artID"] = 1015,
				["coordY"] = 0.7272011637687683,
				["coordX"] = 0.4817949533462524,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1567942699,
			},
			[152677] = {
				["mapID"] = 1527,
				["coordY"] = 0.2459364980459213,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6198843717575073,
				["artID"] = 1343,
				["foundTime"] = 1579360492,
			},
			[139415] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["foundTime"] = 1571837689,
				["coordX"] = 0.588968813419342,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.4217178821563721,
			},
			[293880] = {
				["mapID"] = 895,
				["coordY"] = 0.253416895866394,
				["foundTime"] = 1572064526,
				["coordX"] = 0.2922417521476746,
				["artID"] = 920,
				["atlasName"] = "VignetteLootElite",
			},
			[90232] = {
				["mapID"] = 630,
				["coordY"] = 0.1206006333231926,
				["foundTime"] = 1572182261,
				["coordX"] = 0.5984616875648499,
				["artID"] = 653,
				["atlasName"] = "VignetteEvent",
			},
			[129343] = {
				["mapID"] = 862,
				["coordY"] = 0.5742475986480713,
				["foundTime"] = 1579711150,
				["coordX"] = 0.4983270168304443,
				["artID"] = 887,
				["atlasName"] = "VignetteKill",
			},
			[135926] = {
				["mapID"] = 981,
				["artID"] = 981,
				["foundTime"] = 1564922849,
				["coordX"] = 0.5907793641090393,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.6947014331817627,
			},
			[127877] = {
				["mapID"] = 896,
				["coordY"] = 0.5525553226470947,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5924156308174133,
				["artID"] = 921,
				["foundTime"] = 1573359629,
			},
			[154640] = {
				["mapID"] = 1355,
				["artID"] = 1186,
				["coordY"] = 0.554,
				["coordX"] = 0.38,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1563462987,
			},
			[58768] = {
				["mapID"] = 390,
				["coordY"] = 0.5934264659881592,
				["foundTime"] = 1572529038,
				["coordX"] = 0.4644776880741119,
				["artID"] = 402,
				["atlasName"] = "VignetteKill",
			},
			[138484] = {
				["mapID"] = 1502,
				["artID"] = 1302,
				["coordY"] = 0.4743258357048035,
				["coordX"] = 0.406054675579071,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1564924648,
			},
			[162141] = {
				["mapID"] = 1527,
				["coordY"] = 0.4215905964374542,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4102321565151215,
				["artID"] = 1343,
				["foundTime"] = 1579619932,
			},
			[139763] = {
				["mapID"] = 1033,
				["artID"] = 1014,
				["foundTime"] = 1565797940,
				["coordX"] = 0.5410265922546387,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.1556164622306824,
			},
			[130897] = {
				["mapID"] = 942,
				["coordY"] = 0.6584312319755554,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.4727361798286438,
				["artID"] = 967,
				["foundTime"] = 1572061618,
			},
			[127873] = {
				["mapID"] = 863,
				["coordY"] = 0.08938205987215042,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5808078646659851,
				["artID"] = 888,
				["foundTime"] = 1570027990,
			},
			[273900] = {
				["mapID"] = 895,
				["coordY"] = 0.7463213205337524,
				["foundTime"] = 1570970172,
				["coordX"] = 0.8328934907913208,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[136183] = {
				["mapID"] = 942,
				["coordY"] = 0.5552466511726379,
				["foundTime"] = 1570555402,
				["coordX"] = 0.5125221014022827,
				["artID"] = 967,
				["atlasName"] = "VignetteKill",
			},
			[154490] = {
				["mapID"] = 1530,
				["coordY"] = 0.5173835754394531,
				["foundTime"] = 1579714925,
				["coordX"] = 0.6417983770370483,
				["artID"] = 1342,
				["atlasName"] = "VignetteKill",
			},
			[279373] = {
				["mapID"] = 863,
				["coordY"] = 0.6564158201217651,
				["atlasName"] = "VignetteLoot",
				["coordX"] = 0.4158869087696075,
				["artID"] = 888,
				["foundTime"] = 1573363641,
			},
			[273901] = {
				["mapID"] = 1169,
				["coordY"] = 0.5015817880630493,
				["foundTime"] = 1566736980,
				["coordX"] = 0.2896124124526978,
				["artID"] = 974,
				["atlasName"] = "VignetteLoot",
			},
			[152040] = {
				["mapID"] = 1527,
				["coordY"] = 0.4218126535415649,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.6971331238746643,
				["artID"] = 1343,
				["foundTime"] = 1579366634,
			},
			[152439] = {
				["mapID"] = 1527,
				["coordY"] = 0.599304735660553,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.6990320086479187,
				["artID"] = 1343,
				["foundTime"] = 1579366736,
			},
			[154342] = {
				["mapID"] = 1462,
				["coordY"] = 0.4062241613864899,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.5264180302619934,
				["artID"] = 1276,
				["foundTime"] = 1564244930,
			},
			[140148] = {
				["mapID"] = 1036,
				["artID"] = 1017,
				["coordY"] = 0.6829012632369995,
				["coordX"] = 0.4073429107666016,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569423319,
			},
			[140454] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["coordY"] = 0.7670454978942871,
				["coordX"] = 0.3385685086250305,
				["atlasName"] = "VignetteKill",
				["foundTime"] = 1569422018,
			},
			[162196] = {
				["mapID"] = 1527,
				["coordY"] = 0.1729116439819336,
				["foundTime"] = 1579531672,
				["coordX"] = 0.3505869209766388,
				["artID"] = 1343,
				["atlasName"] = "VignetteKill",
			},
			[139674] = {
				["mapID"] = 1501,
				["artID"] = 1301,
				["foundTime"] = 1569424820,
				["coordX"] = 0.3705012202262878,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.8207483291625977,
			},
			[273903] = {
				["mapID"] = 895,
				["coordY"] = 0.839838445186615,
				["foundTime"] = 1572064892,
				["coordX"] = 0.7530736923217773,
				["artID"] = 920,
				["atlasName"] = "VignetteLoot",
			},
			[154087] = {
				["mapID"] = 1530,
				["coordY"] = 0.4055947959423065,
				["foundTime"] = 1579466729,
				["coordX"] = 0.7094403505325317,
				["artID"] = 1342,
				["atlasName"] = "VignetteKill",
			},
			[138870] = {
				["mapID"] = 896,
				["artID"] = 921,
				["foundTime"] = 1570553337,
				["coordX"] = 0.244,
				["atlasName"] = "VignetteKill",
				["coordY"] = 0.22,
			},
			[162173] = {
				["mapID"] = 1527,
				["coordY"] = 0.1273355185985565,
				["atlasName"] = "VignetteKill",
				["coordX"] = 0.2712431252002716,
				["artID"] = 1343,
				["foundTime"] = 1579531834,
			},
			[163198] = {
				["mapID"] = 1527,
				["coordY"] = 0.4778100848197937,
				["atlasName"] = "VignetteEvent",
				["coordX"] = 0.3707422912120819,
				["artID"] = 1343,
				["foundTime"] = 1579553261,
			},
		},
	},
	["profiles"] = {
		["뉘시빨라마 - 굴단"] = {
		},
		["무시중한디 - 굴단"] = {
		},
		["국제금융로 - 굴단"] = {
		},
	},
}
