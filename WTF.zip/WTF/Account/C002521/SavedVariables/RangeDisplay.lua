
RangeDisplayDB3 = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["이스레인 - 아즈샤라"] = "Wide",
		["아테리에 - 아즈샤라"] = "Wide",
		["아라스틴 - 아즈샤라"] = "Wide",
		["에레로엘 - 아즈샤라"] = "Wide",
		["잘생겨따 - 굴단"] = "Default",
		["Isolesty - 아즈샤라"] = "Wide",
		["데빌테스트용임 - 아즈샤라"] = "Wide",
		["무시중한디 - 굴단"] = "Wide",
		["레이스가드 - 아즈샤라"] = "Wide",
		["아테르나 - 하이잘"] = "Default",
		["아이루릴 - 아즈샤라"] = "Wide",
		["테스트용임다 - 아즈샤라"] = "Wide",
		["Arastin - 아즈샤라"] = "Wide",
		["시에이레 - 듀로탄"] = "Wide",
		["데빌테스트용 - 아즈샤라"] = "Wide",
		["내꿈은샤먼킹 - 데스윙"] = "Wide",
		["폭까말랑카우 - 아즈샤라"] = "Default",
		["Eldersign - 아즈샤라"] = "Wide",
		["아테르나 - 아즈샤라"] = "Wide",
		["에레로엘 - 데스윙"] = "Wide",
		["이솔레스테 - 아즈샤라"] = "Wide",
		["실베르투스 - 아즈샤라"] = "Wide",
		["아테르나 - 듀로탄"] = "Default",
		["Wraithguard - 아즈샤라"] = "Wide",
		["Vindictus - 아즈샤라"] = "Wide",
		["아테리에 - 데스윙"] = "Wide",
	},
	["profiles"] = {
		["Normal"] = {
			["locked"] = true,
			["units"] = {
				["arena2"] = {
				},
				["playertarget"] = {
					["y"] = -231.596648297567,
					["relPoint"] = "TOP",
					["point"] = "TOP",
					["suffix"] = " 미터",
					["x"] = 8.42798896709019,
					["font"] = "데미지 글꼴",
					["warnEnemyOnly"] = false,
				},
				["focus"] = {
					["enabled"] = false,
				},
				["arena5"] = {
				},
				["pet"] = {
				},
				["mouseover"] = {
					["enabled"] = false,
				},
				["arena4"] = {
				},
			},
		},
		["Wide"] = {
			["locked"] = true,
			["units"] = {
				["pet"] = {
				},
				["arena2"] = {
				},
				["focus"] = {
					["enabled"] = false,
				},
				["playertarget"] = {
					["relPoint"] = "TOP",
					["point"] = "TOP",
					["suffix"] = " 미터",
					["warnEnemyOnly"] = false,
					["y"] = -231.596648297567,
					["x"] = 8.42798896709019,
					["font"] = "데미지 글꼴",
				},
				["mouseover"] = {
					["enabled"] = false,
				},
				["arena5"] = {
				},
				["arena4"] = {
				},
			},
		},
		["Default"] = {
			["units"] = {
				["arena2"] = {
				},
				["focus"] = {
					["y"] = -99.9999923706055,
					["x"] = -122.000022888184,
				},
				["arena5"] = {
				},
				["pet"] = {
				},
				["arena4"] = {
				},
			},
		},
	},
}
