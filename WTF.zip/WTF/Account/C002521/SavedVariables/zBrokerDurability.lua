
zBD = {
	["items"] = true,
	["totals"] = true,
	["price"] = true,
	["lowest"] = true,
	["percent"] = true,
	["reputation"] = true,
}
