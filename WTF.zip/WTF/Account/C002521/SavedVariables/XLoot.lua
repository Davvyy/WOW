
XLootADB = {
	["namespaces"] = {
		["Frame"] = {
			["profiles"] = {
				["Wide"] = {
					["frame_position_y"] = 570.185180664063,
					["autoloot_item_list"] = "원시 영혼,화염 암모나이트 촉수,눈부신 사파이어 펜던트,약탈자의 소란스러운 반지,병사의 튼튼한 어깨덧대,팔라나아르의 고대 서판,혼돈 수정",
					["frame_position_x"] = 918.407531738281,
				},
			},
		},
	},
	["profileKeys"] = {
		["이스레인 - 아즈샤라"] = "Wide",
		["아테리에 - 아즈샤라"] = "Wide",
		["아라스틴 - 아즈샤라"] = "Wide",
		["에레로엘 - 아즈샤라"] = "Wide",
		["Isolesty - 아즈샤라"] = "Wide",
		["데빌테스트용임 - 아즈샤라"] = "Wide",
		["무시중한디 - 굴단"] = "Wide",
		["레이스가드 - 아즈샤라"] = "Wide",
		["아테리에 - 데스윙"] = "Wide",
		["Vindictus - 아즈샤라"] = "Wide",
		["테스트용임다 - 아즈샤라"] = "Wide",
		["Wraithguard - 아즈샤라"] = "Wide",
		["아테르나 - 듀로탄"] = "Default",
		["데빌테스트용 - 아즈샤라"] = "Wide",
		["실베르투스 - 아즈샤라"] = "Wide",
		["폭까말랑카우 - 아즈샤라"] = "Default",
		["Eldersign - 아즈샤라"] = "Wide",
		["아테르나 - 아즈샤라"] = "Wide",
		["에레로엘 - 데스윙"] = "Wide",
		["이솔레스테 - 아즈샤라"] = "Wide",
		["내꿈은샤먼킹 - 데스윙"] = "Wide",
		["시에이레 - 듀로탄"] = "Wide",
		["Arastin - 아즈샤라"] = "Wide",
		["아이루릴 - 아즈샤라"] = "Wide",
		["아테르나 - 하이잘"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
		["Wide"] = {
		},
	},
}
