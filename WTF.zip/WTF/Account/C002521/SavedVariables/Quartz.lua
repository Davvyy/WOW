
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
			["profiles"] = {
				["Default"] = {
					["interruptcolor"] = {
						1, -- [1]
						0.0549019607843137, -- [2]
						0.0509803921568627, -- [3]
						1, -- [4]
					},
				},
				["Wide"] = {
					["interruptcolor"] = {
						1, -- [1]
						0.0549019607843137, -- [2]
						0.0509803921568627, -- [3]
						1, -- [4]
					},
				},
			},
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["y"] = 387.126983642578,
					["x"] = 860.448547363281,
				},
				["Wide"] = {
					["x"] = 860.448547363281,
					["y"] = 387.126983642578,
				},
			},
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["w"] = 280,
					["y"] = 300,
					["h"] = 20,
					["fontsize"] = 12,
					["iconalpha"] = 1,
					["nametextposition"] = "centerback",
					["x"] = 763,
					["font"] = "기본 글꼴",
					["texture"] = "Glamour7",
				},
				["Wide"] = {
					["h"] = 20,
					["targetname"] = true,
					["w"] = 280,
					["y"] = 260,
					["x"] = 763,
					["iconalpha"] = 1,
					["fontsize"] = 12,
					["nametextposition"] = "centerback",
					["font"] = "기본 글꼴",
					["texture"] = "Glamour7",
				},
			},
		},
		["EnemyCasts"] = {
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["w"] = 168,
					["y"] = 427,
					["h"] = 14,
					["fontsize"] = 10,
					["nametextposition"] = "centerback",
					["font"] = "기본 글꼴",
					["timefontsize"] = 10,
					["x"] = 1231,
					["texture"] = "Glamour7",
				},
				["Wide"] = {
					["h"] = 14,
					["w"] = 168,
					["y"] = 485,
					["font"] = "기본 글꼴",
					["fontsize"] = 10,
					["texture"] = "Glamour7",
					["x"] = 1231,
					["timefontsize"] = 10,
					["nametextposition"] = "centerback",
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["noInterruptChangeBorder"] = false,
					["w"] = 244,
					["y"] = 321,
					["x"] = 1155,
					["fontsize"] = 12,
					["texture"] = "Glamour7",
					["font"] = "기본 글꼴",
					["nametextposition"] = "centerback",
					["iconposition"] = "left",
				},
				["Wide"] = {
					["w"] = 244,
					["y"] = 321,
					["x"] = 1155,
					["iconposition"] = "left",
					["fontsize"] = 12,
					["texture"] = "Glamour7",
					["font"] = "기본 글꼴",
					["noInterruptChangeBorder"] = false,
					["nametextposition"] = "centerback",
				},
			},
		},
		["Mirror"] = {
		},
		["Range"] = {
		},
		["Latency"] = {
		},
	},
	["profileKeys"] = {
		["이스레인 - 아즈샤라"] = "Wide",
		["아테리에 - 아즈샤라"] = "Wide",
		["아라스틴 - 아즈샤라"] = "Wide",
		["에레로엘 - 아즈샤라"] = "Wide",
		["잘생겨따 - 굴단"] = "Default",
		["실베르투스 - 아즈샤라"] = "Default",
		["데빌테스트용임 - 아즈샤라"] = "Wide",
		["무시중한디 - 굴단"] = "Wide",
		["시에이레 - 듀로탄"] = "Default",
		["내꿈은샤먼킹 - 데스윙"] = "Default",
		["아이루릴 - 아즈샤라"] = "Default",
		["테스트용임다 - 아즈샤라"] = "Wide",
		["아테르나 - 하이잘"] = "Default",
		["Arastin - 아즈샤라"] = "Wide",
		["데빌테스트용 - 아즈샤라"] = "Wide",
		["Isolesty - 아즈샤라"] = "Default",
		["폭까말랑카우 - 아즈샤라"] = "Default",
		["Eldersign - 아즈샤라"] = "Default",
		["아테르나 - 아즈샤라"] = "Wide",
		["에레로엘 - 데스윙"] = "Wide",
		["이솔레스테 - 아즈샤라"] = "Default",
		["레이스가드 - 아즈샤라"] = "Default",
		["Vindictus - 아즈샤라"] = "Default",
		["Wraithguard - 아즈샤라"] = "Wide",
		["아테르나 - 듀로탄"] = "Default",
		["아테리에 - 데스윙"] = "Wide",
	},
	["profiles"] = {
		["Default"] = {
			["channelingcolor"] = {
				0.4, -- [1]
				0.184313725490196, -- [2]
				0.807843137254902, -- [3]
				1, -- [4]
			},
			["castingcolor"] = {
				0.152941176470588, -- [1]
				0.517647058823529, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["borderalpha"] = 0,
			["bordercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["modules"] = {
				["Swing"] = false,
				["GCD"] = false,
				["Buff"] = false,
				["Pet"] = false,
				["Mirror"] = false,
			},
		},
		["Wide"] = {
			["channelingcolor"] = {
				0.4, -- [1]
				0.184313725490196, -- [2]
				0.807843137254902, -- [3]
				1, -- [4]
			},
			["borderalpha"] = 0,
			["bordercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["modules"] = {
				["Swing"] = false,
				["GCD"] = false,
				["Buff"] = false,
				["Pet"] = false,
				["Mirror"] = false,
			},
			["castingcolor"] = {
				0.152941176470588, -- [1]
				0.517647058823529, -- [2]
				1, -- [3]
				1, -- [4]
			},
		},
	},
}
