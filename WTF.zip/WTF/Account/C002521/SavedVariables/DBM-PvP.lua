
DBMPvP_AllSavedVars = {
	["아라스틴-아즈샤라"] = {
		["z529"] = {
			[3] = {
				["Enabled"] = true,
				["TimerWinTColor"] = 0,
				["HealthFrame"] = false,
				["ShowAbBasesToWin"] = false,
				["TimerCapTColor"] = 0,
				["TimerCap"] = true,
				["TimerWin"] = true,
				["ShowAbEstimatedPoints"] = true,
			},
		},
		["Battlegrounds"] = {
			[3] = {
				["Enabled"] = true,
				["HealthFrame"] = false,
				["ColorByClass"] = true,
				["HideBossEmoteFrame"] = false,
				["AutoSpirit"] = false,
			},
		},
		["z727"] = {
			[3] = {
				["HealthFrame"] = false,
				["TimerCartTColor"] = 0,
				["TimerCart"] = true,
				["Enabled"] = true,
			},
		},
		["z1105"] = {
			[3] = {
				["Enabled"] = true,
				["TimerWinTColor"] = 0,
				["TimerCapTColor"] = 0,
				["TimerCap"] = true,
				["TimerWin"] = true,
				["HealthFrame"] = false,
			},
		},
		["z30"] = {
			[3] = {
				["Enabled"] = true,
				["TimerTowerTColor"] = 0,
				["TimerGYTColor"] = 0,
				["HealthFrame"] = false,
				["AutoTurnIn"] = true,
				["TimerTower"] = true,
				["TimerGY"] = true,
			},
		},
		["z726"] = {
			[3] = {
				["Enabled"] = true,
				["TimerFlag"] = true,
				["Timer46392next"] = true,
				["ShowFlagCarrierErrorNote"] = false,
				["HealthFrame"] = false,
				["TimerFlagTColor"] = 0,
				["ShowFlagCarrier"] = true,
				["Timer46392nextTColor"] = 0,
			},
		},
		["z628"] = {
			[3] = {
				["Enabled"] = true,
				["HealthFrame"] = false,
				["ShowGatesHealth"] = true,
				["WarnSiegeEngineSoon"] = true,
				["TimerPOI"] = true,
				["TimerSiegeEngineTColor"] = 0,
				["TimerPOITColor"] = 0,
				["TimerSiegeEngine"] = true,
				["WarnSiegeEngine"] = true,
			},
		},
		["z566"] = {
			[3] = {
				["Enabled"] = true,
				["TimerWinTColor"] = 0,
				["TimerFlag"] = true,
				["HealthFrame"] = false,
				["TimerFlagTColor"] = 0,
				["TimerWin"] = true,
				["ShowPointFrame"] = true,
			},
		},
		["z761"] = {
			[3] = {
				["Enabled"] = true,
				["TimerWinTColor"] = 0,
				["ShowGilneasEstimatedPoints"] = true,
				["HealthFrame"] = false,
				["TimerCapTColor"] = 0,
				["TimerCap"] = true,
				["TimerWin"] = true,
				["ShowGilneasBasesToWin"] = false,
			},
		},
		["Arenas"] = {
			[3] = {
				["Enabled"] = true,
				["Countdown91344"] = true,
				["timer_combatTColor"] = 0,
				["HealthFrame"] = false,
				["timer_combat"] = true,
				["TimerShadow"] = true,
				["Timer110310cast"] = true,
				["Timer110310castTColor"] = 0,
				["TimerShadowTColor"] = 0,
			},
		},
		["z489"] = {
			[3] = {
				["Enabled"] = true,
				["TimerFlag"] = true,
				["Timer46392next"] = true,
				["ShowFlagCarrierErrorNote"] = false,
				["HealthFrame"] = false,
				["TimerFlagTColor"] = 0,
				["ShowFlagCarrier"] = true,
				["Timer46392nextTColor"] = 0,
			},
		},
		["z998"] = {
			[3] = {
				["Enabled"] = true,
				["TimerWinTColor"] = 0,
				["HealthFrame"] = false,
				["ShowKotmoguEstimatedPoints"] = true,
				["TimerWin"] = true,
				["ShowKotmoguOrbsToWin"] = false,
			},
		},
	},
}
