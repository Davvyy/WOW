
SkadaDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["잘생겨따 - 굴단"] = "Default",
		["무시중한디 - 굴단"] = "Wide",
		["뉘시빨라마 - 굴단"] = "Default",
		["국제금융로 - 굴단"] = "Default",
	},
	["profiles"] = {
		["굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
		["WARRIOR"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
		["Default"] = {
			["modeclicks"] = {
				["약화 효과"] = 1,
				["적이 받은 치유"] = 1,
				["피해"] = 1,
				["GTFO 경고"] = 3,
				["치유"] = 12,
				["총 치유"] = 2,
				["DPS"] = 20,
			},
			["windows"] = {
				{
					["y"] = 12.95217990875244,
					["name"] = "S",
					["point"] = "BOTTOMLEFT",
					["mode"] = "DPS",
					["spark"] = false,
					["barwidth"] = 256.95263671875,
					["background"] = {
						["strata"] = "LOW",
						["height"] = 378.0479125976563,
						["bordertexture"] = "None",
					},
					["x"] = 455.4296875,
				}, -- [1]
			},
			["icon"] = {
				["minimapPos"] = 206.6650563676227,
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
			["reset"] = {
				["leave"] = 2,
				["instance"] = 2,
				["join"] = 2,
			},
		},
		["Wide"] = {
			["modeclicks"] = {
				["GTFO 경고"] = 3,
				["치유"] = 5,
				["DPS"] = 16,
			},
			["windows"] = {
				{
					["y"] = 3.047519445419312,
					["x"] = 457.126220703125,
					["point"] = "BOTTOMLEFT",
					["barwidth"] = 286.4770812988281,
					["mode"] = "DPS",
					["background"] = {
						["height"] = 413.3334045410156,
					},
				}, -- [1]
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
			["icon"] = {
				["minimapPos"] = 213.6161596799995,
			},
			["report"] = {
				["chantype"] = "channel",
				["mode"] = "DPS",
				["channel"] = "ok",
			},
		},
		["국제금융로 - 굴단"] = {
			["windows"] = {
				{
					["y"] = 7.380950927734375,
					["x"] = 2166.952407836914,
					["barslocked"] = true,
					["barwidth"] = 195.9999847412109,
					["background"] = {
						["height"] = 448.1429138183594,
						["strata"] = "LOW",
						["bordertexture"] = "None",
					},
					["spark"] = false,
					["point"] = "TOPRIGHT",
				}, -- [1]
			},
		},
	},
}
