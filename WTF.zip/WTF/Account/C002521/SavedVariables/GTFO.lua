
GTFOData = {
	["Active"] = true,
	["TrivialDamagePercent"] = 2,
	["TestMode"] = false,
	["Sounds"] = {
		true, -- [1]
		true, -- [2]
		true, -- [3]
		true, -- [4]
	},
	["DataCode"] = "4",
	["SoundChannel"] = "Master",
	["Volume"] = 3,
	["IgnoreOptions"] = {
	},
	["SoundOverrides"] = {
	},
	["UnmuteMode"] = false,
	["TrivialMode"] = false,
}
