
CANChat = {
	["Fade"] = 0,
	["ChatNo"] = "4",
	["Combat"] = 0,
	["Channel"] = "",
	["OutLine"] = 0,
	["Edit"] = 1,
	["CallMe"] = {
	},
	["Hide"] = 0,
}
