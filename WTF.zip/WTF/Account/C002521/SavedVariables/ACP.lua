
ACP_Data = {
	["sorter"] = "이름별 분류",
	["NoRecurse"] = false,
	["NoChildren"] = true,
	["collapsed"] = {
	},
	["ProtectedAddons"] = {
		["ACP"] = true,
	},
}
