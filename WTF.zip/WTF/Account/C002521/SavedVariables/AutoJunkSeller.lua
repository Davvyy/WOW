
AutoJunkSeller = nil
