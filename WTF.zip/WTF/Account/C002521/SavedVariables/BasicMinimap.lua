
BasicMinimapDB = {
	["strata"] = "HIGH",
	["point"] = "BOTTOM",
	["borderB"] = 0.207843137254902,
	["relpoint"] = "BOTTOM",
	["zoomBtn"] = false,
	["classHall"] = true,
	["lock"] = true,
	["y"] = 22.763879776001,
	["borderSize"] = 1,
	["borderR"] = 0.207843137254902,
	["borderG"] = 0.207843137254902,
	["clock"] = true,
	["x"] = 353.633544921875,
	["tracking"] = "None",
	["zoneText"] = true,
}
