
g_activeBidAuctionIDs = {
}
