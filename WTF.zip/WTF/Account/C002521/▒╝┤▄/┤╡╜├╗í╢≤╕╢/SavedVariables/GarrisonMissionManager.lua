
SVPC_GarrisonMissionManager = {
	["ignored_followers"] = {
	},
}
