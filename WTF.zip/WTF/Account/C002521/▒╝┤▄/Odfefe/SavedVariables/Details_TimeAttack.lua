
_detalhes_databaseTimeAttack = nil
