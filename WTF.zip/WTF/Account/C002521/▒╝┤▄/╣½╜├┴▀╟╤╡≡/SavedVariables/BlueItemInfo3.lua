
BlueItemInfo3CharDB = {
}
