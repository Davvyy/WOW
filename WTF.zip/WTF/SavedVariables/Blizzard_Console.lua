
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["height"] = 300.0002136230469,
	["messageHistory"] = {
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"Time set to 2/6/2020 (Thu) 6:12", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Total: 39d 16h 13m 21s", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Level: 29d 11h 9m 41s", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [88]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [89]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"Time set to 2/6/2020 (Thu) 21:06", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"Total: 39d 16h 13m 55s", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Level: 29d 11h 10m 15s", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"Time set to 2/6/2020 (Thu) 21:11", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Total: 31d 16h 50m 51s", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"Level: 6d 14h 41m 32s", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"Time set to 2/6/2020 (Thu) 21:14", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Total: 20d 20h 27m 49s", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"Level: 14d 16h 33m 42s", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Time set to 2/6/2020 (Thu) 21:17", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Total: 39d 16h 18m 29s", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Level: 29d 11h 14m 49s", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Time set to 2/6/2020 (Thu) 21:19", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Total: 31d 16h 53m 46s", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Level: 6d 14h 44m 27s", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Time set to 2/6/2020 (Thu) 21:26", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Total: 39d 16h 20m 9s", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Level: 29d 11h 16m 29s", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"true\"", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [361]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [362]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"Time set to 2/6/2020 (Thu) 21:28", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"Total: 39d 16h 22m 13s", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"Level: 29d 11h 18m 33s", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Time set to 2/6/2020 (Thu) 21:31", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Total: 20d 20h 30m 40s", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Level: 14d 16h 36m 33s", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [494]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [495]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Time set to 2/6/2020 (Thu) 22:08", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Total: 39d 16h 46m 7s", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Level: 29d 11h 42m 27s", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [600]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [601]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Time set to 2/7/2020 (Fri) 19:40", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Total: 31d 17h 0m 52s", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Level: 6d 14h 51m 33s", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Refraction mode changed to 2", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"Shadow mode changed to 2 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Soft shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Outline mode changed to 2", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"kr.actual.battle.net\" loginPortal=\"kr.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"[IBN_Login] Attempting logonhost=\"kr.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"6\"", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"[IBN_Login] Joining realmsubRegion=\"2-101-89\" realmAddress=\"2-1-31\"", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"[WowEntitlements] [BNetAccount-0-0000001D1D58] [WowAccount-0-0000002E1706] Initialized with 3 entitlements.", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [727]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [728]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"Time set to 2/7/2020 (Fri) 20:59", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Total: 20d 21h 1m 14s", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Level: 14d 17h 7m 7s", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"Time set to 2/7/2020 (Fri) 21:17", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Total: 31d 17h 30m 21s", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Level: 6d 15h 21m 2s", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Proficiency in item class 2 set to 0x0000006081", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Proficiency in item class 2 set to 0x0000006281", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Time set to 2/7/2020 (Fri) 21:20", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Total: 39d 17h 4m 39s", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Level: 29d 12h 0m 59s", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"World transfer aborted (reason: 30)", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Weather changed to 2, intensity 0.085229\n", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Weather changed to 2, intensity 0.085229\n", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Weather changed to 3, intensity 0.310246\n", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Completed challenge mode mapID 1754, level 12, time 1951470", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Weather changed to 5, intensity 0.237988\n", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Weather changed to 5, intensity 0.226995\n", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"Weather changed to 5, intensity 0.210426\n", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"Weather changed to 5, intensity 0.295537\n", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Weather changed to 5, intensity 0.276743\n", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Weather changed to 5, intensity 0.219978\n", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"Weather changed to 5, intensity 0.215420\n", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Weather changed to 5, intensity 0.230279\n", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Weather changed to 4, intensity 0.300000\n", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Proficiency in item class 2 set to 0x000014c5ff", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"Proficiency in item class 2 set to 0x000014e5ff", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"Time set to 2/7/2020 (Fri) 23:38", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"Total: 31d 17h 33m 32s", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"Level: 6d 15h 24m 13s", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Weather changed to 4, intensity 0.300000\n", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"Proficiency in item class 2 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"Proficiency in item class 2 set to 0x0000000011", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Proficiency in item class 2 set to 0x0000000411", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Proficiency in item class 2 set to 0x0000000431", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Proficiency in item class 2 set to 0x0000000433", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Proficiency in item class 2 set to 0x0000008433", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"Proficiency in item class 2 set to 0x000000c433", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Proficiency in item class 2 set to 0x000000e433", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Proficiency in item class 4 set to 0x000000006f", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Time set to 2/7/2020 (Fri) 23:52", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Total: 20d 21h 19m 23s", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Level: 14d 17h 25m 16s", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Weather changed to 4, intensity 0.300000\n", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["isShown"] = false,
	["fontHeight"] = 14,
	["commandHistory"] = {
	},
}
