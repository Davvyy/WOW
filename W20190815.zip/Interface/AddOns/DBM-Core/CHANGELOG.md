# Deadly Boss Mods Core

## [8.2.12](https://github.com/DeadlyBossMods/DeadlyBossMods/tree/8.2.12) (2019-08-08)
[Full Changelog](https://github.com/DeadlyBossMods/DeadlyBossMods/compare/8.2.11...8.2.12)

- Prep tag, want to fix those court regressions before they cause too much annoyance  
- Fix a bug where it didn't give player name for charge target  
    added a general warning for charge if you have stand alone, so you can still see who has it and that it's active, but won't be explicitely told to help soak it like the players who don't have stand alone, are.  
- Scrap differred sentence warning, it doesn't work way it should, and just spams.  
