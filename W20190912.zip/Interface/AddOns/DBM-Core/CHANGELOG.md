# Deadly Boss Mods Core

## [8.2.18](https://github.com/DeadlyBossMods/DeadlyBossMods/tree/8.2.18) (2019-09-10)
[Full Changelog](https://github.com/DeadlyBossMods/DeadlyBossMods/compare/8.2.17...8.2.18)

- Bump version. Sorry for frequent release, but this fix needs to go out to undo damage twitch client did for some users when it installed wrong mods.  
- Re-Fixed sound files being set to classic embed sounds. I forgot the search string was string lowered so last fix didn't work. This one will.  
- KR Update (#67)  
    * KR Update  
- Some git file cleanup (#66)  
    * Some git file cleanup  
    * Github directory is not needed, as its handled via commity wide (issues, contributing, funding, support)  
    * pkgmeta and travis using correct indentation (as per .editorconfig)  
    * README is now markdown syntaxed, and fixed curseforge links  
    * Too much indentation on this line  
    * fix yml file indents  
    * again  
