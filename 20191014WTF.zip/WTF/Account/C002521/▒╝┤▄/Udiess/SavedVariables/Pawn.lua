
PawnOptions = {
	["LastVersion"] = 2.0231,
	["LastPlayerFullName"] = "Udiess-굴단",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "MAGE",
	["LastAdded"] = 1,
}
