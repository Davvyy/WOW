
AzeriteTooltipDB = {
	["profileKeys"] = {
		["쌩뚱마삼 - 렉사르"] = "Default",
		["쌩뚱악사 - 렉사르"] = "Default",
		["쌩뚱마꾼 - 렉사르"] = "Default",
		["완소야드 - 굴단"] = "Default",
		["오지져스 - 렉사르"] = "Default",
		["뉘시빨라마 - 굴단"] = "Default",
		["아놀드클래식 - 렉사르"] = "Default",
		["닌자창고 - 렉사르"] = "Default",
		["악사다구 - 아즈샤라"] = "Default",
		["국제금융로 - 굴단"] = "Default",
		["오우지져스 - 렉사르"] = "Default",
		["쌩뚱마죠 - 렉사르"] = "Default",
		["쌩뚱마적 - 렉사르"] = "Default",
		["쌩뚱마장 - 렉사르"] = "Default",
		["무시중한디 - 굴단"] = "Default",
		["아호와의증인 - 아즈샤라"] = "Default",
		["받아줘요악사 - 아즈샤라"] = "Default",
		["공허엘프닷 - 굴단"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
