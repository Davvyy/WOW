
KuiNameplatesCoreSaved = {
	["profiles"] = {
		["default"] = {
		},
	},
}
