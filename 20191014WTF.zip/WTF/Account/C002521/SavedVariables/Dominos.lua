
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["global"] = {
				["version"] = 1,
			},
		},
	},
	["profileKeys"] = {
		["이스레인 - 아즈샤라"] = "Wide",
		["아테리에 - 아즈샤라"] = "Wide",
		["아라스틴 - 아즈샤라"] = "Wide",
		["에레로엘 - 아즈샤라"] = "Wide",
		["잘생겨따 - 굴단"] = "주술사",
		["Isolesty - 아즈샤라"] = "Wide",
		["데빌테스트용임 - 아즈샤라"] = "Wide",
		["무시중한디 - 굴단"] = "Wide",
		["레이스가드 - 아즈샤라"] = "Wide",
		["아테르나 - 하이잘"] = "주술사",
		["아이루릴 - 아즈샤라"] = "Wide",
		["테스트용임다 - 아즈샤라"] = "Wide",
		["Arastin - 아즈샤라"] = "Wide",
		["시에이레 - 듀로탄"] = "Wide",
		["데빌테스트용 - 아즈샤라"] = "Wide",
		["내꿈은샤먼킹 - 데스윙"] = "Wide",
		["폭까말랑카우 - 아즈샤라"] = "드루이드",
		["Eldersign - 아즈샤라"] = "Wide",
		["아테르나 - 아즈샤라"] = "Wide",
		["에레로엘 - 데스윙"] = "Wide",
		["이솔레스테 - 아즈샤라"] = "Wide",
		["실베르투스 - 아즈샤라"] = "Wide",
		["아테르나 - 듀로탄"] = "드루이드",
		["Wraithguard - 아즈샤라"] = "Wide",
		["Vindictus - 아즈샤라"] = "Wide",
		["아테리에 - 데스윙"] = "Wide",
	},
	["profiles"] = {
		["Normal"] = {
			["minimapPos"] = 345.963544320503,
			["showMinimap"] = false,
			["showgrid"] = 1,
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 1.15,
					["showInOverrideUI"] = true,
					["padW"] = 2,
					["x"] = -220,
					["spacing"] = 1,
					["padH"] = 2,
					["y"] = 146.162048339844,
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARRIOR"] = {
							["battle"] = 6,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["berserker"] = 8,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["shadow"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page2"] = 1,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["DRUID"] = {
							["prowl"] = 6,
							["bear"] = 8,
							["page2"] = 1,
							["cat"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["moonkin"] = 9,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MONK"] = {
							["page6"] = 5,
							["page2"] = 1,
							["page3"] = 2,
							["page5"] = 4,
							["page4"] = 3,
							["tiger"] = 6,
							["serpent"] = 8,
							["ox"] = 7,
						},
						["DEATHKNIGHT"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 0,
					["x"] = 0,
					["spacing"] = 5,
					["padH"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [2]
				{
					["showInPetBattleUI"] = true,
					["point"] = "CENTER",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = 0,
					["padW"] = 0,
					["x"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["spacing"] = -2,
					["padH"] = 0,
					["anchor"] = "4BL",
					["numButtons"] = 12,
					["isBottomToTop"] = true,
				}, -- [3]
				{
					["showInPetBattleUI"] = true,
					["point"] = "BOTTOM",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["padW"] = 0,
					["y"] = 251.199806424109,
					["x"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["spacing"] = -2,
					["padH"] = 0,
					["anchor"] = "5BC",
					["numButtons"] = 12,
					["isBottomToTop"] = true,
				}, -- [4]
				{
					["showInPetBattleUI"] = true,
					["point"] = "BOTTOM",
					["scale"] = 0.95,
					["showInOverrideUI"] = false,
					["y"] = 126,
					["x"] = -73,
					["padW"] = 0,
					["spacing"] = -2,
					["padH"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["numButtons"] = 12,
					["isBottomToTop"] = true,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 1.15,
					["showInOverrideUI"] = false,
					["y"] = 148.572781596245,
					["x"] = -74.3946710843535,
					["padH"] = 2,
					["spacing"] = 1,
					["anchor"] = "1RC",
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 0,
					["x"] = 438.333354935059,
					["y"] = 510.666732311488,
					["spacing"] = 5,
					["anchor"] = "2BL",
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["padH"] = 0,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["alpha"] = 0.798039215686275,
					["padW"] = 0,
					["x"] = -440.555433010075,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["spacing"] = 5,
					["anchor"] = "7BR",
					["y"] = 396.888915452142,
					["numButtons"] = 12,
					["padH"] = 0,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 2,
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 0,
					["y"] = -510.222413966165,
					["x"] = 444.444422461063,
					["numButtons"] = 6,
					["spacing"] = 2,
					["anchor"] = "2TL",
					["padH"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["point"] = "TOPLEFT",
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 2,
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 0,
					["y"] = -510.222374884597,
					["x"] = -444.444283504377,
					["numButtons"] = 6,
					["spacing"] = 2,
					["anchor"] = "2TR",
					["padH"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["SHAMAN"] = {
						},
						["PRIEST"] = {
						},
						["WARLOCK"] = {
						},
						["ROGUE"] = {
						},
						["PALADIN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["point"] = "TOPRIGHT",
				}, -- [10]
				["totem1"] = {
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.9,
					["showRecall"] = true,
					["padW"] = 0,
					["x"] = 561.69983447582,
					["spacing"] = 2,
					["showTotems"] = true,
					["y"] = 339.243954550885,
					["padH"] = 0,
					["anchor"] = "totem2LC",
				},
				["extra"] = {
					["y"] = -341.199987023698,
					["x"] = -403.800217162228,
					["point"] = "TOPRIGHT",
					["anchor"] = "10TC",
					["padH"] = 14,
					["showInOverrideUI"] = false,
					["padW"] = 14,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = 441.29108707442,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 0,
					["anchor"] = "1TR",
					["showInOverrideUI"] = false,
					["numButtons"] = 3,
					["y"] = 221.917746275897,
				},
				["xp"] = {
					["y"] = 0,
					["alwaysShowXP"] = 1,
					["point"] = "BOTTOMRIGHT",
					["width"] = 1,
					["height"] = 5,
					["x"] = 0,
					["alwaysShowText"] = true,
					["texture"] = "Smooth",
				},
				["cast"] = {
					["point"] = "BOTTOMLEFT",
					["scale"] = 1.5,
					["hidden"] = true,
					["padW"] = -5,
					["x"] = 303.376435264856,
					["showText"] = true,
					["padH"] = -5,
					["y"] = 117.200004121884,
					["anchor"] = "2BC",
				},
				["totem3"] = {
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["hidden"] = true,
					["y"] = 339.243954550885,
					["x"] = -398.522384627646,
					["showRecall"] = true,
					["spacing"] = 2,
					["padH"] = 0,
					["showTotems"] = true,
					["padW"] = 0,
					["anchor"] = "totem2RC",
				},
				["bags"] = {
					["showInPetBattleUI"] = true,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 1.12,
					["showInOverrideUI"] = false,
					["y"] = 153.931460547653,
					["x"] = -190.427309816549,
					["spacing"] = -1,
					["anchor"] = "3BR",
					["padW"] = 0,
					["numButtons"] = 5,
					["padH"] = 0,
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 220.917766198337,
					["showstates"] = "[@pet,exists,nobonusbar:5]",
					["spacing"] = 2,
					["anchor"] = "1TL",
					["numButtons"] = 10,
					["x"] = 115.571035520336,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["showstates"] = "[@vehicle,exists]",
					["point"] = "BOTTOMRIGHT",
					["x"] = -241.025024414063,
					["anchor"] = "6TC",
					["showInOverrideUI"] = false,
					["numButtons"] = 3,
					["y"] = 224.20002746582,
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.75,
					["showInOverrideUI"] = false,
					["y"] = 21.8296451568604,
					["x"] = 340.909912109375,
					["spacing"] = -3,
					["padH"] = 0,
					["anchor"] = "bagsLB",
					["padW"] = 0,
					["disabled"] = {
					},
				},
				["totem2"] = {
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["hidden"] = true,
					["y"] = 247.940618610841,
					["x"] = -621.584888649345,
					["spacing"] = 2,
					["padH"] = 0,
					["showRecall"] = true,
					["showTotems"] = true,
					["padW"] = 0,
				},
			},
			["minimap"] = {
				["hide"] = true,
			},
			["ab"] = {
				["style"] = {
					"Onyx", -- [1]
					0.75, -- [2]
					false, -- [3]
					{
					}, -- [4]
				},
			},
			["classStyle"] = {
				"Onyx", -- [1]
				0.75, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
			["bagStyle"] = {
				"Onyx", -- [1]
				nil, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
			["sticky"] = 1,
			["petStyle"] = {
				"Onyx", -- [1]
				0.75, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
			["useOverrideUI"] = false,
		},
		["사제"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["pages"] = {
						["PRIEST"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["shadow"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["pages"] = {
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
			},
		},
		["주술사"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["SHAMAN"] = {
						},
					},
				}, -- [10]
				["artifact"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["numButtons"] = 20,
					["y"] = -16,
					["lockMode"] = true,
					["padH"] = 2,
					["font"] = "Friz Quadrata TT",
					["padW"] = 2,
					["x"] = 0,
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["mode"] = "artifact",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["numButtons"] = 20,
					["y"] = 0,
					["lockMode"] = true,
					["padH"] = 2,
					["font"] = "Friz Quadrata TT",
					["padW"] = 2,
					["x"] = 0,
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["mode"] = "xp",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["point"] = "CENTER",
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["icon"] = false,
						["time"] = true,
					},
					["x"] = 0,
					["texture"] = "blizzard",
				},
			},
		},
		["수도사"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["pages"] = {
						["MONK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["pages"] = {
						["MONK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
		},
		["Wide"] = {
			["showMinimap"] = false,
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1.05,
					["showInOverrideUI"] = true,
					["padW"] = 0,
					["x"] = 93.0639885946849,
					["y"] = 174.579714095353,
					["spacing"] = 0,
					["padH"] = 0,
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARRIOR"] = {
							["battle"] = 6,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["berserker"] = 8,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["shadow"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page2"] = 1,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["meta"] = 6,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["DEMONHUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["SHAMAN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["DRUID"] = {
							["prowl"] = 6,
							["bear"] = 8,
							["page2"] = 1,
							["cat"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["moonkin"] = 9,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MONK"] = {
							["page6"] = 5,
							["page2"] = 1,
							["page3"] = 2,
							["page5"] = 4,
							["page4"] = 3,
							["tiger"] = 6,
							["serpent"] = 8,
							["ox"] = 7,
						},
						["DEATHKNIGHT"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["anchor"] = "6LC",
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["scale"] = 0.96,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 17,
					["alpha"] = 0.9,
					["spacing"] = 17,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["padW"] = 2,
				}, -- [2]
				{
					["showInPetBattleUI"] = true,
					["point"] = "BOTTOM",
					["scale"] = 1.1,
					["showInOverrideUI"] = false,
					["y"] = 42,
					["padW"] = 0,
					["x"] = 40,
					["numButtons"] = 12,
					["spacing"] = 0,
					["padH"] = 0,
					["columns"] = 4,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["isBottomToTop"] = true,
				}, -- [3]
				{
					["showInPetBattleUI"] = true,
					["columns"] = 4,
					["scale"] = 1.1,
					["showInOverrideUI"] = false,
					["y"] = 54.3414598007697,
					["x"] = -432.698800615813,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 0,
					["anchor"] = "3RC",
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["numButtons"] = 12,
					["isBottomToTop"] = true,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 1.05,
					["showInOverrideUI"] = false,
					["y"] = 238.746396002938,
					["x"] = -264.78909789527,
					["padW"] = 0,
					["spacing"] = 0,
					["anchor"] = "6RC",
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 0,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 1.05,
					["showInOverrideUI"] = false,
					["padW"] = 0,
					["x"] = 0,
					["spacing"] = 0,
					["padH"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 170,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["columns"] = 2,
					["padW"] = 0,
					["x"] = 560.897318214435,
					["numButtons"] = 6,
					["spacing"] = 2,
					["anchor"] = "2BL",
					["padH"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 350.723205251742,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["columns"] = 2,
					["padW"] = 0,
					["x"] = -578.45189002587,
					["numButtons"] = 6,
					["spacing"] = 2,
					["anchor"] = "2BR",
					["padH"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 360.011003826443,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "TOPLEFT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["anchor"] = "2TL",
					["padW"] = 0,
					["x"] = 577.955778467372,
					["numButtons"] = 6,
					["spacing"] = 2,
					["padH"] = 0,
					["y"] = -435.555220945218,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["columns"] = 2,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["anchor"] = "2TR",
					["padW"] = 0,
					["x"] = -559.814105990373,
					["numButtons"] = 6,
					["spacing"] = 2,
					["padH"] = 0,
					["y"] = 505.3898363055,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
						["WARLOCK"] = {
						},
						["DEMONHUNTER"] = {
						},
						["SHAMAN"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["DEATHKNIGHT"] = {
						},
					},
					["columns"] = 2,
				}, -- [10]
				["artifact"] = {
					["point"] = "TOP",
					["scale"] = 1,
					["lockMode"] = true,
					["padW"] = 2,
					["spacing"] = 1,
					["anchor"] = "expBL",
					["mode"] = "artifact",
					["numButtons"] = 20,
					["texture"] = "blizzard",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["alpha"] = 0,
					["width"] = 1024,
					["y"] = -16,
					["font"] = "Friz Quadrata TT",
					["x"] = -34,
					["alwaysShowText"] = true,
					["padH"] = 2,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["height"] = 12,
					["hidden"] = true,
				},
				["totem1"] = {
					["y"] = 245.333347578497,
					["x"] = 634.222314659588,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 2,
					["scale"] = 0.9,
					["showTotems"] = true,
					["showRecall"] = true,
					["anchor"] = "6TL",
				},
				["extra"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOPRIGHT",
					["showInOverrideUI"] = false,
					["padW"] = 14,
					["x"] = -527.460098934066,
					["anchor"] = "10TC",
					["y"] = -339.999746117449,
					["padH"] = 14,
				},
				["exp"] = {
					["point"] = "TOP",
					["lockMode"] = true,
					["padW"] = 2,
					["spacing"] = 1,
					["mode"] = "xp",
					["numButtons"] = 20,
					["texture"] = "blizzard",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["font"] = "Friz Quadrata TT",
					["padH"] = 2,
					["alwaysShowText"] = true,
					["x"] = -34,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
				},
				["encounter"] = {
					["y"] = -204,
					["showInOverrideUI"] = true,
					["showInPetBattleUI"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = true,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.88,
					["showInOverrideUI"] = false,
					["padW"] = 0,
					["x"] = -546.255719019363,
					["spacing"] = -2,
					["anchor"] = "4BR",
					["y"] = 22.2840976715088,
					["numButtons"] = 5,
					["padH"] = 0,
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["y"] = 217.395133257061,
					["showstates"] = "[@pet,exists,nobonusbar:5]",
					["spacing"] = 0,
					["anchor"] = "1TR",
					["numButtons"] = 10,
					["x"] = 240.656357526237,
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1.5,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = -5,
					["x"] = 303.376435264856,
					["showText"] = true,
					["y"] = 117.200004121884,
					["padH"] = -5,
					["anchor"] = "2BC",
					["display"] = {
						["icon"] = false,
						["time"] = true,
						["border"] = true,
					},
					["font"] = "Friz Quadrata TT",
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["columns"] = 1,
					["showInOverrideUI"] = true,
					["y"] = 216,
					["x"] = 97,
					["spacing"] = 2,
					["anchor"] = "petLB",
					["point"] = "BOTTOMLEFT",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.61,
					["showInOverrideUI"] = false,
					["y"] = 619.093078613281,
					["x"] = -672.263087214819,
					["spacing"] = -2,
					["anchor"] = "bagsLB",
					["disabled"] = {
					},
				},
				["xp"] = {
					["y"] = 0,
					["alwaysShowXP"] = true,
					["point"] = "BOTTOMLEFT",
					["texture"] = "Smooth",
					["height"] = 4,
					["x"] = 8.637067856354240e-005,
					["alwaysShowText"] = true,
					["width"] = 1,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["spacing"] = 0,
					["anchor"] = "6TC",
					["showInOverrideUI"] = false,
					["numButtons"] = 3,
					["y"] = 216,
				},
				["vehicle"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["y"] = 98.4150657785651,
					["showstates"] = "[@vehicle,exists]",
					["anchor"] = "6TR",
					["numButtons"] = 3,
					["x"] = -568.158752787208,
				},
				["totem3"] = {
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["hidden"] = true,
					["y"] = 336.986849066613,
					["x"] = -486.297994433281,
					["spacing"] = 2,
					["anchor"] = "totem2RC",
					["showRecall"] = true,
					["showTotems"] = true,
				},
				["totem2"] = {
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.9,
					["hidden"] = true,
					["y"] = 336.986849066613,
					["x"] = -636.297945934122,
					["spacing"] = 2,
					["anchor"] = "totem1RT",
					["showRecall"] = true,
					["showTotems"] = true,
				},
			},
			["minimap"] = {
				["hide"] = true,
			},
			["ab"] = {
				["style"] = {
					"Onyx", -- [1]
					0.75, -- [2]
					false, -- [3]
					{
					}, -- [4]
				},
			},
			["petStyle"] = {
				"Onyx", -- [1]
				0.75, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
			["minimapPos"] = 224.261066539179,
			["classStyle"] = {
				"Onyx", -- [1]
				0.75, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
			["bagStyle"] = {
				"Onyx", -- [1]
				nil, -- [2]
				false, -- [3]
				{
				}, -- [4]
			},
			["showgrid"] = 1,
			["sticky"] = 1,
			["useOverrideUI"] = false,
		},
		["흑마법사"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
		},
		["사냥꾼"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 360,
				}, -- [10]
				["artifact"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["alwaysShowText"] = true,
					["y"] = -16,
					["lockMode"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["x"] = 0,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["padH"] = 2,
					["mode"] = "artifact",
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["alwaysShowText"] = true,
					["y"] = 0,
					["lockMode"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["x"] = 0,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["padH"] = 2,
					["mode"] = "xp",
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["point"] = "CENTER",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["border"] = true,
						["icon"] = false,
					},
					["x"] = 0,
					["texture"] = "blizzard",
				},
			},
		},
		["악마사냥꾼"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["DEMONHUNTER"] = {
						},
					},
				}, -- [10]
				["artifact"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["point"] = "TOP",
					["numButtons"] = 20,
					["padW"] = 2,
					["lockMode"] = true,
					["padH"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = -16,
					["x"] = 0,
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["mode"] = "artifact",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["point"] = "TOP",
					["numButtons"] = 20,
					["padW"] = 2,
					["lockMode"] = true,
					["padH"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = 0,
					["x"] = 0,
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["mode"] = "xp",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["x"] = 0,
					["display"] = {
						["border"] = true,
						["icon"] = false,
						["time"] = true,
					},
					["texture"] = "blizzard",
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["point"] = "CENTER",
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
			},
		},
		["마법사"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
		},
		["드루이드"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
							["bear"] = 8,
							["tree"] = 7,
							["page2"] = 1,
							["cat"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["moonkin"] = 9,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DRUID"] = {
						},
					},
					["y"] = 360,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
		},
		["전사"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 360,
				}, -- [10]
				["artifact"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["alwaysShowText"] = true,
					["y"] = -16,
					["lockMode"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["x"] = 0,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["padH"] = 2,
					["mode"] = "artifact",
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["alwaysShowText"] = true,
					["y"] = 0,
					["lockMode"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["x"] = 0,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["padH"] = 2,
					["mode"] = "xp",
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["point"] = "CENTER",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["icon"] = false,
						["time"] = true,
					},
					["x"] = 0,
					["texture"] = "blizzard",
				},
			},
		},
		["성기사"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 360,
				}, -- [10]
				["artifact"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["alwaysShowText"] = true,
					["y"] = -16,
					["lockMode"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["x"] = 0,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["padH"] = 2,
					["mode"] = "artifact",
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["alwaysShowText"] = true,
					["y"] = 0,
					["lockMode"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["x"] = 0,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["padH"] = 2,
					["mode"] = "xp",
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["point"] = "CENTER",
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 30,
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["border"] = true,
						["icon"] = false,
					},
					["x"] = 0,
					["texture"] = "blizzard",
				},
			},
		},
		["도적"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["ROGUE"] = {
						},
					},
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
			},
		},
		["죽음의 기사"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["y"] = 0,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 160,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 200,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["DEATHKNIGHT"] = {
						},
					},
					["y"] = 360,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["extra"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
			},
		},
	},
}
DominosVersion = "7.3.2"
