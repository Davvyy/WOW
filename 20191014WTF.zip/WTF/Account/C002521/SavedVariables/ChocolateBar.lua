
ChocolateBarDB = {
	["profileKeys"] = {
		["이스레인 - 아즈샤라"] = "Wide",
		["아테리에 - 아즈샤라"] = "Wide",
		["아라스틴 - 아즈샤라"] = "Wide",
		["에레로엘 - 아즈샤라"] = "Wide",
		["잘생겨따 - 굴단"] = "Default",
		["Isolesty - 아즈샤라"] = "Wide",
		["데빌테스트용임 - 아즈샤라"] = "Wide",
		["무시중한디 - 굴단"] = "Wide",
		["레이스가드 - 아즈샤라"] = "Wide",
		["아테르나 - 하이잘"] = "Default",
		["아이루릴 - 아즈샤라"] = "Wide",
		["테스트용임다 - 아즈샤라"] = "Wide",
		["Arastin - 아즈샤라"] = "Wide",
		["시에이레 - 듀로탄"] = "Wide",
		["데빌테스트용 - 아즈샤라"] = "Wide",
		["내꿈은샤먼킹 - 데스윙"] = "Wide",
		["폭까말랑카우 - 아즈샤라"] = "Default",
		["Eldersign - 아즈샤라"] = "Wide",
		["아테르나 - 아즈샤라"] = "Wide",
		["에레로엘 - 데스윙"] = "Wide",
		["이솔레스테 - 아즈샤라"] = "Wide",
		["실베르투스 - 아즈샤라"] = "Wide",
		["아테르나 - 듀로탄"] = "Default",
		["Wraithguard - 아즈샤라"] = "Wide",
		["Vindictus - 아즈샤라"] = "Wide",
		["아테리에 - 데스윙"] = "Wide",
	},
	["profiles"] = {
		["Normal"] = {
			["fontSize"] = 13,
			["fontPath"] = "Fonts\\2002.TTF",
			["objSettings"] = {
				["Recount"] = {
					["align"] = "right",
					["index"] = 2,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["RangeDisplay"] = {
					["enabled"] = false,
					["index"] = 1,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["MoreChocolate"] = {
					["enabled"] = false,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["index"] = 2,
					["showIcon"] = false,
				},
				["PitBull4"] = {
					["enabled"] = false,
					["index"] = 4,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["|cFFFFB366Ara|r Friends"] = {
					["align"] = "right",
					["index"] = 1,
					["barName"] = "ChocolateBar2",
				},
				["Broker_XPBar"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar1",
				},
				["EquippedItemLevelTooltip"] = {
					["index"] = 2,
					["barName"] = "ChocolateBar1",
				},
				["zBrokerDurability"] = {
					["align"] = "right",
					["index"] = 5,
					["barName"] = "ChocolateBar1",
				},
				["Devilconfig"] = {
					["align"] = "center",
					["index"] = 1,
					["barName"] = "ChocolateBar2",
				},
				["SavedInstances"] = {
					["index"] = 3,
					["barName"] = "ChocolateBar1",
				},
				["Omen"] = {
					["align"] = "right",
					["index"] = 1,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["|cFFFFB366Ara|r Tradeskills"] = {
					["index"] = 3,
					["barName"] = "ChocolateBar2",
				},
				["QuestPointer"] = {
					["enabled"] = false,
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["|cFFFFB366Ara|r Guild"] = {
					["align"] = "right",
					["index"] = 2,
					["barName"] = "ChocolateBar2",
				},
				["BrokerXPBar"] = {
					["align"] = "center",
					["index"] = 1,
					["barName"] = "ChocolateBar1",
				},
				["BlueItemInfo3"] = {
					["index"] = 5,
					["barName"] = "ChocolateBar1",
				},
				["InvenRaidFrames2"] = {
					["align"] = "right",
					["index"] = 1,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["shLatency"] = {
					["index"] = 2,
					["barName"] = "ChocolateBar2",
				},
				["Dominos"] = {
					["enabled"] = false,
					["index"] = 2,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["Broker_RaidSave"] = {
					["index"] = 4,
					["barName"] = "ChocolateBar2",
				},
				["Broker_Money"] = {
					["align"] = "right",
					["showIcon"] = false,
					["index"] = 6,
					["barName"] = "ChocolateBar1",
				},
				["InvenRaidFrames3"] = {
					["align"] = "right",
					["index"] = 4,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["shFps"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar2",
				},
				["FindParty"] = {
					["index"] = 4,
					["barName"] = "ChocolateBar1",
				},
				["kgPanels"] = {
					["enabled"] = false,
					["index"] = 3,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["Masque"] = {
					["enabled"] = false,
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
			},
			["gap"] = 5,
			["barSettings"] = {
				["ChocolateBar1"] = {
					["barOffy"] = 1,
					["barPoint"] = "RIGHT",
					["align"] = "bottom",
					["barOffx"] = 0,
					["width"] = 3000,
				},
				["ChocolateBar2"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar2",
				},
			},
			["locked"] = true,
			["background"] = {
				["color"] = {
					["a"] = 0,
					["g"] = 0.36078431372549,
					["r"] = 0.380392156862745,
				},
			},
			["fontName"] = "기본 글꼴",
			["iconSize"] = 0.65,
		},
		["Wide"] = {
			["barSettings"] = {
				["ChocolateBar1"] = {
					["barOffy"] = 1,
					["barPoint"] = "RIGHT",
					["align"] = "bottom",
					["width"] = 3000,
					["barOffx"] = 0,
				},
				["ChocolateBar2"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar2",
				},
			},
			["background"] = {
				["color"] = {
					["a"] = 0,
					["g"] = 0.36078431372549,
					["r"] = 0.380392156862745,
				},
			},
			["fontPath"] = "Fonts\\2002.TTF",
			["objSettings"] = {
				["RangeDisplay"] = {
					["enabled"] = false,
					["index"] = 1,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["PitBull4"] = {
					["enabled"] = false,
					["index"] = 4,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["Broker_XPBar"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar1",
				},
				["zBrokerDurability"] = {
					["index"] = 4,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["WeakAuras"] = {
					["barName"] = "ChocolateBar1",
				},
				["|cFFFFB366Ara|r Tradeskills"] = {
					["index"] = 3,
					["barName"] = "ChocolateBar2",
				},
				["|cFFFFB366Ara|r Guild"] = {
					["index"] = 2,
					["barName"] = "ChocolateBar2",
					["align"] = "right",
				},
				["BlueItemInfo3"] = {
					["index"] = 4,
					["barName"] = "ChocolateBar1",
				},
				["TradeLog"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["shLatency"] = {
					["index"] = 2,
					["barName"] = "ChocolateBar2",
				},
				["Dominos"] = {
					["enabled"] = false,
					["index"] = 2,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["Devilconfig"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar2",
					["align"] = "center",
				},
				["Skada"] = {
					["index"] = 6,
					["barName"] = "ChocolateBar1",
				},
				["InvenRaidFrames3"] = {
					["index"] = 3,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["MoreChocolate"] = {
					["enabled"] = false,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["index"] = 2,
					["showIcon"] = false,
				},
				["|cFFFFB366Ara|r Friends"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar2",
					["align"] = "right",
				},
				["ExRT"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["index"] = 6,
				},
				["EquippedItemLevelTooltip"] = {
					["index"] = 2,
					["barName"] = "ChocolateBar1",
				},
				["FindParty"] = {
					["index"] = 3,
					["barName"] = "ChocolateBar1",
				},
				["TellMeWhen"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["SavedInstances"] = {
					["index"] = 2,
					["barName"] = "ChocolateBar1",
				},
				["Grid"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["BrokerXPBar"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar1",
					["align"] = "center",
				},
				["Omen"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["Grid2"] = {
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["Broker_RaidSave"] = {
					["index"] = 4,
					["barName"] = "ChocolateBar2",
				},
				["InvenRaidFrames2"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["QuestPointer"] = {
					["enabled"] = false,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
				["GarrisonMissionManager"] = {
					["index"] = 5,
					["barName"] = "ChocolateBar1",
				},
				["shFps"] = {
					["index"] = 1,
					["barName"] = "ChocolateBar2",
				},
				["Broker_Money"] = {
					["showIcon"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["index"] = 5,
				},
				["Recount"] = {
					["index"] = 2,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["kgPanels"] = {
					["enabled"] = false,
					["index"] = 3,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
					["showText"] = false,
				},
				["Masque"] = {
					["enabled"] = false,
					["showText"] = false,
					["barName"] = "ChocolateBar1",
					["align"] = "right",
				},
			},
			["gap"] = 5,
			["fontName"] = "기본 글꼴",
			["fontSize"] = 13,
			["moduleOptions"] = {
				["MoreChocolate"] = {
				},
				["Placeholder"] = {
					["placeholderNames"] = {
					},
				},
			},
			["iconSize"] = 0.65,
			["locked"] = true,
		},
		["Default"] = {
			["moduleOptions"] = {
				["MoreChocolate"] = {
				},
				["Placeholder"] = {
					["placeholderNames"] = {
					},
				},
			},
			["objSettings"] = {
				["Recount"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["RangeDisplay"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["MoreChocolate"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["PitBull4"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["|cFFFFB366Ara|r Friends"] = {
					["barName"] = "ChocolateBar1",
				},
				["Broker_XPBar"] = {
					["barName"] = "ChocolateBar1",
				},
				["zBrokerDurability"] = {
					["barName"] = "ChocolateBar1",
				},
				["SavedInstances"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["Masque"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["Omen"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["|cFFFFB366Ara|r Guild"] = {
					["barName"] = "ChocolateBar1",
				},
				["Skada"] = {
					["barName"] = "ChocolateBar1",
				},
				["BlueItemInfo3"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["TradeLog"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["shLatency"] = {
					["barName"] = "ChocolateBar1",
				},
				["Dominos"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["Broker_Money"] = {
					["barName"] = "ChocolateBar1",
				},
				["InvenRaidFrames3"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["FindParty"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["shFps"] = {
					["barName"] = "ChocolateBar1",
				},
				["ExRT"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["kgPanels"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
				["Devilconfig"] = {
					["align"] = "right",
					["showText"] = false,
					["barName"] = "ChocolateBar1",
				},
			},
		},
	},
}
