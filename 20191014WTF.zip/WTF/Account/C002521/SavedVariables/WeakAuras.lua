
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["displays"] = {
		["쐐기 : 산개 디버프"] = {
			["glow"] = false,
			["authorOptions"] = {
			},
			["customText"] = "",
			["yOffset"] = -165,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["glow_action"] = "show",
					["message_type"] = "YELL",
					["do_message"] = false,
					["message"] = "",
					["custom"] = "if aura_env and aura_env.state then\n    aura_env.name = aura_env.state.name\nend",
					["do_sound"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
					["do_glow"] = false,
				},
				["finish"] = {
					["do_glow"] = false,
					["custom"] = "aura_env.name = nil\n",
					["glow_action"] = "hide",
					["do_custom"] = true,
					["glow_frame"] = "",
				},
				["init"] = {
					["custom"] = "aura_env.name = nil\n\naura_env.Range ={\n    [\"어둠의 전조\"] = 3,\n    [\"썩은 물\"] = 4,\n    [\"폭발적인 분출\"] = 4,\n    [\"공허의 씨앗\"] = 5,\n    [\"치명적인 병균\"] = 5,\n    [\"공포의 징표\"] = 5,\n    [\"불안정한 룬 징표\"] = 5,\n    [\"룬 징표\"] = 5,\n    [\"불안정한 사술\"] = 7,\n    [\"전도\"] = 7,\n    [\"어둠의 계시\"] = 22,\n}",
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
					["scalex"] = 2.5,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["scaleType"] = "straightScale",
					["scaley"] = 2.5,
					["alpha"] = 0,
					["colorR"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorA"] = 1,
					["duration_type"] = "seconds",
					["type"] = "custom",
					["rotate"] = 0,
					["duration"] = "0.17",
					["use_scale"] = true,
				},
				["main"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scaleType"] = "pulse",
					["type"] = "none",
					["scalex"] = 1.05,
					["use_scale"] = true,
					["duration"] = "1",
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorG"] = 1,
					["colorB"] = 1,
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["scaley"] = 1.05,
					["colorR"] = 1,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["auto"] = true,
			["tocversion"] = 80205,
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["icon"] = true,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "이격",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "기본 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = false,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 34,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
				{
					["type"] = "subborder",
					["border_offset"] = 0,
					["border_color"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "1 Pixel",
					["border_size"] = 3,
				}, -- [2]
			},
			["height"] = 80,
			["keepAspectRatio"] = false,
			["glowLines"] = 8,
			["parent"] = "쐐기 : 기타 0929",
			["glowFrequency"] = 0.25,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["message"] = "%n(이격) 대상!",
								["message_type"] = "YELL",
							},
							["property"] = "chat",
						}, -- [1]
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\ESPARK1.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 1,
						["checks"] = {
							{
								["trigger"] = 2,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "glow",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "sub.1.text_visible",
						}, -- [2]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 0,
						["checks"] = {
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [1]
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [2]
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [3]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "magic",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								0.92156862745098, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "sub.2.border_color",
						}, -- [1]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "curse",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.90196078431373, -- [1]
								0, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "sub.2.border_color",
						}, -- [1]
					},
				}, -- [5]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "disease",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.52156862745098, -- [1]
								0.32941176470588, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "sub.2.border_color",
						}, -- [1]
					},
				}, -- [6]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"불안정한 사술", -- [1]
							"불안정한 룬 징표", -- [2]
							"공포의 징표", -- [3]
							"공허의 씨앗", -- [4]
							"치명적인 병균", -- [5]
							"썩은 물", -- [6]
							"전도", -- [7]
							"어둠의 전조", -- [8]
							"어둠의 계시", -- [9]
							"룬 징표", -- [10]
							"폭발적인 분출", -- [11]
						},
						["matchesShowOn"] = "showOnActive",
						["unit"] = "player",
						["use_tooltip"] = false,
						["debuffType"] = "HARMFUL",
						["type"] = "aura2",
						["use_debuffClass"] = false,
						["unevent"] = "auto",
						["useGroup_count"] = false,
						["event"] = "Health",
						["names"] = {
							"불안정한 사술", -- [1]
							"불안정한 룬 징표", -- [2]
							"공포의 징표", -- [3]
							"공허의 씨앗", -- [4]
							"치명적인 병균", -- [5]
							"썩은 물", -- [6]
							"전도", -- [7]
							"어둠의 전조", -- [8]
							"어둠의 계시", -- [9]
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["useName"] = true,
						["use_absorbMode"] = true,
						["combineMatches"] = "showLowest",
						["buffShowOn"] = "showOnActive",
						["use_unit"] = true,
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customDuration"] = "",
						["custom"] = "function()\n    if not aura_env.last or GetTime() - aura_env.last > 0.1 then\n        aura_env.last = GetTime()\n        if WeakAuras.triggerState[aura_env.id].triggers[1] then\n            for unit in WA_IterateGroupMembers() do                \n                if unit ~= \"player\" and WeakAuras.CheckRange(unit, aura_env.Range[aura_env.name], \"<=\") then\n                    return true\n                end\n            end\n        end\n    end\nend",
						["check"] = "update",
						["events"] = "",
						["custom_type"] = "status",
					},
					["untrigger"] = {
						["custom"] = "function()\nreturn true\nend",
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\nreturn t[1]\nend",
				["activeTriggerMode"] = -10,
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["desaturate"] = false,
			["config"] = {
			},
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["width"] = 80,
			["frameStrata"] = 1,
			["selfPoint"] = "CENTER",
			["cooldownEdge"] = false,
			["zoom"] = 0,
			["glowLength"] = 10,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["glowScale"] = 1,
			["id"] = "쐐기 : 산개 디버프",
			["xOffset"] = 0,
			["alpha"] = 1,
			["glowYOffset"] = 0,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "7YMMToFEO3e",
			["inverse"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = ">=",
				["encounterid"] = "2073",
				["use_encounterid"] = false,
				["role"] = {
					["multi"] = {
					},
				},
				["level"] = "",
				["use_encounter"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["mythic"] = true,
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "110",
				["faction"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "8040",
				["level_operator"] = ">=",
				["use_zoneId"] = false,
				["use_zone"] = false,
			},
			["displayIcon"] = "136066",
			["cooldown"] = true,
			["glowBorder"] = false,
		},
		["쐐기 : 전율 예상"] = {
			["sparkWidth"] = 25,
			["stacksSize"] = 12,
			["authorOptions"] = {
			},
			["stacksFlags"] = "None",
			["yOffset"] = -245,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["icon"] = true,
			["fontFlags"] = "OUTLINE",
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0.66666666666667, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = "==",
				["level_operator"] = "==",
				["role"] = {
					["multi"] = {
					},
				},
				["use_difficulty"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["single"] = 14,
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["level"] = "",
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "120",
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["use_affixes"] = true,
				["race"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
			},
			["timerColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "text",
			["stacks"] = false,
			["texture"] = "Minimalist",
			["textFont"] = "Friz Quadrata TT",
			["borderOffset"] = 5,
			["auto"] = true,
			["tocversion"] = 80205,
			["timerFont"] = "Friz Quadrata TT",
			["alpha"] = 1,
			["borderInset"] = 11,
			["fixedWidth"] = 200,
			["textColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["outline"] = "OUTLINE",
			["borderBackdrop"] = "Blizzard Tooltip",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    if WeakAuras.IsOptionsOpen() then\n        return \"다음 전율 예상: 1.8\" \n    end\n    \n    if aura_env.Quake then\n        local Quake = 20- ((GetTime() - aura_env.Quake)%20)\n        return \"다음 전율 예상: \"..format( \"%.1f\", Quake) \n    end\nend",
			["barInFront"] = true,
			["parent"] = "쐐기 : 기타 0929",
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["displayTextLeft"] = "  다음 전율 예상",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["debuffType"] = "HELPFUL",
						["custom_type"] = "event",
						["subeventPrefix"] = "SPELL",
						["duration"] = "100",
						["event"] = "Chat Message",
						["unit"] = "player",
						["names"] = {
						},
						["dynamicDuration"] = false,
						["custom"] = "function(event, ...)\n    \n    local _,subevent,_,sourceGUID,_,_,_,destGUID,destName,_,_,spellID,spellName = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" and spellName == \"전율\" and destName == WeakAuras.me then   \n        aura_env.Quake = GetTime()\n        return true\n    end\nend",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["spellIds"] = {
						},
						["unevent"] = "timed",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "all",
				["activeTriggerMode"] = 1,
			},
			["textFlags"] = "None",
			["internalVersion"] = 24,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["type"] = "custom",
					["colorR"] = 1,
					["use_color"] = true,
					["scaley"] = 1,
					["x"] = 0,
					["duration"] = "",
					["alpha"] = 0,
					["colorType"] = "custom",
					["y"] = 0,
					["colorA"] = 1,
					["colorG"] = 0,
					["colorB"] = 0.03921568627451,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    if WeakAuras.IsOptionsOpen() then\n        return 1,0,0,1  \n    end\n    \n    if aura_env.Quake then\n        local Quake = 20 - ((GetTime() - aura_env.Quake)%20)\n        \n        if Quake >= 0 and Quake < 3  then\n            return 1,0,0,1\n        elseif Quake >= 3 and Quake < 5 then\n            return  r1 + ((5-Quake)/2 * (r2 - r1)), g1 + ((5-Quake)/2 * (g2 - g1)), b1 + ((5-Quake)/2 * (b2 - b1)), 1\n        elseif Quake >= 5 and Quake < 10 then\n            return 1,1,1,1\n        elseif Quake >= 10 and Quake < 12 then\n            return 1,1,1,0+((12-Quake)/2 * a2)\n        else\n            return 1,1,1,0\n        end\n    else\n        return 0,0,0,0\n    end \nend",
					["rotate"] = 0,
					["scalex"] = 1,
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["displayText"] = "%c",
			["text"] = true,
			["actions"] = {
				["start"] = {
					["custom"] = "",
					["do_message"] = false,
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "aura_env.Quake = nil",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Quake = nil",
					["do_custom"] = true,
				},
			},
			["stickyDuration"] = false,
			["stacksFont"] = "Friz Quadrata TT",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["version"] = 88,
			["zoom"] = 0.25,
			["timer"] = true,
			["timerFlags"] = "None",
			["width"] = 28.000078201294,
			["sparkBlendMode"] = "ADD",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["fontSize"] = 33,
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["sparkOffsetX"] = 0,
			["sparkHidden"] = "NEVER",
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["border"] = false,
			["borderEdge"] = "None",
			["justify"] = "CENTER",
			["borderSize"] = 16,
			["xOffset"] = 0,
			["icon_side"] = "RIGHT",
			["customTextUpdate"] = "update",
			["wordWrap"] = "WordWrap",
			["sparkHeight"] = 100,
			["config"] = {
			},
			["height"] = 32.999984741211,
			["stacksColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["semver"] = "1.0.87",
			["displayTextRight"] = "%p ",
			["id"] = "쐐기 : 전율 예상",
			["timerSize"] = 30,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "4pLU428taOF",
			["spark"] = true,
			["inverse"] = false,
			["sparkDesature"] = false,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["rotateText"] = "NONE",
			["textSize"] = 22,
		},
		["쐐기 : 이름표 거리/투명도"] = {
			["outline"] = "OUTLINE",
			["authorOptions"] = {
				{
					["text"] = "Distance Options",
					["useName"] = true,
					["type"] = "header",
					["width"] = 1,
				}, -- [1]
				{
					["type"] = "toggle",
					["key"] = "krileDistanceEnabled",
					["default"] = true,
					["name"] = "Enable Distance Settings",
					["width"] = 1,
				}, -- [2]
				{
					["text"] = "|cffff00ff[|cff00ffffPlater|cffff00ff, |cff00ffffElvUI|cffff00ff, |cff00ffffKui|cffff00ff, |cff00ffffThreatplates|cffff00ff]",
					["type"] = "description",
					["fontSize"] = "small",
					["width"] = 1,
				}, -- [3]
				{
					["type"] = "range",
					["useDesc"] = true,
					["max"] = 100,
					["step"] = 1,
					["width"] = 2,
					["min"] = 0,
					["name"] = "Reduced Distance",
					["default"] = 15,
					["key"] = "krileReducedDistance",
					["desc"] = "Nameplate distance in congested areas.",
				}, -- [4]
				{
					["type"] = "range",
					["useDesc"] = true,
					["max"] = 100,
					["step"] = 1,
					["width"] = 2,
					["min"] = 0,
					["name"] = "Normal Distance",
					["default"] = 60,
					["key"] = "krileNormalDistance",
					["desc"] = "Nameplate distance outside of congested areas.",
				}, -- [5]
				{
					["type"] = "toggle",
					["key"] = "krileChatDistance",
					["default"] = false,
					["name"] = "Display Chat Message |cffffff00(debug)|r",
					["width"] = 2,
				}, -- [6]
				{
					["text"] = "Alpha Options",
					["useName"] = true,
					["type"] = "header",
					["width"] = 1,
				}, -- [7]
				{
					["type"] = "toggle",
					["key"] = "krileAlphaEnabled",
					["default"] = false,
					["name"] = "Enable Alpha Settings",
					["width"] = 1,
				}, -- [8]
				{
					["text"] = "|cffff00ff[|cff00ffffPlater|cffff00ff, |cff00ffffElvUI|cffff00ff]",
					["type"] = "description",
					["fontSize"] = "small",
					["width"] = 1,
				}, -- [9]
				{
					["type"] = "range",
					["useDesc"] = true,
					["max"] = 1,
					["step"] = 0.05,
					["width"] = 2,
					["min"] = 0,
					["name"] = "Reduced Alpha",
					["default"] = 0.2,
					["key"] = "krileAlphaMin",
					["desc"] = "Nameplate alpha of units not in line of sight in congested areas.",
				}, -- [10]
				{
					["type"] = "range",
					["useDesc"] = true,
					["max"] = 1,
					["step"] = 0.05,
					["width"] = 2,
					["min"] = 0,
					["name"] = "Normal Alpha",
					["default"] = 1,
					["key"] = "krileAlphaMax",
					["desc"] = "Nameplate alpha of units not in line of sight outside of congested areas.",
				}, -- [11]
				{
					["type"] = "toggle",
					["key"] = "krileChatAlpha",
					["default"] = false,
					["name"] = "Display Chat Message |cffffff00(debug)|r",
					["width"] = 2,
				}, -- [12]
			},
			["displayText"] = "%p",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["message_custom"] = "",
					["r"] = 1,
					["message_type"] = "PRINT",
					["g"] = 1,
					["message"] = "",
					["custom"] = "if aura_env.config[\"krileDistanceEnabled\"] then\n    SetCVar(\"nameplatemaxdistance\", aura_env.config[\"krileReducedDistance\"])\nend\n\nif aura_env.config[\"krileAlphaEnabled\"] then\n    SetCVar(\"nameplateoccludedalphamult\", aura_env.config[\"krileAlphaMin\"])\nend\n\nif aura_env.config[\"krileChatDistance\"] then\n    print (\"|cff00ffffNameplate Distance:|r\", aura_env.config[\"krileReducedDistance\"], \"yards\")\nend\n\nif aura_env.config[\"krileChatAlpha\"] then\n    print (\"|cffff00ffNameplate Alpha:|r\", aura_env.config[\"krileAlphaMin\"])\nend",
					["b"] = 0,
					["do_custom"] = true,
					["do_message"] = false,
				},
				["finish"] = {
					["message"] = "",
					["r"] = 1,
					["custom"] = "if aura_env.config[\"krileDistanceEnabled\"] then\n    SetCVar(\"nameplatemaxdistance\", aura_env.config[\"krileNormalDistance\"])\nend\n\nif aura_env.config[\"krileAlphaEnabled\"] then\n    SetCVar(\"nameplateoccludedalphamult\", aura_env.config[\"krileAlphaMax\"])\nend\n\nif aura_env.config[\"krileChatDistance\"] then\n    print (\"|cff00ffffNameplate Distance:|r\", aura_env.config[\"krileNormalDistance\"], \"yards\")\nend\n\nif aura_env.config[\"krileChatAlpha\"] then\n    print (\"|cffff00ffNameplate Alpha:|r\", aura_env.config[\"krileAlphaMax\"])\nend",
					["b"] = 0,
					["message_type"] = "PRINT",
					["g"] = 1,
					["do_message"] = false,
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = true,
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_unitisunit"] = true,
						["use_alwaystrue"] = true,
						["duration"] = "1",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
						["type"] = "status",
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Conditions",
						["use_unit"] = true,
						["unit"] = "player",
						["events"] = "",
						["spellIds"] = {
						},
						["unitisunit"] = "player",
						["check"] = "update",
						["custom_type"] = "event",
						["use_absorbMode"] = true,
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
						["unit"] = "target",
						["use_unit"] = true,
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["font"] = "Friz Quadrata TT",
			["version"] = 88,
			["load"] = {
				["use_effectiveLevel"] = true,
				["use_size"] = true,
				["zoneId"] = "976, 977, 978, 980, 1015, 1016",
				["effectiveLevel_operator"] = ">=",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zoneId"] = true,
				["use_encounter"] = true,
				["effectiveLevel"] = "110",
				["use_level"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
			},
			["fontSize"] = 12,
			["regionType"] = "text",
			["parent"] = "쐐기 : 기타 0929",
			["selfPoint"] = "BOTTOM",
			["justify"] = "CENTER",
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 이름표 거리/투명도",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["conditions"] = {
			},
			["uid"] = "FwEi(vHnOQ3",
			["config"] = {
				["krileChatDistance"] = false,
				["krileNormalDistance"] = 55,
				["krileReducedDistance"] = 30,
				["krileAlphaEnabled"] = true,
				["krileAlphaMax"] = 1,
				["krileAlphaMin"] = 0.2,
				["krileChatAlpha"] = false,
				["krileDistanceEnabled"] = true,
			},
			["automaticWidth"] = "Auto",
			["fixedWidth"] = 200,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["colorR"] = 1,
					["duration"] = "1",
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["type"] = "none",
					["scaley"] = 1,
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["colorType"] = "straightColor",
					["use_color"] = false,
					["duration_type"] = "seconds",
					["colorFunc"] = "    function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n      return r1 + (progress * (r2 - r1)), g1 + (progress * (g2 - g1)), b1 + (progress * (b2 - b1)), a1 + (progress * (a2 - a1))\n    end\n  ",
					["rotate"] = 0,
					["scalex"] = 1,
					["x"] = 0,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["xOffset"] = 0,
		},
		["행진하라!"] = {
			["glow"] = false,
			["parent"] = "여왕의 칙령 (딩까) 2",
			["yOffset"] = 327.1112670898438,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "움직여!",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "굵은 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 31,
				}, -- [1]
			},
			["height"] = 64,
			["glowLines"] = 8,
			["glowFrequency"] = 0.25,
			["glowYOffset"] = 0,
			["selfPoint"] = "CENTER",
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 1,
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["names"] = {
						},
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["auranames"] = {
							"행진하라!", -- [1]
						},
						["unit"] = "player",
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["authorOptions"] = {
			},
			["actions"] = {
				["start"] = {
					["message_type"] = "SAY",
					["message"] = "",
					["do_custom"] = true,
					["do_message"] = true,
				},
				["init"] = {
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["regionType"] = "icon",
			["load"] = {
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "twentyfive",
					["multi"] = {
						["twentyfive"] = true,
					},
				},
			},
			["desaturate"] = false,
			["glowLength"] = 10,
			["uid"] = "O0tIryFrMCa",
			["frameStrata"] = 1,
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["auto"] = true,
			["glowScale"] = 1,
			["id"] = "행진하라!",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["width"] = 64,
			["xOffset"] = 330,
			["config"] = {
			},
			["inverse"] = false,
			["keepAspectRatio"] = false,
			["conditions"] = {
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["glowBorder"] = false,
		},
		["쐐기 : 광역기"] = {
			["sparkWidth"] = 10,
			["authorOptions"] = {
			},
			["displayText"] = "FELBLAZE RUSH ON YOU",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["icon"] = true,
			["fontFlags"] = "OUTLINE",
			["icon_color"] = {
				1, -- [1]
				0.93725490196078, -- [2]
				0.94901960784314, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = ">=",
				["encounterid"] = "2086, 2087, 2102, 2104, 2108, 2113, 2124, 2125, 2126, 2127, 2140",
				["use_encounterid"] = true,
				["role"] = {
					["multi"] = {
					},
				},
				["level"] = "",
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["level_operator"] = ">=",
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "110",
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "",
				["race"] = {
					["multi"] = {
					},
				},
				["use_zoneId"] = false,
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["texture"] = "Raven White",
			["zoom"] = 0,
			["auto"] = true,
			["tocversion"] = 80205,
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayIcon"] = 136195,
			["outline"] = "OUTLINE",
			["borderBackdrop"] = "Blizzard Tooltip",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["customTextUpdate"] = "update",
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "5",
						["genericShowOn"] = "showOnActive",
						["unit"] = "player",
						["customIcon"] = "function()\n    return\"Interface\\\\Icons\\\\ability_devour\"\nend",
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["custom_type"] = "event",
						["event"] = "Health",
						["custom_hide"] = "timed",
						["subeventSuffix"] = "_CAST_START",
						["customName"] = "function()\n    return \"숨기!\"\nend",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["dynamicDuration"] = false,
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"공포스러운 얼굴\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "event",
						["duration"] = "5",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customName"] = "function()\n    return \"모여서 뽑기!\"\nend",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_demonhunter_soulcleave2\"\nend",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"영혼 분리\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "2",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customName"] = "function()\n    return \"광역기!\"\nend",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\spell_shaman_staticshock\"\nend",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"전하 충격\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["custom_type"] = "event",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["type"] = "custom",
						["unevent"] = "auto",
						["duration"] = "2.5",
						["genericShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["custom_type"] = "event",
						["customName"] = "function()\n    return \"고개 돌리기!\"\nend",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"실명의 모래\" then\n        return true    \n    end\nend    \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_rogue_bloodyeye\"\nend",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Chat Message",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "event",
						["duration"] = "3",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customName"] = "function()\n    return \"광역기!\"\nend",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\spell_nature_unrelentingstorm\"\nend\n\n\n",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"전하 소모\" then\n        return true    \n    end\nend",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [5]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "event",
						["duration"] = "5",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customName"] = "function()\n    return \"버프 시전 중!\"\nend",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\spell_nature_regeneration_02\"\nend",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,spellId = ...\n    if message ==\"SPELL_CAST_START\" and spellId == 269670 then\n        return true    \n    end\nend    \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [6]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customDuration"] = "",
						["customName"] = "",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED,UNIT_SPELLCAST_START,UNIT_SPELLCAST_SUCCEEDED,UNIT_SPELLCAST_INTERRUPTED, UNIT_SPELLCAST_FAILED, UNIT_SPELLCAST_FAILED_QUIET, UNIT_SPELLCAST_STOP",
						["customIcon"] = "",
						["check"] = "event",
						["subeventSuffix"] = "_CAST_START",
						["custom"] = "function(allstates, event, ...)\n    local subevent = select(2, ...)\n    \n    if event == \"UNIT_SPELLCAST_START\" and select(3, ...) == 260773 then\n        local caster, lineId = ...\n        local sourceGUID = UnitGUID(caster)\n        local _, _, icon, startMS, endMS = UnitCastingInfo(caster)\n        local duration = (endMS - startMS) / 1000\n        local expiration = endMS / 1000\n        allstates[sourceGUID] = {\n            show = true,\n            changed = true,\n            progressType = \"timed\",\n            icon = icon,\n            duration = duration,\n            expirationTime = expiration,\n            autoHide = true,\n            name = \"광역기!\"\n        }\n        return true\n    elseif subevent == \"SPELL_CAST_START\" and select(12, ...) == 260773 then\n        local _,_,_,sourceGUID = ...\n        if not allstates[sourceGUID] then\n            allstates[sourceGUID] = {\n                show = true,\n                changed = true,\n                progressType = \"timed\",\n                duration = 5,\n                icon = 136121,\n                expirationTime = 5+GetTime(),\n                autoHide = true,\n                name = \"광역기!\"\n            }\n            return true\n        end \n    end\n    \n    \n    if (event == \"UNIT_SPELLCAST_SUCCEEDED\" or event == \"UNIT_SPELLCAST_INTERRUPTED\" or event == \"UNIT_SPELLCAST_FAILED\" or event == \"UNIT_SPELLCAST_STOP\" or event == \"UNIT_SPELLCAST_FAILED_QUIET\") and select(3, ...) == 260773 then\n        local caster,lineId = ...\n        if caster then\n            local sourceGUID = UnitGUID(caster)\n            if allstates[sourceGUID] then\n                allstates[sourceGUID].show = false\n                allstates[sourceGUID].changed = true\n                return true\n            end   \n        end \n    end   \nend\n\n\n\n\n\n\n\n\n\n",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
						["custom"] = "",
					},
				}, -- [7]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "event",
						["duration"] = "6",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customName"] = "function()\n    return \"숨기!\"\nend",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_rogue_fanofknives\"\nend",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"번쩍이는 단검\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [8]
				{
					["trigger"] = {
						["type"] = "custom",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["duration"] = "4",
						["event"] = "Health",
						["unit"] = "player",
						["custom_type"] = "event",
						["customName"] = "function()\n    return \"포격!\"\nend",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"육중한 강타\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_ironmaidens_deployturret\"\nend",
						["use_unit"] = true,
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["subeventPrefix"] = "SPELL",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [9]
				{
					["trigger"] = {
						["type"] = "custom",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["use_absorbMode"] = true,
						["duration"] = "5",
						["event"] = "Health",
						["unit"] = "player",
						["custom_type"] = "event",
						["customName"] = "function()\n    return \"미사일 폭격!\"\nend",
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,spellId = ...\n    if message ==\"SPELL_CAST_START\" and spellId == 276229 then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\inv_misc_missilelarge_red\"\nend",
						["use_unit"] = true,
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["subeventPrefix"] = "SPELL",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [10]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "event",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customDuration"] = "function()\n    return 6, 6+GetTime()\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["customName"] = "function()\n    return \"무조건 차단!\"\nend",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED, CHAT_MSG_MONSTER_YELL",
						["customIcon"] = "function()\n    return\"Interface\\\\Icons\\\\ability_creature_disease_02\"\nend",
						["check"] = "event",
						["dynamicDuration"] = true,
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"독 회오리\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["custom_hide"] = "custom",
					},
					["untrigger"] = {
						["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,destName,_,_,_,spellName,_,extraSpellName = ...\n    \n    if message ==\"SPELL_CAST_SUCCESS\" and spellName == \"독 회오리\" then\n        return true    \n    elseif message ==\"SPELL_INTERRUPT\" and extraSpellName == \"독 회오리\" then\n        return true    \n    elseif message ==\"UNIT_DIED\" and destName ==\"현자 자나잘\" then\n        return true    \n    elseif event == \"CHAT_MSG_MONSTER_YELL\" then\n        local msg, npc = select(1, ...) \n        if npc == \"현자 자나잘\" and strfind(msg, \"부디...\") then\n            return true\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
					},
				}, -- [11]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "grow",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["preset"] = "bounceDecay",
					["duration_type"] = "seconds",
				},
			},
			["backdropInFront"] = false,
			["stickyDuration"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["border_color"] = {
					},
					["type"] = "aurabar_bar",
				}, -- [1]
				{
					["text_shadowXOffset"] = 1,
					["type"] = "subtext",
					["text_text"] = "%p ",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "None",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_RIGHT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 55,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["type"] = "subtext",
					["text_text"] = " %n",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "None",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 47,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [3]
			},
			["height"] = 55.000015258789,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["sparkTexture"] = "Legionfall_BarSpark",
			["sparkOffsetX"] = 0,
			["borderInFront"] = false,
			["config"] = {
			},
			["icon_side"] = "LEFT",
			["xOffset"] = -0.0001220703125,
			["spark"] = true,
			["sparkHeight"] = 100,
			["sparkRotationMode"] = "AUTO",
			["actions"] = {
				["start"] = {
					["message"] = "",
					["do_sound"] = false,
					["message_type"] = "YELL",
					["do_message"] = false,
					["do_custom"] = true,
					["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\splash.ogg",
				},
				["finish"] = {
					["do_custom"] = true,
					["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\shot.ogg",
					["do_sound"] = false,
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = true,
				},
			},
			["parent"] = "쐐기 : 기타 0929",
			["semver"] = "1.0.87",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["id"] = "쐐기 : 광역기",
			["anchorFrameType"] = "SCREEN",
			["frameStrata"] = 1,
			["width"] = 649.00036621094,
			["uid"] = "k9HarAIO8z(",
			["sparkHidden"] = "BOTH",
			["inverse"] = true,
			["sparkDesature"] = false,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 4,
								["variable"] = "show",
								["value"] = 1,
							}, -- [2]
							{
								["trigger"] = 8,
								["variable"] = "show",
								["value"] = 1,
							}, -- [3]
							{
								["trigger"] = 11,
								["variable"] = "show",
								["value"] = 1,
							}, -- [4]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\wolf5.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = 3,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 5,
								["variable"] = "show",
								["value"] = 1,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\ESPARK1.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 6,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Sound\\Spells\\SimonGame_Visual_GameStart.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [1]
						{
							["value"] = {
								0, -- [1]
								1, -- [2]
								0.9921568627451, -- [3]
								1, -- [4]
							},
							["property"] = "barColor",
						}, -- [2]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 10,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Torch.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [1]
					},
				}, -- [4]
			},
			["justify"] = "LEFT",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
		},
		["쐐기 : 기타 0929"] = {
			["controlledChildren"] = {
				"쐐기 : 광역기", -- [1]
				"쐐기 : 도피", -- [2]
				"쐐기 : 탱커 실명", -- [3]
				"쐐기 : 개인 디버프", -- [4]
				"쐐기 : 알룬자 수혈", -- [5]
				"쐐기 : 산개 디버프", -- [6]
				"쐐기 : 다자르 도약", -- [7]
				"쐐기 : 탱커 디버프", -- [8]
				"쐐기 : 부족 의회 토템", -- [9]
				"쐐기 : 상태 이상", -- [10]
				"쐐기 : 파열", -- [11]
				"쐐기 : 괴저", -- [12]
				"쐐기 : 폭탄", -- [13]
				"쐐기 : 도비터", -- [14]
				"쐐기 : 강화", -- [15]
				"쐐기 : 화산", -- [16]
				"쐐기 : 전율", -- [17]
				"쐐기 : 전율 예상", -- [18]
				"쐐기 : !돌", -- [19]
				"쐐기 : 이름표 거리/투명도", -- [20]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = 20.5703125,
			["yOffset"] = 514.7123413085938,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["buffShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["selfPoint"] = "BOTTOMLEFT",
			["desc"] = "HOBUL - AZSHARA",
			["version"] = 88,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["use_class"] = false,
				["race"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["scale"] = 1,
			["border"] = false,
			["borderEdge"] = "None",
			["regionType"] = "group",
			["borderSize"] = 16,
			["borderOffset"] = 5,
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 기타 0929",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["uid"] = "6jtLNL10mjw",
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["groupIcon"] = "525134",
			["conditions"] = {
			},
			["borderInset"] = 11,
			["authorOptions"] = {
			},
		},
		["쐐기 : 탱커 실명"] = {
			["glow"] = false,
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["yOffset"] = -80,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["do_message"] = false,
					["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\aggro.ogg",
					["do_custom"] = true,
					["do_sound"] = true,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Blind = {\n    [257371] = true, -- 최루 가스\n    [269970] = true, -- 실명의 모래\n    [265352] = true, -- 두꺼비 역병\n    [265346] = true, -- 창백한 응시\n    [258917] = true, -- 정의의 불길\n}",
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scalex"] = 1.8,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["scaleType"] = "pulse",
					["scaley"] = 1.8,
					["alpha"] = 0,
					["colorR"] = 1,
					["y"] = 0,
					["x"] = 0,
					["use_scale"] = true,
					["duration_type"] = "seconds",
					["type"] = "custom",
					["rotate"] = 0,
					["duration"] = "0.15",
					["colorA"] = 1,
				},
				["main"] = {
					["type"] = "custom",
					["colorR"] = 1,
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["use_scale"] = true,
					["x"] = 0,
					["duration"] = "1",
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["colorB"] = 1,
					["colorG"] = 1,
					["scaleType"] = "pulse",
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["scalex"] = 1.2,
					["scaley"] = 1.2,
				},
				["finish"] = {
					["type"] = "custom",
					["colorR"] = 1,
					["duration_type"] = "seconds",
					["scalex"] = 1,
					["alphaType"] = "straight",
					["scaley"] = 1,
					["alpha"] = 0,
					["colorB"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["colorA"] = 1,
					["rotate"] = 0,
					["duration"] = "0.1",
					["use_alpha"] = true,
				},
			},
			["auto"] = false,
			["tocversion"] = 80205,
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["icon"] = true,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "탱커 실명!",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 34,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
			},
			["height"] = 80,
			["glowLength"] = 10,
			["glowLines"] = 8,
			["parent"] = "쐐기 : 기타 0929",
			["glowFrequency"] = 0.25,
			["conditions"] = {
			},
			["cooldownEdge"] = false,
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = ">=",
				["class"] = {
					["multi"] = {
					},
				},
				["use_zoneId"] = false,
				["level"] = "",
				["use_encounter"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_role"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["level_operator"] = ">=",
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "110",
				["faction"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "",
				["use_combat"] = true,
				["race"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
						["HEALER"] = true,
						["DAMAGER"] = true,
					},
				},
			},
			["config"] = {
			},
			["authorOptions"] = {
			},
			["regionType"] = "icon",
			["width"] = 80,
			["frameStrata"] = 1,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["zoom"] = 0,
			["glowXOffset"] = 0,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["glowScale"] = 1,
			["id"] = "쐐기 : 탱커 실명",
			["xOffset"] = 0,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["glowYOffset"] = 0,
			["uid"] = "6FUkMecyYQ(",
			["inverse"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["genericShowOn"] = "showOnActive",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["unevent"] = "auto",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customDuration"] = "function()\n    for i = 1, 5 do\n        local unit = \"party\".. i\n        if UnitGroupRolesAssigned(unit) == \"TANK\" then \n            if WA_GetUnitDebuff(unit, \"최루 가스\") then\n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"최루 가스\"))\n                return dur, exp\n            elseif WA_GetUnitDebuff(unit, \"실명의 모래\") then\n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"실명의 모래\"))\n                return dur, exp  \n            elseif WA_GetUnitDebuff(unit, \"두꺼비 폭발\") then \n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"두꺼비 폭발\"))\n                return dur, exp\n            elseif WA_GetUnitDebuff(unit, \"창백한 응시\") then\n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"창백한 응시\"))\n                return dur, exp\n            end\n        end\n    end    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["custom"] = "function(states,event,...)\n    local _,subevent,_,_,_,_,_,destGUID,destName,_,_,spellID,spellName = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" then   \n        if aura_env.Blind[spellID] and UnitGroupRolesAssigned(destName) == \"TANK\" then \n            local id = destGUID..spellID\n            states[id] = states[id] or {}\n            local state = states[id]\n            local _,_,_,d,e = select(2, WA_GetUnitDebuff(destName,  spellName))      \n            state.name = \"|c\"..select(4, GetClassColor(select(2, UnitClass(destName))))..UnitName(destName)\n            state.progressType = \"timed\";\n            state.duration = d;\n            state.expirationTime = e;\n            state.autohide = true;\n            state.changed = true;\n            state.show = true;\n        end\n    elseif subevent == \"SPELL_AURA_REMOVED\" then\n        if aura_env.Blind[spellID] then \n            local id = destGUID..spellID\n            local v = states[id]\n            if v then\n                v.show = false\n                v.changed = true\n            end\n        end\n    end\n    return true\nend",
						["spellIds"] = {
						},
						["use_unit"] = true,
						["check"] = "event",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["custom_type"] = "stateupdate",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
						["custom"] = "function()\n    return true\nend",
					},
				}, -- [1]
				["disjunctive"] = "all",
				["customTriggerLogic"] = "\n\n",
				["activeTriggerMode"] = 1,
			},
			["displayIcon"] = 132284,
			["cooldown"] = true,
			["glowBorder"] = false,
		},
		["쐐기 : 도비터"] = {
			["sparkWidth"] = 10,
			["authorOptions"] = {
			},
			["displayText"] = "%p",
			["yOffset"] = 315.4285888671875,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["fontFlags"] = "OUTLINE",
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["wordWrap"] = "WordWrap",
			["barColor"] = {
				0.70196078431373, -- [1]
				0.70196078431373, -- [2]
				0.69019607843137, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["progressPrecision"] = 1,
			["sparkOffsetY"] = 0,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["class"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["level"] = "110",
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_size"] = true,
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["use_encounter"] = true,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["use_combat"] = false,
				["talent2"] = {
					["multi"] = {
					},
				},
				["level_operator"] = "==",
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["texture"] = "Raven White",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["spark"] = false,
			["tocversion"] = 80205,
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["outline"] = "OUTLINE",
			["borderBackdrop"] = "Blizzard Tooltip",
			["color"] = {
				0.67843137254902, -- [1]
				0.67843137254902, -- [2]
				0.67843137254902, -- [3]
				1, -- [4]
			},
			["customText"] = "",
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["buffShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["custom_type"] = "stateupdate",
						["custom"] = "function(states,event,...)\n    local _,subevent,_,_,_,_,_,destGUID,destName,_,_,spellID,spellName = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" or subevent == \"SPELL_AURA_REFRESH\" then   \n        if spellID == 114018 and UnitClass(destName) == \"도적\" then \n            local id = destGUID..spellID\n            states[id] = states[id] or {}\n            local state = states[id]\n            local c,_,_,d,e = select(2, WA_GetUnitBuff(destName,  spellName))      \n            state.name = \"|c\"..select(4, GetClassColor(select(2, UnitClass(destName))))..UnitName(destName)\n            state.progressType = \"timed\";\n            state.icon = c;\n            state.duration = d;\n            state.expirationTime = e;\n            state.autohide = true\n            state.changed = true;\n            state.show = true;\n        end\n    elseif subevent == \"SPELL_AURA_REMOVED\" then\n        if spellID == 114018 then \n            local id = destGUID..spellID\n            local v = states[id]\n            if v then\n                v.show = false\n                v.changed = true\n            end\n        end\n    end\n    return true\nend",
						["spellIds"] = {
						},
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["check"] = "event",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["useGroup_count"] = false,
						["matchesShowOn"] = "showOnActive",
						["unit"] = "player",
						["use_tooltip"] = false,
						["debuffType"] = "HELPFUL",
						["useName"] = true,
						["use_debuffClass"] = false,
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["event"] = "Health",
						["type"] = "aura2",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["auranames"] = {
							"은폐의 장막", -- [1]
						},
						["use_unit"] = true,
						["combineMatches"] = "showLowest",
						["names"] = {
							"은폐의 장막", -- [1]
						},
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
				["activeTriggerMode"] = 1,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "grow",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["colorR"] = 1,
					["duration_type"] = "seconds",
					["alphaType"] = "alphaPulse",
					["scaley"] = 1,
					["alpha"] = 0,
					["x"] = 0,
					["y"] = 0,
					["colorA"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return start + (((math.sin(angle) + 1)/2) * delta)\n    end\n  ",
					["colorB"] = 1,
					["rotate"] = 0,
					["scalex"] = 1,
					["use_alpha"] = false,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["backdropInFront"] = false,
			["stickyDuration"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["type"] = "aurabar_bar",
				}, -- [1]
				{
					["text_shadowXOffset"] = 1,
					["type"] = "subtext",
					["text_text"] = "%p ",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "None",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_RIGHT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 55,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [2]
			},
			["height"] = 55,
			["sparkBlendMode"] = "ADD",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["zoom"] = 0,
			["actions"] = {
				["start"] = {
					["do_custom"] = true,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["do_custom"] = true,
				},
			},
			["config"] = {
			},
			["auto"] = false,
			["borderInFront"] = true,
			["sparkOffsetX"] = 0,
			["icon_side"] = "LEFT",
			["xOffset"] = 11.42919921875,
			["icon"] = true,
			["sparkHeight"] = 30,
			["selfPoint"] = "CENTER",
			["width"] = 649,
			["justify"] = "LEFT",
			["semver"] = "1.0.87",
			["useAdjustededMax"] = false,
			["id"] = "쐐기 : 도비터",
			["sparkHidden"] = "NEVER",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["displayIcon"] = 635350,
			["customTextUpdate"] = "update",
			["inverse"] = false,
			["sparkDesature"] = false,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								1, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "barColor",
						}, -- [1]
					},
				}, -- [1]
			},
			["uid"] = "VR)Fi4QjQ31",
			["parent"] = "쐐기 : 기타 0929",
		},
		["쐐기 : 알룬자 수혈"] = {
			["glow"] = true,
			["xOffset"] = 0,
			["customText"] = "\n\n",
			["yOffset"] = -80,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
					["glow_action"] = "show",
					["message_type"] = "YELL",
					["do_message"] = false,
					["message"] = "",
					["custom"] = "\n\n",
					["do_sound"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
					["do_glow"] = false,
				},
				["finish"] = {
					["do_glow"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["glow_action"] = "hide",
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["selfPoint"] = "CENTER",
			["zoom"] = 0,
			["auto"] = true,
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["use_absorbMode"] = true,
						["use_unit"] = true,
						["customIcon"] = "",
						["debuffType"] = "HELPFUL",
						["custom_hide"] = "timed",
						["type"] = "custom",
						["unevent"] = "auto",
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["custom"] = "function()\n    if UnitExists(\"boss1\") and not WA_GetUnitDebuff(\"player\", \"오염된 피\") then\n        \n        if UnitChannelInfo(\"boss1\") and select(1, UnitChannelInfo(\"boss1\")) == \"수혈\" then\n            return true\n        else\n            if UnitPower(\"boss1\") == 100 then\n                return true\n            end\n        end\n    end\nend\n\n\n",
						["event"] = "Chat Message",
						["customStacks"] = "",
						["customDuration"] = "function()\n    if UnitChannelInfo(\"boss1\") and select(1, UnitChannelInfo(\"boss1\")) == \"수혈\"then\n        return (select(5,UnitChannelInfo(\"boss1\"))-select(4,UnitChannelInfo(\"boss1\")))/1000, select(5,UnitChannelInfo(\"boss1\"))/1000\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["customName"] = "",
						["spellIds"] = {
						},
						["names"] = {
						},
						["check"] = "event",
						["events"] = "UNIT_POWER UNIT_SPELLCAST_CHANNEL_START UNIT_SPELLCAST_CHANNEL_STOP UNIT_SPELLCAST_CHANNEL_UPDATE UNIT_TARGET UNIT_AURA",
						["custom_type"] = "status",
						["unit"] = "player",
					},
					["untrigger"] = {
						["custom"] = "function()\n    return true\nend",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "오염 필요!",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "기본 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 34,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
				{
					["type"] = "subborder",
					["border_offset"] = 0,
					["text_color"] = {
					},
					["border_color"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "1 Pixel",
					["border_size"] = 3,
				}, -- [2]
			},
			["height"] = 80,
			["parent"] = "쐐기 : 기타 0929",
			["glowLines"] = 8,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
						["checks"] = {
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [1]
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BikeHorn.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [1]
					},
				}, -- [1]
			},
			["glowFrequency"] = 0.25,
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
					["scalex"] = 2.5,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["scaleType"] = "straightScale",
					["scaley"] = 2.5,
					["alpha"] = 0,
					["colorR"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorA"] = 1,
					["duration_type"] = "seconds",
					["type"] = "custom",
					["rotate"] = 0,
					["duration"] = "0.17",
					["use_scale"] = true,
				},
				["main"] = {
					["colorR"] = 1,
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scaleType"] = "pulse",
					["duration_type"] = "seconds",
					["colorB"] = 1,
					["scaley"] = 1.05,
					["alpha"] = 0,
					["x"] = 0,
					["y"] = 0,
					["colorA"] = 1,
					["colorG"] = 1,
					["use_scale"] = true,
					["scalex"] = 1.05,
					["rotate"] = 0,
					["duration"] = "1",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = ">=",
				["class"] = {
					["multi"] = {
					},
				},
				["use_encounterid"] = true,
				["use_zone"] = false,
				["use_encounter"] = true,
				["level"] = "",
				["talent2"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["use_size"] = true,
				["zoneId"] = "8040",
				["talent"] = {
					["multi"] = {
					},
				},
				["encounterid"] = "2084",
				["spec"] = {
					["multi"] = {
					},
				},
				["use_zoneId"] = false,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["mythic"] = true,
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "110",
				["level_operator"] = ">=",
				["faction"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["use_combat"] = true,
				["use_level"] = false,
				["role"] = {
					["multi"] = {
					},
				},
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["uid"] = ")F0p(8Gp(bQ",
			["desaturate"] = true,
			["anchorFrameType"] = "SCREEN",
			["regionType"] = "icon",
			["frameStrata"] = 1,
			["width"] = 80,
			["authorOptions"] = {
			},
			["glowScale"] = 1,
			["useGlowColor"] = false,
			["icon"] = true,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 알룬자 수혈",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["alpha"] = 1,
			["glowYOffset"] = 0,
			["keepAspectRatio"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["glowLength"] = 10,
			["displayIcon"] = 538039,
			["cooldown"] = true,
			["glowBorder"] = false,
		},
		["쐐기 : 다자르 도약"] = {
			["glow"] = false,
			["authorOptions"] = {
			},
			["customText"] = "",
			["yOffset"] = -165,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
					["scalex"] = 2.5,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["scaleType"] = "straightScale",
					["scaley"] = 2.5,
					["alpha"] = 0,
					["colorR"] = 1,
					["y"] = 0,
					["x"] = 0,
					["use_scale"] = true,
					["duration_type"] = "seconds",
					["type"] = "custom",
					["rotate"] = 0,
					["duration"] = "0.17",
					["colorA"] = 1,
				},
				["main"] = {
					["type"] = "none",
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scaleType"] = "pulse",
					["scaley"] = 1.05,
					["use_scale"] = true,
					["duration"] = "1",
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorG"] = 1,
					["colorB"] = 1,
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["scalex"] = 1.05,
					["colorR"] = 1,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["auto"] = false,
			["tocversion"] = 80205,
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "이격",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "기본 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = false,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 34,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
				{
					["type"] = "subborder",
					["border_offset"] = 0,
					["border_color"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "1 Pixel",
					["border_size"] = 3,
				}, -- [2]
			},
			["height"] = 80,
			["xOffset"] = 0,
			["glowLines"] = 8,
			["parent"] = "쐐기 : 기타 0929",
			["glowFrequency"] = 0.25,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 1,
						["checks"] = {
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [1]
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 1,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["message"] = "%n(이격) 대상!",
								["message_type"] = "YELL",
							},
							["property"] = "chat",
						}, -- [1]
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\ESPARK1.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [2]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "glow",
						}, -- [1]
						{
							["value"] = true,
							["property"] = "sub.1.text_visible",
						}, -- [2]
					},
				}, -- [3]
			},
			["triggers"] = {
				{
					["trigger"] = {
						["subeventSuffix"] = "_CAST_START",
						["type"] = "custom",
						["custom"] = "function()\n    if UnitExists(\"boss1\") and UnitName(\"boss1\") == \"왕 다자르\" \n    and UnitCastingInfo(\"boss1\") == \"지진의 도약\" and UnitIsUnit(\"boss1target\", \"player\") then\n        return true\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["custom_type"] = "status",
						["customOverlay1"] = "",
						["events"] = "UNIT_SPELLCAST_DELAYED UNIT_SPELLCAST_FAILED UNIT_SPELLCAST_FAILED_QUIET UNIT_SPELLCAST_INTERRUPTED UNIT_SPELLCAST_START UNIT_SPELLCAST_STOP UNIT_SPELLCAST_SUCCEEDED UNIT_TARGET",
						["event"] = "Health",
						["unit"] = "player",
						["customDuration"] = "function()\n    return (select(5,UnitCastingInfo(\"boss1\"))-select(4,UnitCastingInfo(\"boss1\")))/1000, select(5,UnitCastingInfo(\"boss1\"))/1000\nend\n\n\n\n\n\n",
						["customName"] = "",
						["spellIds"] = {
						},
						["customIcon"] = "",
						["check"] = "event",
						["subeventPrefix"] = "SPELL",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\nreturn true\nend",
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customDuration"] = "",
						["events"] = "",
						["check"] = "update",
						["custom"] = "function()\n    if not aura_env.last or GetTime() - aura_env.last > 0.1 then\n        aura_env.last = GetTime()\n        if WeakAuras.triggerState[aura_env.id].triggers[1] then\n            for unit in WA_IterateGroupMembers() do\n                if unit ~= \"player\" and WeakAuras.CheckRange(unit, 22, \"<=\") then\n                    return true\n                end\n            end\n        end\n    end\nend",
						["custom_type"] = "status",
					},
					["untrigger"] = {
						["custom"] = "function()\nreturn true\nend",
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
				["activeTriggerMode"] = -10,
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["actions"] = {
				["start"] = {
					["glow_action"] = "show",
					["message_type"] = "YELL",
					["do_message"] = false,
					["message"] = "",
					["custom"] = "",
					["do_sound"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
					["do_glow"] = false,
				},
				["finish"] = {
					["do_glow"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["glow_action"] = "hide",
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = true,
				},
			},
			["uid"] = "Rq2QiyhriVp",
			["anchorFrameType"] = "SCREEN",
			["regionType"] = "icon",
			["glowYOffset"] = 0,
			["alpha"] = 1,
			["selfPoint"] = "CENTER",
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["zoom"] = 0,
			["keepAspectRatio"] = false,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["glowScale"] = 1,
			["id"] = "쐐기 : 다자르 도약",
			["glowLength"] = 10,
			["frameStrata"] = 1,
			["width"] = 80,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = ">=",
				["encounterid"] = "2143",
				["use_encounterid"] = true,
				["role"] = {
					["multi"] = {
						["HEALER"] = true,
						["DAMAGER"] = true,
					},
				},
				["use_encounter"] = true,
				["level"] = "",
				["use_zone"] = false,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_role"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["use_zoneId"] = false,
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["mythic"] = true,
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "110",
				["faction"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "8040",
				["class"] = {
					["multi"] = {
					},
				},
				["level_operator"] = ">=",
			},
			["config"] = {
			},
			["inverse"] = false,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["displayIcon"] = 878213,
			["cooldown"] = true,
			["glowBorder"] = false,
		},
		["쐐기 : 탱커 디버프"] = {
			["glow"] = false,
			["xOffset"] = 0,
			["customText"] = "function()\n    if aura_env and aura_env.state and aura_env.state.name then\n        if aura_env.state.name == \"톱날 이빨\" then\n            return \"물리 +50%\"\n        elseif aura_env.state.name == \"으스러진 방어\" then\n            return \"물리 +200%\"\n        elseif aura_env.state.name == \"심장 공격\" then\n            return \"피해 +\"..20*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"소탕의 모래\" then\n            return \"피해 +30%\"\n        elseif aura_env.state.name == \"크게 깨물기\" then\n            return \"체력 -\"..5*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"정신 도려내기\" then\n            return \"체력 -\"..10*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"부패시키는 손길\" then\n            return \"피해 +15%\"    \n        elseif aura_env.state.name == \"기름친 칼날\" then\n            return \"치감 70%\"      \n        elseif aura_env.state.name == \"독니 일격\" then\n            return \"자연 +100%\"    \n        elseif aura_env.state.name == \"저주받은 베기\" then\n            return \"피해 +\"..15*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"파열의 일격\" then\n            return \"방어 -\"..10*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"아제라이트 심장추적자\" then\n            local n = 1\n            local stack = 0\n            local name = select(1, UnitDebuff(\"player\", n))\n            \n            while name do\n                if name == \"아제라이트 심장추적자\" then \n                    stack = stack + 1\n                end\n                n = n + 1\n                name = select(1, UnitDebuff(\"player\", n))\n            end\n            return \"치감 \"..33*stack..\"%\"    \n        elseif aura_env.state.name == \"방해의 절단\" or aura_env.state.name == \"이빨 분쇄자\" then\n            return \"가속 -35%\"\n        elseif aura_env.state.name == \"썩어가는 상처\" then\n            return \"치감 25%\"    \n        elseif aura_env.state.name == \"상처 감염\" then\n            return \"치감 20%\"    \n        elseif aura_env.state.name == \"역병 걸음\" then\n            return \"치감 25%\"    \n        elseif aura_env.state.name == \"우둘투둘한 이빨\" then\n            return \"치감 \"..10*aura_env.state.stacks..\"%\"\n        else\n            return \"\"\n        end\n    end\nend",
			["yOffset"] = -165,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
					["glow_action"] = "show",
					["message_type"] = "YELL",
					["do_message"] = false,
					["message"] = "",
					["custom"] = "\n\n",
					["do_sound"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
					["do_glow"] = false,
				},
				["finish"] = {
					["do_glow"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["glow_action"] = "hide",
				},
				["init"] = {
					["custom"] = "\n\n",
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["auto"] = true,
			["glowScale"] = 1,
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "%c",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "기본 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 34,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 5,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "기본 글꼴",
					["text_anchorYOffset"] = -7,
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_shadowYOffset"] = 0,
					["text_fontSize"] = 35,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [2]
				{
					["type"] = "subborder",
					["border_offset"] = 0,
					["border_color"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "1 Pixel",
					["border_size"] = 3,
				}, -- [3]
			},
			["height"] = 65,
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
					["scalex"] = 2.5,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["scaleType"] = "straightScale",
					["scaley"] = 2.5,
					["alpha"] = 0,
					["colorR"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorA"] = 1,
					["duration_type"] = "seconds",
					["type"] = "custom",
					["rotate"] = 0,
					["duration"] = "0.17",
					["use_scale"] = true,
				},
				["main"] = {
					["colorR"] = 1,
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["scaleType"] = "pulse",
					["duration_type"] = "seconds",
					["colorB"] = 1,
					["scaley"] = 1.05,
					["alpha"] = 0,
					["x"] = 0,
					["y"] = 0,
					["colorA"] = 1,
					["colorG"] = 1,
					["scalex"] = 1.05,
					["use_scale"] = true,
					["rotate"] = 0,
					["duration"] = "1",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["glowLines"] = 8,
			["parent"] = "쐐기 : 기타 0929",
			["glowFrequency"] = 0.25,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["value"] = 1,
								["variable"] = "show",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\BITE.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "magic",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								0.92549019607843, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "curse",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.87450980392157, -- [1]
								0, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "poison",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.2, -- [1]
								0.70196078431373, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = "==",
						["value"] = "disease",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.52156862745098, -- [1]
								0.32941176470588, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [5]
			},
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = ">=",
				["encounterid"] = "2073",
				["use_encounterid"] = false,
				["role"] = {
					["single"] = "TANK",
					["multi"] = {
					},
				},
				["use_encounter"] = true,
				["level"] = "",
				["talent2"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["use_size"] = true,
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_role"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "8040",
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["mythic"] = true,
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "110",
				["faction"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["use_zoneId"] = false,
				["use_zone"] = false,
				["level_operator"] = ">=",
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["uid"] = "tfd4Z5fghwj",
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"266238", -- [1]
							"톱날 이빨", -- [2]
							"심장 공격", -- [3]
							"크게 깨물기", -- [4]
							"부패시키는 손길", -- [5]
							"정신 도려내기", -- [6]
							"기름친 칼날", -- [7]
							"저주받은 베기", -- [8]
							"독니 일격", -- [9]
							"아제라이트 심장추적자", -- [10]
							"방해의 절단", -- [11]
							"썩어가는 상처", -- [12]
							"상처 감염", -- [13]
							"역병 걸음", -- [14]
							"우둘투둘한 이빨", -- [15]
							"절단 칼날", -- [16]
							"소탕의 모래", -- [17]
							"이빨 분쇄자", -- [18]
							"274633", -- [19]
						},
						["matchesShowOn"] = "showOnActive",
						["unit"] = "player",
						["use_tooltip"] = false,
						["debuffType"] = "HARMFUL",
						["type"] = "aura2",
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["spellIds"] = {
						},
						["useGroup_count"] = false,
						["names"] = {
							"공포의 오라", -- [1]
							"활력 주입", -- [2]
							"힘의 속삭임", -- [3]
							"지각 변동", -- [4]
							"숨 막히는 소금물", -- [5]
							"흉포한 포식자", -- [6]
							"황금 뱉기", -- [7]
							"교수형 집행인의 올가미", -- [8]
							"심연의 역류", -- [9]
						},
						["combineMatches"] = "showLowest",
						["custom_hide"] = "timed",
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "",
				["activeTriggerMode"] = -10,
			},
			["regionType"] = "icon",
			["width"] = 65,
			["frameStrata"] = 1,
			["glowXOffset"] = 0,
			["icon"] = true,
			["zoom"] = 0,
			["authorOptions"] = {
			},
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 탱커 디버프",
			["glowLength"] = 10,
			["alpha"] = 1,
			["glowYOffset"] = 0,
			["anchorFrameType"] = "SCREEN",
			["config"] = {
			},
			["inverse"] = false,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["displayIcon"] = 136066,
			["cooldown"] = true,
			["glowBorder"] = false,
		},
		["복종"] = {
			["glow"] = false,
			["parent"] = "여왕의 칙령 (딩까) 2",
			["yOffset"] = 327.1112670898438,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["desaturate"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "보주 밟지 말고",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "굵은 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 31,
				}, -- [1]
			},
			["height"] = 64,
			["load"] = {
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "twentyfive",
					["multi"] = {
						["twentyfive"] = true,
					},
				},
			},
			["glowFrequency"] = 0.25,
			["anchorFrameType"] = "SCREEN",
			["glowXOffset"] = 0,
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 1,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["names"] = {
						},
						["spellIds"] = {
						},
						["unit"] = "player",
						["auranames"] = {
							"복종하라!", -- [1]
						},
						["subeventPrefix"] = "SPELL",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["actions"] = {
				["start"] = {
					["message_type"] = "SAY",
					["message"] = "{가위표}보주 밟지마!{가위표}",
					["do_custom"] = true,
					["do_message"] = true,
				},
				["finish"] = {
				},
				["init"] = {
					["do_custom"] = true,
				},
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["selfPoint"] = "CENTER",
			["glowLines"] = 8,
			["width"] = 64,
			["config"] = {
			},
			["frameStrata"] = 1,
			["cooldownTextDisabled"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["glowScale"] = 1,
			["id"] = "복종",
			["xOffset"] = -32,
			["alpha"] = 1,
			["glowYOffset"] = 0,
			["stickyDuration"] = false,
			["uid"] = "6jMDSoO5YpB",
			["inverse"] = false,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["glowLength"] = 10,
			["glowBorder"] = false,
		},
		["쐐기 : 개인 디버프"] = {
			["glow"] = false,
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    if WA_GetUnitDebuff(\"player\", \"살점 파내기\") then\n        return \"수호물 필요!\"\n    end\n    \n    if aura_env and aura_env.state and aura_env.state.name then\n        if aura_env.state.name == \"공포의 오라\" and aura_env.state.stacks > 1 then\n            return \"이동!\"\n        elseif aura_env.state.name == \"고대 환각의 마귀\" or aura_env.state.name == \"영혼 조작\" then\n            return floor((UnitHealth(\"player\")/UnitHealthMax(\"player\")-0.5)*100)..\"%\"\n        elseif aura_env.state.name == \"신경독\" then\n            return \"이동 중지!\"    \n        elseif aura_env.state.name == \"풍력\" or aura_env.state.name == \"심연의 역류\" then \n            return \"저항!\"    \n        elseif  aura_env.state.name == \"교수형 집행인의 올가미\" then\n            return \"끌린 후 회피!\"\n        elseif aura_env.state.name ==\"미끄러운 거품\" then\n            return \"점프 금지!\"\n        elseif aura_env.state.name == \"추격\" or aura_env.state.name == \"눈먼 분노\" or\n        aura_env.state.name == \"피에 대한 갈증\"  or aura_env.state.name == \"시선 고정\"\n        or aura_env.state.name == \"강철의 시선\" or aura_env.state.name == \"수색과 섬멸\" then\n            return \"추격 대상!\"\n        elseif aura_env.state.name == \"부패하는 정신\" then\n            return format(\"%.1f만\", select(17, WA_GetUnitDebuff(\"player\", \"부패하는 정신\"))/10000)   \n        else\n            return \"\"\n        end\n    end\n    \n    \nend",
			["yOffset"] = -80,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["glow_action"] = "show",
					["message_type"] = "YELL",
					["do_message"] = false,
					["message"] = "",
					["custom"] = "\n\n",
					["do_sound"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
					["do_glow"] = false,
				},
				["finish"] = {
					["do_glow"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["glow_action"] = "hide",
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["selfPoint"] = "CENTER",
			["zoom"] = 0,
			["auto"] = true,
			["glowLength"] = 10,
			["desaturate"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["authorOptions"] = {
			},
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "%c",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "기본 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 34,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 5,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "기본 글꼴",
					["text_anchorYOffset"] = -7,
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_shadowYOffset"] = 0,
					["text_fontSize"] = 41,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [2]
				{
					["type"] = "subborder",
					["border_offset"] = 0,
					["border_color"] = {
						1, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["border_visible"] = true,
					["border_edge"] = "1 Pixel",
					["border_size"] = 3,
				}, -- [3]
			},
			["height"] = 80,
			["parent"] = "쐐기 : 기타 0929",
			["glowLines"] = 8,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = 1,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 5,
								["variable"] = "show",
								["value"] = 1,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BikeHorn.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = 2,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = 3,
								["variable"] = "show",
								["value"] = 1,
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = {
								["message"] = "%n(해제) 대상!",
								["message_type"] = "YELL",
							},
							["property"] = "chat",
						}, -- [1]
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\BITE.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [2]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 4,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								["message"] = "추격 받는 중!",
								["message_type"] = "YELL",
							},
							["property"] = "chat",
						}, -- [1]
						{
							["value"] = {
								["sound_type"] = "Play",
								["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\aggro.ogg",
								["sound_channel"] = "Master",
							},
							["property"] = "sound",
						}, -- [2]
					},
				}, -- [3]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = 5,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = -2,
								["op"] = "==",
								["variable"] = "AND",
								["checks"] = {
									{
										["trigger"] = 1,
										["op"] = "==",
										["value"] = "공포의 오라",
										["variable"] = "name",
									}, -- [1]
									{
										["trigger"] = 1,
										["op"] = ">",
										["value"] = "1",
										["variable"] = "stacks",
									}, -- [2]
								},
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "glow",
						}, -- [1]
					},
				}, -- [4]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = 5,
								["variable"] = "show",
								["value"] = 1,
							}, -- [1]
							{
								["trigger"] = -2,
								["variable"] = "AND",
								["checks"] = {
									{
										["trigger"] = 1,
										["op"] = "==",
										["value"] = "공포의 오라",
										["variable"] = "name",
									}, -- [1]
									{
										["trigger"] = 1,
										["op"] = "==",
										["value"] = "1",
										["variable"] = "stacks",
									}, -- [2]
								},
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "desaturate",
						}, -- [1]
					},
				}, -- [5]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = -2,
								["variable"] = "AND",
								["checks"] = {
									{
										["trigger"] = 1,
										["op"] = "==",
										["value"] = "활력 주입",
										["variable"] = "name",
									}, -- [1]
									{
										["trigger"] = 1,
										["op"] = ">=",
										["value"] = "9",
										["variable"] = "stacks",
									}, -- [2]
								},
							}, -- [1]
							{
								["trigger"] = 1,
								["op"] = "==",
								["value"] = "미끄러운 거품",
								["variable"] = "name",
							}, -- [2]
						},
					},
					["changes"] = {
						{
							["value"] = true,
							["property"] = "glow",
						}, -- [1]
						{
							["value"] = "Pixel",
							["property"] = "glowType",
						}, -- [2]
					},
				}, -- [6]
				{
					["check"] = {
						["trigger"] = -2,
						["variable"] = "OR",
						["checks"] = {
							{
								["trigger"] = 1,
								["op"] = "==",
								["value"] = "magic",
								["variable"] = "debuffClass",
							}, -- [1]
							{
								["trigger"] = 2,
								["op"] = "==",
								["value"] = "magic",
								["variable"] = "debuffClass",
							}, -- [2]
							{
								["trigger"] = 3,
								["op"] = "==",
								["value"] = "magic",
								["variable"] = "debuffClass",
							}, -- [3]
						},
					},
					["changes"] = {
						{
							["value"] = {
								0, -- [1]
								0.92156862745098, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [7]
				{
					["check"] = {
						["trigger"] = 2,
						["op"] = "==",
						["value"] = "curse",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.90196078431373, -- [1]
								0, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [8]
				{
					["check"] = {
						["trigger"] = 2,
						["op"] = "==",
						["value"] = "poison",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.2, -- [1]
								0.70196078431373, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [9]
				{
					["check"] = {
						["trigger"] = 2,
						["op"] = "==",
						["value"] = "disease",
						["variable"] = "debuffClass",
					},
					["changes"] = {
						{
							["value"] = {
								0.52156862745098, -- [1]
								0.32941176470588, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.border_color",
						}, -- [1]
					},
				}, -- [10]
			},
			["glowFrequency"] = 0.25,
			["cooldownEdge"] = false,
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
					["scalex"] = 2.5,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["scaleType"] = "straightScale",
					["scaley"] = 2.5,
					["alpha"] = 0,
					["colorR"] = 1,
					["y"] = 0,
					["x"] = 0,
					["use_scale"] = true,
					["duration_type"] = "seconds",
					["type"] = "custom",
					["rotate"] = 0,
					["duration"] = "0.17",
					["colorA"] = 1,
				},
				["main"] = {
					["type"] = "none",
					["colorR"] = 1,
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
					["use_scale"] = true,
					["x"] = 0,
					["duration"] = "1",
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["colorB"] = 1,
					["colorG"] = 1,
					["scaleType"] = "pulse",
					["duration_type"] = "seconds",
					["rotate"] = 0,
					["scalex"] = 1.05,
					["scaley"] = 1.05,
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["config"] = {
			},
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = ">=",
				["encounterid"] = "2073",
				["use_encounterid"] = false,
				["role"] = {
					["multi"] = {
					},
				},
				["level"] = "",
				["use_encounter"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_zone"] = false,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["level_operator"] = ">=",
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["mythic"] = true,
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "110",
				["faction"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["use_zoneId"] = false,
				["race"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "8040",
				["class"] = {
					["multi"] = {
					},
				},
			},
			["width"] = 80,
			["regionType"] = "icon",
			["frameStrata"] = 1,
			["stickyDuration"] = false,
			["icon"] = true,
			["glowScale"] = 1,
			["keepAspectRatio"] = false,
			["useGlowColor"] = false,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 개인 디버프",
			["xOffset"] = 0,
			["alpha"] = 1,
			["glowYOffset"] = 0,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "u9JIYR7e5jl",
			["inverse"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["auranames"] = {
							"공포의 오라", -- [1]
							"활력 주입", -- [2]
							"힘의 속삭임", -- [3]
							"지각 변동", -- [4]
							"흉포한 포식자", -- [5]
							"황금 뱉기", -- [6]
							"교수형 집행인의 올가미", -- [7]
							"심연의 역류", -- [8]
							"풍력", -- [9]
							"감염", -- [10]
							"미끄러운 거품", -- [11]
							"고대 환각의 마귀", -- [12]
							"흐려진 시야", -- [13]
							"손 마비", -- [14]
							"보주", -- [15]
							"영혼 조작", -- [16]
						},
						["matchesShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["use_tooltip"] = false,
						["debuffType"] = "HARMFUL",
						["showClones"] = false,
						["type"] = "aura2",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["buffShowOn"] = "showOnActive",
						["useName"] = true,
						["spellIds"] = {
						},
						["names"] = {
							"공포의 오라", -- [1]
							"활력 주입", -- [2]
							"힘의 속삭임", -- [3]
							"지각 변동", -- [4]
							"숨 막히는 소금물", -- [5]
							"흉포한 포식자", -- [6]
							"황금 뱉기", -- [7]
							"교수형 집행인의 올가미", -- [8]
							"심연의 역류", -- [9]
						},
						["useGroup_count"] = false,
						["combineMatches"] = "showLowest",
						["unit"] = "player",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
						["useGroup_count"] = false,
						["subeventPrefix"] = "SPELL",
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["use_tooltip"] = false,
						["spellIds"] = {
						},
						["auranames"] = {
							"변환: 적을 점액으로", -- [1]
							"뱀의 현혹", -- [2]
							"사술", -- [3]
							"신경독", -- [4]
							"절망의 구덩이", -- [5]
							"부패하는 정신", -- [6]
							"익사의 손길", -- [7]
							"도화선 점화기", -- [8]
							"정신 분열", -- [9]
							"마력 속박", -- [10]
							"룬새김 회전베기", -- [11]
							"광기의 눈길", -- [12]
							"숨은 칼날", -- [13]
							"정신 공격", -- [14]
							"두뇌 빙결", -- [15]
							"숨막히는 물", -- [16]
							"맹독 포화", -- [17]
							"감전 충격", -- [18]
							"메아리 칼날", -- [19]
							"정의의 불길", -- [20]
							"충격 발톱", -- [21]
							"공포스러운 얼굴", -- [22]
							"공포의 비명소리", -- [23]
							"마비시키는 독칼", -- [24]
							"쇠약의 외침", -- [25]
							"잡아채는 가시", -- [26]
							"폭발성 공허", -- [27]
							"화학 화상", -- [28]
							"숨 막히는 소금물", -- [29]
							"냉기 충격", -- [30]
							"공포의 울부짖음", -- [31]
							"흉측한 방출", -- [32]
							"빙결 덫", -- [33]
							"두꺼비 역병", -- [34]
							"솟구치는 파도", -- [35]
							"정신력 고갈", -- [36]
						},
						["names"] = {
							"변환: 적을 점액으로", -- [1]
							"뱀의 현혹", -- [2]
							"사술", -- [3]
							"신경독", -- [4]
							"절망의 구덩이", -- [5]
							"부패하는 정신", -- [6]
							"익사의 손길", -- [7]
							"도화선 점화기", -- [8]
							"정신 분열", -- [9]
						},
						["combineMatches"] = "showLowest",
						["useName"] = true,
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["debuffType"] = "HELPFUL",
						["type"] = "aura2",
						["useName"] = true,
						["auranames"] = {
							"유혹", -- [1]
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [3]
				{
					["trigger"] = {
						["buffShowOn"] = "showOnActive",
						["type"] = "aura2",
						["use_debuffClass"] = false,
						["auranames"] = {
							"추격", -- [1]
							"피에 대한 갈증", -- [2]
							"시선 고정", -- [3]
							"눈먼 분노", -- [4]
							"강철의 시선", -- [5]
							"수색과 섬멸", -- [6]
							"검은 화약 폭탄", -- [7]
							"발견된 대포", -- [8]
						},
						["useGroup_count"] = false,
						["matchesShowOn"] = "showOnActive",
						["event"] = "Health",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["use_tooltip"] = false,
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["names"] = {
							"추격", -- [1]
							"피에 대한 갈증", -- [2]
							"시선 고정", -- [3]
							"눈먼 분노", -- [4]
							"강철의 시선", -- [5]
							"수색과 섬멸", -- [6]
							"검은 화약 폭탄", -- [7]
							"발견된 대포", -- [8]
						},
						["combineMatches"] = "showLowest",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [4]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "status",
						["event"] = "Health",
						["customStacks"] = "function()\nreturn 0\nend",
						["customDuration"] = "function()\n    local dur, exp = select(5,WA_GetUnitDebuff(\"player\", \"살점 파내기\"))\n    return dur, exp\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["customName"] = "",
						["events"] = "UNIT_AURA",
						["customIcon"] = "function()\n    return \"Interface\\\\icons\\\\70_inscription_vantus_rune_light\"\nend",
						["check"] = "event",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["custom"] = "function()\n    if WA_GetUnitDebuff(\"player\", \"살점 파내기\") and not WA_GetUnitBuff(\"player\", \"최하급 강화 수호물\") then\n        return true\n    end\nend",
					},
					["untrigger"] = {
						["custom"] = "function()\n    return true\nend",
					},
				}, -- [5]
				["disjunctive"] = "any",
				["customTriggerLogic"] = "\n\n",
				["activeTriggerMode"] = -10,
			},
			["displayIcon"] = 136066,
			["cooldown"] = true,
			["glowBorder"] = false,
		},
		["쐐기 : 화산"] = {
			["outline"] = "OUTLINE",
			["vulcanic_hits_player0"] = 0,
			["displayText"] = "%n",
			["customText"] = "function()\n    if aura_env.display ~= nil then\n        return aura_env.display\n    end\nend",
			["yOffset"] = 0,
			["anchorPoint"] = "BOTTOMLEFT",
			["customTextUpdate"] = "event",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["icon"] = true,
			["fontFlags"] = "OUTLINE",
			["internalVersion"] = 24,
			["wordWrap"] = "WordWrap",
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["type"] = "preset",
					["preset"] = "fade",
					["duration_type"] = "seconds",
				},
			},
			["desaturate"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "event",
						["custom_hide"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["genericShowOn"] = "showOnActive",
						["unit"] = "player",
						["custom"] = "function(mainevent)\n    local time, subevent, wtf1, sourceGUID, sourceName, sourceFlags, wtf2, destGUID, destName, somenumber, wtf3, spellID, spellName, _, amount, _, _, _, _, _, crit =  CombatLogGetCurrentEventInfo()\n    \n    if mainevent == \"CHALLENGE_MODE_START\" then\n        local player1 = strsplit(\"-\", (UnitName(\"player\")))\n        local player2 = strsplit(\"-\", (UnitName(\"party1\")))\n        local player3 = strsplit(\"-\", (UnitName(\"party2\")))\n        local player4 = strsplit(\"-\", (UnitName(\"party3\")))\n        local player5 = strsplit(\"-\", (UnitName(\"party4\")))\n        WeakAurasSaved['volcanic_hits_table'] = {[player1] = 0, [player2] = 0, [player3] = 0, [player4] = 0, [player5] = 0}\n        WeakAurasSaved['total'] = 0\n    end\n    ---\n    if mainevent == \"COMBAT_LOG_EVENT_UNFILTERED\"\n    and subevent == \"SPELL_DAMAGE\"\n    and spellID == 209862 then\n        WeakAurasSaved['total'] = WeakAurasSaved['total'] + 1\n        local player = strsplit(\"-\", (destName))\n        for k,v in pairs(WeakAurasSaved['volcanic_hits_table']) do\n            if k == player then\n                WeakAurasSaved['volcanic_hits_table'][k] = WeakAurasSaved['volcanic_hits_table'][k] + 1\n            end\n        end\n        SendChatMessage(\"화산: \"..player..\" (\"..WeakAurasSaved['volcanic_hits_table'][player]..\"/\"..WeakAurasSaved['total']..\").\", \"PARTY\")\n    end\n    --\n    if mainevent == \"CHALLENGE_MODE_COMPLETED\" then\n        SendChatMessage(\"---------------------------------------------\", \"PARTY\")\n        SendChatMessage(\"화산 총 피해: \"..WeakAurasSaved['total']..\".\", \"PARTY\")\n        SendChatMessage(\"---------------------------------------------\", \"PARTY\")\n        for k,v in pairs(WeakAurasSaved['volcanic_hits_table']) do\n            SendChatMessage(k..\": \"..v..\".\", \"PARTY\")\n        end\n        SendChatMessage(\"---------------------------------------------\", \"PARTY\")\n    end\n    --\n    if WeakAurasSaved['total'] ~= nil then\n        return true\n    end\nend",
						["customName"] = "function()\n    local display = \"총 화산: \"..WeakAurasSaved['total']\n    for k,v in pairs(WeakAurasSaved['volcanic_hits_table']) do\n        display = display..\"\\n\"..k..\": \"..v\n    end\n    return display\nend",
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED, CHALLENGE_MODE_COMPLETED, CHALLENGE_MODE_START",
						["event"] = "Health",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
						["custom"] = "function()\n    return true\nend",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = 1,
			},
			["font"] = "Expressway",
			["version"] = 88,
			["parent"] = "쐐기 : 기타 0929",
			["height"] = 24.999923706055,
			["vulcanic_hits_total"] = 0,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = "==",
				["use_encounter"] = true,
				["level_operator"] = "==",
				["use_zoneId"] = false,
				["use_encounterid"] = false,
				["role"] = {
					["single"] = "HEALER",
					["multi"] = {
						["HEALER"] = true,
					},
				},
				["use_zone"] = false,
				["encounterid"] = "",
				["faction"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "",
				["use_difficulty"] = true,
				["use_affixes"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["use_size"] = true,
				["affixes"] = {
					["single"] = 3,
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_role"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["mythic"] = true,
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "120",
				["name"] = "",
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["talent2"] = {
					["multi"] = {
					},
				},
				["level"] = "",
				["use_level"] = false,
				["zone"] = "",
			},
			["conditions"] = {
			},
			["xOffset"] = 0,
			["fontSize"] = 25,
			["vulcanic_hits_player1"] = 0,
			["selfPoint"] = "CENTER",
			["config"] = {
			},
			["stickyDuration"] = false,
			["anchorFrameType"] = "SCREEN",
			["displayStacks"] = "%c",
			["regionType"] = "text",
			["authorOptions"] = {
			},
			["justify"] = "CENTER",
			["auto"] = true,
			["vulcanic_hits_player4"] = 0,
			["vulcanic_hits_player3"] = 0,
			["anchorFrameParent"] = true,
			["vulcanic_hits_player2"] = 0,
			["stacksContainment"] = "INSIDE",
			["zoom"] = 0,
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 화산",
			["automaticWidth"] = "Auto",
			["frameStrata"] = 2,
			["width"] = 26.000062942505,
			["actions"] = {
				["start"] = {
					["glow_action"] = "hide",
					["message_type"] = "PRINT",
					["do_message"] = false,
					["message"] = "",
					["custom"] = "",
					["do_sound"] = false,
					["glow_frame"] = "",
					["do_custom"] = true,
					["sound"] = " custom",
					["do_glow"] = false,
				},
				["finish"] = {
					["do_message"] = false,
					["custom"] = "aura_env.display = nil",
					["do_custom"] = true,
				},
				["init"] = {
					["do_custom"] = true,
				},
			},
			["uid"] = "9Z2lgZ7poSu",
			["inverse"] = false,
			["color"] = {
				0.97647058823529, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["fixedWidth"] = 200,
			["stacksPoint"] = "BOTTOMRIGHT",
			["textColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
		},
		["쐐기 : 전율"] = {
			["textFlags"] = "None",
			["stacksSize"] = 12,
			["authorOptions"] = {
			},
			["displayText"] = "%p",
			["yOffset"] = -245,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["do_message"] = false,
					["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\sonar.ogg",
					["do_custom"] = true,
					["do_sound"] = true,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = true,
				},
			},
			["fontFlags"] = "OUTLINE",
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0.90588235294118, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["font"] = "Friz Quadrata TT",
			["sparkOffsetY"] = 0,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = "==",
				["level_operator"] = "==",
				["role"] = {
					["multi"] = {
					},
				},
				["use_difficulty"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["single"] = 14,
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["level"] = "",
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "120",
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["use_affixes"] = true,
				["race"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
			},
			["timerColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "text",
			["stacks"] = false,
			["texture"] = "Minimalist",
			["textFont"] = "Friz Quadrata TT",
			["borderOffset"] = 5,
			["auto"] = false,
			["tocversion"] = 80205,
			["timerFont"] = "Friz Quadrata TT",
			["alpha"] = 1,
			["borderInset"] = 11,
			["fixedWidth"] = 200,
			["textColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["outline"] = "OUTLINE",
			["borderBackdrop"] = "Blizzard Tooltip",
			["color"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["customText"] = "",
			["barInFront"] = true,
			["parent"] = "쐐기 : 기타 0929",
			["stacksFont"] = "Friz Quadrata TT",
			["sparkRotationMode"] = "AUTO",
			["automaticWidth"] = "Auto",
			["displayTextLeft"] = "  시전 중지!!",
			["triggers"] = {
				{
					["trigger"] = {
						["useGroup_count"] = false,
						["matchesShowOn"] = "showOnActive",
						["names"] = {
							"전율", -- [1]
						},
						["use_tooltip"] = false,
						["debuffType"] = "HARMFUL",
						["useName"] = true,
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["type"] = "aura2",
						["auranames"] = {
							"전율", -- [1]
						},
						["spellIds"] = {
						},
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["combineMatches"] = "showLowest",
						["custom_hide"] = "timed",
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["event"] = "Health",
						["unit"] = "player",
						["use_unit"] = true,
						["duration"] = "1",
						["custom"] = "function()\n    if WeakAuras.triggerState[aura_env.id].triggers[1] then\n        for unit in WA_IterateGroupMembers() do                \n            if unit ~= \"player\" and WeakAuras.CheckRange(unit, 4, \"<=\") then\n                return true\n            end\n        end\n    end\nend\n\n\n",
						["custom_type"] = "status",
						["check"] = "update",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
						["custom"] = "function()\nreturn true\nend",
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
				["activeTriggerMode"] = 1,
			},
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["internalVersion"] = 24,
			["textSize"] = 22,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["type"] = "custom",
					["colorR"] = 1,
					["use_color"] = true,
					["scaley"] = 1,
					["x"] = 0,
					["duration_type"] = "seconds",
					["alpha"] = 0,
					["colorType"] = "custom",
					["y"] = 0,
					["colorA"] = 1,
					["colorG"] = 0,
					["colorB"] = 0.03921568627451,
					["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    \n    if WeakAuras.IsOptionsOpen() then\n        return r1,g1,b1,a1\n    end\n    \n    local cast = select(5, UnitCastingInfo(\"player\")) or select(5, UnitChannelInfo(\"player\"))\n    local intp = select(8, UnitCastingInfo(\"player\")) or select(7, UnitChannelInfo(\"player\"))\n    \n    if cast and not intp and cast/1000 > aura_env.state.expirationTime then\n        return 1,0,0,1\n    else\n        return r1,g1,b1,a1\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
					["rotate"] = 0,
					["scalex"] = 1,
					["duration"] = "",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["uid"] = "uC0SoXWfm5u",
			["text"] = true,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["stickyDuration"] = false,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["height"] = 59.999923706055,
			["version"] = 88,
			["anchorFrameType"] = "SCREEN",
			["timer"] = true,
			["timerFlags"] = "None",
			["rotateText"] = "NONE",
			["sparkBlendMode"] = "ADD",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["fontSize"] = 60,
			["config"] = {
			},
			["sparkHidden"] = "NEVER",
			["spark"] = true,
			["justify"] = "CENTER",
			["border"] = false,
			["borderEdge"] = "None",
			["zoom"] = 0.25,
			["borderSize"] = 16,
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["icon_side"] = "RIGHT",
			["sparkOffsetX"] = 0,
			["xOffset"] = 0,
			["sparkHeight"] = 100,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["stacksColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["semver"] = "1.0.87",
			["displayTextRight"] = "%p ",
			["id"] = "쐐기 : 전율",
			["timerSize"] = 30,
			["frameStrata"] = 1,
			["width"] = 33.999992370605,
			["wordWrap"] = "WordWrap",
			["displayIcon"] = 135975,
			["inverse"] = true,
			["sparkDesature"] = false,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0.49019607843137, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "color",
						}, -- [1]
					},
				}, -- [1]
			},
			["sparkWidth"] = 25,
			["stacksFlags"] = "None",
		},
		["쐐기 : 강화"] = {
			["glow"] = true,
			["xOffset"] = 0,
			["yOffset"] = 1080,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
					["do_glow"] = false,
					["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nlocal plate = C_NamePlate.GetNamePlateForUnit(aura_env.state.unitId)\n\nif plate then\n    region:ClearAllPoints()\n    region:SetPoint(\"RIGHT\", plate, \"LEFT\", -5, 0)\nend\n\n\n\n\n",
					["do_message"] = false,
					["do_custom"] = true,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["auto"] = true,
			["tocversion"] = 80205,
			["desaturate"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["parent"] = "쐐기 : 기타 0929",
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "AUTO",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = 0,
					["text_fontType"] = "OUTLINE",
					["text_anchorPoint"] = "CENTER",
					["border_color"] = {
					},
					["text_fontSize"] = 23,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [1]
			},
			["height"] = 25,
			["stickyDuration"] = false,
			["glowLines"] = 4,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["event"] = "Health",
						["genericShowOn"] = "showOnActive",
						["unit"] = "player",
						["subeventSuffix"] = "_CAST_START",
						["custom"] = "function(allstates, event, ...)\n    local unitId = ...\n    local subEv = select(2, ...)\n    local destGUID = select(8, ...)\n    local spellId = select(12, ...)\n    \n    if event == \"NAME_PLATE_UNIT_ADDED\" and unitId then\n        local _, icon = WA_GetUnitBuff(unitId, 209859)\n        local n = 1\n        local stack = 0\n        local BuffID = select(10, UnitBuff(unitId, n))\n        \n        while BuffID do\n            if BuffID == 209859 then \n                stack = stack + 1\n            end\n            n = n + 1\n            BuffID = select(10, UnitBuff(unitId, n))\n        end\n        \n        \n        if icon then\n            local state = {\n                show = true,\n                changed = true,\n                icon = icon,\n                stacks = stack,\n                guid = UnitGUID(unitId),\n                unitId = unitId\n            }\n            \n            allstates[UnitGUID(unitId)] = state\n            \n            return true\n        end\n        \n    elseif event == \"NAME_PLATE_UNIT_REMOVED\" and unitId then\n        local state = allstates[UnitGUID(unitId)]\n        if state then\n            state.show = false\n            state.changed = true\n            return true\n        end\n        \n    elseif subEv == \"SPELL_AURA_APPLIED\" and spellId == 209859 then\n        local guid = destGUID\n        \n        for _, plate in pairs(C_NamePlate.GetNamePlates()) do\n            unitId = plate.namePlateUnitToken\n            if UnitGUID(unitId) == guid then\n                local n = 1\n                local stack = 0\n                local BuffID = select(10, UnitBuff(unitId, n))\n                \n                while BuffID do\n                    if BuffID == 209859 then \n                        stack = stack + 1\n                    end\n                    n = n + 1\n                    BuffID = select(10, UnitBuff(unitId, n))\n                end\n                \n                local state = {\n                    show = true,\n                    changed = true,\n                    icon = select(3, GetSpellInfo(209859)),\n                    stacks = stack,\n                    guid = guid,\n                    unitId = unitId\n                }                \n                allstates[guid] = state\n                return true\n            end\n        end\n        \n    elseif subEv == \"SPELL_AURA_REMOVED\" and spellId == 209859 then\n        local state = allstates[destGUID]\n        if state then\n            state.show = false\n            state.changed = true\n            return true\n        end\n    end\n    \nend",
						["events"] = "NAME_PLATE_UNIT_ADDED, NAME_PLATE_UNIT_REMOVED, COMBAT_LOG_EVENT_UNFILTERED",
						["subeventPrefix"] = "SPELL",
						["check"] = "event",
						["spellIds"] = {
						},
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["glowFrequency"] = 0.25,
			["conditions"] = {
			},
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = "==",
				["level_operator"] = "==",
				["role"] = {
					["multi"] = {
					},
				},
				["use_difficulty"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["single"] = 7,
					["multi"] = {
						[16] = true,
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["use_level"] = false,
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
					},
				},
				["effectiveLevel"] = "120",
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["use_affixes"] = true,
				["level"] = "120",
				["race"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
			},
			["glowType"] = "ACShine",
			["glowThickness"] = 4,
			["useGlowColor"] = true,
			["uid"] = "MEuhimUF28d",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["width"] = 25,
			["frameStrata"] = 2,
			["icon"] = true,
			["selfPoint"] = "CENTER",
			["zoom"] = 0,
			["glowXOffset"] = 0,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["glowScale"] = 1.15,
			["id"] = "쐐기 : 강화",
			["authorOptions"] = {
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["glowYOffset"] = 0,
			["config"] = {
			},
			["inverse"] = false,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["displayIcon"] = 1041231,
			["glowLength"] = 10,
			["glowBorder"] = false,
		},
		["홀로"] = {
			["glow"] = false,
			["parent"] = "여왕의 칙령 (딩까) 2",
			["yOffset"] = 327.1112670898438,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["auranames"] = {
							"홀로서기!", -- [1]
						},
						["event"] = "Health",
						["names"] = {
						},
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["desaturate"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "혼자 나가!",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "굵은 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 31,
				}, -- [1]
			},
			["height"] = 64,
			["glowLines"] = 8,
			["glowFrequency"] = 0.25,
			["glowYOffset"] = 0,
			["xOffset"] = 160,
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 1,
			["selfPoint"] = "CENTER",
			["glowLength"] = 10,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["actions"] = {
				["start"] = {
					["message_type"] = "SAY",
					["do_message"] = true,
					["do_custom"] = true,
				},
				["finish"] = {
				},
				["init"] = {
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["stickyDuration"] = false,
			["config"] = {
			},
			["alpha"] = 1,
			["cooldownTextDisabled"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["glowScale"] = 1,
			["id"] = "홀로",
			["load"] = {
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "twentyfive",
					["multi"] = {
						["twentyfive"] = true,
					},
				},
			},
			["frameStrata"] = 1,
			["width"] = 64,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "KFCz88adE0C",
			["inverse"] = false,
			["authorOptions"] = {
			},
			["conditions"] = {
			},
			["keepAspectRatio"] = false,
			["glowBorder"] = false,
		},
		["쐐기 : 부족 의회 토템"] = {
			["glow"] = false,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["parent"] = "쐐기 : 기타 0929",
			["authorOptions"] = {
			},
			["useglowColor"] = false,
			["customText"] = "function()\n    if aura_env.state and aura_env.state.PassUnit then\n        local region = aura_env.region\n        local plate = C_NamePlate.GetNamePlateForUnit(aura_env.state.PassUnit)\n        if plate then\n            region:ClearAllPoints()\n            region:SetPoint(\"BOTTOM\", plate, \"TOP\", 0, 0)\n            region:Show()\n        else\n            region:Hide()\n        end\n    end\nend",
			["yOffset"] = 5000,
			["anchorPoint"] = "CENTER",
			["iconInset"] = 0,
			["cooldownSwipe"] = true,
			["glowLength"] = 10,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["do_message"] = false,
					["do_custom"] = true,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "-- you can change order below\n\naura_env.order = {\n    [\"135764\"] = \"1\", --explosive\n    [\"135759\"] = \"4\", --earthwall\n    [\"135761\"] = \"2\", --thundering\n    [\"135765\"] = \"3\", --torrent\n}\naura_env.totemGUID = {\n    [\"135764\"] = true, --explosive\n    [\"135759\"] = true, --earthwall\n    [\"135761\"] = true, --thundering\n    [\"135765\"] = true, --torrent\n}\n\n\n\n\n\n",
					["do_custom"] = true,
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["unevent"] = "auto",
						["buffShowOn"] = "showOnActive",
						["custom_type"] = "stateupdate",
						["event"] = "Chat Message",
						["names"] = {
						},
						["spellIds"] = {
						},
						["events"] = "NAME_PLATE_UNIT_ADDED, NAME_PLATE_UNIT_REMOVED",
						["custom"] = "function(allstates, event, ...)\n    local unit = ...\n    local subEv = select(2, ...)\n    local destGUID = select(8, ...)\n    \n    if event == \"NAME_PLATE_UNIT_ADDED\" then\n        if UnitExists(unit) then\n            local guid = select(6, strsplit(\"-\", UnitGUID(unit)))\n            if aura_env.totemGUID[guid] then\n                allstates[UnitGUID(unit)] = {\n                    show = true,\n                    changed = true,\n                    progressType = \"static\",\n                    name = aura_env.order[guid],\n                    PassUnit = unit,\n                }\n            end\n        end\n    end\n    \n    if event == \"NAME_PLATE_UNIT_REMOVED\" then\n        if UnitExists(unit) then\n            local guid = UnitGUID(unit)\n            if allstates[guid] then\n                allstates[guid].show = false\n                allstates[guid].changed = true\n                allstates[guid].PassUnit = \"none\"\n            end\n        end\n    elseif (subEv == \"UNIT_DIED\" or subEv == \"UNIT_DESTROYED\") and aura_env.totemGUID[destGUID] then\n        if allstates[destGUID] then\n            allstates[destGUID].show = false\n            allstates[destGUID].changed = true\n            allstates[destGUID].PassUnit = \"none\"\n        end\n    end\n    \n    return true\nend",
						["subeventSuffix"] = "_CAST_START",
						["check"] = "event",
						["unit"] = "player",
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["conditions"] = {
			},
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["selfPoint"] = "CENTER",
			["cooldownEdge"] = false,
			["icon"] = true,
			["config"] = {
			},
			["desaturate"] = false,
			["discrete_rotation"] = 0,
			["keepAspectRatio"] = false,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "%name%c",
					["text_color"] = {
						1, -- [1]
						0, -- [2]
						0.023529411764706, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 39,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
			},
			["height"] = 48,
			["rotate"] = false,
			["glowLines"] = 8,
			["glowYOffset"] = 0,
			["glowFrequency"] = 0.25,
			["frameStrata"] = 1,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["stickyDuration"] = false,
			["mirror"] = false,
			["glowScale"] = 1,
			["regionType"] = "texture",
			["auto"] = false,
			["blendMode"] = "BLEND",
			["zoom"] = 1,
			["load"] = {
				["use_effectiveLevel"] = true,
				["use_size"] = true,
				["use_level"] = false,
				["effectiveLevel_operator"] = ">=",
				["level_operator"] = ">=",
				["use_encounterid"] = true,
				["use_encounter"] = true,
				["effectiveLevel"] = "110",
				["encounterid"] = "2140",
				["class"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["level"] = "",
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
			},
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["rotation"] = 0,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 부족 의회 토템",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["width"] = 48,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["uid"] = "3b8aX9jQUPc",
			["inverse"] = false,
			["xOffset"] = 0,
			["displayIcon"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_White",
			["cooldown"] = false,
			["glowBorder"] = false,
		},
		["쐐기 : 도피"] = {
			["sparkWidth"] = 10,
			["text2Point"] = "CENTER",
			["text1FontSize"] = 23,
			["authorOptions"] = {
			},
			["displayText"] = "FELBLAZE RUSH ON YOU",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["icon"] = true,
			["fontFlags"] = "OUTLINE",
			["icon_color"] = {
				1, -- [1]
				0.93725490196078, -- [2]
				0.94901960784314, -- [3]
				1, -- [4]
			},
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["barColor"] = {
				0.59607843137255, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["text1Point"] = "CENTER",
			["sparkOffsetY"] = 0,
			["text2FontFlags"] = "OUTLINE",
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = "==",
				["level_operator"] = "==",
				["role"] = {
					["multi"] = {
					},
				},
				["use_difficulty"] = true,
				["use_encounter"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["zoneId"] = "934, 935",
				["talent"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_zoneId"] = false,
				["use_level"] = false,
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
					},
				},
				["effectiveLevel"] = "120",
				["faction"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["level"] = "",
				["race"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["single"] = 117,
					["multi"] = {
						[117] = true,
					},
				},
			},
			["glowType"] = "buttonOverlay",
			["smoothProgress"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["text2FontSize"] = 24,
			["texture"] = "Raven White",
			["cooldownTextDisabled"] = false,
			["auto"] = false,
			["tocversion"] = 80205,
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayIcon"] = 237565,
			["outline"] = "OUTLINE",
			["sparkOffsetX"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    if updateTime == nil then\n        updateTime = GetTime()\n    end\n    timeDelay = GetTime()\n    if timeDelay >= updateTime+1 then\n        _, _, count = WA_GetUnitDebuff(\"player\", 302420)\n        if count == nil then\n            count = 0    \n        end \n        updateTime = GetTime()\n        lastvalue = count\n        if count > 0 then\n            return count..\" 중첩\"\n        else return end\n    else\n        if lastvalue and lastvalue > 0 then\n            return lastvalue..\" 중첩\"\n        else return end\n    end\nend",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["parent"] = "쐐기 : 기타 0929",
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "stateupdate",
						["subeventSuffix"] = "_CAST_START",
						["names"] = {
						},
						["duration"] = "1",
						["genericShowOn"] = "showOnActive",
						["subeventPrefix"] = "SPELL",
						["event"] = "Chat Message",
						["custom"] = "function(allstates, event, ...)\n    local subevent = select(2, ...)\n    \n    if event == \"UNIT_SPELLCAST_START\" then\n        local caster, lineId, castSpellId = ...\n        if castSpellId == 302420 then\n            local sourceGUID = UnitGUID(caster)\n            local _, _, _, startMS, endMS = UnitCastingInfo(caster)\n            local duration = (endMS - startMS) / 1000\n            local expiration = endMS / 1000\n            allstates[sourceGUID] = {\n                show = true,\n                changed = true,\n                progressType = \"timed\",\n                duration = duration,\n                expirationTime = expiration,\n                autoHide = true,\n                name = \"숨기!\"\n            }\n            return true\n        end\n    elseif subevent == \"SPELL_CAST_START\" then\n        local _,_,_,sourceGUID,_,_,_,_,_,_,_,spellId = ...\n        if spellId == 302420 and not allstates[sourceGUID] then\n            allstates[sourceGUID] = {\n                show = true,\n                changed = true,\n                progressType = \"timed\",\n                duration = 9,\n                expirationTime = 9+GetTime(),\n                autoHide = true,\n                name = \"숨기!\"\n            }\n            return true\n        end \n    end\n    \n    \n    if event == \"UNIT_SPELLCAST_SUCCEEDED\" or event == \"UNIT_SPELLCAST_INTERRUPTED\" or event == \"UNIT_SPELLCAST_FAILED\" or event == \"UNIT_SPELLCAST_STOP\" or event == \"UNIT_SPELLCAST_FAILED_QUIET\" then\n        local caster,lineId,castSpellId = ...\n        if caster and casterSpellId == 302420 then\n            local sourceGUID = UnitGUID(caster)\n            if allstates[sourceGUID] then\n                allstates[sourceGUID].show = false\n                allstates[sourceGUID].changed = true\n                return true\n            end   \n        end \n    end   \nend",
						["spellIds"] = {
						},
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED,UNIT_SPELLCAST_START,UNIT_SPELLCAST_SUCCEEDED,UNIT_SPELLCAST_INTERRUPTED, UNIT_SPELLCAST_FAILED, UNIT_SPELLCAST_FAILED_QUIET, UNIT_SPELLCAST_STOP",
						["check"] = "event",
						["unevent"] = "auto",
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["debuffType"] = "HARMFUL",
						["type"] = "aura2",
						["useName"] = true,
						["auranames"] = {
							"여왕의 칙령: 도피", -- [1]
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [2]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
				["activeTriggerMode"] = 1,
			},
			["text1Containment"] = "INSIDE",
			["internalVersion"] = 24,
			["desc"] = "Shows the cooldown until the next quaking will happen - sometimes longer will pass by, but never shorter",
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["backdropInFront"] = false,
			["text2Enabled"] = false,
			["uid"] = "h)4ORuhiqz8",
			["stickyDuration"] = false,
			["spark"] = true,
			["borderBackdrop"] = "Blizzard Tooltip",
			["version"] = 88,
			["subRegions"] = {
				{
					["border_color"] = {
					},
					["type"] = "aurabar_bar",
				}, -- [1]
				{
					["text_shadowXOffset"] = 1,
					["type"] = "subtext",
					["text_text"] = "%p ",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_selfPoint"] = "AUTO",
					["text_fontSize"] = 55,
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_RIGHT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["anchorXOffset"] = 0,
					["text_fontType"] = "None",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["text_text"] = " %c",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "LEFT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 0,
					["text_color"] = {
						1, -- [1]
						0.97647058823529, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_font"] = "Friz Quadrata TT",
					["text_shadowYOffset"] = -1,
					["text_fontType"] = "None",
					["text_anchorPoint"] = "LEFT",
					["text_fontSize"] = 47,
					["anchorXOffset"] = 0,
					["text_visible"] = true,
				}, -- [3]
			},
			["height"] = 55,
			["text2"] = "%p",
			["width"] = 649.00036621094,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["zoom"] = 0.24,
			["text2Containment"] = "INSIDE",
			["actions"] = {
				["start"] = {
					["do_message"] = false,
					["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\TempleBellHuge.ogg",
					["do_custom"] = true,
					["do_sound"] = true,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "",
					["do_custom"] = true,
				},
			},
			["text1Font"] = "Expressway",
			["id"] = "쐐기 : 도피",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["justify"] = "LEFT",
			["borderInFront"] = false,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["icon_side"] = "LEFT",
			["glow"] = false,
			["sparkHeight"] = 100,
			["text1"] = "%p",
			["xOffset"] = 0,
			["text1Color"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["config"] = {
			},
			["semver"] = "1.0.87",
			["sparkRotationMode"] = "AUTO",
			["sparkHidden"] = "BOTH",
			["text2Font"] = "Friz Quadrata TT",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["text1FontFlags"] = "THICKOUTLINE",
			["useglowColor"] = false,
			["inverse"] = true,
			["sparkDesature"] = false,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 2,
						["op"] = ">=",
						["value"] = "3",
						["variable"] = "stacks",
					},
					["changes"] = {
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "sub.3.text_color",
						}, -- [1]
					},
				}, -- [1]
			},
			["cooldown"] = true,
			["sparkTexture"] = "Legionfall_BarSpark",
		},
		["쐐기 : 상태 이상"] = {
			["glow"] = false,
			["authorOptions"] = {
			},
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["icon"] = true,
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["glowScale"] = 1,
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["parent"] = "쐐기 : 기타 0929",
			["version"] = 88,
			["subRegions"] = {
			},
			["height"] = 1,
			["load"] = {
				["use_effectiveLevel"] = true,
				["use_size"] = true,
				["use_level"] = false,
				["effectiveLevel_operator"] = ">=",
				["class"] = {
					["multi"] = {
					},
				},
				["effectiveLevel"] = "110",
				["use_encounter"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["level"] = "",
				["level_operator"] = ">=",
				["size"] = {
					["single"] = "party",
					["multi"] = {
					},
				},
			},
			["glowLines"] = 8,
			["glowLength"] = 10,
			["glowFrequency"] = 0.25,
			["glowXOffset"] = 0,
			["conditions"] = {
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 4,
			["actions"] = {
				["start"] = {
					["message"] = "%n",
					["do_sound"] = false,
					["message_type"] = "YELL",
					["do_message"] = false,
					["do_custom"] = true,
				},
				["finish"] = {
					["custom"] = "aura_env.message = nil",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.Status = {}\naura_env.LocalS = {\n    [\"세스랄리스 사원\"] = {\n        [268993] = {\"기절\"}, -- 비열한 습격, 가려진 송곳니\n        [269970] = {\"실명\"}, -- 실명의 모래, 메레크타\n        [263958] = {\"기절\"} -- 뱀들의 똬리, 메레크타\n    },\n    [\"썩은굴\"] = {\n        [265377] = {\"속박\"} -- 갈고리 올가미, 광신적인 인간사냥꾼\n    },\n    [\"아탈다자르\"] = {\n        [255421] = {\"먹힘\"}, -- 집어삼키기, 레잔\n        [252692] = {\"기절\"}, -- 급습 찌르기, 그림자칼날 추적자\n        [255567] = {\"기절\"} -- 광포한 돌진, 트론자 \n    },\n    [\"왕들의 안식처\"] = {\n        [270003] = {\"기절\"}, -- 억제의 강타, 살아 움직이는 수호자\n        [268796] = {\"기절\"} -- 꿰뚫는 창, 왕 다자르\n    },\n    [\"왕노다지 광산!!\"] = {\n        [257371] = {\"실명\"}, -- 최루 가스, 기계화 평화감시단\n        [275907] = {\"기절\"} -- 지층 강타, 아제로크\n    },\n    [\"보랄러스 공성전\"] = {\n        [257069] = {\"기절\"}, -- 방수 껍질, 쿨 티란 파도지기/무쇠파도 물결구체자\n        [257292] = {\"기절\"}, -- 묵직한 베기, 쿨 티란 선봉대원\n        [279763] = {\"기절\"}, \n        [272874] = {\"기절\"}, -- 짓밟기, 애쉬베인 지휘관 \n        [256866] = {\"기절\"}, -- 강철 매복, 성난파도 파쇄꾼\n        [256897] = {\"속박\"}, -- 물어뜯는 주둥이, 으르렁거리는 부두사냥개\n        [257169] = {\"공포\"}, -- 공포의 포효, 항만의 시궁쥐단 파괴자\n        [274942] = {\"기절\"}, -- 바나나 광란, 항만의 시궁쥐단 해적단원\n        [270624] = {\"속박\"} -- 분쇄의 포옹, 조이는 공포\n    },\n    [\"톨 다고르\"] = {\n        [258058] = {\"속박\"}, -- 압착, 진흙 게\n        [258054] = {\"기절\"}, -- 바닷물 소용돌이, 바닷물 무쇠턱거북\n        [257119] = {\"기절\"}, -- 모래 함정, 모래 여왕\n        [258313] = {\"침묵\"}, -- 수갑, 애쉬베인 장교, 간수\n        [260067] = {\"기절\"}, -- 흉포한 포식자, 바비 하울리스\n        [256474] = {\"기절\"}, -- 심정지 맹독, 감독관 코르거스\n        [259711] = {\"속박\"} -- 구속, 독방 간수/애쉬베인 감독관\n    },\n    [\"자유지대\"] = {\n        [274400] = {\"기절\"}, -- 결투사 질주, 바다가름 결투사\n        [276061] = {\"기절\"}, -- 바위 투척, 무쇠파도 분쇄자\n        [274516] = {\"기절\"}, -- 미끄러운 거품, 항만의 시궁쥐단 선원\n        [274389] = {\"속박\"}, -- 쥐덫, 야생 덫사냥꾼\n        [258875] = {\"방향 감각 상실\"}, -- 의식상실의 통, 라울\n        [257949] = {\"돼지!\"} -- 미끄러움, 기름칠한 돼지\n    },\n    [\"폭풍의 사원\"] = {\n        [276268] = {\"기절\"}, -- 융기의 강타, 사원 기사단원\n        [268059] = {\"속박\"}, -- 속박의 닻, 파도현자 심령술사   \n        [264526] = {\"속박\"}, -- 심연의 손아귀, 갈고리 촉수\n        [267956] = {\"기절\"} -- 감전, 해파리\n    },\n    [\"웨이크레스트 저택\"] = {\n        [264407] = {\"공포\"}, -- 끔찍한 얼굴, 얼굴 없는 여인\n        [265346] = {\"실명\"}, -- 창백한 응시, 공포날개 까마귀\n        [265407] = {\"침묵\"}, -- 만찬 종, 연회 집사\n        [260926] = {\"현혹\"}, -- 영혼 조작, 자매 솔레나\n        [267907] = {\"기절\"}, -- 영혼 가시, 영혼결속 거한\n        [268202] = {\"기절\"} -- 죽음의 렌즈, 죽음에 물든 노예사냥꾼\n    }\n}\n\naura_env.message = nil",
					["do_custom"] = true,
				},
			},
			["cooldownEdge"] = false,
			["uid"] = "7Nzr50egfUe",
			["regionType"] = "icon",
			["xOffset"] = 0,
			["glowYOffset"] = 0,
			["frameStrata"] = 1,
			["desaturate"] = false,
			["auto"] = false,
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["semver"] = "1.0.87",
			["tocversion"] = 80205,
			["id"] = "쐐기 : 상태 이상",
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 0,
			["width"] = 1,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
			},
			["config"] = {
			},
			["inverse"] = false,
			["triggers"] = {
				{
					["trigger"] = {
						["duration"] = "0.15",
						["unit"] = "player",
						["customIcon"] = "",
						["debuffType"] = "HELPFUL",
						["type"] = "custom",
						["unevent"] = "auto",
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Chat Message",
						["dynamicDuration"] = false,
						["custom_type"] = "event",
						["customName"] = "function()\n    return aura_env.message\nend\n\n\n\n\n\n\n\n\n",
						["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
						["custom_hide"] = "timed",
						["custom"] = "function(event, ...)\n    local _,subevent,_,_,_,_,_,_,destName,_,_,spellID = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" and aura_env.Status[spellID] and destName == WeakAuras.me then   \n        aura_env.message = aura_env.Status[spellID][1]\n        return true\n    end\nend",
						["spellIds"] = {
						},
						["names"] = {
						},
						["buffShowOn"] = "showOnActive",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["custom_type"] = "event",
						["duration"] = "0.15",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["customName"] = "function()\n    return aura_env.message\nend\n\n\n\n\n\n\n\n\n",
						["events"] = "LOSS_OF_CONTROL_ADDED, LOSS_OF_CONTROL_UPDATE",
						["custom"] = "function(event, ...)\n    if event == \"LOSS_OF_CONTROL_ADDED\" then\n        local eventIndex = ...;\n        local locType, spellID, text, iconTexture, startTime, timeRemaining, duration, lockoutSchool, priority, displayType = C_LossOfControl.GetEventInfo(eventIndex);\n        if text == \"차단\" then\n            aura_env.message = \"차단당함\"\n            return true\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [2]
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["duration"] = "0.15",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["custom"] = "function()\n    \n    local loc = select(1, GetInstanceInfo())\n    \n    if loc then\n        if aura_env.LocalS[loc] then\n            aura_env.Status = aura_env.LocalS[loc]\n        else\n            aura_env.Status = {}   \n        end\n    end\n    \nend\n\n\n\n\n",
						["events"] = "ZONE_CHANGED_NEW_AREA, PLAYER_ENTERING_WORLD, CHALLENGE_MODE_START",
						["custom_type"] = "event",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [3]
				["disjunctive"] = "custom",
				["customTriggerLogic"] = "function(t)\n    return(t[1] or t[2])\nend",
				["activeTriggerMode"] = -10,
			},
			["displayIcon"] = 135860,
			["selfPoint"] = "CENTER",
			["glowBorder"] = false,
		},
		["고통"] = {
			["glow"] = false,
			["parent"] = "여왕의 칙령 (딩까) 2",
			["yOffset"] = 327.1112670898438,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["useName"] = true,
						["auranames"] = {
							"고통받으라!", -- [1]
						},
						["event"] = "Health",
						["unit"] = "player",
						["spellIds"] = {
						},
						["names"] = {
						},
						["subeventSuffix"] = "_CAST_START",
						["subeventPrefix"] = "SPELL",
						["type"] = "aura2",
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "보주 밟고",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "굵은 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 31,
				}, -- [1]
			},
			["height"] = 64,
			["load"] = {
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "twentyfive",
					["multi"] = {
						["twentyfive"] = true,
					},
				},
			},
			["glowFrequency"] = 0.25,
			["anchorFrameType"] = "SCREEN",
			["authorOptions"] = {
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 1,
			["glowLines"] = 8,
			["glowXOffset"] = 0,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["glowLength"] = 10,
			["desaturate"] = false,
			["selfPoint"] = "CENTER",
			["uid"] = "TPfiPZMPpwT",
			["alpha"] = 1,
			["cooldownTextDisabled"] = false,
			["zoom"] = 0,
			["auto"] = true,
			["glowScale"] = 1,
			["id"] = "고통",
			["xOffset"] = -32,
			["frameStrata"] = 1,
			["width"] = 64,
			["useglowColor"] = false,
			["config"] = {
			},
			["inverse"] = false,
			["glowYOffset"] = 0,
			["conditions"] = {
			},
			["actions"] = {
				["start"] = {
					["message_type"] = "SAY",
					["message"] = "{다이아몬드}보주 밟아!{다이아몬드}",
					["do_custom"] = true,
					["do_message"] = true,
				},
				["init"] = {
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["glowBorder"] = false,
		},
		["쐐기 : 괴저"] = {
			["sparkWidth"] = 15,
			["text2Point"] = "CENTER",
			["text1FontSize"] = 24,
			["xOffset"] = 0,
			["displayText"] = "%s",
			["yOffset"] = -245,
			["anchorPoint"] = "CENTER",
			["sparkRotation"] = 0,
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["icon"] = true,
			["fontFlags"] = "OUTLINE",
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = false,
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["text1Containment"] = "INSIDE",
			["text1Point"] = "BOTTOMRIGHT",
			["sparkOffsetY"] = 0,
			["text2FontFlags"] = "OUTLINE",
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = "==",
				["level_operator"] = "==",
				["use_encounterid"] = false,
				["use_zone"] = false,
				["use_encounter"] = true,
				["race"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["use_difficulty"] = true,
				["use_level"] = false,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["single"] = 4,
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_role"] = true,
				["use_affixes"] = true,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["encounterid"] = "",
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "120",
				["class"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["level"] = "",
				["use_zoneId"] = false,
				["role"] = {
					["single"] = "TANK",
					["multi"] = {
						["TANK"] = true,
					},
				},
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["text2FontSize"] = 24,
			["texture"] = "Raven White",
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["auto"] = false,
			["tocversion"] = 80205,
			["text2Enabled"] = false,
			["uid"] = "8sMWtCP7Lr8",
			["displayIcon"] = 458736,
			["outline"] = "OUTLINE",
			["borderBackdrop"] = "Blizzard Tooltip",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    if aura_env and aura_env.state and aura_env.state.stacks then\n        local stack = aura_env.state.stacks\n        if stack < 20 then\n            return \"|cffFF7D00\"..(stack * -2) ..\"%\"\n        else\n            return \"|cffFF0000\"..(stack * -2) ..\"%\"   \n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
			["customTextUpdate"] = "event",
			["triggers"] = {
				{
					["trigger"] = {
						["useStacks"] = true,
						["useGroup_count"] = false,
						["matchesShowOn"] = "showOnActive",
						["unit"] = "player",
						["use_tooltip"] = false,
						["subeventPrefix"] = "SPELL",
						["debuffType"] = "HARMFUL",
						["custom_hide"] = "timed",
						["auraspellids"] = {
							"209858", -- [1]
						},
						["type"] = "aura2",
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_START",
						["auranames"] = {
						},
						["countOperator"] = ">",
						["event"] = "Health",
						["count"] = "19",
						["useCount"] = true,
						["stacks"] = "19",
						["spellIds"] = {
							209858, -- [1]
						},
						["stacksOperator"] = ">",
						["useExactSpellId"] = true,
						["combineMatches"] = "showLowest",
						["buffShowOn"] = "showOnActive",
						["names"] = {
							"괴저성 부패", -- [1]
						},
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "all",
				["activeTriggerMode"] = -10,
			},
			["parent"] = "쐐기 : 기타 0929",
			["internalVersion"] = 24,
			["actions"] = {
				["start"] = {
					["message"] = "괴저 20중",
					["glow_frame"] = "WeakAuras:공용 : 괴저",
					["glow_action"] = "show",
					["message_type"] = "SAY",
					["do_custom"] = true,
					["do_message"] = false,
					["do_glow"] = false,
				},
				["finish"] = {
					["message"] = "괴저 끝",
					["do_glow"] = false,
					["glow_frame"] = "WeakAuras:공용 : 괴저",
					["message_type"] = "SAY",
					["do_message"] = true,
					["do_custom"] = true,
					["glow_action"] = "hide",
				},
				["init"] = {
					["do_custom"] = true,
				},
			},
			["animation"] = {
				["start"] = {
					["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
					["scalex"] = 1.8,
					["alphaType"] = "straight",
					["colorB"] = 1,
					["colorG"] = 1,
					["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
					["use_alpha"] = true,
					["scaleType"] = "straightScale",
					["scaley"] = 1.8,
					["alpha"] = 0,
					["colorR"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorA"] = 1,
					["duration_type"] = "seconds",
					["type"] = "custom",
					["rotate"] = 0,
					["duration"] = "0.15",
					["use_scale"] = true,
				},
				["main"] = {
					["colorR"] = 0.36862745098039,
					["type"] = "custom",
					["duration_type"] = "relative",
					["scaley"] = 1,
					["colorType"] = "straightColor",
					["use_color"] = true,
					["alpha"] = 0,
					["colorA"] = 1,
					["y"] = 0,
					["x"] = 0,
					["colorG"] = 1,
					["colorB"] = 0,
					["colorFunc"] = "    function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n      return r1 + (progress * (r2 - r1)), g1 + (progress * (g2 - g1)), b1 + (progress * (b2 - b1)), a1 + (progress * (a2 - a1))\n    end\n  ",
					["rotate"] = 0,
					["scalex"] = 1,
					["duration"] = "1",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["backdropInFront"] = false,
			["sparkRotationMode"] = "AUTO",
			["alpha"] = 1,
			["stickyDuration"] = false,
			["spark"] = false,
			["text1Enabled"] = true,
			["version"] = 88,
			["subRegions"] = {
				{
					["border_color"] = {
					},
					["type"] = "aurabar_bar",
				}, -- [1]
				{
					["text_shadowXOffset"] = 1,
					["type"] = "subtext",
					["text_text"] = "%c",
					["text_color"] = {
						1, -- [1]
						0.95294117647059, -- [2]
						0.95294117647059, -- [3]
						1, -- [4]
					},
					["text_font"] = "[WoW] 기본 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "None",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_RIGHT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 30,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [2]
				{
					["text_shadowXOffset"] = 1,
					["type"] = "subtext",
					["text_text"] = " %p",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "[WoW] 기본 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = -1,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "None",
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_LEFT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 30,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [3]
			},
			["height"] = 42,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useAdjustededMax"] = false,
			["sparkBlendMode"] = "ADD",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["anchorFrameType"] = "SCREEN",
			["text2Containment"] = "INSIDE",
			["text1Font"] = "Friz Quadrata TT",
			["text1Color"] = {
				1, -- [1]
				0.9921568627451, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["zoom"] = 0.45,
			["id"] = "쐐기 : 괴저",
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["text2"] = "%p",
			["borderInFront"] = false,
			["justify"] = "CENTER",
			["icon_side"] = "RIGHT",
			["glow"] = false,
			["sparkHeight"] = 50,
			["text1"] = "%c",
			["sparkOffsetX"] = 0,
			["authorOptions"] = {
			},
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["semver"] = "1.0.87",
			["cooldownTextDisabled"] = false,
			["sparkHidden"] = "NEVER",
			["text2Font"] = "Friz Quadrata TT",
			["frameStrata"] = 1,
			["width"] = 255,
			["text1FontFlags"] = "OUTLINE",
			["config"] = {
			},
			["inverse"] = false,
			["sparkDesature"] = false,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["cooldown"] = true,
			["desaturate"] = false,
		},
		["행진하라! 2"] = {
			["glow"] = false,
			["parent"] = "여왕의 칙령 (딩까) 2",
			["yOffset"] = 327.1112670898438,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["icon"] = true,
			["useglowColor"] = false,
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["desaturate"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "움직이지마",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "굵은 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 31,
				}, -- [1]
			},
			["height"] = 64,
			["glowLines"] = 8,
			["glowFrequency"] = 0.25,
			["glowYOffset"] = 0,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["names"] = {
						},
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["auranames"] = {
							"멈춰라!", -- [1]
						},
						["unit"] = "player",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 1,
			["actions"] = {
				["start"] = {
					["message_type"] = "SAY",
					["message"] = "",
					["do_custom"] = true,
					["do_message"] = true,
				},
				["finish"] = {
				},
				["init"] = {
					["do_custom"] = true,
				},
			},
			["xOffset"] = 330,
			["stickyDuration"] = false,
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["glowLength"] = 10,
			["load"] = {
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "twentyfive",
					["multi"] = {
						["twentyfive"] = true,
					},
				},
			},
			["uid"] = "1nWUE2yfvnI",
			["frameStrata"] = 1,
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["auto"] = true,
			["glowScale"] = 1,
			["id"] = "행진하라! 2",
			["authorOptions"] = {
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["width"] = 64,
			["config"] = {
			},
			["inverse"] = false,
			["glowXOffset"] = 0,
			["conditions"] = {
			},
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["glowBorder"] = false,
		},
		["쐐기 : 파열"] = {
			["glow"] = true,
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["customText"] = "function()\n    \n    local r = 1\n    local g = 1\n    local b = 1\n    local a = 1\n    \n    if WeakAuras.IsOptionsOpen() then\n        g = 0.5\n        b = 0\n        aura_env.region.text2:SetText(\"9\")\n        aura_env.region.text2:SetTextColor(r,g,b,a)\n        aura_env.region.stacks:SetTextColor(r,g,b,a)\n        return \"-36%\"\n    end\n    \n    if aura_env and aura_env.state and aura_env.state.stacks then\n        local count = aura_env.state.stacks \n        if count > 9 then\n            g = 0    \n            b = 0\n        elseif count > 4 then\n            g = (10-count)/5    \n            b = 0\n        elseif count > 1 then\n            g = 1    \n            b = (5-count)/3\n        else\n            g = 1\n            b = 1\n        end\n        aura_env.region.stacks:SetTextColor(r,g,b,a)\n        aura_env.region.text2:SetTextColor(r,g,b,a)\n        return \"-\".. count*4 ..\"%\"\n    end\nend",
			["yOffset"] = -245,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "event",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["glow_action"] = "show",
					["message_type"] = "SAY",
					["do_message"] = false,
					["message"] = "",
					["glow_frame"] = "WeakAuras:Artillery",
					["do_glow"] = false,
					["do_custom"] = true,
					["sound"] = "Interface\\AddOns\\Prat-3.0\\Sounds\\Link.ogg",
					["do_sound"] = false,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "\n\n",
					["do_custom"] = true,
				},
			},
			["useglowColor"] = false,
			["width"] = 67,
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["animation"] = {
				["start"] = {
					["type"] = "preset",
					["preset"] = "grow",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["cooldownTextDisabled"] = false,
			["selfPoint"] = "CENTER",
			["keepAspectRatio"] = false,
			["desc"] = "by Kazrah EU Blackrock, Shows stacks and overall incoming damage for M+ bursting affix.",
			["glowColor"] = {
				0.96078431372549, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["glowLength"] = 10,
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "%c",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "PT Sans Narrow",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 32,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
				{
					["text_shadowXOffset"] = 0,
					["text_text"] = "%s",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_selfPoint"] = "BOTTOMRIGHT",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["type"] = "subtext",
					["text_anchorXOffset"] = 6,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "PT Sans Narrow",
					["text_shadowYOffset"] = 0,
					["text_visible"] = true,
					["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
					["text_anchorYOffset"] = -6,
					["text_fontSize"] = 26,
					["anchorXOffset"] = 0,
					["text_fontType"] = "OUTLINE",
				}, -- [2]
			},
			["height"] = 67,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = ">",
						["value"] = "4",
						["variable"] = "stacks",
					},
					["changes"] = {
						{
							["value"] = "Pixel",
							["property"] = "glowType",
						}, -- [1]
						{
							["value"] = 2,
							["property"] = "glowThickness",
						}, -- [2]
						{
							["value"] = 15,
							["property"] = "glowLength",
						}, -- [3]
						{
							["value"] = 8,
							["property"] = "glowLines",
						}, -- [4]
						{
							["value"] = {
								1, -- [1]
								0.4, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "glowColor",
						}, -- [5]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 1,
						["op"] = ">",
						["value"] = "9",
						["variable"] = "stacks",
					},
					["changes"] = {
						{
							["value"] = "buttonOverlay",
							["property"] = "glowType",
						}, -- [1]
						{
							["value"] = {
								1, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["property"] = "glowColor",
						}, -- [2]
					},
				}, -- [2]
			},
			["glowLines"] = 4,
			["icon"] = true,
			["glowFrequency"] = 0.25,
			["authorOptions"] = {
			},
			["config"] = {
			},
			["glowType"] = "ACShine",
			["glowThickness"] = 4,
			["parent"] = "쐐기 : 기타 0929",
			["glowYOffset"] = 0,
			["frameStrata"] = 1,
			["regionType"] = "icon",
			["cooldownEdge"] = false,
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["zone"] = "Hellfire Citadel",
				["encounterid"] = "11456",
				["use_encounterid"] = false,
				["role"] = {
					["single"] = "TANK",
					["multi"] = {
						["TANK"] = true,
					},
				},
				["use_encounter"] = true,
				["use_zone"] = false,
				["use_difficulty"] = true,
				["effectiveLevel_operator"] = "==",
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["use_level"] = false,
				["talent"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["use_affixes"] = true,
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "120",
				["race"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["single"] = 11,
				},
				["level"] = "",
				["level_operator"] = "==",
			},
			["tocversion"] = 80205,
			["useGlowColor"] = true,
			["auto"] = false,
			["desaturate"] = false,
			["zoom"] = 0.3,
			["semver"] = "1.0.87",
			["glowScale"] = 1.25,
			["id"] = "쐐기 : 파열",
			["triggers"] = {
				{
					["trigger"] = {
						["spellId"] = "209858",
						["useGroup_count"] = false,
						["duration"] = "2",
						["use_unit"] = true,
						["subeventPrefix"] = "SPELL",
						["specificUnit"] = "Reloe",
						["use_specific_unit"] = false,
						["matchesShowOn"] = "showOnActive",
						["tooltip_operator"] = "find('%s')",
						["debuffType"] = "HARMFUL",
						["auraspellids"] = {
						},
						["type"] = "aura2",
						["use_debuffClass"] = false,
						["subeventSuffix"] = "_CAST_START",
						["name"] = "괴저성 부패",
						["auranames"] = {
							"파열", -- [1]
						},
						["event"] = "Combat Log",
						["unevent"] = "timed",
						["buffShowOn"] = "showOnActive",
						["use_spellId"] = true,
						["spellIds"] = {
							243237, -- [1]
						},
						["useName"] = true,
						["custom_hide"] = "timed",
						["combineMatches"] = "showLowest",
						["names"] = {
							"파열", -- [1]
						},
						["unit"] = "player",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = 1,
			},
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["xOffset"] = 0,
			["uid"] = "erL6zfkiJgc",
			["inverse"] = false,
			["stickyDuration"] = false,
			["displayIcon"] = 1035055,
			["cooldown"] = true,
			["glowBorder"] = false,
		},
		["여왕의 칙령 (딩까) 2"] = {
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["controlledChildren"] = {
				"함꼐", -- [1]
				"홀로", -- [2]
				"행진하라!", -- [3]
				"행진하라! 2", -- [4]
				"고통", -- [5]
				"복종", -- [6]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["scale"] = 1,
			["border"] = false,
			["yOffset"] = 149.339599609375,
			["anchorPoint"] = "CENTER",
			["borderSize"] = 16,
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["selfPoint"] = "BOTTOMLEFT",
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura",
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["buffShowOn"] = "showOnActive",
						["unit"] = "player",
						["names"] = {
						},
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = 1,
			},
			["regionType"] = "group",
			["borderOffset"] = 5,
			["xOffset"] = -141.4119873046875,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["id"] = "여왕의 칙령 (딩까) 2",
			["internalVersion"] = 24,
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["uid"] = "mG)Uy4oA34N",
			["borderInset"] = 11,
			["authorOptions"] = {
			},
			["config"] = {
			},
			["conditions"] = {
			},
			["load"] = {
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["role"] = {
					["multi"] = {
					},
				},
				["difficulty"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["talent3"] = {
					["multi"] = {
					},
				},
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_class"] = false,
				["size"] = {
					["multi"] = {
					},
				},
			},
			["borderEdge"] = "None",
		},
		["쐐기 : 폭탄"] = {
			["outline"] = "OUTLINE",
			["glow"] = true,
			["authorOptions"] = {
			},
			["displayText"] = "%c",
			["customText"] = "function()\n    return #aura_env.orbs\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
			["yOffset"] = -231.0001831054688,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["icon"] = true,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["subeventSuffix"] = "_CAST_START",
						["debuffType"] = "HELPFUL",
						["names"] = {
						},
						["genericShowOn"] = "showOnActive",
						["unit"] = "player",
						["custom_type"] = "status",
						["custom"] = "function(event,unit)\n    if not unit then return end\n    local guid = UnitGUID(unit)\n    if event == \"NAME_PLATE_UNIT_ADDED\" then\n        -- new nameplate\n        local npcId = aura_env.GetNPCId(guid)\n        if (npcId and aura_env.npcID[npcId]) then\n            table.insert(aura_env.orbs,{guid = guid,unit = unit})\n        end\n    elseif event == \"NAME_PLATE_UNIT_REMOVED\" then\n        aura_env.RemoveOrb(guid)\n    end\n    aura_env.ShowIcon()\n    return true\nend\n\n\n\n",
						["spellIds"] = {
						},
						["events"] = "NAME_PLATE_UNIT_ADDED NAME_PLATE_UNIT_REMOVED",
						["check"] = "event",
						["subeventPrefix"] = "SPELL",
						["event"] = "Health",
						["custom_hide"] = "custom",
					},
					["untrigger"] = {
						["custom"] = "",
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["auto"] = true,
			["internalVersion"] = 24,
			["keepAspectRatio"] = false,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["zoom"] = 0,
			["glowLength"] = 15,
			["color"] = {
				1, -- [1]
				0.98823529411765, -- [2]
				0.95686274509804, -- [3]
				1, -- [4]
			},
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["version"] = 88,
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "%c",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "Expressway",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "CENTER",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["text_fontSize"] = 38,
					["anchorXOffset"] = 0,
					["rotateText"] = "NONE",
				}, -- [1]
			},
			["height"] = 67,
			["conditions"] = {
			},
			["glowLines"] = 8,
			["useglowColor"] = false,
			["glowFrequency"] = 0.25,
			["cooldownEdge"] = false,
			["config"] = {
			},
			["glowType"] = "Pixel",
			["glowThickness"] = 2,
			["actions"] = {
				["start"] = {
					["do_custom"] = true,
					["custom"] = "\n\n\n\n\n\n\n\n\n\n\n",
					["do_message"] = false,
					["do_sound"] = false,
				},
				["finish"] = {
					["custom"] = "\n\n",
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.orbs = {}\naura_env.npcID = {  \n    [120651] = true, -- 폭발물\n    --[144081] = true, -- 테스트\n}\n\naura_env.GetNPCId = function(guid)\n    local type, zero, server_id, instance_id, zone_uid, npc_id, spawn_uid = strsplit(\"-\",guid)\n    return tonumber(npc_id)\nend\n\naura_env.RemoveOrb = function(guid)\n    for indx,orbInfo in ipairs(aura_env.orbs) do\n        if orbInfo.guid == guid then\n            table.remove(aura_env.orbs,indx)\n            break\n        end\n    end\nend\n\nlocal r,g,b,a = aura_env.region:GetColor()\naura_env.ShowIcon = function()\n    if #aura_env.orbs > 0 then\n        aura_env.region:SetAlpha(1)\n        aura_env.region:Color(r,g,b,a)\n    else\n        aura_env.region:SetAlpha(0)\n        aura_env.region:Color(r,g,b,0)\n    end\nend\n\n\n\n\n\n\n\n\n\n",
					["do_custom"] = true,
				},
			},
			["width"] = 67,
			["frameStrata"] = 1,
			["regionType"] = "icon",
			["anchorFrameType"] = "SCREEN",
			["load"] = {
				["ingroup"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["effectiveLevel_operator"] = "==",
				["level_operator"] = "==",
				["use_encounterid"] = false,
				["role"] = {
					["multi"] = {
					},
				},
				["use_difficulty"] = true,
				["size"] = {
					["single"] = "party",
					["multi"] = {
						["party"] = true,
					},
				},
				["use_effectiveLevel"] = true,
				["talent2"] = {
					["multi"] = {
					},
				},
				["affixes"] = {
					["single"] = 13,
					["multi"] = {
						[13] = true,
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
				["use_encounter"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_size"] = true,
				["use_level"] = false,
				["difficulty"] = {
					["single"] = "challenge",
					["multi"] = {
						["challenge"] = true,
					},
				},
				["effectiveLevel"] = "120",
				["pvptalent"] = {
					["multi"] = {
					},
				},
				["faction"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["race"] = {
					["multi"] = {
					},
				},
				["use_affixes"] = true,
				["level"] = "",
			},
			["tocversion"] = 80205,
			["semver"] = "1.0.87",
			["glowXOffset"] = 0,
			["useGlowColor"] = false,
			["cooldownTextDisabled"] = false,
			["justify"] = "LEFT",
			["glowScale"] = 1,
			["id"] = "쐐기 : 폭탄",
			["desc"] = "Made by Exality-Silvermoon EU",
			["alpha"] = 1,
			["glowYOffset"] = 0,
			["desaturate"] = false,
			["uid"] = "XhAKavJbrOJ",
			["inverse"] = false,
			["parent"] = "쐐기 : 기타 0929",
			["displayIcon"] = "2175503",
			["xOffset"] = -6.501220703125,
			["glowBorder"] = false,
		},
		["쐐기 : !돌"] = {
			["outline"] = "OUTLINE",
			["authorOptions"] = {
				{
					["type"] = "toggle",
					["key"] = "keysParty",
					["width"] = 1,
					["name"] = "Party Chat",
					["useDesc"] = true,
					["default"] = true,
					["desc"] = "!keys command will work in /party",
				}, -- [1]
				{
					["type"] = "toggle",
					["key"] = "keysGuild",
					["width"] = 1,
					["name"] = "Guild Chat",
					["useDesc"] = true,
					["default"] = true,
					["desc"] = "!keys command will work in /guild",
				}, -- [2]
			},
			["displayText"] = "",
			["customText"] = "\n\n",
			["yOffset"] = 0,
			["anchorPoint"] = "CENTER",
			["customTextUpdate"] = "update",
			["url"] = "https://wago.io/fCabQ-hF8/88",
			["actions"] = {
				["start"] = {
					["do_message"] = false,
					["do_custom"] = true,
				},
				["finish"] = {
					["do_custom"] = true,
				},
				["init"] = {
					["custom"] = "aura_env.postkey = function(channel)\n    for bag = 0, NUM_BAG_SLOTS do\n        local numSlots = GetContainerNumSlots(bag)\n        for slot = 1, numSlots do\n            if (GetContainerItemID(bag, slot) == 158923) then \n                local link = GetContainerItemLink(bag, slot)\n                SendChatMessage(link, channel)\n            end\n        end\n    end\nend",
					["do_custom"] = true,
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["unevent"] = "timed",
						["debuffType"] = "HELPFUL",
						["duration"] = "0.1",
						["event"] = "Chat Message",
						["unit"] = "player",
						["names"] = {
						},
						["custom"] = "function(event, text)\n    if event == \"REQUEST_PARTY_KEYS\" then\n        aura_env.postkey(\"PARTY\")\n    elseif event == \"REQUEST_GUILD_KEYS\" then\n        aura_env.postkey(\"GUILD\")\n    end\n    \n    if event == \"CHALLENGE_MODE_COMPLETED\" then\n        local aura_env = aura_env\n        C_Timer.After(1, function() aura_env.postkey(\"PARTY\") end)\n    end\n    if text and (text:find(\"!돌\") or text:find(\"!ehf\")) then\n        if (event == \"CHAT_MSG_PARTY\" or event == \"CHAT_MSG_PARTY_LEADER\") and aura_env.config.keysParty then\n            WeakAuras.ScanEvents(\"REQUEST_PARTY_KEYS\")\n        elseif event == \"CHAT_MSG_GUILD\" and aura_env.config.keysGuild then\n            WeakAuras.ScanEvents(\"REQUEST_GUILD_KEYS\")\n        end\n    end\nend",
						["spellIds"] = {
						},
						["events"] = "CHALLENGE_MODE_COMPLETED, CHAT_MSG_GUILD, CHAT_MSG_PARTY, CHAT_MSG_PARTY_LEADER, REQUEST_GUILD_KEYS, REQUEST_PARTY_KEYS",
						["subeventPrefix"] = "SPELL",
						["custom_type"] = "event",
						["subeventSuffix"] = "_CAST_START",
						["custom_hide"] = "timed",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["disjunctive"] = "any",
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["desc"] = "Made by Luckyone",
			["font"] = "Friz Quadrata TT",
			["version"] = 88,
			["subRegions"] = {
			},
			["load"] = {
				["use_effectiveLevel"] = true,
				["use_level"] = false,
				["effectiveLevel_operator"] = "==",
				["class"] = {
					["multi"] = {
					},
				},
				["effectiveLevel"] = "120",
				["use_encounter"] = true,
				["spec"] = {
					["multi"] = {
					},
				},
				["use_never"] = false,
				["level"] = "",
				["level_operator"] = "==",
				["size"] = {
					["multi"] = {
					},
				},
			},
			["fontSize"] = 20,
			["regionType"] = "text",
			["semver"] = "1.0.87",
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
			},
			["parent"] = "쐐기 : 기타 0929",
			["justify"] = "LEFT",
			["tocversion"] = 80205,
			["id"] = "쐐기 : !돌",
			["conditions"] = {
			},
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["selfPoint"] = "BOTTOM",
			["uid"] = "Up6YxIcGOiz",
			["config"] = {
				["keysParty"] = true,
				["keysGuild"] = true,
			},
			["xOffset"] = 0,
			["fixedWidth"] = 200,
			["automaticWidth"] = "Auto",
			["wordWrap"] = "WordWrap",
		},
		["함꼐"] = {
			["glow"] = false,
			["parent"] = "여왕의 칙령 (딩까) 2",
			["yOffset"] = 327.1112670898438,
			["anchorPoint"] = "CENTER",
			["cooldownSwipe"] = true,
			["customTextUpdate"] = "update",
			["cooldownEdge"] = false,
			["actions"] = {
				["start"] = {
					["message_type"] = "SAY",
					["message"] = "",
					["do_custom"] = true,
					["do_message"] = true,
				},
				["init"] = {
					["do_custom"] = true,
				},
				["finish"] = {
				},
			},
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "aura2",
						["auranames"] = {
							"함께하라!", -- [1]
						},
						["event"] = "Health",
						["names"] = {
						},
						["spellIds"] = {
						},
						["subeventPrefix"] = "SPELL",
						["subeventSuffix"] = "_CAST_START",
						["unit"] = "player",
						["useName"] = true,
						["debuffType"] = "HARMFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["internalVersion"] = 24,
			["glowXOffset"] = 0,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["stickyDuration"] = false,
			["glowColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["subRegions"] = {
				{
					["text_shadowXOffset"] = 0,
					["type"] = "subtext",
					["text_text"] = "옆사람 붙어!",
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["text_font"] = "굵은 글꼴",
					["text_shadowColor"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["text_shadowYOffset"] = 0,
					["text_selfPoint"] = "AUTO",
					["text_fontType"] = "OUTLINE",
					["text_visible"] = true,
					["text_anchorPoint"] = "OUTER_BOTTOM",
					["anchorYOffset"] = 0,
					["text_justify"] = "CENTER",
					["rotateText"] = "NONE",
					["anchorXOffset"] = 0,
					["text_fontSize"] = 31,
				}, -- [1]
			},
			["height"] = 64,
			["load"] = {
				["use_combat"] = true,
				["class"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["single"] = "twentyfive",
					["multi"] = {
						["twentyfive"] = true,
					},
				},
			},
			["glowFrequency"] = 0.25,
			["anchorFrameType"] = "SCREEN",
			["selfPoint"] = "CENTER",
			["glowType"] = "buttonOverlay",
			["glowThickness"] = 1,
			["useglowColor"] = false,
			["authorOptions"] = {
			},
			["desaturate"] = false,
			["regionType"] = "icon",
			["keepAspectRatio"] = false,
			["xOffset"] = 160,
			["glowLength"] = 10,
			["config"] = {
			},
			["frameStrata"] = 1,
			["zoom"] = 0,
			["cooldownTextDisabled"] = false,
			["auto"] = true,
			["glowScale"] = 1,
			["id"] = "함꼐",
			["glowLines"] = 8,
			["alpha"] = 1,
			["width"] = 64,
			["glowYOffset"] = 0,
			["uid"] = "kseBBnM7GDi",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["icon"] = true,
			["glowBorder"] = false,
		},
	},
	["login_squelch_time"] = 10,
	["minimap"] = {
		["minimapPos"] = 184.5092633258392,
		["hide"] = false,
	},
	["lastUpgrade"] = 1569845560,
	["history"] = {
		["erL6zfkiJgc"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = true,
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["customText"] = "function()\n    \n    local r = 1\n    local g = 1\n    local b = 1\n    local a = 1\n    \n    if WeakAuras.IsOptionsOpen() then\n        g = 0.5\n        b = 0\n        aura_env.region.text2:SetText(\"9\")\n        aura_env.region.text2:SetTextColor(r,g,b,a)\n        aura_env.region.stacks:SetTextColor(r,g,b,a)\n        return \"-36%\"\n    end\n    \n    if aura_env and aura_env.state and aura_env.state.stacks then\n        local count = aura_env.state.stacks \n        if count > 9 then\n            g = 0    \n            b = 0\n        elseif count > 4 then\n            g = (10-count)/5    \n            b = 0\n        elseif count > 1 then\n            g = 1    \n            b = (5-count)/3\n        else\n            g = 1\n            b = 1\n        end\n        aura_env.region.stacks:SetTextColor(r,g,b,a)\n        aura_env.region.text2:SetTextColor(r,g,b,a)\n        return \"-\".. count*4 ..\"%\"\n    end\nend",
				["yOffset"] = -245,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "event",
				["cooldownEdge"] = false,
				["icon"] = true,
				["useglowColor"] = false,
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["selfPoint"] = "CENTER",
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "grow",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					0.96078431372549, -- [1]
					1, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["desaturate"] = false,
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "%c",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "PT Sans Narrow",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 32,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [1]
					{
						["text_shadowXOffset"] = 0,
						["text_text"] = "%s",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_selfPoint"] = "BOTTOMRIGHT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["rotateText"] = "NONE",
						["type"] = "subtext",
						["text_anchorXOffset"] = 6,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "PT Sans Narrow",
						["text_anchorYOffset"] = -6,
						["text_visible"] = true,
						["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
						["text_fontType"] = "OUTLINE",
						["text_fontSize"] = 26,
						["anchorXOffset"] = 0,
						["text_shadowYOffset"] = 0,
					}, -- [2]
				},
				["height"] = 67,
				["displayIcon"] = 1035055,
				["glowLines"] = 4,
				["triggers"] = {
					{
						["trigger"] = {
							["spellId"] = "209858",
							["useGroup_count"] = false,
							["duration"] = "2",
							["use_specific_unit"] = false,
							["unit"] = "player",
							["specificUnit"] = "Reloe",
							["use_unit"] = true,
							["matchesShowOn"] = "showOnActive",
							["debuffType"] = "HARMFUL",
							["custom_hide"] = "timed",
							["subeventSuffix"] = "_CAST_START",
							["useName"] = true,
							["use_debuffClass"] = false,
							["auraspellids"] = {
							},
							["spellIds"] = {
								243237, -- [1]
							},
							["auranames"] = {
								"파열", -- [1]
							},
							["event"] = "Combat Log",
							["buffShowOn"] = "showOnActive",
							["unevent"] = "timed",
							["use_spellId"] = true,
							["name"] = "괴저성 부패",
							["tooltip_operator"] = "find('%s')",
							["type"] = "aura2",
							["combineMatches"] = "showLowest",
							["subeventPrefix"] = "SPELL",
							["names"] = {
								"파열", -- [1]
							},
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = 1,
				},
				["glowFrequency"] = 0.25,
				["authorOptions"] = {
				},
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["encounterid"] = "11456",
					["use_encounterid"] = false,
					["use_zone"] = false,
					["level"] = "",
					["use_difficulty"] = true,
					["use_level"] = false,
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["affixes"] = {
						["single"] = 11,
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["use_affixes"] = true,
					["level_operator"] = "==",
					["faction"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "120",
					["race"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["zone"] = "Hellfire Citadel",
					["use_size"] = true,
					["role"] = {
						["single"] = "TANK",
						["multi"] = {
							["TANK"] = true,
						},
					},
				},
				["glowType"] = "ACShine",
				["glowThickness"] = 4,
				["uid"] = "erL6zfkiJgc",
				["xOffset"] = 0,
				["anchorFrameType"] = "SCREEN",
				["regionType"] = "icon",
				["alpha"] = 1,
				["parent"] = "쐐기 : 기타 0929",
				["desc"] = "by Kazrah EU Blackrock, Shows stacks and overall incoming damage for M+ bursting affix.",
				["glowScale"] = 1.25,
				["semver"] = "1.0.87",
				["zoom"] = 0.3,
				["auto"] = false,
				["keepAspectRatio"] = false,
				["cooldownTextDisabled"] = false,
				["useGlowColor"] = true,
				["tocversion"] = 80205,
				["id"] = "쐐기 : 파열",
				["glowLength"] = 10,
				["frameStrata"] = 1,
				["width"] = 67,
				["glowYOffset"] = 0,
				["config"] = {
				},
				["inverse"] = false,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
						["do_glow"] = false,
						["glow_frame"] = "WeakAuras:Artillery",
						["do_message"] = false,
						["glow_action"] = "show",
						["message_type"] = "SAY",
						["message"] = "",
						["sound"] = "Interface\\AddOns\\Prat-3.0\\Sounds\\Link.ogg",
						["do_sound"] = false,
					},
					["init"] = {
						["custom"] = "\n\n",
						["do_custom"] = false,
					},
					["finish"] = {
					},
				},
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = ">",
							["variable"] = "stacks",
							["value"] = "4",
						},
						["changes"] = {
							{
								["value"] = "Pixel",
								["property"] = "glowType",
							}, -- [1]
							{
								["value"] = 2,
								["property"] = "glowThickness",
							}, -- [2]
							{
								["value"] = 15,
								["property"] = "glowLength",
							}, -- [3]
							{
								["value"] = 8,
								["property"] = "glowLines",
							}, -- [4]
							{
								["value"] = {
									1, -- [1]
									0.4, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "glowColor",
							}, -- [5]
						},
					}, -- [1]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = ">",
							["variable"] = "stacks",
							["value"] = "9",
						},
						["changes"] = {
							{
								["value"] = "buttonOverlay",
								["property"] = "glowType",
							}, -- [1]
							{
								["value"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "glowColor",
							}, -- [2]
						},
					}, -- [2]
				},
				["cooldown"] = true,
				["glowBorder"] = false,
			},
		},
		["KFCz88adE0C"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1570539293,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["glowLength"] = 10,
				["yOffset"] = 327.1112670898438,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "aura2",
							["auranames"] = {
								"홀로서기!", -- [1]
							},
							["event"] = "Health",
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["useName"] = true,
							["unit"] = "player",
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "혼자 나가!",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "굵은 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["text_visible"] = true,
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_fontSize"] = 31,
						["anchorXOffset"] = 0,
						["text_fontType"] = "OUTLINE",
					}, -- [1]
				},
				["height"] = 64,
				["glowLines"] = 8,
				["glowFrequency"] = 0.25,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 1,
				["authorOptions"] = {
				},
				["glowXOffset"] = 0,
				["regionType"] = "icon",
				["parent"] = "여왕의 칙령 (딩까) 2",
				["icon"] = true,
				["xOffset"] = 160,
				["load"] = {
					["class"] = {
						["multi"] = {
						},
					},
					["use_combat"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "twentyfive",
						["multi"] = {
							["twentyfive"] = true,
						},
					},
				},
				["uid"] = "KFCz88adE0C",
				["anchorFrameType"] = "SCREEN",
				["width"] = 64,
				["frameStrata"] = 1,
				["cooldownTextDisabled"] = false,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "홀로",
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["alpha"] = 1,
				["glowYOffset"] = 0,
				["zoom"] = 0,
				["config"] = {
				},
				["inverse"] = false,
				["desaturate"] = false,
				["useglowColor"] = false,
				["conditions"] = {
				},
				["selfPoint"] = "CENTER",
				["glowBorder"] = false,
			},
		},
		["6FUkMecyYQ("] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["yOffset"] = -80,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["icon"] = true,
				["triggers"] = {
					{
						["trigger"] = {
							["use_absorbMode"] = true,
							["genericShowOn"] = "showOnActive",
							["unit"] = "player",
							["debuffType"] = "HELPFUL",
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
							["unevent"] = "auto",
							["event"] = "Health",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customDuration"] = "function()\n    for i = 1, 5 do\n        local unit = \"party\".. i\n        if UnitGroupRolesAssigned(unit) == \"TANK\" then \n            if WA_GetUnitDebuff(unit, \"최루 가스\") then\n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"최루 가스\"))\n                return dur, exp\n            elseif WA_GetUnitDebuff(unit, \"실명의 모래\") then\n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"실명의 모래\"))\n                return dur, exp  \n            elseif WA_GetUnitDebuff(unit, \"두꺼비 폭발\") then \n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"두꺼비 폭발\"))\n                return dur, exp\n            elseif WA_GetUnitDebuff(unit, \"창백한 응시\") then\n                local dur, exp = select(5,WA_GetUnitDebuff(unit, \"창백한 응시\"))\n                return dur, exp\n            end\n        end\n    end    \nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["spellIds"] = {
							},
							["custom"] = "function(states,event,...)\n    local _,subevent,_,_,_,_,_,destGUID,destName,_,_,spellID,spellName = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" then   \n        if aura_env.Blind[spellID] and UnitGroupRolesAssigned(destName) == \"TANK\" then \n            local id = destGUID..spellID\n            states[id] = states[id] or {}\n            local state = states[id]\n            local _,_,_,d,e = select(2, WA_GetUnitDebuff(destName,  spellName))      \n            state.name = \"|c\"..select(4, GetClassColor(select(2, UnitClass(destName))))..UnitName(destName)\n            state.progressType = \"timed\";\n            state.duration = d;\n            state.expirationTime = e;\n            state.autohide = true;\n            state.changed = true;\n            state.show = true;\n        end\n    elseif subevent == \"SPELL_AURA_REMOVED\" then\n        if aura_env.Blind[spellID] then \n            local id = destGUID..spellID\n            local v = states[id]\n            if v then\n                v.show = false\n                v.changed = true\n            end\n        end\n    end\n    return true\nend",
							["use_unit"] = true,
							["check"] = "event",
							["names"] = {
							},
							["custom_type"] = "stateupdate",
							["subeventPrefix"] = "SPELL",
						},
						["untrigger"] = {
							["custom"] = "function()\n    return true\nend",
						},
					}, -- [1]
					["disjunctive"] = "all",
					["customTriggerLogic"] = "\n\n",
					["activeTriggerMode"] = 1,
				},
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["animation"] = {
					["start"] = {
						["colorR"] = 1,
						["scalex"] = 1.8,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["scaleType"] = "pulse",
						["scaley"] = 1.8,
						["alpha"] = 0,
						["colorA"] = 1,
						["y"] = 0,
						["x"] = 0,
						["duration"] = "0.15",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
						["type"] = "custom",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["use_scale"] = true,
					},
					["main"] = {
						["scaley"] = 1.2,
						["type"] = "custom",
						["duration_type"] = "seconds",
						["duration"] = "1",
						["scalex"] = 1.2,
						["use_scale"] = true,
						["alpha"] = 0,
						["scaleType"] = "pulse",
						["y"] = 0,
						["x"] = 0,
						["colorG"] = 1,
						["colorB"] = 1,
						["colorA"] = 1,
						["rotate"] = 0,
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
						["colorR"] = 1,
					},
					["finish"] = {
						["type"] = "custom",
						["colorR"] = 1,
						["scalex"] = 1,
						["scaley"] = 1,
						["colorA"] = 1,
						["duration_type"] = "seconds",
						["alpha"] = 0,
						["x"] = 0,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["y"] = 0,
						["rotate"] = 0,
						["duration"] = "0.1",
						["use_alpha"] = true,
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "탱커 실명!",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "Friz Quadrata TT",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 34,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [1]
				},
				["height"] = 80,
				["authorOptions"] = {
				},
				["glowLines"] = 8,
				["glowLength"] = 10,
				["glowFrequency"] = 0.25,
				["displayIcon"] = 132284,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["class"] = {
						["multi"] = {
						},
					},
					["use_zoneId"] = false,
					["level"] = "",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["use_role"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["role"] = {
						["multi"] = {
							["HEALER"] = true,
							["DAMAGER"] = true,
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "110",
					["faction"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["zoneId"] = "",
					["use_combat"] = true,
					["level_operator"] = ">=",
					["use_size"] = true,
				},
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["parent"] = "쐐기 : 기타 0929",
				["useglowColor"] = false,
				["uid"] = "6FUkMecyYQ(",
				["regionType"] = "icon",
				["xOffset"] = 0,
				["glowYOffset"] = 0,
				["alpha"] = 1,
				["desaturate"] = false,
				["glowXOffset"] = 0,
				["glowScale"] = 1,
				["semver"] = "1.0.87",
				["cooldownTextDisabled"] = false,
				["zoom"] = 0,
				["auto"] = false,
				["tocversion"] = 80205,
				["id"] = "쐐기 : 탱커 실명",
				["selfPoint"] = "CENTER",
				["frameStrata"] = 1,
				["width"] = 80,
				["anchorFrameType"] = "SCREEN",
				["config"] = {
				},
				["inverse"] = false,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
						["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\aggro.ogg",
						["do_sound"] = true,
					},
					["init"] = {
						["custom"] = "aura_env.Blind = {\n    [257371] = true, -- 최루 가스\n    [269970] = true, -- 실명의 모래\n    [265352] = true, -- 두꺼비 역병\n    [265346] = true, -- 창백한 응시\n    [258917] = true, -- 정의의 불길\n}",
						["do_custom"] = true,
					},
					["finish"] = {
					},
				},
				["conditions"] = {
				},
				["cooldown"] = true,
				["glowBorder"] = false,
			},
		},
		["kseBBnM7GDi"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1570539293,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["yOffset"] = 327.1112670898438,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["icon"] = true,
				["useglowColor"] = false,
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["animation"] = {
					["start"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "옆사람 붙어!",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "굵은 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["text_visible"] = true,
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_fontSize"] = 31,
						["anchorXOffset"] = 0,
						["text_fontType"] = "OUTLINE",
					}, -- [1]
				},
				["height"] = 64,
				["load"] = {
					["class"] = {
						["multi"] = {
						},
					},
					["use_combat"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "twentyfive",
						["multi"] = {
							["twentyfive"] = true,
						},
					},
				},
				["glowFrequency"] = 0.25,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 1,
				["desaturate"] = false,
				["parent"] = "여왕의 칙령 (딩까) 2",
				["regionType"] = "icon",
				["keepAspectRatio"] = false,
				["actions"] = {
					["start"] = {
						["message_type"] = "SAY",
						["do_message"] = true,
						["message"] = "",
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["xOffset"] = 160,
				["glowLines"] = 8,
				["uid"] = "kseBBnM7GDi",
				["width"] = 64,
				["glowYOffset"] = 0,
				["alpha"] = 1,
				["zoom"] = 0,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "함꼐",
				["authorOptions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["cooldownTextDisabled"] = false,
				["config"] = {
				},
				["inverse"] = false,
				["glowLength"] = 10,
				["selfPoint"] = "CENTER",
				["conditions"] = {
				},
				["triggers"] = {
					{
						["trigger"] = {
							["useName"] = true,
							["auranames"] = {
								"함께하라!", -- [1]
							},
							["event"] = "Health",
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["type"] = "aura2",
							["unit"] = "player",
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = -10,
				},
				["glowBorder"] = false,
			},
		},
		["4pLU428taOF"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["sparkWidth"] = 25,
				["stacksSize"] = 12,
				["authorOptions"] = {
				},
				["displayText"] = "%c",
				["yOffset"] = -245,
				["anchorPoint"] = "CENTER",
				["sparkRotation"] = 0,
				["rotateText"] = "NONE",
				["icon"] = true,
				["fontFlags"] = "OUTLINE",
				["icon_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["selfPoint"] = "CENTER",
				["barColor"] = {
					1, -- [1]
					0.66666666666667, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["desaturate"] = false,
				["font"] = "Friz Quadrata TT",
				["sparkOffsetY"] = 0,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["level_operator"] = "==",
					["role"] = {
						["multi"] = {
						},
					},
					["use_difficulty"] = true,
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["affixes"] = {
						["single"] = 14,
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "120",
					["use_affixes"] = true,
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["faction"] = {
						["multi"] = {
						},
					},
					["level"] = "",
					["use_size"] = true,
				},
				["timerColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["regionType"] = "text",
				["stacks"] = false,
				["texture"] = "Minimalist",
				["textFont"] = "Friz Quadrata TT",
				["borderOffset"] = 5,
				["auto"] = true,
				["tocversion"] = 80205,
				["timerFont"] = "Friz Quadrata TT",
				["alpha"] = 1,
				["borderInset"] = 11,
				["fixedWidth"] = 200,
				["textColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["outline"] = "OUTLINE",
				["sparkOffsetX"] = 0,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["customText"] = "function()\n    if WeakAuras.IsOptionsOpen() then\n        return \"다음 전율 예상: 1.8\" \n    end\n    \n    if aura_env.Quake then\n        local Quake = 20- ((GetTime() - aura_env.Quake)%20)\n        return \"다음 전율 예상: \"..format( \"%.1f\", Quake) \n    end\nend",
				["barInFront"] = true,
				["textSize"] = 22,
				["sparkRotationMode"] = "AUTO",
				["automaticWidth"] = "Auto",
				["displayTextLeft"] = "  다음 전율 예상",
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_hide"] = "timed",
							["subeventSuffix"] = "_CAST_START",
							["custom_type"] = "event",
							["duration"] = "100",
							["event"] = "Chat Message",
							["subeventPrefix"] = "SPELL",
							["unevent"] = "timed",
							["spellIds"] = {
							},
							["custom"] = "function(event, ...)\n    \n    local _,subevent,_,sourceGUID,_,_,_,destGUID,destName,_,_,spellID,spellName = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" and spellName == \"전율\" and destName == WeakAuras.me then   \n        aura_env.Quake = GetTime()\n        return true\n    end\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["dynamicDuration"] = false,
							["names"] = {
							},
							["unit"] = "player",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "all",
					["activeTriggerMode"] = 1,
				},
				["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
				["internalVersion"] = 24,
				["zoom"] = 0.25,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "custom",
						["colorR"] = 1,
						["duration"] = "",
						["duration_type"] = "seconds",
						["x"] = 0,
						["scaley"] = 1,
						["alpha"] = 0,
						["colorType"] = "custom",
						["y"] = 0,
						["colorB"] = 0.03921568627451,
						["colorG"] = 0,
						["colorA"] = 1,
						["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    if WeakAuras.IsOptionsOpen() then\n        return 1,0,0,1  \n    end\n    \n    if aura_env.Quake then\n        local Quake = 20 - ((GetTime() - aura_env.Quake)%20)\n        \n        if Quake >= 0 and Quake < 3  then\n            return 1,0,0,1\n        elseif Quake >= 3 and Quake < 5 then\n            return  r1 + ((5-Quake)/2 * (r2 - r1)), g1 + ((5-Quake)/2 * (g2 - g1)), b1 + ((5-Quake)/2 * (b2 - b1)), 1\n        elseif Quake >= 5 and Quake < 10 then\n            return 1,1,1,1\n        elseif Quake >= 10 and Quake < 12 then\n            return 1,1,1,0+((12-Quake)/2 * a2)\n        else\n            return 1,1,1,0\n        end\n    else\n        return 0,0,0,0\n    end \nend",
						["rotate"] = 0,
						["use_color"] = true,
						["scalex"] = 1,
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["stacksFont"] = "Friz Quadrata TT",
				["text"] = true,
				["actions"] = {
					["start"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["init"] = {
						["custom"] = "aura_env.Quake = nil",
						["do_custom"] = true,
					},
					["finish"] = {
						["custom"] = "aura_env.Quake = nil",
						["do_custom"] = true,
					},
				},
				["stickyDuration"] = false,
				["sparkColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["stacksFlags"] = "None",
				["version"] = 88,
				["uid"] = "4pLU428taOF",
				["timer"] = true,
				["timerFlags"] = "None",
				["anchorFrameType"] = "SCREEN",
				["sparkBlendMode"] = "ADD",
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["fontSize"] = 33,
				["backgroundColor"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.5, -- [4]
				},
				["timerSize"] = 30,
				["id"] = "쐐기 : 전율 예상",
				["displayTextRight"] = "%p ",
				["border"] = false,
				["borderEdge"] = "None",
				["semver"] = "1.0.87",
				["borderSize"] = 16,
				["xOffset"] = 0,
				["icon_side"] = "RIGHT",
				["height"] = 32.999984741211,
				["config"] = {
				},
				["sparkHeight"] = 100,
				["wordWrap"] = "WordWrap",
				["customTextUpdate"] = "update",
				["stacksColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["justify"] = "CENTER",
				["borderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["sparkHidden"] = "NEVER",
				["borderBackdrop"] = "Blizzard Tooltip",
				["frameStrata"] = 1,
				["width"] = 28.000078201294,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["spark"] = true,
				["inverse"] = false,
				["sparkDesature"] = false,
				["orientation"] = "HORIZONTAL",
				["conditions"] = {
				},
				["textFlags"] = "None",
				["parent"] = "쐐기 : 기타 0929",
			},
		},
		["FwEi(vHnOQ3"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "OUTLINE",
				["fontSize"] = 12,
				["authorOptions"] = {
					{
						["useName"] = true,
						["text"] = "Distance Options",
						["type"] = "header",
						["width"] = 1,
					}, -- [1]
					{
						["type"] = "toggle",
						["default"] = true,
						["key"] = "krileDistanceEnabled",
						["name"] = "Enable Distance Settings",
						["width"] = 1,
					}, -- [2]
					{
						["type"] = "description",
						["text"] = "|cffff00ff[|cff00ffffPlater|cffff00ff, |cff00ffffElvUI|cffff00ff, |cff00ffffKui|cffff00ff, |cff00ffffThreatplates|cffff00ff]",
						["fontSize"] = "small",
						["width"] = 1,
					}, -- [3]
					{
						["type"] = "range",
						["useDesc"] = true,
						["max"] = 100,
						["step"] = 1,
						["width"] = 2,
						["min"] = 0,
						["name"] = "Reduced Distance",
						["desc"] = "Nameplate distance in congested areas.",
						["key"] = "krileReducedDistance",
						["default"] = 15,
					}, -- [4]
					{
						["type"] = "range",
						["useDesc"] = true,
						["max"] = 100,
						["step"] = 1,
						["width"] = 2,
						["min"] = 0,
						["name"] = "Normal Distance",
						["desc"] = "Nameplate distance outside of congested areas.",
						["key"] = "krileNormalDistance",
						["default"] = 60,
					}, -- [5]
					{
						["type"] = "toggle",
						["default"] = false,
						["key"] = "krileChatDistance",
						["name"] = "Display Chat Message |cffffff00(debug)|r",
						["width"] = 2,
					}, -- [6]
					{
						["useName"] = true,
						["text"] = "Alpha Options",
						["type"] = "header",
						["width"] = 1,
					}, -- [7]
					{
						["type"] = "toggle",
						["default"] = false,
						["key"] = "krileAlphaEnabled",
						["name"] = "Enable Alpha Settings",
						["width"] = 1,
					}, -- [8]
					{
						["type"] = "description",
						["text"] = "|cffff00ff[|cff00ffffPlater|cffff00ff, |cff00ffffElvUI|cffff00ff]",
						["fontSize"] = "small",
						["width"] = 1,
					}, -- [9]
					{
						["type"] = "range",
						["useDesc"] = true,
						["max"] = 1,
						["step"] = 0.05,
						["width"] = 2,
						["min"] = 0,
						["name"] = "Reduced Alpha",
						["desc"] = "Nameplate alpha of units not in line of sight in congested areas.",
						["key"] = "krileAlphaMin",
						["default"] = 0.2,
					}, -- [10]
					{
						["type"] = "range",
						["useDesc"] = true,
						["max"] = 1,
						["step"] = 0.05,
						["width"] = 2,
						["min"] = 0,
						["name"] = "Normal Alpha",
						["desc"] = "Nameplate alpha of units not in line of sight outside of congested areas.",
						["key"] = "krileAlphaMax",
						["default"] = 1,
					}, -- [11]
					{
						["type"] = "toggle",
						["default"] = false,
						["key"] = "krileChatAlpha",
						["name"] = "Display Chat Message |cffffff00(debug)|r",
						["width"] = 2,
					}, -- [12]
				},
				["anchorPoint"] = "CENTER",
				["xOffset"] = 0,
				["displayText"] = "%p",
				["conditions"] = {
				},
				["yOffset"] = 0,
				["regionType"] = "text",
				["tocversion"] = 80205,
				["uid"] = "FwEi(vHnOQ3",
				["wordWrap"] = "WordWrap",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
						["message_custom"] = "",
						["b"] = 0,
						["message_type"] = "PRINT",
						["g"] = 1,
						["message"] = "",
						["custom"] = "if aura_env.config[\"krileDistanceEnabled\"] then\n    SetCVar(\"nameplatemaxdistance\", aura_env.config[\"krileReducedDistance\"])\nend\n\nif aura_env.config[\"krileAlphaEnabled\"] then\n    SetCVar(\"nameplateoccludedalphamult\", aura_env.config[\"krileAlphaMin\"])\nend\n\nif aura_env.config[\"krileChatDistance\"] then\n    print (\"|cff00ffffNameplate Distance:|r\", aura_env.config[\"krileReducedDistance\"], \"yards\")\nend\n\nif aura_env.config[\"krileChatAlpha\"] then\n    print (\"|cffff00ffNameplate Alpha:|r\", aura_env.config[\"krileAlphaMin\"])\nend",
						["do_message"] = false,
						["do_custom"] = true,
						["r"] = 1,
					},
					["init"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["finish"] = {
						["message"] = "",
						["do_custom"] = true,
						["custom"] = "if aura_env.config[\"krileDistanceEnabled\"] then\n    SetCVar(\"nameplatemaxdistance\", aura_env.config[\"krileNormalDistance\"])\nend\n\nif aura_env.config[\"krileAlphaEnabled\"] then\n    SetCVar(\"nameplateoccludedalphamult\", aura_env.config[\"krileAlphaMax\"])\nend\n\nif aura_env.config[\"krileChatDistance\"] then\n    print (\"|cff00ffffNameplate Distance:|r\", aura_env.config[\"krileNormalDistance\"], \"yards\")\nend\n\nif aura_env.config[\"krileChatAlpha\"] then\n    print (\"|cffff00ffNameplate Alpha:|r\", aura_env.config[\"krileAlphaMax\"])\nend",
						["r"] = 1,
						["message_type"] = "PRINT",
						["do_message"] = false,
						["g"] = 1,
						["b"] = 0,
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["use_unitisunit"] = true,
							["use_alwaystrue"] = true,
							["duration"] = "1",
							["subeventPrefix"] = "SPELL",
							["debuffType"] = "HELPFUL",
							["type"] = "status",
							["custom_type"] = "event",
							["custom_hide"] = "timed",
							["use_absorbMode"] = true,
							["event"] = "Conditions",
							["subeventSuffix"] = "_CAST_START",
							["unevent"] = "auto",
							["spellIds"] = {
							},
							["events"] = "",
							["unitisunit"] = "player",
							["check"] = "update",
							["use_unit"] = true,
							["names"] = {
							},
							["unit"] = "player",
						},
						["untrigger"] = {
							["use_unit"] = true,
							["unit"] = "target",
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["font"] = "Friz Quadrata TT",
				["internalVersion"] = 24,
				["justify"] = "CENTER",
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["colorR"] = 1,
						["duration"] = "1",
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["type"] = "none",
						["scaley"] = 1,
						["alpha"] = 0,
						["x"] = 0,
						["y"] = 0,
						["colorType"] = "straightColor",
						["scalex"] = 1,
						["colorA"] = 1,
						["colorFunc"] = "    function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n      return r1 + (progress * (r2 - r1)), g1 + (progress * (g2 - g1)), b1 + (progress * (b2 - b1)), a1 + (progress * (a2 - a1))\n    end\n  ",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["use_color"] = false,
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["id"] = "쐐기 : 이름표 거리/투명도",
				["semver"] = "1.0.87",
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["selfPoint"] = "BOTTOM",
				["config"] = {
					["krileDistanceEnabled"] = true,
					["krileReducedDistance"] = 30,
					["krileChatAlpha"] = false,
					["krileAlphaEnabled"] = true,
					["krileAlphaMax"] = 1,
					["krileAlphaMin"] = 0.2,
					["krileNormalDistance"] = 55,
					["krileChatDistance"] = false,
				},
				["version"] = 88,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["parent"] = "쐐기 : 기타 0929",
				["fixedWidth"] = 200,
				["load"] = {
					["use_effectiveLevel"] = true,
					["use_size"] = true,
					["use_level"] = false,
					["effectiveLevel_operator"] = ">=",
					["class"] = {
						["multi"] = {
						},
					},
					["use_zoneId"] = true,
					["effectiveLevel"] = "110",
					["spec"] = {
						["multi"] = {
						},
					},
					["zoneId"] = "976, 977, 978, 980, 1015, 1016",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
				},
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
			},
		},
		["VR)Fi4QjQ31"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["sparkWidth"] = 10,
				["authorOptions"] = {
				},
				["displayText"] = "%p",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["sparkRotation"] = 0,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["fontFlags"] = "OUTLINE",
				["icon_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["selfPoint"] = "CENTER",
				["barColor"] = {
					0.70196078431373, -- [1]
					0.70196078431373, -- [2]
					0.69019607843137, -- [3]
					1, -- [4]
				},
				["desaturate"] = false,
				["progressPrecision"] = 1,
				["sparkOffsetY"] = 0,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["class"] = {
						["multi"] = {
						},
					},
					["role"] = {
						["multi"] = {
						},
					},
					["level"] = "110",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_size"] = true,
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["level_operator"] = "==",
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_combat"] = false,
					["race"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
				},
				["smoothProgress"] = false,
				["useAdjustededMin"] = false,
				["regionType"] = "aurabar",
				["texture"] = "Raven White",
				["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
				["spark"] = false,
				["tocversion"] = 80205,
				["alpha"] = 1,
				["sparkColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fixedWidth"] = 200,
				["outline"] = "OUTLINE",
				["sparkOffsetX"] = 0,
				["parent"] = "쐐기 : 기타 0929",
				["customText"] = "",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "stateupdate",
							["debuffType"] = "HELPFUL",
							["event"] = "Health",
							["unit"] = "player",
							["names"] = {
							},
							["subeventPrefix"] = "SPELL",
							["custom"] = "function(states,event,...)\n    local _,subevent,_,_,_,_,_,destGUID,destName,_,_,spellID,spellName = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" or subevent == \"SPELL_AURA_REFRESH\" then   \n        if spellID == 114018 and UnitClass(destName) == \"도적\" then \n            local id = destGUID..spellID\n            states[id] = states[id] or {}\n            local state = states[id]\n            local c,_,_,d,e = select(2, WA_GetUnitBuff(destName,  spellName))      \n            state.name = \"|c\"..select(4, GetClassColor(select(2, UnitClass(destName))))..UnitName(destName)\n            state.progressType = \"timed\";\n            state.icon = c;\n            state.duration = d;\n            state.expirationTime = e;\n            state.autohide = true\n            state.changed = true;\n            state.show = true;\n        end\n    elseif subevent == \"SPELL_AURA_REMOVED\" then\n        if spellID == 114018 then \n            local id = destGUID..spellID\n            local v = states[id]\n            if v then\n                v.show = false\n                v.changed = true\n            end\n        end\n    end\n    return true\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["check"] = "event",
							["spellIds"] = {
							},
							["subeventSuffix"] = "_CAST_START",
							["buffShowOn"] = "showOnActive",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["auranames"] = {
								"은폐의 장막", -- [1]
							},
							["use_absorbMode"] = true,
							["subeventPrefix"] = "SPELL",
							["use_tooltip"] = false,
							["debuffType"] = "HELPFUL",
							["type"] = "aura2",
							["use_debuffClass"] = false,
							["unevent"] = "auto",
							["buffShowOn"] = "showOnActive",
							["event"] = "Health",
							["names"] = {
								"은폐의 장막", -- [1]
							},
							["matchesShowOn"] = "showOnActive",
							["use_unit"] = true,
							["spellIds"] = {
							},
							["useName"] = true,
							["useGroup_count"] = false,
							["combineMatches"] = "showLowest",
							["unit"] = "player",
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "custom",
					["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
					["activeTriggerMode"] = 1,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "grow",
					},
					["main"] = {
						["colorR"] = 1,
						["type"] = "none",
						["scalex"] = 1,
						["alphaType"] = "alphaPulse",
						["duration_type"] = "seconds",
						["alpha"] = 0,
						["colorB"] = 1,
						["y"] = 0,
						["x"] = 0,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return start + (((math.sin(angle) + 1)/2) * delta)\n    end\n  ",
						["colorA"] = 1,
						["rotate"] = 0,
						["scaley"] = 1,
						["use_alpha"] = false,
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["backdropInFront"] = false,
				["stickyDuration"] = false,
				["version"] = 88,
				["subRegions"] = {
					{
						["type"] = "aurabar_bar",
					}, -- [1]
					{
						["text_shadowXOffset"] = 1,
						["type"] = "subtext",
						["text_text"] = "%p ",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "Friz Quadrata TT",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = -1,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "None",
						["text_anchorPoint"] = "INNER_RIGHT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 55,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [2]
				},
				["height"] = 55,
				["sparkBlendMode"] = "ADD",
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["uid"] = "VR)Fi4QjQ31",
				["config"] = {
				},
				["auto"] = false,
				["icon"] = true,
				["borderInFront"] = true,
				["displayIcon"] = 635350,
				["icon_side"] = "LEFT",
				["borderBackdrop"] = "Blizzard Tooltip",
				["color"] = {
					0.67843137254902, -- [1]
					0.67843137254902, -- [2]
					0.67843137254902, -- [3]
					1, -- [4]
				},
				["sparkHeight"] = 30,
				["sparkRotationMode"] = "AUTO",
				["anchorFrameType"] = "SCREEN",
				["semver"] = "1.0.87",
				["justify"] = "LEFT",
				["backgroundColor"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.5, -- [4]
				},
				["id"] = "쐐기 : 도비터",
				["sparkHidden"] = "NEVER",
				["frameStrata"] = 1,
				["width"] = 649,
				["wordWrap"] = "WordWrap",
				["useAdjustededMax"] = false,
				["inverse"] = false,
				["sparkDesature"] = false,
				["orientation"] = "HORIZONTAL",
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 2,
							["variable"] = "show",
							["value"] = 1,
						},
						["changes"] = {
							{
								["value"] = {
									1, -- [1]
									1, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "barColor",
							}, -- [1]
						},
					}, -- [1]
				},
				["xOffset"] = 0,
				["zoom"] = 0,
			},
		},
		["TPfiPZMPpwT"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1570539293,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["yOffset"] = 327.1112670898438,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["message_type"] = "SAY",
						["do_message"] = true,
						["message"] = "{다이아몬드}보주 밟아!{다이아몬드}",
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["useglowColor"] = false,
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["animation"] = {
					["start"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "보주 밟고",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "굵은 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["text_visible"] = true,
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_fontSize"] = 31,
						["anchorXOffset"] = 0,
						["text_fontType"] = "OUTLINE",
					}, -- [1]
				},
				["height"] = 64,
				["load"] = {
					["class"] = {
						["multi"] = {
						},
					},
					["use_combat"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "twentyfive",
						["multi"] = {
							["twentyfive"] = true,
						},
					},
				},
				["glowFrequency"] = 0.25,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 1,
				["keepAspectRatio"] = false,
				["glowLength"] = 10,
				["regionType"] = "icon",
				["icon"] = true,
				["glowLines"] = 8,
				["authorOptions"] = {
				},
				["desaturate"] = false,
				["config"] = {
				},
				["zoom"] = 0,
				["glowYOffset"] = 0,
				["frameStrata"] = 1,
				["cooldownTextDisabled"] = false,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "고통",
				["parent"] = "여왕의 칙령 (딩까) 2",
				["alpha"] = 1,
				["anchorFrameType"] = "SCREEN",
				["width"] = 64,
				["uid"] = "TPfiPZMPpwT",
				["inverse"] = false,
				["selfPoint"] = "CENTER",
				["xOffset"] = -32,
				["conditions"] = {
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "aura2",
							["auranames"] = {
								"고통받으라!", -- [1]
							},
							["event"] = "Health",
							["unit"] = "player",
							["spellIds"] = {
							},
							["names"] = {
							},
							["useName"] = true,
							["subeventPrefix"] = "SPELL",
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = -10,
				},
				["glowBorder"] = false,
			},
		},
		["6jtLNL10mjw"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["controlledChildren"] = {
				},
				["borderBackdrop"] = "Blizzard Tooltip",
				["xOffset"] = 0,
				["groupIcon"] = "525134",
				["anchorPoint"] = "CENTER",
				["borderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "aura",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["unit"] = "player",
							["spellIds"] = {
							},
							["debuffType"] = "HELPFUL",
							["names"] = {
							},
							["subeventPrefix"] = "SPELL",
							["buffShowOn"] = "showOnActive",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "all",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["selfPoint"] = "BOTTOMLEFT",
				["desc"] = "HOBUL - AZSHARA",
				["version"] = 88,
				["load"] = {
					["talent2"] = {
						["multi"] = {
						},
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["use_class"] = false,
					["race"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["multi"] = {
						},
					},
					["role"] = {
						["multi"] = {
						},
					},
					["ingroup"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["scale"] = 1,
				["border"] = false,
				["borderEdge"] = "None",
				["regionType"] = "group",
				["borderSize"] = 16,
				["borderOffset"] = 5,
				["semver"] = "1.0.87",
				["tocversion"] = 80205,
				["id"] = "쐐기 : 기타 0929",
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["borderInset"] = 11,
				["authorOptions"] = {
				},
				["uid"] = "6jtLNL10mjw",
				["yOffset"] = 420,
				["conditions"] = {
				},
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["config"] = {
				},
			},
		},
		["9Z2lgZ7poSu"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "OUTLINE",
				["vulcanic_hits_player0"] = 0,
				["displayText"] = "%n",
				["customText"] = "function()\n    if aura_env.display ~= nil then\n        return aura_env.display\n    end\nend",
				["yOffset"] = 0,
				["anchorPoint"] = "BOTTOMLEFT",
				["customTextUpdate"] = "event",
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["icon"] = true,
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["debuffType"] = "HELPFUL",
							["names"] = {
							},
							["genericShowOn"] = "showOnActive",
							["unit"] = "player",
							["event"] = "Health",
							["customName"] = "function()\n    local display = \"총 화산: \"..WeakAurasSaved['total']\n    for k,v in pairs(WeakAurasSaved['volcanic_hits_table']) do\n        display = display..\"\\n\"..k..\": \"..v\n    end\n    return display\nend",
							["custom"] = "function(mainevent)\n    local time, subevent, wtf1, sourceGUID, sourceName, sourceFlags, wtf2, destGUID, destName, somenumber, wtf3, spellID, spellName, _, amount, _, _, _, _, _, crit =  CombatLogGetCurrentEventInfo()\n    \n    if mainevent == \"CHALLENGE_MODE_START\" then\n        local player1 = strsplit(\"-\", (UnitName(\"player\")))\n        local player2 = strsplit(\"-\", (UnitName(\"party1\")))\n        local player3 = strsplit(\"-\", (UnitName(\"party2\")))\n        local player4 = strsplit(\"-\", (UnitName(\"party3\")))\n        local player5 = strsplit(\"-\", (UnitName(\"party4\")))\n        WeakAurasSaved['volcanic_hits_table'] = {[player1] = 0, [player2] = 0, [player3] = 0, [player4] = 0, [player5] = 0}\n        WeakAurasSaved['total'] = 0\n    end\n    ---\n    if mainevent == \"COMBAT_LOG_EVENT_UNFILTERED\"\n    and subevent == \"SPELL_DAMAGE\"\n    and spellID == 209862 then\n        WeakAurasSaved['total'] = WeakAurasSaved['total'] + 1\n        local player = strsplit(\"-\", (destName))\n        for k,v in pairs(WeakAurasSaved['volcanic_hits_table']) do\n            if k == player then\n                WeakAurasSaved['volcanic_hits_table'][k] = WeakAurasSaved['volcanic_hits_table'][k] + 1\n            end\n        end\n        SendChatMessage(\"화산: \"..player..\" (\"..WeakAurasSaved['volcanic_hits_table'][player]..\"/\"..WeakAurasSaved['total']..\").\", \"PARTY\")\n    end\n    --\n    if mainevent == \"CHALLENGE_MODE_COMPLETED\" then\n        SendChatMessage(\"---------------------------------------------\", \"PARTY\")\n        SendChatMessage(\"화산 총 피해: \"..WeakAurasSaved['total']..\".\", \"PARTY\")\n        SendChatMessage(\"---------------------------------------------\", \"PARTY\")\n        for k,v in pairs(WeakAurasSaved['volcanic_hits_table']) do\n            SendChatMessage(k..\": \"..v..\".\", \"PARTY\")\n        end\n        SendChatMessage(\"---------------------------------------------\", \"PARTY\")\n    end\n    --\n    if WeakAurasSaved['total'] ~= nil then\n        return true\n    end\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED, CHALLENGE_MODE_COMPLETED, CHALLENGE_MODE_START",
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["custom_type"] = "event",
							["custom_hide"] = "custom",
						},
						["untrigger"] = {
							["custom"] = "function()\n    return true\nend",
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = 1,
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "fade",
					},
				},
				["desaturate"] = false,
				["wordWrap"] = "WordWrap",
				["font"] = "Expressway",
				["version"] = 88,
				["xOffset"] = 0,
				["height"] = 24.999923706055,
				["vulcanic_hits_total"] = 0,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["encounterid"] = "",
					["zone"] = "",
					["use_encounterid"] = false,
					["affixes"] = {
						["single"] = 3,
					},
					["use_zone"] = false,
					["level"] = "",
					["use_level"] = false,
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["use_difficulty"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["use_size"] = true,
					["zoneId"] = "",
					["talent"] = {
						["multi"] = {
						},
					},
					["use_role"] = true,
					["use_affixes"] = true,
					["race"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["mythic"] = true,
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "120",
					["name"] = "",
					["faction"] = {
						["multi"] = {
						},
					},
					["talent2"] = {
						["multi"] = {
						},
					},
					["level_operator"] = "==",
					["role"] = {
						["single"] = "HEALER",
						["multi"] = {
							["HEALER"] = true,
						},
					},
					["use_zoneId"] = false,
				},
				["fixedWidth"] = 200,
				["color"] = {
					0.97647058823529, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["fontSize"] = 25,
				["displayStacks"] = "%c",
				["parent"] = "쐐기 : 기타 0929",
				["actions"] = {
					["start"] = {
						["glow_action"] = "hide",
						["message_type"] = "PRINT",
						["do_message"] = false,
						["do_glow"] = false,
						["custom"] = "",
						["do_sound"] = false,
						["message"] = "",
						["sound"] = " custom",
						["do_custom"] = false,
						["glow_frame"] = "",
					},
					["init"] = {
					},
					["finish"] = {
						["do_message"] = false,
						["do_custom"] = true,
						["custom"] = "aura_env.display = nil",
					},
				},
				["uid"] = "9Z2lgZ7poSu",
				["vulcanic_hits_player1"] = 0,
				["width"] = 26.000062942505,
				["regionType"] = "text",
				["automaticWidth"] = "Auto",
				["authorOptions"] = {
				},
				["semver"] = "1.0.87",
				["vulcanic_hits_player4"] = 0,
				["vulcanic_hits_player3"] = 0,
				["anchorFrameParent"] = true,
				["vulcanic_hits_player2"] = 0,
				["stacksContainment"] = "INSIDE",
				["zoom"] = 0,
				["auto"] = true,
				["tocversion"] = 80205,
				["id"] = "쐐기 : 화산",
				["justify"] = "CENTER",
				["frameStrata"] = 2,
				["anchorFrameType"] = "SCREEN",
				["fontFlags"] = "OUTLINE",
				["config"] = {
				},
				["inverse"] = false,
				["stickyDuration"] = false,
				["selfPoint"] = "CENTER",
				["conditions"] = {
				},
				["stacksPoint"] = "BOTTOMRIGHT",
				["textColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
			},
		},
		["u9JIYR7e5jl"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["customText"] = "function()\n    if WA_GetUnitDebuff(\"player\", \"살점 파내기\") then\n        return \"수호물 필요!\"\n    end\n    \n    if aura_env and aura_env.state and aura_env.state.name then\n        if aura_env.state.name == \"공포의 오라\" and aura_env.state.stacks > 1 then\n            return \"이동!\"\n        elseif aura_env.state.name == \"고대 환각의 마귀\" or aura_env.state.name == \"영혼 조작\" then\n            return floor((UnitHealth(\"player\")/UnitHealthMax(\"player\")-0.5)*100)..\"%\"\n        elseif aura_env.state.name == \"신경독\" then\n            return \"이동 중지!\"    \n        elseif aura_env.state.name == \"풍력\" or aura_env.state.name == \"심연의 역류\" then \n            return \"저항!\"    \n        elseif  aura_env.state.name == \"교수형 집행인의 올가미\" then\n            return \"끌린 후 회피!\"\n        elseif aura_env.state.name ==\"미끄러운 거품\" then\n            return \"점프 금지!\"\n        elseif aura_env.state.name == \"추격\" or aura_env.state.name == \"눈먼 분노\" or\n        aura_env.state.name == \"피에 대한 갈증\"  or aura_env.state.name == \"시선 고정\"\n        or aura_env.state.name == \"강철의 시선\" or aura_env.state.name == \"수색과 섬멸\" then\n            return \"추격 대상!\"\n        elseif aura_env.state.name == \"부패하는 정신\" then\n            return format(\"%.1f만\", select(17, WA_GetUnitDebuff(\"player\", \"부패하는 정신\"))/10000)   \n        else\n            return \"\"\n        end\n    end\n    \n    \nend",
				["yOffset"] = -80,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["glow_action"] = "show",
						["message_type"] = "YELL",
						["do_message"] = false,
						["do_glow"] = false,
						["custom"] = "\n\n",
						["do_sound"] = false,
						["message"] = "",
						["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
						["do_custom"] = false,
						["glow_frame"] = "",
					},
					["init"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["finish"] = {
						["do_glow"] = false,
						["glow_action"] = "hide",
						["glow_frame"] = "",
					},
				},
				["useglowColor"] = false,
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["selfPoint"] = "CENTER",
				["desaturate"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["glowLength"] = 10,
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "%c",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "기본 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 34,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [1]
					{
						["text_shadowXOffset"] = 0,
						["text_text"] = "%s",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_selfPoint"] = "AUTO",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["rotateText"] = "NONE",
						["type"] = "subtext",
						["text_anchorXOffset"] = 5,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "기본 글꼴",
						["text_shadowYOffset"] = 0,
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
						["text_visible"] = true,
						["text_fontSize"] = 41,
						["anchorXOffset"] = 0,
						["text_anchorYOffset"] = -7,
					}, -- [2]
					{
						["border_offset"] = 0,
						["border_size"] = 3,
						["border_color"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["border_visible"] = true,
						["border_edge"] = "1 Pixel",
						["type"] = "subborder",
					}, -- [3]
				},
				["height"] = 80,
				["authorOptions"] = {
				},
				["glowLines"] = 8,
				["displayIcon"] = 136066,
				["glowFrequency"] = 0.25,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["encounterid"] = "2073",
					["use_encounterid"] = false,
					["use_zone"] = false,
					["level"] = "",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["zoneId"] = "8040",
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["mythic"] = true,
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "110",
					["faction"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["use_zoneId"] = false,
					["level_operator"] = ">=",
					["use_size"] = true,
					["role"] = {
						["multi"] = {
						},
					},
				},
				["animation"] = {
					["start"] = {
						["colorR"] = 1,
						["scalex"] = 2.5,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["scaleType"] = "straightScale",
						["scaley"] = 2.5,
						["alpha"] = 0,
						["colorA"] = 1,
						["y"] = 0,
						["x"] = 0,
						["duration"] = "0.17",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
						["type"] = "custom",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["use_scale"] = true,
					},
					["main"] = {
						["scaley"] = 1.05,
						["type"] = "none",
						["duration_type"] = "seconds",
						["duration"] = "1",
						["scalex"] = 1.05,
						["use_scale"] = true,
						["alpha"] = 0,
						["scaleType"] = "pulse",
						["y"] = 0,
						["x"] = 0,
						["colorG"] = 1,
						["colorB"] = 1,
						["colorA"] = 1,
						["rotate"] = 0,
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
						["colorR"] = 1,
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["parent"] = "쐐기 : 기타 0929",
				["uid"] = "u9JIYR7e5jl",
				["xOffset"] = 0,
				["regionType"] = "icon",
				["anchorFrameType"] = "SCREEN",
				["alpha"] = 1,
				["icon"] = true,
				["auto"] = true,
				["tocversion"] = 80205,
				["semver"] = "1.0.87",
				["cooldownTextDisabled"] = false,
				["keepAspectRatio"] = false,
				["zoom"] = 0,
				["useGlowColor"] = false,
				["glowScale"] = 1,
				["id"] = "쐐기 : 개인 디버프",
				["stickyDuration"] = false,
				["frameStrata"] = 1,
				["width"] = 80,
				["glowYOffset"] = 0,
				["config"] = {
				},
				["inverse"] = false,
				["triggers"] = {
					{
						["trigger"] = {
							["useGroup_count"] = false,
							["matchesShowOn"] = "showOnActive",
							["names"] = {
								"공포의 오라", -- [1]
								"활력 주입", -- [2]
								"힘의 속삭임", -- [3]
								"지각 변동", -- [4]
								"숨 막히는 소금물", -- [5]
								"흉포한 포식자", -- [6]
								"황금 뱉기", -- [7]
								"교수형 집행인의 올가미", -- [8]
								"심연의 역류", -- [9]
							},
							["use_tooltip"] = false,
							["debuffType"] = "HARMFUL",
							["showClones"] = false,
							["useName"] = true,
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["custom_hide"] = "timed",
							["type"] = "aura2",
							["spellIds"] = {
							},
							["unit"] = "player",
							["auranames"] = {
								"공포의 오라", -- [1]
								"활력 주입", -- [2]
								"힘의 속삭임", -- [3]
								"지각 변동", -- [4]
								"흉포한 포식자", -- [5]
								"황금 뱉기", -- [6]
								"교수형 집행인의 올가미", -- [7]
								"심연의 역류", -- [8]
								"풍력", -- [9]
								"감염", -- [10]
								"미끄러운 거품", -- [11]
								"고대 환각의 마귀", -- [12]
								"흐려진 시야", -- [13]
								"손 마비", -- [14]
								"보주", -- [15]
								"영혼 조작", -- [16]
							},
							["combineMatches"] = "showLowest",
							["buffShowOn"] = "showOnActive",
							["subeventPrefix"] = "SPELL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "aura2",
							["buffShowOn"] = "showOnActive",
							["useGroup_count"] = false,
							["unit"] = "player",
							["matchesShowOn"] = "showOnActive",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["subeventSuffix"] = "_CAST_START",
							["use_tooltip"] = false,
							["spellIds"] = {
							},
							["names"] = {
								"변환: 적을 점액으로", -- [1]
								"뱀의 현혹", -- [2]
								"사술", -- [3]
								"신경독", -- [4]
								"절망의 구덩이", -- [5]
								"부패하는 정신", -- [6]
								"익사의 손길", -- [7]
								"도화선 점화기", -- [8]
								"정신 분열", -- [9]
							},
							["auranames"] = {
								"변환: 적을 점액으로", -- [1]
								"뱀의 현혹", -- [2]
								"사술", -- [3]
								"신경독", -- [4]
								"절망의 구덩이", -- [5]
								"부패하는 정신", -- [6]
								"익사의 손길", -- [7]
								"도화선 점화기", -- [8]
								"정신 분열", -- [9]
								"마력 속박", -- [10]
								"룬새김 회전베기", -- [11]
								"광기의 눈길", -- [12]
								"숨은 칼날", -- [13]
								"정신 공격", -- [14]
								"두뇌 빙결", -- [15]
								"숨막히는 물", -- [16]
								"맹독 포화", -- [17]
								"감전 충격", -- [18]
								"메아리 칼날", -- [19]
								"정의의 불길", -- [20]
								"충격 발톱", -- [21]
								"공포스러운 얼굴", -- [22]
								"공포의 비명소리", -- [23]
								"마비시키는 독칼", -- [24]
								"쇠약의 외침", -- [25]
								"잡아채는 가시", -- [26]
								"폭발성 공허", -- [27]
								"화학 화상", -- [28]
								"숨 막히는 소금물", -- [29]
								"냉기 충격", -- [30]
								"공포의 울부짖음", -- [31]
								"흉측한 방출", -- [32]
								"빙결 덫", -- [33]
								"두꺼비 역병", -- [34]
								"솟구치는 파도", -- [35]
								"정신력 고갈", -- [36]
							},
							["combineMatches"] = "showLowest",
							["useName"] = true,
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [2]
					{
						["trigger"] = {
							["unit"] = "player",
							["useName"] = true,
							["type"] = "aura2",
							["auranames"] = {
								"유혹", -- [1]
							},
							["subeventPrefix"] = "SPELL",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [3]
					{
						["trigger"] = {
							["debuffType"] = "HARMFUL",
							["type"] = "aura2",
							["use_debuffClass"] = false,
							["useGroup_count"] = false,
							["auranames"] = {
								"추격", -- [1]
								"피에 대한 갈증", -- [2]
								"시선 고정", -- [3]
								"눈먼 분노", -- [4]
								"강철의 시선", -- [5]
								"수색과 섬멸", -- [6]
								"검은 화약 폭탄", -- [7]
								"발견된 대포", -- [8]
							},
							["matchesShowOn"] = "showOnActive",
							["event"] = "Health",
							["unit"] = "player",
							["subeventSuffix"] = "_CAST_START",
							["use_tooltip"] = false,
							["spellIds"] = {
							},
							["names"] = {
								"추격", -- [1]
								"피에 대한 갈증", -- [2]
								"시선 고정", -- [3]
								"눈먼 분노", -- [4]
								"강철의 시선", -- [5]
								"수색과 섬멸", -- [6]
								"검은 화약 폭탄", -- [7]
								"발견된 대포", -- [8]
							},
							["subeventPrefix"] = "SPELL",
							["combineMatches"] = "showLowest",
							["useName"] = true,
							["buffShowOn"] = "showOnActive",
						},
						["untrigger"] = {
						},
					}, -- [4]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "status",
							["event"] = "Health",
							["customStacks"] = "function()\nreturn 0\nend",
							["customDuration"] = "function()\n    local dur, exp = select(5,WA_GetUnitDebuff(\"player\", \"살점 파내기\"))\n    return dur, exp\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["customName"] = "",
							["events"] = "UNIT_AURA",
							["customIcon"] = "function()\n    return \"Interface\\\\icons\\\\70_inscription_vantus_rune_light\"\nend",
							["check"] = "event",
							["custom"] = "function()\n    if WA_GetUnitDebuff(\"player\", \"살점 파내기\") and not WA_GetUnitBuff(\"player\", \"최하급 강화 수호물\") then\n        return true\n    end\nend",
							["subeventSuffix"] = "_CAST_START",
							["subeventPrefix"] = "SPELL",
						},
						["untrigger"] = {
							["custom"] = "function()\n    return true\nend",
						},
					}, -- [5]
					["disjunctive"] = "any",
					["customTriggerLogic"] = "\n\n",
					["activeTriggerMode"] = -10,
				},
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = 1,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["trigger"] = 5,
									["variable"] = "show",
									["value"] = 1,
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BikeHorn.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [1]
						},
					}, -- [1]
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = 2,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["trigger"] = 3,
									["variable"] = "show",
									["value"] = 1,
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["message"] = "%n(해제) 대상!",
									["message_type"] = "YELL",
								},
								["property"] = "chat",
							}, -- [1]
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\BITE.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [2]
						},
					}, -- [2]
					{
						["check"] = {
							["trigger"] = 4,
							["variable"] = "show",
							["value"] = 1,
						},
						["changes"] = {
							{
								["value"] = {
									["message"] = "추격 받는 중!",
									["message_type"] = "YELL",
								},
								["property"] = "chat",
							}, -- [1]
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\aggro.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [2]
						},
					}, -- [3]
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = 5,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["trigger"] = -2,
									["op"] = "==",
									["variable"] = "AND",
									["checks"] = {
										{
											["trigger"] = 1,
											["op"] = "==",
											["variable"] = "name",
											["value"] = "공포의 오라",
										}, -- [1]
										{
											["trigger"] = 1,
											["op"] = ">",
											["variable"] = "stacks",
											["value"] = "1",
										}, -- [2]
									},
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = true,
								["property"] = "glow",
							}, -- [1]
						},
					}, -- [4]
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = 5,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["trigger"] = -2,
									["variable"] = "AND",
									["checks"] = {
										{
											["trigger"] = 1,
											["op"] = "==",
											["variable"] = "name",
											["value"] = "공포의 오라",
										}, -- [1]
										{
											["trigger"] = 1,
											["op"] = "==",
											["variable"] = "stacks",
											["value"] = "1",
										}, -- [2]
									},
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = true,
								["property"] = "desaturate",
							}, -- [1]
						},
					}, -- [5]
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = -2,
									["variable"] = "AND",
									["checks"] = {
										{
											["trigger"] = 1,
											["op"] = "==",
											["variable"] = "name",
											["value"] = "활력 주입",
										}, -- [1]
										{
											["trigger"] = 1,
											["op"] = ">=",
											["variable"] = "stacks",
											["value"] = "9",
										}, -- [2]
									},
								}, -- [1]
								{
									["trigger"] = 1,
									["op"] = "==",
									["variable"] = "name",
									["value"] = "미끄러운 거품",
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = true,
								["property"] = "glow",
							}, -- [1]
							{
								["value"] = "Pixel",
								["property"] = "glowType",
							}, -- [2]
						},
					}, -- [6]
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = 1,
									["op"] = "==",
									["variable"] = "debuffClass",
									["value"] = "magic",
								}, -- [1]
								{
									["trigger"] = 2,
									["op"] = "==",
									["variable"] = "debuffClass",
									["value"] = "magic",
								}, -- [2]
								{
									["trigger"] = 3,
									["op"] = "==",
									["variable"] = "debuffClass",
									["value"] = "magic",
								}, -- [3]
							},
						},
						["changes"] = {
							{
								["value"] = {
									0, -- [1]
									0.92156862745098, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [7]
					{
						["check"] = {
							["trigger"] = 2,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "curse",
						},
						["changes"] = {
							{
								["value"] = {
									0.90196078431373, -- [1]
									0, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [8]
					{
						["check"] = {
							["trigger"] = 2,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "poison",
						},
						["changes"] = {
							{
								["value"] = {
									0.2, -- [1]
									0.70196078431373, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [9]
					{
						["check"] = {
							["trigger"] = 2,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "disease",
						},
						["changes"] = {
							{
								["value"] = {
									0.52156862745098, -- [1]
									0.32941176470588, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [10]
				},
				["cooldown"] = true,
				["glowBorder"] = false,
			},
		},
		["XhAKavJbrOJ"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "OUTLINE",
				["glow"] = true,
				["authorOptions"] = {
				},
				["displayText"] = "%c",
				["customText"] = "function()\n    return #aura_env.orbs\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
				["yOffset"] = -245,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["icon"] = true,
				["useglowColor"] = false,
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["glowLength"] = 15,
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["selfPoint"] = "CENTER",
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "%c",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "Expressway",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "CENTER",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 38,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [1]
				},
				["height"] = 67,
				["displayIcon"] = "2175503",
				["glowLines"] = 8,
				["cooldownEdge"] = false,
				["glowFrequency"] = 0.25,
				["parent"] = "쐐기 : 기타 0929",
				["desc"] = "Made by Exality-Silvermoon EU",
				["glowType"] = "Pixel",
				["glowThickness"] = 2,
				["uid"] = "XhAKavJbrOJ",
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["level_operator"] = "==",
					["use_encounterid"] = false,
					["role"] = {
						["multi"] = {
						},
					},
					["use_difficulty"] = true,
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["affixes"] = {
						["single"] = 13,
						["multi"] = {
							[13] = true,
						},
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["level"] = "",
					["use_affixes"] = true,
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "120",
					["race"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["use_size"] = true,
				},
				["glowYOffset"] = 0,
				["regionType"] = "icon",
				["alpha"] = 1,
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["justify"] = "LEFT",
				["glowScale"] = 1,
				["useGlowColor"] = false,
				["cooldownTextDisabled"] = false,
				["glowXOffset"] = 0,
				["auto"] = true,
				["zoom"] = 0,
				["semver"] = "1.0.87",
				["tocversion"] = 80205,
				["id"] = "쐐기 : 폭탄",
				["anchorFrameType"] = "SCREEN",
				["frameStrata"] = 1,
				["width"] = 67,
				["actions"] = {
					["start"] = {
						["do_custom"] = false,
						["custom"] = "\n\n\n\n\n\n\n\n\n\n\n",
						["do_sound"] = false,
					},
					["init"] = {
						["custom"] = "aura_env.orbs = {}\naura_env.npcID = {  \n    [120651] = true, -- 폭발물\n    --[144081] = true, -- 테스트\n}\n\naura_env.GetNPCId = function(guid)\n    local type, zero, server_id, instance_id, zone_uid, npc_id, spawn_uid = strsplit(\"-\",guid)\n    return tonumber(npc_id)\nend\n\naura_env.RemoveOrb = function(guid)\n    for indx,orbInfo in ipairs(aura_env.orbs) do\n        if orbInfo.guid == guid then\n            table.remove(aura_env.orbs,indx)\n            break\n        end\n    end\nend\n\nlocal r,g,b,a = aura_env.region:GetColor()\naura_env.ShowIcon = function()\n    if #aura_env.orbs > 0 then\n        aura_env.region:SetAlpha(1)\n        aura_env.region:Color(r,g,b,a)\n    else\n        aura_env.region:SetAlpha(0)\n        aura_env.region:Color(r,g,b,0)\n    end\nend\n\n\n\n\n\n\n\n\n\n",
						["do_custom"] = true,
					},
					["finish"] = {
						["custom"] = "\n\n",
						["do_custom"] = false,
					},
				},
				["config"] = {
				},
				["inverse"] = false,
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "custom",
							["event"] = "Health",
							["genericShowOn"] = "showOnActive",
							["names"] = {
							},
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["custom"] = "function(event,unit)\n    if not unit then return end\n    local guid = UnitGUID(unit)\n    if event == \"NAME_PLATE_UNIT_ADDED\" then\n        -- new nameplate\n        local npcId = aura_env.GetNPCId(guid)\n        if (npcId and aura_env.npcID[npcId]) then\n            table.insert(aura_env.orbs,{guid = guid,unit = unit})\n        end\n    elseif event == \"NAME_PLATE_UNIT_REMOVED\" then\n        aura_env.RemoveOrb(guid)\n    end\n    aura_env.ShowIcon()\n    return true\nend\n\n\n\n",
							["events"] = "NAME_PLATE_UNIT_ADDED NAME_PLATE_UNIT_REMOVED",
							["check"] = "event",
							["custom_type"] = "status",
							["unit"] = "player",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
							["custom"] = "",
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["desaturate"] = false,
				["conditions"] = {
				},
				["xOffset"] = 0,
				["glowBorder"] = false,
			},
		},
		[")F0p(8Gp(bQ"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = true,
				["xOffset"] = 0,
				["customText"] = "\n\n",
				["yOffset"] = -80,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "event",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["glow_action"] = "show",
						["message_type"] = "YELL",
						["do_message"] = false,
						["do_glow"] = false,
						["custom"] = "\n\n",
						["do_sound"] = false,
						["message"] = "",
						["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
						["do_custom"] = false,
						["glow_frame"] = "",
					},
					["init"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["finish"] = {
						["do_glow"] = false,
						["glow_action"] = "hide",
						["glow_frame"] = "",
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["use_absorbMode"] = true,
							["subeventPrefix"] = "SPELL",
							["customIcon"] = "",
							["debuffType"] = "HELPFUL",
							["unit"] = "player",
							["type"] = "custom",
							["unevent"] = "auto",
							["custom_type"] = "status",
							["events"] = "UNIT_POWER UNIT_SPELLCAST_CHANNEL_START UNIT_SPELLCAST_CHANNEL_STOP UNIT_SPELLCAST_CHANNEL_UPDATE UNIT_TARGET UNIT_AURA",
							["spellIds"] = {
							},
							["event"] = "Chat Message",
							["customStacks"] = "",
							["customDuration"] = "function()\n    if UnitChannelInfo(\"boss1\") and select(1, UnitChannelInfo(\"boss1\")) == \"수혈\"then\n        return (select(5,UnitChannelInfo(\"boss1\"))-select(4,UnitChannelInfo(\"boss1\")))/1000, select(5,UnitChannelInfo(\"boss1\"))/1000\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["customName"] = "",
							["custom"] = "function()\n    if UnitExists(\"boss1\") and not WA_GetUnitDebuff(\"player\", \"오염된 피\") then\n        \n        if UnitChannelInfo(\"boss1\") and select(1, UnitChannelInfo(\"boss1\")) == \"수혈\" then\n            return true\n        else\n            if UnitPower(\"boss1\") == 100 then\n                return true\n            end\n        end\n    end\nend\n\n\n",
							["names"] = {
							},
							["check"] = "event",
							["subeventSuffix"] = "_CAST_START",
							["use_unit"] = true,
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
							["custom"] = "function()\n    return true\nend",
						},
					}, -- [1]
					["disjunctive"] = "any",
					["customTriggerLogic"] = "",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["selfPoint"] = "CENTER",
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "오염 필요!",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "기본 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 34,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [1]
					{
						["border_offset"] = 0,
						["border_size"] = 3,
						["text_color"] = {
						},
						["border_color"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["border_visible"] = true,
						["border_edge"] = "1 Pixel",
						["type"] = "subborder",
					}, -- [2]
				},
				["height"] = 80,
				["authorOptions"] = {
				},
				["glowLines"] = 8,
				["displayIcon"] = 538039,
				["glowFrequency"] = 0.25,
				["glowLength"] = 10,
				["parent"] = "쐐기 : 기타 0929",
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["keepAspectRatio"] = false,
				["config"] = {
				},
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["regionType"] = "icon",
				["glowYOffset"] = 0,
				["alpha"] = 1,
				["useglowColor"] = false,
				["icon"] = true,
				["tocversion"] = 80205,
				["semver"] = "1.0.87",
				["cooldownTextDisabled"] = false,
				["useGlowColor"] = false,
				["zoom"] = 0,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "쐐기 : 알룬자 수혈",
				["width"] = 80,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["desaturate"] = true,
				["uid"] = ")F0p(8Gp(bQ",
				["inverse"] = false,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["class"] = {
						["multi"] = {
						},
					},
					["use_encounterid"] = true,
					["use_zone"] = false,
					["level"] = "",
					["role"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["zoneId"] = "8040",
					["spec"] = {
						["multi"] = {
						},
					},
					["use_zoneId"] = false,
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["mythic"] = true,
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "110",
					["faction"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["level_operator"] = ">=",
					["use_combat"] = true,
					["encounterid"] = "2084",
					["use_size"] = true,
				},
				["animation"] = {
					["start"] = {
						["colorR"] = 1,
						["scalex"] = 2.5,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["scaleType"] = "straightScale",
						["scaley"] = 2.5,
						["alpha"] = 0,
						["use_scale"] = true,
						["y"] = 0,
						["x"] = 0,
						["duration"] = "0.17",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
						["type"] = "custom",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["colorA"] = 1,
					},
					["main"] = {
						["colorR"] = 1,
						["type"] = "none",
						["scalex"] = 1.05,
						["scaley"] = 1.05,
						["duration"] = "1",
						["duration_type"] = "seconds",
						["alpha"] = 0,
						["use_scale"] = true,
						["y"] = 0,
						["colorA"] = 1,
						["colorG"] = 1,
						["colorB"] = 1,
						["x"] = 0,
						["rotate"] = 0,
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
						["scaleType"] = "pulse",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 1,
							["variable"] = "show",
							["value"] = 1,
							["checks"] = {
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [1]
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\BikeHorn.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [1]
						},
					}, -- [1]
				},
				["cooldown"] = true,
				["glowBorder"] = false,
			},
		},
		["uC0SoXWfm5u"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["textFlags"] = "None",
				["stacksSize"] = 12,
				["authorOptions"] = {
				},
				["stacksFlags"] = "None",
				["yOffset"] = -245,
				["anchorPoint"] = "CENTER",
				["borderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
						["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\sonar.ogg",
						["do_sound"] = true,
					},
					["init"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["finish"] = {
					},
				},
				["fontFlags"] = "OUTLINE",
				["icon_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["selfPoint"] = "CENTER",
				["barColor"] = {
					1, -- [1]
					0.90588235294118, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["desaturate"] = false,
				["font"] = "Friz Quadrata TT",
				["sparkOffsetY"] = 0,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["level_operator"] = "==",
					["role"] = {
						["multi"] = {
						},
					},
					["use_difficulty"] = true,
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["affixes"] = {
						["single"] = 14,
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "120",
					["use_affixes"] = true,
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["faction"] = {
						["multi"] = {
						},
					},
					["level"] = "",
					["use_size"] = true,
				},
				["timerColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["regionType"] = "text",
				["stacks"] = false,
				["texture"] = "Minimalist",
				["textFont"] = "Friz Quadrata TT",
				["stacksFont"] = "Friz Quadrata TT",
				["auto"] = false,
				["tocversion"] = 80205,
				["timerFont"] = "Friz Quadrata TT",
				["alpha"] = 1,
				["borderInset"] = 11,
				["fixedWidth"] = 200,
				["textColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["outline"] = "OUTLINE",
				["borderBackdrop"] = "Blizzard Tooltip",
				["color"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["customText"] = "",
				["barInFront"] = true,
				["sparkWidth"] = 25,
				["sparkColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["sparkRotationMode"] = "AUTO",
				["automaticWidth"] = "Auto",
				["displayTextLeft"] = "  시전 중지!!",
				["triggers"] = {
					{
						["trigger"] = {
							["auranames"] = {
								"전율", -- [1]
							},
							["matchesShowOn"] = "showOnActive",
							["unit"] = "player",
							["use_tooltip"] = false,
							["debuffType"] = "HARMFUL",
							["type"] = "aura2",
							["use_debuffClass"] = false,
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["buffShowOn"] = "showOnActive",
							["custom_hide"] = "timed",
							["spellIds"] = {
							},
							["useName"] = true,
							["useGroup_count"] = false,
							["combineMatches"] = "showLowest",
							["names"] = {
								"전율", -- [1]
							},
							["subeventPrefix"] = "SPELL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "custom",
							["unevent"] = "auto",
							["use_absorbMode"] = true,
							["event"] = "Health",
							["unit"] = "player",
							["use_unit"] = true,
							["subeventSuffix"] = "_CAST_START",
							["custom"] = "function()\n    if WeakAuras.triggerState[aura_env.id].triggers[1] then\n        for unit in WA_IterateGroupMembers() do                \n            if unit ~= \"player\" and WeakAuras.CheckRange(unit, 4, \"<=\") then\n                return true\n            end\n        end\n    end\nend\n\n\n",
							["subeventPrefix"] = "SPELL",
							["check"] = "update",
							["custom_type"] = "status",
							["duration"] = "1",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
							["custom"] = "function()\nreturn true\nend",
						},
					}, -- [2]
					["disjunctive"] = "custom",
					["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
					["activeTriggerMode"] = 1,
				},
				["displayIcon"] = 135975,
				["internalVersion"] = 24,
				["uid"] = "uC0SoXWfm5u",
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "custom",
						["colorR"] = 1,
						["duration_type"] = "seconds",
						["duration"] = "",
						["x"] = 0,
						["scaley"] = 1,
						["alpha"] = 0,
						["colorType"] = "custom",
						["y"] = 0,
						["colorB"] = 0.03921568627451,
						["colorG"] = 0,
						["colorA"] = 1,
						["colorFunc"] = "function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n    \n    if WeakAuras.IsOptionsOpen() then\n        return r1,g1,b1,a1\n    end\n    \n    local cast = select(5, UnitCastingInfo(\"player\")) or select(5, UnitChannelInfo(\"player\"))\n    local intp = select(8, UnitCastingInfo(\"player\")) or select(7, UnitChannelInfo(\"player\"))\n    \n    if cast and not intp and cast/1000 > aura_env.state.expirationTime then\n        return 1,0,0,1\n    else\n        return r1,g1,b1,a1\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n",
						["rotate"] = 0,
						["use_color"] = true,
						["scalex"] = 1,
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
				["text"] = true,
				["spark"] = true,
				["stickyDuration"] = false,
				["wordWrap"] = "WordWrap",
				["timer"] = true,
				["version"] = 88,
				["width"] = 33.999992370605,
				["height"] = 59.999923706055,
				["timerFlags"] = "None",
				["rotateText"] = "NONE",
				["sparkBlendMode"] = "ADD",
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["fontSize"] = 60,
				["timerSize"] = 30,
				["id"] = "쐐기 : 전율",
				["displayTextRight"] = "%p ",
				["semver"] = "1.0.87",
				["border"] = false,
				["borderEdge"] = "None",
				["textSize"] = 22,
				["borderSize"] = 16,
				["icon"] = true,
				["icon_side"] = "RIGHT",
				["customTextUpdate"] = "update",
				["xOffset"] = 0,
				["sparkHeight"] = 100,
				["sparkOffsetX"] = 0,
				["backgroundColor"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.5, -- [4]
				},
				["stacksColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["justify"] = "CENTER",
				["displayText"] = "%p",
				["sparkHidden"] = "NEVER",
				["zoom"] = 0.25,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["sparkRotation"] = 0,
				["config"] = {
				},
				["inverse"] = true,
				["sparkDesature"] = false,
				["orientation"] = "HORIZONTAL",
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 2,
							["variable"] = "show",
							["value"] = 1,
						},
						["changes"] = {
							{
								["value"] = {
									1, -- [1]
									0.49019607843137, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "color",
							}, -- [1]
						},
					}, -- [1]
				},
				["borderOffset"] = 5,
				["parent"] = "쐐기 : 기타 0929",
			},
		},
		["Up6YxIcGOiz"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "OUTLINE",
				["parent"] = "쐐기 : 기타 0929",
				["displayText"] = "",
				["customText"] = "\n\n",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["automaticWidth"] = "Auto",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
						["custom"] = "aura_env.postkey = function(channel)\n    for bag = 0, NUM_BAG_SLOTS do\n        local numSlots = GetContainerNumSlots(bag)\n        for slot = 1, numSlots do\n            if (GetContainerItemID(bag, slot) == 158923) then \n                local link = GetContainerItemLink(bag, slot)\n                SendChatMessage(link, channel)\n            end\n        end\n    end\nend",
						["do_custom"] = true,
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
							["duration"] = "0.1",
							["event"] = "Chat Message",
							["unit"] = "player",
							["unevent"] = "timed",
							["custom_type"] = "event",
							["custom"] = "function(event, text)\n    if event == \"REQUEST_PARTY_KEYS\" then\n        aura_env.postkey(\"PARTY\")\n    elseif event == \"REQUEST_GUILD_KEYS\" then\n        aura_env.postkey(\"GUILD\")\n    end\n    \n    if event == \"CHALLENGE_MODE_COMPLETED\" then\n        local aura_env = aura_env\n        C_Timer.After(1, function() aura_env.postkey(\"PARTY\") end)\n    end\n    if text and (text:find(\"!돌\") or text:find(\"!ehf\")) then\n        if (event == \"CHAT_MSG_PARTY\" or event == \"CHAT_MSG_PARTY_LEADER\") and aura_env.config.keysParty then\n            WeakAuras.ScanEvents(\"REQUEST_PARTY_KEYS\")\n        elseif event == \"CHAT_MSG_GUILD\" and aura_env.config.keysGuild then\n            WeakAuras.ScanEvents(\"REQUEST_GUILD_KEYS\")\n        end\n    end\nend",
							["subeventPrefix"] = "SPELL",
							["events"] = "CHALLENGE_MODE_COMPLETED, CHAT_MSG_GUILD, CHAT_MSG_PARTY, CHAT_MSG_PARTY_LEADER, REQUEST_GUILD_KEYS, REQUEST_PARTY_KEYS",
							["spellIds"] = {
							},
							["names"] = {
							},
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "any",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["wordWrap"] = "WordWrap",
				["desc"] = "Made by Luckyone",
				["font"] = "Friz Quadrata TT",
				["version"] = 88,
				["subRegions"] = {
				},
				["load"] = {
					["use_effectiveLevel"] = true,
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["spec"] = {
						["multi"] = {
						},
					},
					["effectiveLevel"] = "120",
					["class"] = {
						["multi"] = {
						},
					},
					["level_operator"] = "==",
					["level"] = "",
					["use_level"] = false,
					["size"] = {
						["multi"] = {
						},
					},
				},
				["fontSize"] = 20,
				["regionType"] = "text",
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["semver"] = "1.0.87",
				["justify"] = "LEFT",
				["tocversion"] = 80205,
				["id"] = "쐐기 : !돌",
				["fixedWidth"] = 200,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["xOffset"] = 0,
				["uid"] = "Up6YxIcGOiz",
				["config"] = {
					["keysParty"] = true,
					["keysGuild"] = true,
				},
				["authorOptions"] = {
					{
						["type"] = "toggle",
						["default"] = true,
						["desc"] = "!keys command will work in /party",
						["key"] = "keysParty",
						["useDesc"] = true,
						["name"] = "Party Chat",
						["width"] = 1,
					}, -- [1]
					{
						["type"] = "toggle",
						["default"] = true,
						["desc"] = "!keys command will work in /guild",
						["key"] = "keysGuild",
						["useDesc"] = true,
						["name"] = "Guild Chat",
						["width"] = 1,
					}, -- [2]
				},
				["selfPoint"] = "BOTTOM",
				["conditions"] = {
				},
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0, -- [4]
				},
			},
		},
		["3b8aX9jQUPc"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["xOffset"] = 0,
				["customText"] = "function()\n    if aura_env.state and aura_env.state.PassUnit then\n        local region = aura_env.region\n        local plate = C_NamePlate.GetNamePlateForUnit(aura_env.state.PassUnit)\n        if plate then\n            region:ClearAllPoints()\n            region:SetPoint(\"BOTTOM\", plate, \"TOP\", 0, 0)\n            region:Show()\n        else\n            region:Hide()\n        end\n    end\nend",
				["yOffset"] = 5000,
				["anchorPoint"] = "CENTER",
				["glowBorder"] = false,
				["cooldownSwipe"] = true,
				["selfPoint"] = "CENTER",
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
					},
					["init"] = {
						["custom"] = "-- you can change order below\n\naura_env.order = {\n    [\"135764\"] = \"1\", --explosive\n    [\"135759\"] = \"4\", --earthwall\n    [\"135761\"] = \"2\", --thundering\n    [\"135765\"] = \"3\", --torrent\n}\naura_env.totemGUID = {\n    [\"135764\"] = true, --explosive\n    [\"135759\"] = true, --earthwall\n    [\"135761\"] = true, --thundering\n    [\"135765\"] = true, --torrent\n}\n\n\n\n\n\n",
						["do_custom"] = true,
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "stateupdate",
							["debuffType"] = "HELPFUL",
							["subeventPrefix"] = "SPELL",
							["event"] = "Chat Message",
							["names"] = {
							},
							["unit"] = "player",
							["custom"] = "function(allstates, event, ...)\n    local unit = ...\n    local subEv = select(2, ...)\n    local destGUID = select(8, ...)\n    \n    if event == \"NAME_PLATE_UNIT_ADDED\" then\n        if UnitExists(unit) then\n            local guid = select(6, strsplit(\"-\", UnitGUID(unit)))\n            if aura_env.totemGUID[guid] then\n                allstates[UnitGUID(unit)] = {\n                    show = true,\n                    changed = true,\n                    progressType = \"static\",\n                    name = aura_env.order[guid],\n                    PassUnit = unit,\n                }\n            end\n        end\n    end\n    \n    if event == \"NAME_PLATE_UNIT_REMOVED\" then\n        if UnitExists(unit) then\n            local guid = UnitGUID(unit)\n            if allstates[guid] then\n                allstates[guid].show = false\n                allstates[guid].changed = true\n                allstates[guid].PassUnit = \"none\"\n            end\n        end\n    elseif (subEv == \"UNIT_DIED\" or subEv == \"UNIT_DESTROYED\") and aura_env.totemGUID[destGUID] then\n        if allstates[destGUID] then\n            allstates[destGUID].show = false\n            allstates[destGUID].changed = true\n            allstates[destGUID].PassUnit = \"none\"\n        end\n    end\n    \n    return true\nend",
							["spellIds"] = {
							},
							["subeventSuffix"] = "_CAST_START",
							["check"] = "event",
							["events"] = "NAME_PLATE_UNIT_ADDED, NAME_PLATE_UNIT_REMOVED",
							["unevent"] = "auto",
							["buffShowOn"] = "showOnActive",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = -10,
				},
				["displayIcon"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Circle_White",
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["glowLength"] = 10,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["discrete_rotation"] = 0,
				["stickyDuration"] = false,
				["rotation"] = 0,
				["uid"] = "3b8aX9jQUPc",
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "%name%c",
						["text_color"] = {
							1, -- [1]
							0, -- [2]
							0.023529411764706, -- [3]
							1, -- [4]
						},
						["text_font"] = "Friz Quadrata TT",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "CENTER",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 39,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [1]
				},
				["height"] = 48,
				["rotate"] = false,
				["glowLines"] = 8,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["glowFrequency"] = 0.25,
				["anchorFrameType"] = "SCREEN",
				["alpha"] = 1,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["parent"] = "쐐기 : 기타 0929",
				["mirror"] = false,
				["glowXOffset"] = 0,
				["regionType"] = "texture",
				["tocversion"] = 80205,
				["blendMode"] = "BLEND",
				["semver"] = "1.0.87",
				["cooldownTextDisabled"] = false,
				["load"] = {
					["use_effectiveLevel"] = true,
					["use_size"] = true,
					["use_level"] = false,
					["effectiveLevel_operator"] = ">=",
					["level_operator"] = ">=",
					["use_encounterid"] = true,
					["effectiveLevel"] = "110",
					["encounterid"] = "2140",
					["spec"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["level"] = "",
					["class"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
				},
				["authorOptions"] = {
				},
				["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
				["desaturate"] = false,
				["zoom"] = 1,
				["auto"] = false,
				["glowScale"] = 1,
				["id"] = "쐐기 : 부족 의회 토템",
				["useglowColor"] = false,
				["frameStrata"] = 1,
				["width"] = 48,
				["glowYOffset"] = 0,
				["config"] = {
				},
				["inverse"] = false,
				["cooldownEdge"] = false,
				["icon"] = true,
				["conditions"] = {
				},
				["cooldown"] = false,
				["iconInset"] = 0,
			},
		},
		["7YMMToFEO3e"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["authorOptions"] = {
				},
				["customText"] = "",
				["yOffset"] = -165,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "event",
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["icon"] = true,
				["triggers"] = {
					{
						["trigger"] = {
							["useGroup_count"] = false,
							["matchesShowOn"] = "showOnActive",
							["names"] = {
								"불안정한 사술", -- [1]
								"불안정한 룬 징표", -- [2]
								"공포의 징표", -- [3]
								"공허의 씨앗", -- [4]
								"치명적인 병균", -- [5]
								"썩은 물", -- [6]
								"전도", -- [7]
								"어둠의 전조", -- [8]
								"어둠의 계시", -- [9]
							},
							["use_tooltip"] = false,
							["debuffType"] = "HARMFUL",
							["useName"] = true,
							["use_debuffClass"] = false,
							["unevent"] = "auto",
							["use_unit"] = true,
							["event"] = "Health",
							["buffShowOn"] = "showOnActive",
							["unit"] = "player",
							["use_absorbMode"] = true,
							["spellIds"] = {
							},
							["type"] = "aura2",
							["auranames"] = {
								"불안정한 사술", -- [1]
								"불안정한 룬 징표", -- [2]
								"공포의 징표", -- [3]
								"공허의 씨앗", -- [4]
								"치명적인 병균", -- [5]
								"썩은 물", -- [6]
								"전도", -- [7]
								"어둠의 전조", -- [8]
								"어둠의 계시", -- [9]
								"룬 징표", -- [10]
								"폭발적인 분출", -- [11]
							},
							["combineMatches"] = "showLowest",
							["subeventPrefix"] = "SPELL",
							["subeventSuffix"] = "_CAST_START",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customDuration"] = "",
							["events"] = "",
							["check"] = "update",
							["custom_type"] = "status",
							["custom"] = "function()\n    if not aura_env.last or GetTime() - aura_env.last > 0.1 then\n        aura_env.last = GetTime()\n        if WeakAuras.triggerState[aura_env.id].triggers[1] then\n            for unit in WA_IterateGroupMembers() do                \n                if unit ~= \"player\" and WeakAuras.CheckRange(unit, aura_env.Range[aura_env.name], \"<=\") then\n                    return true\n                end\n            end\n        end\n    end\nend",
						},
						["untrigger"] = {
							["custom"] = "function()\nreturn true\nend",
						},
					}, -- [2]
					["disjunctive"] = "custom",
					["customTriggerLogic"] = "function(t)\nreturn t[1]\nend",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["animation"] = {
					["start"] = {
						["colorR"] = 1,
						["scalex"] = 2.5,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["scaleType"] = "straightScale",
						["scaley"] = 2.5,
						["alpha"] = 0,
						["use_scale"] = true,
						["y"] = 0,
						["x"] = 0,
						["duration"] = "0.17",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
						["type"] = "custom",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["colorA"] = 1,
					},
					["main"] = {
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
						["type"] = "none",
						["scaleType"] = "pulse",
						["duration"] = "1",
						["scalex"] = 1.05,
						["duration_type"] = "seconds",
						["alpha"] = 0,
						["colorB"] = 1,
						["y"] = 0,
						["colorA"] = 1,
						["colorG"] = 1,
						["x"] = 0,
						["scaley"] = 1.05,
						["rotate"] = 0,
						["use_scale"] = true,
						["colorR"] = 1,
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "이격",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "기본 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 34,
						["anchorXOffset"] = 0,
						["text_visible"] = false,
					}, -- [1]
					{
						["border_offset"] = 0,
						["border_size"] = 3,
						["border_color"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["border_visible"] = true,
						["border_edge"] = "1 Pixel",
						["type"] = "subborder",
					}, -- [2]
				},
				["height"] = 80,
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["glowLines"] = 8,
				["keepAspectRatio"] = false,
				["glowFrequency"] = 0.25,
				["displayIcon"] = "136066",
				["parent"] = "쐐기 : 기타 0929",
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["desaturate"] = false,
				["useglowColor"] = false,
				["uid"] = "7YMMToFEO3e",
				["regionType"] = "icon",
				["xOffset"] = 0,
				["anchorFrameType"] = "SCREEN",
				["alpha"] = 1,
				["cooldownEdge"] = false,
				["glowLength"] = 10,
				["glowScale"] = 1,
				["semver"] = "1.0.87",
				["cooldownTextDisabled"] = false,
				["zoom"] = 0,
				["auto"] = true,
				["tocversion"] = 80205,
				["id"] = "쐐기 : 산개 디버프",
				["selfPoint"] = "CENTER",
				["frameStrata"] = 1,
				["width"] = 80,
				["glowYOffset"] = 0,
				["config"] = {
				},
				["inverse"] = false,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["encounterid"] = "2073",
					["use_encounterid"] = false,
					["role"] = {
						["multi"] = {
						},
					},
					["level"] = "",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["use_zone"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["use_zoneId"] = false,
					["level_operator"] = ">=",
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["mythic"] = true,
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "110",
					["zoneId"] = "8040",
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["use_size"] = true,
				},
				["actions"] = {
					["start"] = {
						["glow_action"] = "show",
						["message_type"] = "YELL",
						["do_message"] = false,
						["do_glow"] = false,
						["custom"] = "if aura_env and aura_env.state then\n    aura_env.name = aura_env.state.name\nend",
						["do_sound"] = false,
						["message"] = "",
						["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
						["do_custom"] = true,
						["glow_frame"] = "",
					},
					["init"] = {
						["custom"] = "aura_env.name = nil\n\naura_env.Range ={\n    [\"어둠의 전조\"] = 3,\n    [\"썩은 물\"] = 4,\n    [\"폭발적인 분출\"] = 4,\n    [\"공허의 씨앗\"] = 5,\n    [\"치명적인 병균\"] = 5,\n    [\"공포의 징표\"] = 5,\n    [\"불안정한 룬 징표\"] = 5,\n    [\"룬 징표\"] = 5,\n    [\"불안정한 사술\"] = 7,\n    [\"전도\"] = 7,\n    [\"어둠의 계시\"] = 22,\n}",
						["do_custom"] = true,
					},
					["finish"] = {
						["do_glow"] = false,
						["custom"] = "aura_env.name = nil\n",
						["glow_action"] = "hide",
						["do_custom"] = true,
						["glow_frame"] = "",
					},
				},
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 1,
							["variable"] = "show",
							["value"] = 1,
							["checks"] = {
								{
									["trigger"] = 1,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["message"] = "%n(이격) 대상!",
									["message_type"] = "YELL",
								},
								["property"] = "chat",
							}, -- [1]
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\ESPARK1.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [2]
						},
					}, -- [1]
					{
						["check"] = {
							["trigger"] = 2,
							["variable"] = "show",
							["value"] = 1,
							["checks"] = {
								{
									["trigger"] = 2,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
							},
						},
						["changes"] = {
							{
								["value"] = true,
								["property"] = "glow",
							}, -- [1]
							{
								["value"] = true,
								["property"] = "sub.1.text_visible",
							}, -- [2]
						},
					}, -- [2]
					{
						["check"] = {
							["trigger"] = 2,
							["variable"] = "show",
							["value"] = 0,
							["checks"] = {
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [1]
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [2]
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [3]
							},
						},
						["changes"] = {
							{
								["value"] = true,
								["property"] = "desaturate",
							}, -- [1]
						},
					}, -- [3]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "magic",
						},
						["changes"] = {
							{
								["value"] = {
									0, -- [1]
									0.92156862745098, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["property"] = "sub.2.border_color",
							}, -- [1]
						},
					}, -- [4]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "curse",
						},
						["changes"] = {
							{
								["value"] = {
									0.90196078431373, -- [1]
									0, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["property"] = "sub.2.border_color",
							}, -- [1]
						},
					}, -- [5]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "disease",
						},
						["changes"] = {
							{
								["value"] = {
									0.52156862745098, -- [1]
									0.32941176470588, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "sub.2.border_color",
							}, -- [1]
						},
					}, -- [6]
				},
				["cooldown"] = true,
				["glowBorder"] = false,
			},
		},
		["mG)Uy4oA34N"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1570539293,
			["allowUpdates"] = true,
			["data"] = {
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["controlledChildren"] = {
				},
				["borderBackdrop"] = "Blizzard Tooltip",
				["scale"] = 1,
				["border"] = false,
				["borderEdge"] = "None",
				["regionType"] = "group",
				["borderSize"] = 16,
				["borderColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["actions"] = {
					["start"] = {
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "aura",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["debuffType"] = "HELPFUL",
							["names"] = {
							},
							["unit"] = "player",
							["buffShowOn"] = "showOnActive",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = 1,
				},
				["anchorPoint"] = "CENTER",
				["internalVersion"] = 24,
				["yOffset"] = 0,
				["animation"] = {
					["start"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
				},
				["id"] = "여왕의 칙령 (딩까) 2",
				["authorOptions"] = {
				},
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["borderOffset"] = 5,
				["borderInset"] = 11,
				["selfPoint"] = "BOTTOMLEFT",
				["uid"] = "mG)Uy4oA34N",
				["config"] = {
				},
				["conditions"] = {
				},
				["load"] = {
					["talent2"] = {
						["multi"] = {
						},
					},
					["affixes"] = {
						["multi"] = {
						},
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["multi"] = {
						},
					},
					["use_class"] = false,
					["role"] = {
						["multi"] = {
						},
					},
					["talent3"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["ingroup"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["multi"] = {
						},
					},
				},
				["xOffset"] = -155.126220703125,
			},
		},
		["MEuhimUF28d"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = true,
				["xOffset"] = 0,
				["yOffset"] = 1080,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["do_glow"] = false,
						["do_custom"] = true,
						["custom"] = "local region = WeakAuras.GetRegion(aura_env.id, aura_env.cloneId)\nlocal plate = C_NamePlate.GetNamePlateForUnit(aura_env.state.unitId)\n\nif plate then\n    region:ClearAllPoints()\n    region:SetPoint(\"RIGHT\", plate, \"LEFT\", -5, 0)\nend\n\n\n\n\n",
					},
					["init"] = {
						["do_custom"] = false,
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["genericShowOn"] = "showOnActive",
							["event"] = "Health",
							["unit"] = "player",
							["names"] = {
							},
							["spellIds"] = {
							},
							["custom"] = "function(allstates, event, ...)\n    local unitId = ...\n    local subEv = select(2, ...)\n    local destGUID = select(8, ...)\n    local spellId = select(12, ...)\n    \n    if event == \"NAME_PLATE_UNIT_ADDED\" and unitId then\n        local _, icon = WA_GetUnitBuff(unitId, 209859)\n        local n = 1\n        local stack = 0\n        local BuffID = select(10, UnitBuff(unitId, n))\n        \n        while BuffID do\n            if BuffID == 209859 then \n                stack = stack + 1\n            end\n            n = n + 1\n            BuffID = select(10, UnitBuff(unitId, n))\n        end\n        \n        \n        if icon then\n            local state = {\n                show = true,\n                changed = true,\n                icon = icon,\n                stacks = stack,\n                guid = UnitGUID(unitId),\n                unitId = unitId\n            }\n            \n            allstates[UnitGUID(unitId)] = state\n            \n            return true\n        end\n        \n    elseif event == \"NAME_PLATE_UNIT_REMOVED\" and unitId then\n        local state = allstates[UnitGUID(unitId)]\n        if state then\n            state.show = false\n            state.changed = true\n            return true\n        end\n        \n    elseif subEv == \"SPELL_AURA_APPLIED\" and spellId == 209859 then\n        local guid = destGUID\n        \n        for _, plate in pairs(C_NamePlate.GetNamePlates()) do\n            unitId = plate.namePlateUnitToken\n            if UnitGUID(unitId) == guid then\n                local n = 1\n                local stack = 0\n                local BuffID = select(10, UnitBuff(unitId, n))\n                \n                while BuffID do\n                    if BuffID == 209859 then \n                        stack = stack + 1\n                    end\n                    n = n + 1\n                    BuffID = select(10, UnitBuff(unitId, n))\n                end\n                \n                local state = {\n                    show = true,\n                    changed = true,\n                    icon = select(3, GetSpellInfo(209859)),\n                    stacks = stack,\n                    guid = guid,\n                    unitId = unitId\n                }                \n                allstates[guid] = state\n                return true\n            end\n        end\n        \n    elseif subEv == \"SPELL_AURA_REMOVED\" and spellId == 209859 then\n        local state = allstates[destGUID]\n        if state then\n            state.show = false\n            state.changed = true\n            return true\n        end\n    end\n    \nend",
							["subeventPrefix"] = "SPELL",
							["check"] = "event",
							["events"] = "NAME_PLATE_UNIT_ADDED, NAME_PLATE_UNIT_REMOVED, COMBAT_LOG_EVENT_UNFILTERED",
							["custom_type"] = "stateupdate",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "all",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["text_text"] = "%s",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_selfPoint"] = "AUTO",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["rotateText"] = "NONE",
						["type"] = "subtext",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["border_color"] = {
						},
						["text_shadowYOffset"] = 0,
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "CENTER",
						["text_visible"] = true,
						["text_fontSize"] = 23,
						["anchorXOffset"] = 0,
						["text_font"] = "Friz Quadrata TT",
					}, -- [1]
				},
				["height"] = 25,
				["desaturate"] = false,
				["glowLines"] = 4,
				["glowLength"] = 10,
				["glowFrequency"] = 0.25,
				["displayIcon"] = 1041231,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["glowType"] = "ACShine",
				["glowThickness"] = 4,
				["authorOptions"] = {
				},
				["selfPoint"] = "CENTER",
				["config"] = {
				},
				["regionType"] = "icon",
				["glowYOffset"] = 0,
				["anchorFrameType"] = "SCREEN",
				["alpha"] = 1,
				["glowXOffset"] = 0,
				["semver"] = "1.0.87",
				["glowScale"] = 1.15,
				["auto"] = true,
				["cooldownTextDisabled"] = false,
				["zoom"] = 0,
				["useGlowColor"] = true,
				["tocversion"] = 80205,
				["id"] = "쐐기 : 강화",
				["icon"] = true,
				["frameStrata"] = 2,
				["width"] = 25,
				["parent"] = "쐐기 : 기타 0929",
				["uid"] = "MEuhimUF28d",
				["inverse"] = false,
				["useglowColor"] = false,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["level_operator"] = "==",
					["role"] = {
						["multi"] = {
						},
					},
					["use_difficulty"] = true,
					["size"] = {
						["single"] = "party",
						["multi"] = {
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["affixes"] = {
						["single"] = 7,
						["multi"] = {
							[16] = true,
						},
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
						},
					},
					["effectiveLevel"] = "120",
					["level"] = "120",
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["use_affixes"] = true,
					["faction"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["use_size"] = true,
				},
				["conditions"] = {
				},
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["glowBorder"] = false,
			},
		},
		["h)4ORuhiqz8"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["sparkWidth"] = 10,
				["text2Point"] = "CENTER",
				["text1FontSize"] = 23,
				["authorOptions"] = {
				},
				["displayText"] = "FELBLAZE RUSH ON YOU",
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["sparkRotation"] = 0,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["icon"] = true,
				["fontFlags"] = "OUTLINE",
				["icon_color"] = {
					1, -- [1]
					0.93725490196078, -- [2]
					0.94901960784314, -- [3]
					1, -- [4]
				},
				["text1Enabled"] = true,
				["keepAspectRatio"] = false,
				["selfPoint"] = "CENTER",
				["barColor"] = {
					0.59607843137255, -- [1]
					0, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["text1Containment"] = "INSIDE",
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["text1Point"] = "CENTER",
				["sparkOffsetY"] = 0,
				["text2FontFlags"] = "OUTLINE",
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["level_operator"] = "==",
					["role"] = {
						["multi"] = {
						},
					},
					["use_difficulty"] = true,
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["affixes"] = {
						["single"] = 117,
						["multi"] = {
							[117] = true,
						},
					},
					["talent"] = {
						["multi"] = {
						},
					},
					["zoneId"] = "934, 935",
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
						},
					},
					["effectiveLevel"] = "120",
					["level"] = "",
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["use_zoneId"] = false,
					["use_size"] = true,
				},
				["glowType"] = "buttonOverlay",
				["smoothProgress"] = false,
				["useAdjustededMin"] = false,
				["regionType"] = "aurabar",
				["text2FontSize"] = 24,
				["texture"] = "Raven White",
				["cooldownTextDisabled"] = false,
				["auto"] = false,
				["tocversion"] = 80205,
				["alpha"] = 1,
				["sparkColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["displayIcon"] = 237565,
				["outline"] = "OUTLINE",
				["borderBackdrop"] = "Blizzard Tooltip",
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["customText"] = "function()\n    if updateTime == nil then\n        updateTime = GetTime()\n    end\n    timeDelay = GetTime()\n    if timeDelay >= updateTime+1 then\n        _, _, count = WA_GetUnitDebuff(\"player\", 302420)\n        if count == nil then\n            count = 0    \n        end \n        updateTime = GetTime()\n        lastvalue = count\n        if count > 0 then\n            return count..\" 중첩\"\n        else return end\n    else\n        if lastvalue and lastvalue > 0 then\n            return lastvalue..\" 중첩\"\n        else return end\n    end\nend",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["sparkTexture"] = "Legionfall_BarSpark",
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "stateupdate",
							["subeventSuffix"] = "_CAST_START",
							["unit"] = "player",
							["duration"] = "1",
							["genericShowOn"] = "showOnActive",
							["names"] = {
							},
							["unevent"] = "auto",
							["spellIds"] = {
							},
							["custom"] = "function(allstates, event, ...)\n    local subevent = select(2, ...)\n    \n    if event == \"UNIT_SPELLCAST_START\" then\n        local caster, lineId, castSpellId = ...\n        if castSpellId == 302420 then\n            local sourceGUID = UnitGUID(caster)\n            local _, _, _, startMS, endMS = UnitCastingInfo(caster)\n            local duration = (endMS - startMS) / 1000\n            local expiration = endMS / 1000\n            allstates[sourceGUID] = {\n                show = true,\n                changed = true,\n                progressType = \"timed\",\n                duration = duration,\n                expirationTime = expiration,\n                autoHide = true,\n                name = \"숨기!\"\n            }\n            return true\n        end\n    elseif subevent == \"SPELL_CAST_START\" then\n        local _,_,_,sourceGUID,_,_,_,_,_,_,_,spellId = ...\n        if spellId == 302420 and not allstates[sourceGUID] then\n            allstates[sourceGUID] = {\n                show = true,\n                changed = true,\n                progressType = \"timed\",\n                duration = 9,\n                expirationTime = 9+GetTime(),\n                autoHide = true,\n                name = \"숨기!\"\n            }\n            return true\n        end \n    end\n    \n    \n    if event == \"UNIT_SPELLCAST_SUCCEEDED\" or event == \"UNIT_SPELLCAST_INTERRUPTED\" or event == \"UNIT_SPELLCAST_FAILED\" or event == \"UNIT_SPELLCAST_STOP\" or event == \"UNIT_SPELLCAST_FAILED_QUIET\" then\n        local caster,lineId,castSpellId = ...\n        if caster and casterSpellId == 302420 then\n            local sourceGUID = UnitGUID(caster)\n            if allstates[sourceGUID] then\n                allstates[sourceGUID].show = false\n                allstates[sourceGUID].changed = true\n                return true\n            end   \n        end \n    end   \nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED,UNIT_SPELLCAST_START,UNIT_SPELLCAST_SUCCEEDED,UNIT_SPELLCAST_INTERRUPTED, UNIT_SPELLCAST_FAILED, UNIT_SPELLCAST_FAILED_QUIET, UNIT_SPELLCAST_STOP",
							["check"] = "event",
							["event"] = "Chat Message",
							["subeventPrefix"] = "SPELL",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["unit"] = "player",
							["useName"] = true,
							["type"] = "aura2",
							["auranames"] = {
								"여왕의 칙령: 도피", -- [1]
							},
							["subeventPrefix"] = "SPELL",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [2]
					["disjunctive"] = "custom",
					["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
					["activeTriggerMode"] = 1,
				},
				["desc"] = "Shows the cooldown until the next quaking will happen - sometimes longer will pass by, but never shorter",
				["internalVersion"] = 24,
				["text2Enabled"] = false,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["backdropInFront"] = false,
				["spark"] = true,
				["desaturate"] = false,
				["stickyDuration"] = false,
				["text2"] = "%p",
				["useglowColor"] = false,
				["version"] = 88,
				["subRegions"] = {
					{
						["border_color"] = {
						},
						["type"] = "aurabar_bar",
					}, -- [1]
					{
						["text_shadowXOffset"] = 1,
						["type"] = "subtext",
						["text_text"] = "%p ",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "Friz Quadrata TT",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = -1,
						["text_selfPoint"] = "AUTO",
						["text_fontType"] = "None",
						["text_visible"] = true,
						["text_anchorPoint"] = "INNER_RIGHT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 55,
						["anchorXOffset"] = 0,
						["rotateText"] = "NONE",
					}, -- [2]
					{
						["text_shadowXOffset"] = 1,
						["text_text"] = " %c",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_selfPoint"] = "LEFT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["rotateText"] = "NONE",
						["type"] = "subtext",
						["text_anchorXOffset"] = 0,
						["text_color"] = {
							1, -- [1]
							0.97647058823529, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "Friz Quadrata TT",
						["text_shadowYOffset"] = -1,
						["text_fontType"] = "None",
						["text_anchorPoint"] = "LEFT",
						["text_fontSize"] = 47,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [3]
				},
				["height"] = 55,
				["text1FontFlags"] = "THICKOUTLINE",
				["anchorFrameType"] = "SCREEN",
				["sparkBlendMode"] = "ADD",
				["useAdjustededMax"] = false,
				["zoom"] = 0.24,
				["text2Containment"] = "INSIDE",
				["text2Font"] = "Friz Quadrata TT",
				["text1Font"] = "Expressway",
				["sparkHidden"] = "BOTH",
				["sparkRotationMode"] = "AUTO",
				["text2Color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["semver"] = "1.0.87",
				["borderInFront"] = false,
				["config"] = {
				},
				["icon_side"] = "LEFT",
				["text1Color"] = {
					1, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["xOffset"] = 0,
				["sparkHeight"] = 100,
				["text1"] = "%p",
				["glow"] = false,
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["justify"] = "LEFT",
				["backgroundColor"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.5, -- [4]
				},
				["id"] = "쐐기 : 도피",
				["actions"] = {
					["start"] = {
						["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\TempleBellHuge.ogg",
						["do_sound"] = true,
					},
					["init"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["finish"] = {
					},
				},
				["frameStrata"] = 1,
				["width"] = 649.00036621094,
				["sparkOffsetX"] = 0,
				["uid"] = "h)4ORuhiqz8",
				["inverse"] = true,
				["sparkDesature"] = false,
				["orientation"] = "HORIZONTAL",
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 2,
							["op"] = ">=",
							["variable"] = "stacks",
							["value"] = "3",
						},
						["changes"] = {
							{
								["value"] = {
									1, -- [1]
									0, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.text_color",
							}, -- [1]
						},
					}, -- [1]
				},
				["cooldown"] = true,
				["parent"] = "쐐기 : 기타 0929",
			},
		},
		["Rq2QiyhriVp"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["authorOptions"] = {
				},
				["customText"] = "",
				["yOffset"] = -165,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["icon"] = true,
				["useglowColor"] = false,
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["animation"] = {
					["start"] = {
						["colorR"] = 1,
						["scalex"] = 2.5,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["scaleType"] = "straightScale",
						["scaley"] = 2.5,
						["alpha"] = 0,
						["colorA"] = 1,
						["y"] = 0,
						["x"] = 0,
						["duration"] = "0.17",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
						["type"] = "custom",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["use_scale"] = true,
					},
					["main"] = {
						["colorR"] = 1,
						["scaleType"] = "pulse",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
						["duration"] = "1",
						["scaley"] = 1.05,
						["use_scale"] = true,
						["alpha"] = 0,
						["colorB"] = 1,
						["y"] = 0,
						["colorA"] = 1,
						["colorG"] = 1,
						["x"] = 0,
						["scalex"] = 1.05,
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["desaturate"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "이격",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "기본 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 34,
						["anchorXOffset"] = 0,
						["text_visible"] = false,
					}, -- [1]
					{
						["border_offset"] = 0,
						["border_size"] = 3,
						["border_color"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["border_visible"] = true,
						["border_edge"] = "1 Pixel",
						["type"] = "subborder",
					}, -- [2]
				},
				["height"] = 80,
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["glowLines"] = 8,
				["stickyDuration"] = false,
				["glowFrequency"] = 0.25,
				["displayIcon"] = 878213,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["parent"] = "쐐기 : 기타 0929",
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["encounterid"] = "2143",
					["use_encounterid"] = true,
					["use_zone"] = false,
					["level"] = "",
					["level_operator"] = ">=",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["use_role"] = false,
					["spec"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["zoneId"] = "8040",
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["mythic"] = true,
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "110",
					["faction"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
					["use_zoneId"] = false,
					["use_size"] = true,
					["role"] = {
						["multi"] = {
							["HEALER"] = true,
							["DAMAGER"] = true,
						},
					},
				},
				["config"] = {
				},
				["regionType"] = "icon",
				["glowLength"] = 10,
				["width"] = 80,
				["frameStrata"] = 1,
				["xOffset"] = 0,
				["keepAspectRatio"] = false,
				["glowScale"] = 1,
				["semver"] = "1.0.87",
				["cooldownTextDisabled"] = false,
				["zoom"] = 0,
				["auto"] = false,
				["tocversion"] = 80205,
				["id"] = "쐐기 : 다자르 도약",
				["selfPoint"] = "CENTER",
				["alpha"] = 1,
				["anchorFrameType"] = "SCREEN",
				["glowYOffset"] = 0,
				["uid"] = "Rq2QiyhriVp",
				["inverse"] = false,
				["actions"] = {
					["start"] = {
						["glow_action"] = "show",
						["message_type"] = "YELL",
						["do_message"] = false,
						["do_glow"] = false,
						["custom"] = "",
						["do_sound"] = false,
						["message"] = "",
						["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
						["do_custom"] = false,
						["glow_frame"] = "",
					},
					["init"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["finish"] = {
						["do_glow"] = false,
						["glow_action"] = "hide",
						["glow_frame"] = "",
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["subeventSuffix"] = "_CAST_START",
							["type"] = "custom",
							["names"] = {
							},
							["custom_type"] = "status",
							["subeventPrefix"] = "SPELL",
							["spellIds"] = {
							},
							["event"] = "Health",
							["customOverlay1"] = "",
							["customDuration"] = "function()\n    return (select(5,UnitCastingInfo(\"boss1\"))-select(4,UnitCastingInfo(\"boss1\")))/1000, select(5,UnitCastingInfo(\"boss1\"))/1000\nend\n\n\n\n\n\n",
							["customName"] = "",
							["events"] = "UNIT_SPELLCAST_DELAYED UNIT_SPELLCAST_FAILED UNIT_SPELLCAST_FAILED_QUIET UNIT_SPELLCAST_INTERRUPTED UNIT_SPELLCAST_START UNIT_SPELLCAST_STOP UNIT_SPELLCAST_SUCCEEDED UNIT_TARGET",
							["customIcon"] = "",
							["check"] = "event",
							["unit"] = "player",
							["custom"] = "function()\n    if UnitExists(\"boss1\") and UnitName(\"boss1\") == \"왕 다자르\" \n    and UnitCastingInfo(\"boss1\") == \"지진의 도약\" and UnitIsUnit(\"boss1target\", \"player\") then\n        return true\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["debuffType"] = "HELPFUL",
						},
						["untrigger"] = {
							["custom"] = "function()\nreturn true\nend",
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customDuration"] = "",
							["custom"] = "function()\n    if not aura_env.last or GetTime() - aura_env.last > 0.1 then\n        aura_env.last = GetTime()\n        if WeakAuras.triggerState[aura_env.id].triggers[1] then\n            for unit in WA_IterateGroupMembers() do\n                if unit ~= \"player\" and WeakAuras.CheckRange(unit, 22, \"<=\") then\n                    return true\n                end\n            end\n        end\n    end\nend",
							["check"] = "update",
							["custom_type"] = "status",
							["events"] = "",
						},
						["untrigger"] = {
							["custom"] = "function()\nreturn true\nend",
						},
					}, -- [2]
					["disjunctive"] = "custom",
					["customTriggerLogic"] = "function(t)\n    return t[1]\nend",
					["activeTriggerMode"] = -10,
				},
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 2,
							["variable"] = "show",
							["value"] = 1,
							["checks"] = {
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [1]
								{
									["trigger"] = 1,
									["variable"] = "show",
									["value"] = 1,
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["message"] = "%n(이격) 대상!",
									["message_type"] = "YELL",
								},
								["property"] = "chat",
							}, -- [1]
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\ESPARK1.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [2]
						},
					}, -- [1]
					{
						["check"] = {
							["trigger"] = 2,
							["variable"] = "show",
							["value"] = 0,
						},
						["changes"] = {
							{
								["value"] = true,
								["property"] = "desaturate",
							}, -- [1]
						},
					}, -- [2]
					{
						["check"] = {
							["trigger"] = 2,
							["variable"] = "show",
							["value"] = 1,
						},
						["changes"] = {
							{
								["value"] = true,
								["property"] = "glow",
							}, -- [1]
							{
								["value"] = true,
								["property"] = "sub.1.text_visible",
							}, -- [2]
						},
					}, -- [3]
				},
				["cooldown"] = true,
				["glowBorder"] = false,
			},
		},
		["1nWUE2yfvnI"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1570539293,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["glowLength"] = 10,
				["yOffset"] = 327.1112670898438,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["message_type"] = "SAY",
						["do_message"] = true,
						["message"] = "",
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["useName"] = true,
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["type"] = "aura2",
							["unit"] = "player",
							["auranames"] = {
								"멈춰라!", -- [1]
							},
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["selfPoint"] = "CENTER",
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "움직이지마",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "굵은 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["text_visible"] = true,
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_fontSize"] = 31,
						["anchorXOffset"] = 0,
						["text_fontType"] = "OUTLINE",
					}, -- [1]
				},
				["height"] = 64,
				["glowLines"] = 8,
				["glowFrequency"] = 0.25,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 1,
				["desaturate"] = false,
				["keepAspectRatio"] = false,
				["regionType"] = "icon",
				["useglowColor"] = false,
				["icon"] = true,
				["parent"] = "여왕의 칙령 (딩까) 2",
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["config"] = {
				},
				["anchorFrameType"] = "SCREEN",
				["width"] = 64,
				["alpha"] = 1,
				["zoom"] = 0,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "행진하라! 2",
				["authorOptions"] = {
				},
				["frameStrata"] = 1,
				["glowYOffset"] = 0,
				["cooldownTextDisabled"] = false,
				["uid"] = "1nWUE2yfvnI",
				["inverse"] = false,
				["load"] = {
					["class"] = {
						["multi"] = {
						},
					},
					["use_combat"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "twentyfive",
						["multi"] = {
							["twentyfive"] = true,
						},
					},
				},
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["conditions"] = {
				},
				["xOffset"] = 330,
				["glowBorder"] = false,
			},
		},
		["O0tIryFrMCa"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1570539293,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["yOffset"] = 327.1112670898438,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["message_type"] = "SAY",
						["do_message"] = true,
						["message"] = "",
					},
					["finish"] = {
					},
					["init"] = {
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["type"] = "aura2",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["names"] = {
							},
							["spellIds"] = {
							},
							["subeventPrefix"] = "SPELL",
							["useName"] = true,
							["unit"] = "player",
							["auranames"] = {
								"행진하라!", -- [1]
							},
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["animation"] = {
					["start"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["main"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
					["finish"] = {
						["duration_type"] = "seconds",
						["type"] = "none",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "움직여!",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "굵은 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["text_visible"] = true,
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_fontSize"] = 31,
						["anchorXOffset"] = 0,
						["text_fontType"] = "OUTLINE",
					}, -- [1]
				},
				["height"] = 64,
				["glowLines"] = 8,
				["glowFrequency"] = 0.25,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 1,
				["glowXOffset"] = 0,
				["xOffset"] = 330,
				["regionType"] = "icon",
				["load"] = {
					["class"] = {
						["multi"] = {
						},
					},
					["use_combat"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "twentyfive",
						["multi"] = {
							["twentyfive"] = true,
						},
					},
				},
				["useglowColor"] = false,
				["icon"] = true,
				["desaturate"] = false,
				["config"] = {
				},
				["width"] = 64,
				["anchorFrameType"] = "SCREEN",
				["alpha"] = 1,
				["zoom"] = 0,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "행진하라!",
				["authorOptions"] = {
				},
				["frameStrata"] = 1,
				["glowYOffset"] = 0,
				["cooldownTextDisabled"] = false,
				["uid"] = "O0tIryFrMCa",
				["inverse"] = false,
				["glowLength"] = 10,
				["selfPoint"] = "CENTER",
				["conditions"] = {
				},
				["parent"] = "여왕의 칙령 (딩까) 2",
				["glowBorder"] = false,
			},
		},
		["8sMWtCP7Lr8"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["sparkWidth"] = 15,
				["text2Point"] = "CENTER",
				["text1FontSize"] = 24,
				["xOffset"] = 0,
				["displayText"] = "%s",
				["yOffset"] = -245,
				["anchorPoint"] = "CENTER",
				["sparkRotation"] = 0,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
						["message"] = "괴저 20중",
						["glow_action"] = "show",
						["message_type"] = "SAY",
						["do_glow"] = false,
						["do_message"] = true,
						["glow_frame"] = "WeakAuras:공용 : 괴저",
					},
					["init"] = {
					},
					["finish"] = {
						["do_glow"] = false,
						["glow_action"] = "hide",
						["message_type"] = "SAY",
						["glow_frame"] = "WeakAuras:공용 : 괴저",
						["do_message"] = true,
						["message"] = "괴저 끝",
					},
				},
				["fontFlags"] = "OUTLINE",
				["icon_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["text1Enabled"] = true,
				["selfPoint"] = "CENTER",
				["barColor"] = {
					1, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["desaturate"] = false,
				["text1Point"] = "BOTTOMRIGHT",
				["sparkOffsetY"] = 0,
				["text2FontFlags"] = "OUTLINE",
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = "==",
					["level_operator"] = "==",
					["use_encounterid"] = false,
					["use_zone"] = false,
					["role"] = {
						["single"] = "TANK",
						["multi"] = {
							["TANK"] = true,
						},
					},
					["level"] = "",
					["use_difficulty"] = true,
					["use_zoneId"] = false,
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["use_size"] = true,
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["use_role"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["use_affixes"] = true,
					["faction"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "120",
					["class"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["encounterid"] = "",
					["affixes"] = {
						["single"] = 4,
					},
					["talent2"] = {
						["multi"] = {
						},
					},
					["race"] = {
						["multi"] = {
						},
					},
				},
				["smoothProgress"] = false,
				["useAdjustededMin"] = false,
				["regionType"] = "aurabar",
				["text2FontSize"] = 24,
				["texture"] = "Raven White",
				["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
				["auto"] = false,
				["tocversion"] = 80205,
				["text2Enabled"] = false,
				["uid"] = "8sMWtCP7Lr8",
				["displayIcon"] = 458736,
				["outline"] = "OUTLINE",
				["borderBackdrop"] = "Blizzard Tooltip",
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["customText"] = "function()\n    if aura_env and aura_env.state and aura_env.state.stacks then\n        local stack = aura_env.state.stacks\n        if stack < 20 then\n            return \"|cffFF7D00\"..(stack * -2) ..\"%\"\n        else\n            return \"|cffFF0000\"..(stack * -2) ..\"%\"   \n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
				["customTextUpdate"] = "event",
				["triggers"] = {
					{
						["trigger"] = {
							["useStacks"] = true,
							["useGroup_count"] = false,
							["matchesShowOn"] = "showOnActive",
							["subeventPrefix"] = "SPELL",
							["use_tooltip"] = false,
							["unit"] = "player",
							["buffShowOn"] = "showOnActive",
							["debuffType"] = "HARMFUL",
							["subeventSuffix"] = "_CAST_START",
							["type"] = "aura2",
							["use_debuffClass"] = false,
							["auraspellids"] = {
								"209858", -- [1]
							},
							["useExactSpellId"] = true,
							["stacksOperator"] = ">",
							["countOperator"] = ">",
							["spellIds"] = {
								209858, -- [1]
							},
							["stacks"] = "19",
							["useCount"] = true,
							["count"] = "19",
							["event"] = "Health",
							["auranames"] = {
							},
							["combineMatches"] = "showLowest",
							["custom_hide"] = "timed",
							["names"] = {
								"괴저성 부패", -- [1]
							},
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "all",
					["activeTriggerMode"] = -10,
				},
				["alpha"] = 1,
				["internalVersion"] = 24,
				["sparkColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["animation"] = {
					["start"] = {
						["colorR"] = 1,
						["scalex"] = 1.8,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["scaleType"] = "straightScale",
						["scaley"] = 1.8,
						["alpha"] = 0,
						["use_scale"] = true,
						["y"] = 0,
						["x"] = 0,
						["duration"] = "0.15",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
						["type"] = "custom",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["colorA"] = 1,
					},
					["main"] = {
						["type"] = "custom",
						["colorR"] = 0.36862745098039,
						["use_color"] = true,
						["duration"] = "1",
						["colorType"] = "straightColor",
						["scaley"] = 1,
						["alpha"] = 0,
						["x"] = 0,
						["y"] = 0,
						["colorB"] = 0,
						["colorG"] = 1,
						["colorA"] = 1,
						["colorFunc"] = "    function(progress, r1, g1, b1, a1, r2, g2, b2, a2)\n      return r1 + (progress * (r2 - r1)), g1 + (progress * (g2 - g1)), b1 + (progress * (b2 - b1)), a1 + (progress * (a2 - a1))\n    end\n  ",
						["rotate"] = 0,
						["duration_type"] = "relative",
						["scalex"] = 1,
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["backdropInFront"] = false,
				["config"] = {
				},
				["text1FontFlags"] = "OUTLINE",
				["stickyDuration"] = false,
				["spark"] = false,
				["text1Containment"] = "INSIDE",
				["version"] = 88,
				["subRegions"] = {
					{
						["border_color"] = {
						},
						["type"] = "aurabar_bar",
					}, -- [1]
					{
						["text_shadowXOffset"] = 1,
						["type"] = "subtext",
						["text_text"] = "%c",
						["text_color"] = {
							1, -- [1]
							0.95294117647059, -- [2]
							0.95294117647059, -- [3]
							1, -- [4]
						},
						["text_font"] = "[WoW] 기본 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = -1,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "None",
						["text_anchorPoint"] = "INNER_RIGHT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 30,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [2]
					{
						["text_shadowXOffset"] = 1,
						["type"] = "subtext",
						["text_text"] = " %p",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "[WoW] 기본 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = -1,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "None",
						["text_anchorPoint"] = "INNER_LEFT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 30,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [3]
				},
				["height"] = 42,
				["useTooltip"] = false,
				["icon"] = true,
				["sparkBlendMode"] = "ADD",
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["width"] = 255,
				["text2Containment"] = "INSIDE",
				["text1Color"] = {
					1, -- [1]
					0.9921568627451, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["text1Font"] = "Friz Quadrata TT",
				["text2Font"] = "Friz Quadrata TT",
				["sparkHidden"] = "NEVER",
				["text2Color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["cooldownTextDisabled"] = false,
				["borderInFront"] = false,
				["semver"] = "1.0.87",
				["icon_side"] = "RIGHT",
				["backgroundColor"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.5, -- [4]
				},
				["authorOptions"] = {
				},
				["sparkHeight"] = 50,
				["sparkOffsetX"] = 0,
				["text1"] = "%c",
				["glow"] = false,
				["justify"] = "CENTER",
				["text2"] = "%p",
				["id"] = "쐐기 : 괴저",
				["sparkRotationMode"] = "AUTO",
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["useAdjustededMax"] = false,
				["zoom"] = 0.45,
				["inverse"] = false,
				["sparkDesature"] = false,
				["orientation"] = "HORIZONTAL",
				["conditions"] = {
				},
				["cooldown"] = true,
				["parent"] = "쐐기 : 기타 0929",
			},
		},
		["tfd4Z5fghwj"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["xOffset"] = 0,
				["customText"] = "function()\n    if aura_env and aura_env.state and aura_env.state.name then\n        if aura_env.state.name == \"톱날 이빨\" then\n            return \"물리 +50%\"\n        elseif aura_env.state.name == \"으스러진 방어\" then\n            return \"물리 +200%\"\n        elseif aura_env.state.name == \"심장 공격\" then\n            return \"피해 +\"..20*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"소탕의 모래\" then\n            return \"피해 +30%\"\n        elseif aura_env.state.name == \"크게 깨물기\" then\n            return \"체력 -\"..5*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"정신 도려내기\" then\n            return \"체력 -\"..10*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"부패시키는 손길\" then\n            return \"피해 +15%\"    \n        elseif aura_env.state.name == \"기름친 칼날\" then\n            return \"치감 70%\"      \n        elseif aura_env.state.name == \"독니 일격\" then\n            return \"자연 +100%\"    \n        elseif aura_env.state.name == \"저주받은 베기\" then\n            return \"피해 +\"..15*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"파열의 일격\" then\n            return \"방어 -\"..10*aura_env.state.stacks..\"%\"\n        elseif aura_env.state.name == \"아제라이트 심장추적자\" then\n            local n = 1\n            local stack = 0\n            local name = select(1, UnitDebuff(\"player\", n))\n            \n            while name do\n                if name == \"아제라이트 심장추적자\" then \n                    stack = stack + 1\n                end\n                n = n + 1\n                name = select(1, UnitDebuff(\"player\", n))\n            end\n            return \"치감 \"..33*stack..\"%\"    \n        elseif aura_env.state.name == \"방해의 절단\" or aura_env.state.name == \"이빨 분쇄자\" then\n            return \"가속 -35%\"\n        elseif aura_env.state.name == \"썩어가는 상처\" then\n            return \"치감 25%\"    \n        elseif aura_env.state.name == \"상처 감염\" then\n            return \"치감 20%\"    \n        elseif aura_env.state.name == \"역병 걸음\" then\n            return \"치감 25%\"    \n        elseif aura_env.state.name == \"우둘투둘한 이빨\" then\n            return \"치감 \"..10*aura_env.state.stacks..\"%\"\n        else\n            return \"\"\n        end\n    end\nend",
				["yOffset"] = -165,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["glow_action"] = "show",
						["message_type"] = "YELL",
						["do_message"] = false,
						["do_glow"] = false,
						["custom"] = "\n\n",
						["do_sound"] = false,
						["message"] = "",
						["sound"] = "Sound\\Spells\\SimonGame_Visual_BadPress.ogg",
						["do_custom"] = false,
						["glow_frame"] = "",
					},
					["init"] = {
						["custom"] = "\n\n",
						["do_custom"] = false,
					},
					["finish"] = {
						["do_glow"] = false,
						["glow_action"] = "hide",
						["glow_frame"] = "",
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["useGroup_count"] = false,
							["matchesShowOn"] = "showOnActive",
							["names"] = {
								"공포의 오라", -- [1]
								"활력 주입", -- [2]
								"힘의 속삭임", -- [3]
								"지각 변동", -- [4]
								"숨 막히는 소금물", -- [5]
								"흉포한 포식자", -- [6]
								"황금 뱉기", -- [7]
								"교수형 집행인의 올가미", -- [8]
								"심연의 역류", -- [9]
							},
							["use_tooltip"] = false,
							["debuffType"] = "HARMFUL",
							["useName"] = true,
							["use_debuffClass"] = false,
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["buffShowOn"] = "showOnActive",
							["custom_hide"] = "timed",
							["spellIds"] = {
							},
							["type"] = "aura2",
							["auranames"] = {
								"266238", -- [1]
								"톱날 이빨", -- [2]
								"심장 공격", -- [3]
								"크게 깨물기", -- [4]
								"부패시키는 손길", -- [5]
								"정신 도려내기", -- [6]
								"기름친 칼날", -- [7]
								"저주받은 베기", -- [8]
								"독니 일격", -- [9]
								"아제라이트 심장추적자", -- [10]
								"방해의 절단", -- [11]
								"썩어가는 상처", -- [12]
								"상처 감염", -- [13]
								"역병 걸음", -- [14]
								"우둘투둘한 이빨", -- [15]
								"절단 칼날", -- [16]
								"소탕의 모래", -- [17]
								"이빨 분쇄자", -- [18]
								"274633", -- [19]
							},
							["combineMatches"] = "showLowest",
							["subeventPrefix"] = "SPELL",
							["unit"] = "player",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["disjunctive"] = "any",
					["customTriggerLogic"] = "",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["selfPoint"] = "CENTER",
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["version"] = 88,
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "%c",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "기본 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 34,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [1]
					{
						["text_shadowXOffset"] = 0,
						["text_text"] = "%s",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_selfPoint"] = "AUTO",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["rotateText"] = "NONE",
						["type"] = "subtext",
						["text_anchorXOffset"] = 5,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_font"] = "기본 글꼴",
						["text_shadowYOffset"] = 0,
						["text_fontType"] = "OUTLINE",
						["text_anchorPoint"] = "INNER_BOTTOMRIGHT",
						["text_visible"] = true,
						["text_fontSize"] = 35,
						["anchorXOffset"] = 0,
						["text_anchorYOffset"] = -7,
					}, -- [2]
					{
						["border_offset"] = 0,
						["border_size"] = 3,
						["border_color"] = {
							1, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["border_visible"] = true,
						["border_edge"] = "1 Pixel",
						["type"] = "subborder",
					}, -- [3]
				},
				["height"] = 65,
				["desaturate"] = false,
				["glowLines"] = 8,
				["useglowColor"] = false,
				["glowFrequency"] = 0.25,
				["displayIcon"] = 136066,
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["color"] = {
					1, -- [1]
					0.98823529411765, -- [2]
					0.95686274509804, -- [3]
					1, -- [4]
				},
				["animation"] = {
					["start"] = {
						["colorR"] = 1,
						["scalex"] = 2.5,
						["alphaType"] = "straight",
						["colorB"] = 1,
						["colorG"] = 1,
						["alphaFunc"] = "    function(progress, start, delta)\n      return start + (progress * delta)\n    end\n  ",
						["use_alpha"] = true,
						["scaleType"] = "straightScale",
						["scaley"] = 2.5,
						["alpha"] = 0,
						["use_scale"] = true,
						["y"] = 0,
						["x"] = 0,
						["duration"] = "0.17",
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      return startX + (progress * (scaleX - startX)), startY + (progress * (scaleY - startY))\n    end\n  ",
						["type"] = "custom",
						["rotate"] = 0,
						["duration_type"] = "seconds",
						["colorA"] = 1,
					},
					["main"] = {
						["colorR"] = 1,
						["type"] = "none",
						["use_scale"] = true,
						["scaley"] = 1.05,
						["duration"] = "1",
						["duration_type"] = "seconds",
						["alpha"] = 0,
						["scalex"] = 1.05,
						["y"] = 0,
						["colorA"] = 1,
						["colorG"] = 1,
						["colorB"] = 1,
						["x"] = 0,
						["rotate"] = 0,
						["scaleFunc"] = "    function(progress, startX, startY, scaleX, scaleY)\n      local angle = (progress * 2 * math.pi) - (math.pi / 2)\n      return startX + (((math.sin(angle) + 1)/2) * (scaleX - 1)), startY + (((math.sin(angle) + 1)/2) * (scaleY - 1))\n    end\n  ",
						["scaleType"] = "pulse",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["config"] = {
				},
				["regionType"] = "icon",
				["glowLength"] = 10,
				["anchorFrameType"] = "SCREEN",
				["alpha"] = 1,
				["icon"] = true,
				["authorOptions"] = {
				},
				["tocversion"] = 80205,
				["semver"] = "1.0.87",
				["cooldownTextDisabled"] = false,
				["zoom"] = 0,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "쐐기 : 탱커 디버프",
				["glowXOffset"] = 0,
				["frameStrata"] = 1,
				["width"] = 65,
				["glowYOffset"] = 0,
				["uid"] = "tfd4Z5fghwj",
				["inverse"] = false,
				["parent"] = "쐐기 : 기타 0929",
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["encounterid"] = "2073",
					["use_encounterid"] = false,
					["role"] = {
						["single"] = "TANK",
						["multi"] = {
						},
					},
					["level"] = "",
					["level_operator"] = ">=",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["use_role"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["use_zone"] = false,
					["use_zoneId"] = false,
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["mythic"] = true,
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "110",
					["class"] = {
						["multi"] = {
						},
					},
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
					["zoneId"] = "8040",
					["race"] = {
						["multi"] = {
						},
					},
					["use_size"] = true,
				},
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = 1,
							["variable"] = "show",
							["value"] = 1,
							["checks"] = {
								{
									["trigger"] = 1,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["value"] = 1,
									["variable"] = "show",
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\BITE.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [1]
						},
					}, -- [1]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "magic",
						},
						["changes"] = {
							{
								["value"] = {
									0, -- [1]
									0.92549019607843, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [2]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "curse",
						},
						["changes"] = {
							{
								["value"] = {
									0.87450980392157, -- [1]
									0, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [3]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "poison",
						},
						["changes"] = {
							{
								["value"] = {
									0.2, -- [1]
									0.70196078431373, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [4]
					{
						["check"] = {
							["trigger"] = 1,
							["op"] = "==",
							["variable"] = "debuffClass",
							["value"] = "disease",
						},
						["changes"] = {
							{
								["value"] = {
									0.52156862745098, -- [1]
									0.32941176470588, -- [2]
									0, -- [3]
									1, -- [4]
								},
								["property"] = "sub.3.border_color",
							}, -- [1]
						},
					}, -- [5]
				},
				["cooldown"] = true,
				["glowBorder"] = false,
			},
		},
		["6jMDSoO5YpB"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1570539293,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["parent"] = "여왕의 칙령 (딩까) 2",
				["yOffset"] = 327.1112670898438,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["cooldownEdge"] = false,
				["actions"] = {
					["start"] = {
						["message_type"] = "SAY",
						["do_message"] = true,
						["message"] = "{가위표}보주 밟지마!{가위표}",
					},
					["init"] = {
					},
					["finish"] = {
					},
				},
				["useglowColor"] = false,
				["internalVersion"] = 24,
				["glowXOffset"] = 0,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["desaturate"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["subRegions"] = {
					{
						["text_shadowXOffset"] = 0,
						["type"] = "subtext",
						["text_text"] = "보주 밟지 말고",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "굵은 글꼴",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = 0,
						["text_selfPoint"] = "AUTO",
						["text_visible"] = true,
						["text_anchorPoint"] = "OUTER_BOTTOM",
						["anchorYOffset"] = 0,
						["text_fontSize"] = 31,
						["anchorXOffset"] = 0,
						["text_fontType"] = "OUTLINE",
					}, -- [1]
				},
				["height"] = 64,
				["load"] = {
					["class"] = {
						["multi"] = {
						},
					},
					["use_combat"] = true,
					["spec"] = {
						["multi"] = {
						},
					},
					["size"] = {
						["single"] = "twentyfive",
						["multi"] = {
							["twentyfive"] = true,
						},
					},
				},
				["glowFrequency"] = 0.25,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 1,
				["authorOptions"] = {
				},
				["glowLength"] = 10,
				["regionType"] = "icon",
				["triggers"] = {
					{
						["trigger"] = {
							["useName"] = true,
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["names"] = {
							},
							["spellIds"] = {
							},
							["unit"] = "player",
							["type"] = "aura2",
							["subeventPrefix"] = "SPELL",
							["auranames"] = {
								"복종하라!", -- [1]
							},
							["debuffType"] = "HARMFUL",
						},
						["untrigger"] = {
						},
					}, -- [1]
					["activeTriggerMode"] = -10,
				},
				["icon"] = true,
				["selfPoint"] = "CENTER",
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["uid"] = "6jMDSoO5YpB",
				["width"] = 64,
				["glowYOffset"] = 0,
				["alpha"] = 1,
				["cooldownTextDisabled"] = false,
				["auto"] = true,
				["glowScale"] = 1,
				["id"] = "복종",
				["xOffset"] = -32,
				["frameStrata"] = 1,
				["anchorFrameType"] = "SCREEN",
				["zoom"] = 0,
				["config"] = {
				},
				["inverse"] = false,
				["glowLines"] = 8,
				["stickyDuration"] = false,
				["conditions"] = {
				},
				["keepAspectRatio"] = false,
				["glowBorder"] = false,
			},
		},
		["k9HarAIO8z("] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["outline"] = "OUTLINE",
				["authorOptions"] = {
				},
				["borderBackdrop"] = "Blizzard Tooltip",
				["xOffset"] = -0.0001220703125,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["displayText"] = "FELBLAZE RUSH ON YOU",
				["displayIcon"] = 136195,
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["actions"] = {
					["start"] = {
						["message"] = "",
						["do_sound"] = false,
						["message_type"] = "YELL",
						["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\splash.ogg",
						["do_message"] = false,
					},
					["init"] = {
						["custom"] = "",
						["do_custom"] = false,
					},
					["finish"] = {
						["do_custom"] = false,
						["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\shot.ogg",
						["do_sound"] = false,
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["duration"] = "5",
							["genericShowOn"] = "showOnActive",
							["subeventPrefix"] = "SPELL",
							["customIcon"] = "function()\n    return\"Interface\\\\Icons\\\\ability_devour\"\nend",
							["debuffType"] = "HELPFUL",
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["event"] = "Health",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"공포스러운 얼굴\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["customName"] = "function()\n    return \"숨기!\"\nend",
							["spellIds"] = {
							},
							["dynamicDuration"] = false,
							["custom_type"] = "event",
							["names"] = {
							},
							["unit"] = "player",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "event",
							["duration"] = "5",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customName"] = "function()\n    return \"모여서 뽑기!\"\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_demonhunter_soulcleave2\"\nend",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"영혼 분리\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [2]
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "2",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customName"] = "function()\n    return \"광역기!\"\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\spell_shaman_staticshock\"\nend",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"전하 충격\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["custom_type"] = "event",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [3]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "event",
							["duration"] = "2.5",
							["genericShowOn"] = "showOnActive",
							["subeventPrefix"] = "SPELL",
							["unevent"] = "auto",
							["customName"] = "function()\n    return \"고개 돌리기!\"\nend",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"실명의 모래\" then\n        return true    \n    end\nend    \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_rogue_bloodyeye\"\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["event"] = "Chat Message",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [4]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "event",
							["duration"] = "3",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customName"] = "function()\n    return \"광역기!\"\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\spell_nature_unrelentingstorm\"\nend\n\n\n",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"전하 소모\" then\n        return true    \n    end\nend",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [5]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "event",
							["duration"] = "5",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customName"] = "function()\n    return \"버프 시전 중!\"\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\spell_nature_regeneration_02\"\nend",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,spellId = ...\n    if message ==\"SPELL_CAST_START\" and spellId == 269670 then\n        return true    \n    end\nend    \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [6]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "stateupdate",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customDuration"] = "",
							["customName"] = "",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED,UNIT_SPELLCAST_START,UNIT_SPELLCAST_SUCCEEDED,UNIT_SPELLCAST_INTERRUPTED, UNIT_SPELLCAST_FAILED, UNIT_SPELLCAST_FAILED_QUIET, UNIT_SPELLCAST_STOP",
							["customIcon"] = "",
							["check"] = "event",
							["subeventSuffix"] = "_CAST_START",
							["custom"] = "function(allstates, event, ...)\n    local subevent = select(2, ...)\n    \n    if event == \"UNIT_SPELLCAST_START\" and select(3, ...) == 260773 then\n        local caster, lineId = ...\n        local sourceGUID = UnitGUID(caster)\n        local _, _, icon, startMS, endMS = UnitCastingInfo(caster)\n        local duration = (endMS - startMS) / 1000\n        local expiration = endMS / 1000\n        allstates[sourceGUID] = {\n            show = true,\n            changed = true,\n            progressType = \"timed\",\n            icon = icon,\n            duration = duration,\n            expirationTime = expiration,\n            autoHide = true,\n            name = \"광역기!\"\n        }\n        return true\n    elseif subevent == \"SPELL_CAST_START\" and select(12, ...) == 260773 then\n        local _,_,_,sourceGUID = ...\n        if not allstates[sourceGUID] then\n            allstates[sourceGUID] = {\n                show = true,\n                changed = true,\n                progressType = \"timed\",\n                duration = 5,\n                icon = 136121,\n                expirationTime = 5+GetTime(),\n                autoHide = true,\n                name = \"광역기!\"\n            }\n            return true\n        end \n    end\n    \n    \n    if (event == \"UNIT_SPELLCAST_SUCCEEDED\" or event == \"UNIT_SPELLCAST_INTERRUPTED\" or event == \"UNIT_SPELLCAST_FAILED\" or event == \"UNIT_SPELLCAST_STOP\" or event == \"UNIT_SPELLCAST_FAILED_QUIET\") and select(3, ...) == 260773 then\n        local caster,lineId = ...\n        if caster then\n            local sourceGUID = UnitGUID(caster)\n            if allstates[sourceGUID] then\n                allstates[sourceGUID].show = false\n                allstates[sourceGUID].changed = true\n                return true\n            end   \n        end \n    end   \nend\n\n\n\n\n\n\n\n\n\n",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
							["custom"] = "",
						},
					}, -- [7]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "event",
							["duration"] = "6",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customName"] = "function()\n    return \"숨기!\"\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_rogue_fanofknives\"\nend",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"번쩍이는 단검\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [8]
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["unevent"] = "auto",
							["subeventPrefix"] = "SPELL",
							["duration"] = "4",
							["event"] = "Health",
							["unit"] = "player",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customName"] = "function()\n    return \"포격!\"\nend",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"육중한 강타\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\ability_ironmaidens_deployturret\"\nend",
							["use_unit"] = true,
							["custom_type"] = "event",
							["use_absorbMode"] = true,
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [9]
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["unevent"] = "auto",
							["subeventPrefix"] = "SPELL",
							["duration"] = "5",
							["event"] = "Health",
							["unit"] = "player",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["customName"] = "function()\n    return \"미사일 폭격!\"\nend",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,spellId = ...\n    if message ==\"SPELL_CAST_START\" and spellId == 276229 then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["customIcon"] = "function()\n    return \"Interface\\\\Icons\\\\inv_misc_missilelarge_red\"\nend",
							["use_unit"] = true,
							["custom_type"] = "event",
							["use_absorbMode"] = true,
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [10]
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["custom_type"] = "event",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customDuration"] = "function()\n    return 6, 6+GetTime()\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["customName"] = "function()\n    return \"무조건 차단!\"\nend",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED, CHAT_MSG_MONSTER_YELL",
							["customIcon"] = "function()\n    return\"Interface\\\\Icons\\\\ability_creature_disease_02\"\nend",
							["check"] = "event",
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,_,_,_,_,spellName = ...\n    if message ==\"SPELL_CAST_START\" and spellName == \"독 회오리\" then\n        return true    \n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
							["dynamicDuration"] = true,
							["custom_hide"] = "custom",
						},
						["untrigger"] = {
							["custom"] = "function(event,...)\n    local _,message,_,_,_,_,_,_,destName,_,_,_,spellName,_,extraSpellName = ...\n    \n    if message ==\"SPELL_CAST_SUCCESS\" and spellName == \"독 회오리\" then\n        return true    \n    elseif message ==\"SPELL_INTERRUPT\" and extraSpellName == \"독 회오리\" then\n        return true    \n    elseif message ==\"UNIT_DIED\" and destName ==\"현자 자나잘\" then\n        return true    \n    elseif event == \"CHAT_MSG_MONSTER_YELL\" then\n        local msg, npc = select(1, ...) \n        if npc == \"현자 자나잘\" and strfind(msg, \"부디...\") then\n            return true\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
						},
					}, -- [11]
					["disjunctive"] = "any",
					["customTriggerLogic"] = "",
					["activeTriggerMode"] = -10,
				},
				["sparkRotation"] = 0,
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["icon"] = true,
				["fontFlags"] = "OUTLINE",
				["icon_color"] = {
					1, -- [1]
					0.93725490196078, -- [2]
					0.94901960784314, -- [3]
					1, -- [4]
				},
				["internalVersion"] = 24,
				["animation"] = {
					["start"] = {
						["type"] = "preset",
						["duration_type"] = "seconds",
						["preset"] = "grow",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
						["preset"] = "bounceDecay",
					},
				},
				["selfPoint"] = "CENTER",
				["backdropInFront"] = false,
				["sparkColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["barColor"] = {
					1, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["stickyDuration"] = false,
				["sparkOffsetY"] = 0,
				["anchorFrameType"] = "SCREEN",
				["version"] = 88,
				["subRegions"] = {
					{
						["border_color"] = {
						},
						["type"] = "aurabar_bar",
					}, -- [1]
					{
						["text_shadowXOffset"] = 1,
						["type"] = "subtext",
						["text_text"] = "%p ",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "Friz Quadrata TT",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = -1,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "None",
						["text_anchorPoint"] = "INNER_RIGHT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 55,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [2]
					{
						["text_shadowXOffset"] = 1,
						["type"] = "subtext",
						["text_text"] = " %n",
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["text_font"] = "Friz Quadrata TT",
						["text_shadowColor"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["text_shadowYOffset"] = -1,
						["text_selfPoint"] = "AUTO",
						["rotateText"] = "NONE",
						["text_fontType"] = "None",
						["text_anchorPoint"] = "INNER_LEFT",
						["anchorYOffset"] = 0,
						["text_justify"] = "CENTER",
						["text_fontSize"] = 47,
						["anchorXOffset"] = 0,
						["text_visible"] = true,
					}, -- [3]
				},
				["height"] = 55.000015258789,
				["alpha"] = 1,
				["load"] = {
					["ingroup"] = {
						["multi"] = {
						},
					},
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["encounterid"] = "2086, 2087, 2102, 2104, 2108, 2113, 2124, 2125, 2126, 2127, 2140",
					["use_encounterid"] = true,
					["role"] = {
						["multi"] = {
						},
					},
					["level"] = "",
					["size"] = {
						["single"] = "party",
						["multi"] = {
							["party"] = true,
						},
					},
					["use_effectiveLevel"] = true,
					["talent2"] = {
						["multi"] = {
						},
					},
					["use_level"] = false,
					["talent"] = {
						["multi"] = {
						},
					},
					["spec"] = {
						["multi"] = {
						},
					},
					["use_zoneId"] = false,
					["race"] = {
						["multi"] = {
						},
					},
					["difficulty"] = {
						["single"] = "challenge",
						["multi"] = {
							["challenge"] = true,
						},
					},
					["effectiveLevel"] = "110",
					["zoneId"] = "",
					["pvptalent"] = {
						["multi"] = {
						},
					},
					["class"] = {
						["multi"] = {
						},
					},
					["faction"] = {
						["multi"] = {
						},
					},
					["level_operator"] = ">=",
					["use_size"] = true,
				},
				["sparkBlendMode"] = "ADD",
				["backdropColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0.5, -- [4]
				},
				["auto"] = true,
				["id"] = "쐐기 : 광역기",
				["semver"] = "1.0.87",
				["spark"] = true,
				["zoom"] = 0,
				["smoothProgress"] = false,
				["useAdjustededMin"] = false,
				["regionType"] = "aurabar",
				["borderInFront"] = false,
				["backgroundColor"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					0.5, -- [4]
				},
				["icon_side"] = "LEFT",
				["sparkRotationMode"] = "AUTO",
				["config"] = {
				},
				["sparkHeight"] = 100,
				["texture"] = "Raven White",
				["sparkOffsetX"] = 0,
				["sparkTexture"] = "Legionfall_BarSpark",
				["justify"] = "LEFT",
				["tocversion"] = 80205,
				["sparkHidden"] = "BOTH",
				["useAdjustededMax"] = false,
				["frameStrata"] = 1,
				["width"] = 649.00036621094,
				["desaturate"] = false,
				["uid"] = "k9HarAIO8z(",
				["inverse"] = true,
				["sparkDesature"] = false,
				["orientation"] = "HORIZONTAL",
				["conditions"] = {
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = 1,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["trigger"] = 4,
									["variable"] = "show",
									["value"] = 1,
								}, -- [2]
								{
									["trigger"] = 8,
									["variable"] = "show",
									["value"] = 1,
								}, -- [3]
								{
									["trigger"] = 11,
									["variable"] = "show",
									["value"] = 1,
								}, -- [4]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\wolf5.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [1]
						},
					}, -- [1]
					{
						["check"] = {
							["trigger"] = -2,
							["variable"] = "OR",
							["checks"] = {
								{
									["trigger"] = 3,
									["variable"] = "show",
									["value"] = 1,
								}, -- [1]
								{
									["trigger"] = 5,
									["variable"] = "show",
									["value"] = 1,
								}, -- [2]
							},
						},
						["changes"] = {
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\Addons\\WeakAuras\\PowerAurasMedia\\Sounds\\ESPARK1.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [1]
						},
					}, -- [2]
					{
						["check"] = {
							["trigger"] = 6,
							["variable"] = "show",
							["value"] = 1,
						},
						["changes"] = {
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Sound\\Spells\\SimonGame_Visual_GameStart.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [1]
							{
								["value"] = {
									0, -- [1]
									1, -- [2]
									0.9921568627451, -- [3]
									1, -- [4]
								},
								["property"] = "barColor",
							}, -- [2]
						},
					}, -- [3]
					{
						["check"] = {
							["trigger"] = 10,
							["variable"] = "show",
							["value"] = 1,
						},
						["changes"] = {
							{
								["value"] = {
									["sound_type"] = "Play",
									["sound"] = "Interface\\AddOns\\WeakAuras\\Media\\Sounds\\Torch.ogg",
									["sound_channel"] = "Master",
								},
								["property"] = "sound",
							}, -- [1]
						},
					}, -- [4]
				},
				["parent"] = "쐐기 : 기타 0929",
				["sparkWidth"] = 10,
			},
		},
		["7Nzr50egfUe"] = {
			["skippedVersions"] = {
			},
			["source"] = "import",
			["lastUpdate"] = 1569852505,
			["allowUpdates"] = true,
			["data"] = {
				["glow"] = false,
				["authorOptions"] = {
				},
				["yOffset"] = 0,
				["anchorPoint"] = "CENTER",
				["cooldownSwipe"] = true,
				["customTextUpdate"] = "update",
				["url"] = "https://wago.io/fCabQ-hF8/88",
				["actions"] = {
					["start"] = {
						["message_type"] = "YELL",
						["message"] = "%n",
						["do_message"] = true,
						["do_sound"] = false,
					},
					["init"] = {
						["custom"] = "aura_env.Status = {}\naura_env.LocalS = {\n    [\"세스랄리스 사원\"] = {\n        [268993] = {\"기절\"}, -- 비열한 습격, 가려진 송곳니\n        [269970] = {\"실명\"}, -- 실명의 모래, 메레크타\n        [263958] = {\"기절\"} -- 뱀들의 똬리, 메레크타\n    },\n    [\"썩은굴\"] = {\n        [265377] = {\"속박\"} -- 갈고리 올가미, 광신적인 인간사냥꾼\n    },\n    [\"아탈다자르\"] = {\n        [255421] = {\"먹힘\"}, -- 집어삼키기, 레잔\n        [252692] = {\"기절\"}, -- 급습 찌르기, 그림자칼날 추적자\n        [255567] = {\"기절\"} -- 광포한 돌진, 트론자 \n    },\n    [\"왕들의 안식처\"] = {\n        [270003] = {\"기절\"}, -- 억제의 강타, 살아 움직이는 수호자\n        [268796] = {\"기절\"} -- 꿰뚫는 창, 왕 다자르\n    },\n    [\"왕노다지 광산!!\"] = {\n        [257371] = {\"실명\"}, -- 최루 가스, 기계화 평화감시단\n        [275907] = {\"기절\"} -- 지층 강타, 아제로크\n    },\n    [\"보랄러스 공성전\"] = {\n        [257069] = {\"기절\"}, -- 방수 껍질, 쿨 티란 파도지기/무쇠파도 물결구체자\n        [257292] = {\"기절\"}, -- 묵직한 베기, 쿨 티란 선봉대원\n        [279763] = {\"기절\"}, \n        [272874] = {\"기절\"}, -- 짓밟기, 애쉬베인 지휘관 \n        [256866] = {\"기절\"}, -- 강철 매복, 성난파도 파쇄꾼\n        [256897] = {\"속박\"}, -- 물어뜯는 주둥이, 으르렁거리는 부두사냥개\n        [257169] = {\"공포\"}, -- 공포의 포효, 항만의 시궁쥐단 파괴자\n        [274942] = {\"기절\"}, -- 바나나 광란, 항만의 시궁쥐단 해적단원\n        [270624] = {\"속박\"} -- 분쇄의 포옹, 조이는 공포\n    },\n    [\"톨 다고르\"] = {\n        [258058] = {\"속박\"}, -- 압착, 진흙 게\n        [258054] = {\"기절\"}, -- 바닷물 소용돌이, 바닷물 무쇠턱거북\n        [257119] = {\"기절\"}, -- 모래 함정, 모래 여왕\n        [258313] = {\"침묵\"}, -- 수갑, 애쉬베인 장교, 간수\n        [260067] = {\"기절\"}, -- 흉포한 포식자, 바비 하울리스\n        [256474] = {\"기절\"}, -- 심정지 맹독, 감독관 코르거스\n        [259711] = {\"속박\"} -- 구속, 독방 간수/애쉬베인 감독관\n    },\n    [\"자유지대\"] = {\n        [274400] = {\"기절\"}, -- 결투사 질주, 바다가름 결투사\n        [276061] = {\"기절\"}, -- 바위 투척, 무쇠파도 분쇄자\n        [274516] = {\"기절\"}, -- 미끄러운 거품, 항만의 시궁쥐단 선원\n        [274389] = {\"속박\"}, -- 쥐덫, 야생 덫사냥꾼\n        [258875] = {\"방향 감각 상실\"}, -- 의식상실의 통, 라울\n        [257949] = {\"돼지!\"} -- 미끄러움, 기름칠한 돼지\n    },\n    [\"폭풍의 사원\"] = {\n        [276268] = {\"기절\"}, -- 융기의 강타, 사원 기사단원\n        [268059] = {\"속박\"}, -- 속박의 닻, 파도현자 심령술사   \n        [264526] = {\"속박\"}, -- 심연의 손아귀, 갈고리 촉수\n        [267956] = {\"기절\"} -- 감전, 해파리\n    },\n    [\"웨이크레스트 저택\"] = {\n        [264407] = {\"공포\"}, -- 끔찍한 얼굴, 얼굴 없는 여인\n        [265346] = {\"실명\"}, -- 창백한 응시, 공포날개 까마귀\n        [265407] = {\"침묵\"}, -- 만찬 종, 연회 집사\n        [260926] = {\"현혹\"}, -- 영혼 조작, 자매 솔레나\n        [267907] = {\"기절\"}, -- 영혼 가시, 영혼결속 거한\n        [268202] = {\"기절\"} -- 죽음의 렌즈, 죽음에 물든 노예사냥꾼\n    }\n}\n\naura_env.message = nil",
						["do_custom"] = true,
					},
					["finish"] = {
						["custom"] = "aura_env.message = nil",
						["do_custom"] = true,
					},
				},
				["triggers"] = {
					{
						["trigger"] = {
							["duration"] = "0.15",
							["subeventPrefix"] = "SPELL",
							["customIcon"] = "",
							["debuffType"] = "HELPFUL",
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["buffShowOn"] = "showOnActive",
							["names"] = {
							},
							["event"] = "Chat Message",
							["spellIds"] = {
							},
							["custom"] = "function(event, ...)\n    local _,subevent,_,_,_,_,_,_,destName,_,_,spellID = ...\n    \n    if subevent == \"SPELL_AURA_APPLIED\" and aura_env.Status[spellID] and destName == WeakAuras.me then   \n        aura_env.message = aura_env.Status[spellID][1]\n        return true\n    end\nend",
							["customName"] = "function()\n    return aura_env.message\nend\n\n\n\n\n\n\n\n\n",
							["events"] = "COMBAT_LOG_EVENT_UNFILTERED",
							["unevent"] = "auto",
							["custom_hide"] = "timed",
							["unit"] = "player",
							["custom_type"] = "event",
							["dynamicDuration"] = false,
						},
						["untrigger"] = {
						},
					}, -- [1]
					{
						["trigger"] = {
							["type"] = "custom",
							["custom_type"] = "event",
							["duration"] = "0.15",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["customName"] = "function()\n    return aura_env.message\nend\n\n\n\n\n\n\n\n\n",
							["events"] = "LOSS_OF_CONTROL_ADDED, LOSS_OF_CONTROL_UPDATE",
							["custom"] = "function(event, ...)\n    if event == \"LOSS_OF_CONTROL_ADDED\" then\n        local eventIndex = ...;\n        local locType, spellID, text, iconTexture, startTime, timeRemaining, duration, lockoutSchool, priority, displayType = C_LossOfControl.GetEventInfo(eventIndex);\n        if text == \"차단\" then\n            aura_env.message = \"차단당함\"\n            return true\n        end\n    end\nend\n\n\n\n\n\n\n\n\n\n\n\n",
							["subeventSuffix"] = "_CAST_START",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [2]
					{
						["trigger"] = {
							["type"] = "custom",
							["subeventSuffix"] = "_CAST_START",
							["duration"] = "0.15",
							["event"] = "Health",
							["subeventPrefix"] = "SPELL",
							["events"] = "ZONE_CHANGED_NEW_AREA, PLAYER_ENTERING_WORLD, CHALLENGE_MODE_START",
							["custom"] = "function()\n    \n    local loc = select(1, GetInstanceInfo())\n    \n    if loc then\n        if aura_env.LocalS[loc] then\n            aura_env.Status = aura_env.LocalS[loc]\n        else\n            aura_env.Status = {}   \n        end\n    end\n    \nend\n\n\n\n\n",
							["custom_type"] = "event",
							["custom_hide"] = "timed",
						},
						["untrigger"] = {
						},
					}, -- [3]
					["disjunctive"] = "custom",
					["customTriggerLogic"] = "function(t)\n    return(t[1] or t[2])\nend",
					["activeTriggerMode"] = -10,
				},
				["internalVersion"] = 24,
				["keepAspectRatio"] = false,
				["animation"] = {
					["start"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["main"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
					["finish"] = {
						["type"] = "none",
						["duration_type"] = "seconds",
					},
				},
				["stickyDuration"] = false,
				["glowColor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["version"] = 88,
				["subRegions"] = {
				},
				["height"] = 1,
				["glowLines"] = 8,
				["useglowColor"] = false,
				["glowFrequency"] = 0.25,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0, -- [4]
				},
				["displayIcon"] = 135860,
				["glowType"] = "buttonOverlay",
				["glowThickness"] = 4,
				["desaturate"] = false,
				["selfPoint"] = "CENTER",
				["load"] = {
					["use_effectiveLevel"] = true,
					["use_size"] = true,
					["use_never"] = false,
					["effectiveLevel_operator"] = ">=",
					["spec"] = {
						["multi"] = {
						},
					},
					["effectiveLevel"] = "110",
					["class"] = {
						["multi"] = {
						},
					},
					["level_operator"] = ">=",
					["level"] = "",
					["use_level"] = false,
					["size"] = {
						["single"] = "party",
						["multi"] = {
						},
					},
				},
				["regionType"] = "icon",
				["config"] = {
				},
				["xOffset"] = 0,
				["anchorFrameType"] = "SCREEN",
				["alpha"] = 0,
				["cooldownEdge"] = false,
				["cooldownTextDisabled"] = false,
				["tocversion"] = 80205,
				["semver"] = "1.0.87",
				["zoom"] = 0,
				["auto"] = false,
				["glowScale"] = 1,
				["id"] = "쐐기 : 상태 이상",
				["glowLength"] = 10,
				["frameStrata"] = 1,
				["width"] = 1,
				["glowYOffset"] = 0,
				["uid"] = "7Nzr50egfUe",
				["inverse"] = false,
				["parent"] = "쐐기 : 기타 0929",
				["glowXOffset"] = 0,
				["conditions"] = {
				},
				["icon"] = true,
				["glowBorder"] = false,
			},
		},
	},
	["clearOldHistory"] = 30,
	["registered"] = {
	},
	["dbVersion"] = 24,
	["frame"] = {
		["xOffset"] = -59.665771484375,
		["width"] = 830,
		["height"] = 665,
		["yOffset"] = -307.5003051757813,
	},
	["editor_theme"] = "Monokai",
}
