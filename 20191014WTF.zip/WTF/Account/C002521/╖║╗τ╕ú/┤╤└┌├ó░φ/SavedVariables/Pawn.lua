
PawnOptions = {
	["LastVersion"] = 2.0241,
	["LastPlayerFullName"] = "닌자창고-렉사르",
	["AutoSelectScales"] = true,
	["UpgradeTracking"] = false,
	["LastKeybindingsSet"] = 1,
}
PawnMrRobotScaleProviderOptions = {
	["LastClass"] = "MAGE",
	["LastAdded"] = 1,
}
